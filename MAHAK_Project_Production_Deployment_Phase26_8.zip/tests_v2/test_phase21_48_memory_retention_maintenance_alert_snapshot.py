from __future__ import annotations

from datetime import datetime

from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import (
    MemoryRetentionMaintenanceAlertSnapshot,
    MemoryRetentionMaintenanceRun,
)
from backend_v2.memory.retention_maintenance_alert_persistence import (
    MemoryRetentionMaintenanceAlertSnapshotService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return engine, session_factory()


def _seed(db):
    run_time = datetime(2026, 9, 19, 11, 59, 30)
    db.add(
        MemoryRetentionMaintenanceRun(
            run_id="phase21-48-run",
            status="completed",
            started_at=datetime(2026, 9, 19, 11, 58, 30),
            completed_at=run_time,
            dry_run=False,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=1,
            memory_planned_count=1,
            memory_executed_count=1,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=1,
            memory_would_delete_count=1,
            memory_deleted_count=1,
            history_status="completed",
            history_configured=True,
            history_retention_days=365,
            history_max_delete=500,
            history_candidate_count=0,
            history_would_delete_count=0,
            history_deleted_count=0,
        )
    )
    db.commit()


def test_capture_persists_content_free_snapshot():
    engine, db = _db()
    try:
        _seed(db)
        result = MemoryRetentionMaintenanceAlertSnapshotService(
            db,
            assume_enabled=True,
            stale_after_seconds=60,
        ).capture(now=datetime(2026, 9, 19, 12, 0, 0))
        db.commit()

        assert result.snapshot_id
        assert result.health == "healthy"
        assert result.severity == "none"
        assert result.alert_count == 0
        assert result.alert_codes == ()
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
    finally:
        db.close()
        engine.dispose()


def test_capture_persists_alert_codes_only():
    engine, db = _db()
    try:
        _seed(db)
        # Default disabled mode intentionally creates a system-level warning.
        result = MemoryRetentionMaintenanceAlertSnapshotService(db).capture(
            now=datetime(2026, 9, 19, 12, 0, 0)
        )
        db.commit()
        row = db.get(MemoryRetentionMaintenanceAlertSnapshot, result.snapshot_id)
        assert row is not None
        assert row.alert_codes == "maintenance_disabled"
        assert row.alert_count == 1
        assert not hasattr(row, "message")
        assert not hasattr(row, "value")
        assert not hasattr(row, "user_id")
    finally:
        db.close()
        engine.dispose()


def test_capture_with_injected_session_flushes_without_own_commit():
    engine, db = _db()
    try:
        _seed(db)
        result = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True).capture(
            now=datetime(2026, 9, 19, 12, 0, 0)
        )
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, result.snapshot_id) is not None
        db.rollback()
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 0
    finally:
        db.close()
        engine.dispose()


def test_latest_returns_most_recent_snapshot():
    engine, db = _db()
    try:
        _seed(db)
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True)
        first = service.capture(now=datetime(2026, 9, 19, 11, 59, 50))
        db.commit()
        second = service.capture(now=datetime(2026, 9, 19, 12, 0, 0))
        db.commit()

        latest = service.latest()
        assert latest is not None
        assert latest.snapshot_id == second.snapshot_id
        assert latest.captured_at > first.captured_at
    finally:
        db.close()
        engine.dispose()


def test_capture_uses_persisted_alert_policy_when_opted_in():
    engine, db = _db()
    try:
        _seed(db)
        from backend_v2.memory.retention_maintenance_alert_policy import (
            MemoryRetentionMaintenanceAlertPolicyService,
        )

        MemoryRetentionMaintenanceAlertPolicyService(db).set(stale_after_seconds=60)
        db.commit()
        result = MemoryRetentionMaintenanceAlertSnapshotService(
            db,
            assume_enabled=True,
            use_policy=True,
        ).capture(now=datetime(2026, 9, 19, 12, 0, 0))
        db.commit()
        assert result.use_policy is True
        assert result.stale_after_seconds == 60
    finally:
        db.close()
        engine.dispose()
