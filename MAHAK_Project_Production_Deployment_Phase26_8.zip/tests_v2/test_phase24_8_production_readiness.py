from __future__ import annotations

import json
from pathlib import Path
import sqlite3

import pytest

from backend_v2.operations.backup import BackupError, BackupService
from backend_v2.operations.readiness import check_operational_readiness


def _service(tmp_path: Path) -> BackupService:
    database = tmp_path / "mahak_v2.db"
    connection = sqlite3.connect(database)
    connection.execute("CREATE TABLE items (id INTEGER PRIMARY KEY, value TEXT NOT NULL)")
    connection.execute("INSERT INTO items(value) VALUES ('phase24-8')")
    connection.commit()
    connection.close()
    storage = tmp_path / "storage_v2"
    storage.mkdir()
    (storage / "hello.txt").write_text("operational-state", encoding="utf-8")
    return BackupService(
        database_url=f"sqlite:///{database}",
        storage_dir=storage,
        backup_dir=tmp_path / "backups_v2",
        retention_count=2,
        min_free_space_mb=0,
    )


def test_create_and_verify_backup(tmp_path: Path):
    service = _service(tmp_path)
    archive = service.create_backup(label="test")
    manifest = service.verify_backup(archive)
    assert archive.exists()
    assert manifest.includes_storage is True
    assert manifest.storage_file_count == 1


def test_restore_replaces_database_and_storage(tmp_path: Path):
    service = _service(tmp_path)
    archive = service.create_backup(label="restore")
    service.storage_dir.joinpath("hello.txt").write_text("changed", encoding="utf-8")
    connection = sqlite3.connect(tmp_path / "mahak_v2.db")
    connection.execute("DELETE FROM items")
    connection.commit()
    connection.close()

    manifest = service.restore_backup(archive, overwrite=True, create_pre_restore_backup=False)
    assert manifest.backup_id in archive.name
    assert service.storage_dir.joinpath("hello.txt").read_text(encoding="utf-8") == "operational-state"
    connection = sqlite3.connect(tmp_path / "mahak_v2.db")
    rows = connection.execute("SELECT value FROM items").fetchall()
    connection.close()
    assert rows == [("phase24-8",)]


def test_restore_rejects_nonempty_target_without_force(tmp_path: Path):
    service = _service(tmp_path)
    archive = service.create_backup(label="guard")
    with pytest.raises(BackupError, match="not empty"):
        service.restore_backup(archive)


def test_tampered_archive_fails_verification(tmp_path: Path):
    service = _service(tmp_path)
    archive = service.create_backup(label="tamper")
    import tarfile

    tampered = tmp_path / "tampered.tar.gz"
    with tarfile.open(archive, "r:gz") as source, tarfile.open(tampered, "w:gz") as target:
        for member in source.getmembers():
            extracted = source.extractfile(member)
            if extracted is None:
                continue
            data = extracted.read()
            if member.name == "database/mahak_v2.db":
                data = data + b"tamper"
            import io
            info = tarfile.TarInfo(member.name)
            info.size = len(data)
            target.addfile(info, io.BytesIO(data))
    with pytest.raises(BackupError, match="checksum mismatch"):
        service.verify_backup(tampered)


def test_retention_keeps_only_newest_backups(tmp_path: Path):
    service = _service(tmp_path)
    for label in ("a", "b", "c"):
        service.create_backup(label=label)
    assert len(service.list_backups()) == 2


def test_cli_files_and_production_docs_exist():
    root = Path(__file__).resolve().parents[1]
    assert (root / "scripts/backup_restore_phase24_8.py").exists()
    assert (root / "scripts/ops_readiness_phase24_8.py").exists()
    assert (root / "README_PHASE24_8.md").exists()
    assert (root / "ROADMAP_STATUS_PHASE24_8.md").exists()
    assert (root / ".env.production.example").read_text(encoding="utf-8").find("BACKUP_DIR=") >= 0


def test_compose_mounts_persistent_operational_state():
    text = (Path(__file__).resolve().parents[1] / "compose.yaml").read_text(encoding="utf-8")
    assert "mahak_data:/app/data" in text
    assert "BACKUP_DIR: /app/data/backups_v2" in text
    assert "GRACEFUL_SHUTDOWN_SECONDS" in text


def test_operational_readiness_reports_storage_and_vector_store():
    result = check_operational_readiness()
    assert result.ready is True
    assert result.checks["database"] == "ok"
    assert result.checks["storage"] == "ok"
    assert result.checks["vector_store"] == "ok"
