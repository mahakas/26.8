from __future__ import annotations

from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db):
    rows = [
        MemoryRetentionMaintenanceRun(
            run_id="sum-a",
            status="completed",
            started_at=datetime(2026, 9, 18, 10, 0),
            completed_at=datetime(2026, 9, 18, 10, 1),
            dry_run=False,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=2,
            memory_planned_count=2,
            memory_executed_count=2,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=7,
            memory_would_delete_count=5,
            memory_deleted_count=5,
            history_status="completed",
            history_configured=True,
            history_retention_days=365,
            history_max_delete=500,
            history_candidate_count=4,
            history_would_delete_count=4,
            history_deleted_count=4,
            history_error=None,
        ),
        MemoryRetentionMaintenanceRun(
            run_id="sum-b",
            status="completed_with_errors",
            started_at=datetime(2026, 9, 19, 10, 0),
            completed_at=datetime(2026, 9, 19, 10, 2),
            dry_run=True,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=1,
            memory_planned_count=1,
            memory_executed_count=0,
            memory_skipped_count=1,
            memory_failed_count=0,
            memory_candidate_count=3,
            memory_would_delete_count=2,
            memory_deleted_count=0,
            history_status="failed",
            history_configured=True,
            history_retention_days=180,
            history_max_delete=200,
            history_candidate_count=6,
            history_would_delete_count=6,
            history_deleted_count=0,
            history_error="history cleanup failed",
        ),
        MemoryRetentionMaintenanceRun(
            run_id="sum-c",
            status="completed",
            started_at=datetime(2026, 9, 20, 10, 0),
            completed_at=datetime(2026, 9, 20, 10, 1),
            dry_run=True,
            cleanup_history=False,
            memory_status="completed",
            memory_user_count=0,
            memory_planned_count=0,
            memory_executed_count=0,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=0,
            memory_would_delete_count=0,
            memory_deleted_count=0,
            history_status=None,
            history_configured=None,
            history_retention_days=None,
            history_max_delete=None,
            history_candidate_count=None,
            history_would_delete_count=None,
            history_deleted_count=None,
            history_error=None,
        ),
    ]
    db.add_all(rows)
    db.commit()


def test_unified_history_summary_is_read_only_and_aggregated():
    client, db, engine = _client()
    try:
        _seed(db)
        before_count = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        response = client.get("/api/memory/maintenance/runs/summary")
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 3
        assert payload["completed_run_count"] == 2
        assert payload["completed_with_errors_run_count"] == 1
        assert payload["dry_run_count"] == 2
        assert payload["cleanup_history_count"] == 2
        assert payload["configured_history_count"] == 2
        assert payload["memory_candidate_count"] == 10
        assert payload["memory_would_delete_count"] == 7
        assert payload["memory_deleted_count"] == 5
        assert payload["history_candidate_count"] == 10
        assert payload["history_would_delete_count"] == 10
        assert payload["history_deleted_count"] == 4
        assert payload["history_error_count"] == 1
        assert payload["read_only"] is True
        assert payload["first_started_at"] == "2026-09-18T10:00:00"
        assert payload["last_completed_at"] == "2026-09-20T10:01:00"
        after_count = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        assert after_count == before_count
        assert "user_id" not in payload
        assert "value" not in payload
    finally:
        db.close()
        engine.dispose()


def test_unified_history_summary_filters_work():
    client, db, engine = _client()
    try:
        _seed(db)
        response = client.get(
            "/api/memory/maintenance/runs/summary",
            params={"dry_run": "true", "cleanup_history": "true"},
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 1
        assert payload["dry_run_count"] == 1
        assert payload["memory_candidate_count"] == 3

        response = client.get(
            "/api/memory/maintenance/runs/summary",
            params={
                "start_at": "2026-09-19T00:00:00Z",
                "end_at": "2026-09-21T00:00:00Z",
            },
        )
        assert response.status_code == 200
        assert response.json()["run_count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_unified_history_summary_rejects_invalid_status_and_range():
    client, db, engine = _client()
    try:
        bad_status = client.get(
            "/api/memory/maintenance/runs/summary",
            params={"status": "disabled"},
        )
        assert bad_status.status_code == 422

        bad_range = client.get(
            "/api/memory/maintenance/runs/summary",
            params={
                "start_at": "2026-09-20T00:00:00Z",
                "end_at": "2026-09-19T00:00:00Z",
            },
        )
        assert bad_range.status_code == 422
    finally:
        db.close()
        engine.dispose()
