from __future__ import annotations

from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed_runs(db):
    service = MemoryRetentionMaintenanceService(db, enabled=True)
    service.run_with_report(
        user_ids=[],
        now=datetime(2026, 9, 19, 10, 0, tzinfo=UTC),
        dry_run=True,
        cleanup_history=False,
    )
    service.run_with_report(
        user_ids=[],
        now=datetime(2026, 9, 19, 11, 0, tzinfo=UTC),
        dry_run=False,
        cleanup_history=True,
    )
    db.commit()


def test_unified_history_is_read_only_and_content_free():
    client, db, engine = _client()
    try:
        _seed_runs(db)
        before_count = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        response = client.get("/api/memory/maintenance/runs")
        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 2
        item = payload["items"][0]
        assert item["run_id"]
        assert item["dry_run"] is False
        assert "value" not in item
        assert "memory_key" not in item
        assert "user_id" not in item
        after_count = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        assert after_count == before_count
        assert payload["read_only"] is True
    finally:
        db.close()
        engine.dispose()


def test_unified_history_cursor_paginates_without_gaps():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceService(db, enabled=True)
        for hour in (10, 11, 12):
            service.run_with_report(
                user_ids=[],
                now=datetime(2026, 9, 19, hour, 0, tzinfo=UTC),
                dry_run=True,
                cleanup_history=False,
            )
        db.commit()
        seen = []
        cursor = None
        counts = []
        while True:
            params = {"limit": 2}
            if cursor:
                params["cursor"] = cursor
            response = client.get("/api/memory/maintenance/runs", params=params)
            assert response.status_code == 200
            payload = response.json()
            counts.append(payload["count"])
            seen.extend(item["run_id"] for item in payload["items"])
            cursor = payload["next_cursor"]
            if not cursor:
                break
        assert counts == [2, 1]
        assert len(seen) == 3
        assert len(set(seen)) == 3
    finally:
        db.close()
        engine.dispose()


def test_unified_history_filters_work():
    client, db, engine = _client()
    try:
        _seed_runs(db)
        dry = client.get(
            "/api/memory/maintenance/runs",
            params={"dry_run": "true", "cleanup_history": "false"},
        )
        assert dry.status_code == 200
        assert dry.json()["count"] == 1

        execute = client.get(
            "/api/memory/maintenance/runs",
            params={"dry_run": "false", "cleanup_history": "true"},
        )
        assert execute.status_code == 200
        assert execute.json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_unified_history_rejects_invalid_cursor_status_and_time_range():
    client, db, engine = _client()
    try:
        bad_cursor = client.get(
            "/api/memory/maintenance/runs",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert bad_cursor.status_code == 422

        bad_status = client.get(
            "/api/memory/maintenance/runs",
            params={"status": "disabled"},
        )
        assert bad_status.status_code == 422

        bad_range = client.get(
            "/api/memory/maintenance/runs",
            params={
                "start_at": "2026-09-20T00:00:00Z",
                "end_at": "2026-09-19T00:00:00Z",
            },
        )
        assert bad_range.status_code == 422
    finally:
        db.close()
        engine.dispose()
