from __future__ import annotations

from unittest.mock import patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.repositories.memory import MemoryRepository
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryRecord, MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _record(user_id: str, key: str, value: str) -> MemoryRecord:
    return MemoryRecord(
        id=f"snapshot-{key}-{value}",
        user_id=user_id,
        memory_type=MemoryType.PREVIOUS_QUESTION,
        memory_key=key,
        value={"question": value},
        confidence=1.0,
        source="snapshot",
    )


def test_import_batch_rolls_back_when_repository_fails_mid_restore():
    db, engine = _db()
    try:
        service = MemoryService(db)
        records = [_record("atomic-user", "q1", "one"), _record("atomic-user", "q2", "two")]
        real_create = MemoryRepository.create
        calls = {"count": 0}

        def failing_create(self, **kwargs):
            calls["count"] += 1
            if calls["count"] == 2:
                raise RuntimeError("simulated persistence failure")
            return real_create(self, **kwargs)

        with patch.object(MemoryRepository, "create", failing_create):
            with pytest.raises(RuntimeError, match="simulated persistence failure"):
                service.import_records_with_conflicts("atomic-user", records)

        assert service.list("atomic-user") == []
    finally:
        db.close()
        engine.dispose()


def test_successful_restore_commits_all_records_after_savepoint():
    db, engine = _db()
    try:
        service = MemoryService(db)
        records = [_record("atomic-success", "q1", "one"), _record("atomic-success", "q2", "two")]
        imported, skipped, conflicts = service.import_records_with_conflicts(
            "atomic-success", records
        )

        assert (imported, skipped, conflicts) == (2, 0, 0)
        assert len(service.list("atomic-success")) == 2
    finally:
        db.close()
        engine.dispose()


def test_reject_policy_remains_atomic_and_reports_conflicts_without_writes():
    db, engine = _db()
    try:
        service = MemoryService(db)
        service.remember(
            user_id="atomic-reject",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"grade": "10"},
        )
        records = [
            MemoryRecord(
                id="a",
                user_id="atomic-reject",
                memory_type=MemoryType.STUDENT_PROFILE,
                memory_key="profile",
                value={"grade": "11"},
                confidence=1.0,
                source="snapshot",
            ),
            _record("atomic-reject", "new", "question"),
        ]

        imported, skipped, conflicts = service.import_records_with_conflicts(
            "atomic-reject", records,
            conflict_policy="reject",
        )
        assert (imported, skipped, conflicts) == (0, 0, 1)
        assert len(service.list("atomic-reject")) == 1
    finally:
        db.close()
        engine.dispose()
