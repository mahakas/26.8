from backend_v2.core.enums import Capability
from backend_v2.education import (
    EducationalContentGenerator,
    EducationalQuestionType,
    EducationalTaskPlanner,
    EducationalTaskPlanningRequest,
)
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.vectorstores.base import VectorHit


def _orchestrator(handler):
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            "test-structured",
            {Capability.STRUCTURED_OUTPUT, Capability.CHAT},
            default_model="test-model",
            handler=handler,
        ),
        priority=1,
    )
    return ProviderOrchestrator(registry, ProviderHealthManager(), max_attempts=1)


def _plan():
    return EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            task_type="quiz",
            difficulty="medium",
            question_count=2,
            topic="قانون دوم نیوتن",
        )
    )


def _hits():
    return [
        VectorHit(
            id="h1",
            document="نیرو برابر جرم ضربدر شتاب است.",
            score=0.81,
            metadata={"source_id": "src-1", "title": "فیزیک دهم", "page": 12},
        )
    ]


def test_generation_parses_structured_output_and_binds_sources():
    def handler(payload):
        return '{"items":[{"item_id":"q1","question_type":"multiple_choice","question":"کدام رابطه درست است؟","options":["F=ma","F=m/a"],"correct_answer":"F=ma","explanation":"رابطه در منبع آمده است.","difficulty":"medium","topic":"قانون دوم نیوتن","source_refs":[1]},{"item_id":"q2","question_type":"short_answer","question":"شتاب چه ارتباطی با نیرو دارد؟","options":[],"correct_answer":"با نیرو نسبت مستقیم دارد.","explanation":"پاسخ از منبع است.","difficulty":"medium","topic":"قانون دوم نیوتن","source_refs":[1]}]}'

    result = EducationalContentGenerator(_orchestrator(handler)).generate(_plan(), _hits())

    assert result.generated is True
    assert len(result.items) == 2
    assert result.items[0].question_type is EducationalQuestionType.MULTIPLE_CHOICE
    assert result.items[0].source_refs == (1,)
    assert result.citations[0].page == 12


def test_generation_rejects_missing_source_reference():
    def handler(payload):
        return '{"items":[{"item_id":"q1","question_type":"short_answer","question":"سؤال","options":[],"correct_answer":"پاسخ","explanation":"توضیح","difficulty":"medium","topic":"قانون","source_refs":[]}]}'

    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(question_count=1, topic="قانون")
    )
    try:
        EducationalContentGenerator(_orchestrator(handler)).generate(plan, _hits())
    except ValueError as exc:
        assert "source" in str(exc)
    else:
        raise AssertionError("Expected missing source reference validation error")


def test_generation_returns_closed_world_result_without_sources():
    result = EducationalContentGenerator(_orchestrator(lambda payload: "unused")).generate(_plan(), [])
    assert result.generated is False
    assert result.items == ()
    assert result.reasons == ("no_supported_sources",)


def test_generation_rejects_wrong_question_count():
    def handler(payload):
        return '{"items":[{"item_id":"q1","question_type":"short_answer","question":"سؤال","options":[],"correct_answer":"پاسخ","explanation":"توضیح","difficulty":"medium","topic":"قانون","source_refs":[1]}]}'

    try:
        EducationalContentGenerator(_orchestrator(handler)).generate(_plan(), _hits())
    except ValueError as exc:
        assert "Expected 2 generated items" in str(exc)
    else:
        raise AssertionError("Expected question-count validation error")


def test_generation_supports_code_fenced_json():
    def handler(payload):
        return '```json\n{"items":[{"item_id":"q1","question_type":"true_false","question":"F=ma است؟","options":["صحیح","غلط"],"correct_answer":"صحیح","explanation":"منبع رابطه را بیان می‌کند.","difficulty":"medium","topic":"قانون دوم نیوتن","source_refs":[1]},{"item_id":"q2","question_type":"true_false","question":"شتاب مستقل از نیرو است؟","options":["صحیح","غلط"],"correct_answer":"غلط","explanation":"منبع وابستگی نیرو و شتاب را بیان می‌کند.","difficulty":"medium","topic":"قانون دوم نیوتن","source_refs":[1]}]}\n```'

    result = EducationalContentGenerator(_orchestrator(handler)).generate(_plan(), _hits())
    assert len(result.items) == 2
    assert result.items[0].question_type is EducationalQuestionType.TRUE_FALSE


def test_generate_endpoint_binds_retrieval_and_returns_schema(monkeypatch):
    from backend_v2.api import education as education_api
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    from backend_v2.retrieval.service import RetrievalResult

    class FakeEmbedding:
        pass

    class FakeStore:
        pass

    class FakeRuntime:
        vector_store = FakeStore()
        embedding = FakeEmbedding()
        llm_orchestrator = _orchestrator(
            lambda payload: '{"items":[{"item_id":"q1","question_type":"short_answer","question":"نیرو چیست؟","options":[],"correct_answer":"کمیتی که می‌تواند شتاب ایجاد کند.","explanation":"این تعریف از منبع آمده است.","difficulty":"medium","topic":"قانون دوم نیوتن","source_refs":[1]}]}'
        )

    class FakeRetrievalService:
        def __init__(self, *args, **kwargs):
            pass

        def retrieve(self, request):
            return RetrievalResult(
                accepted=_hits(),
                rejected=[],
                embedding_provider="test",
                embedding_model="test",
                embedding_dimension=8,
                filters={},
            )

    monkeypatch.setattr(education_api, "runtime", FakeRuntime())
    monkeypatch.setattr(education_api, "RetrievalService", FakeRetrievalService)
    client = TestClient(create_app())

    response = client.post(
        "/api/education/tasks/generate",
        json={
            "task_type": "quiz",
            "difficulty": "medium",
            "question_count": 1,
            "topic": "قانون دوم نیوتن",
        },
    )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["generated"] is True
    assert len(body["items"]) == 1
    assert body["items"][0]["source_refs"] == [1]
    assert body["citations"][0]["page"] == 12
    assert body["plan"]["content_generation"] == "phase22_2"


def test_generate_endpoint_returns_closed_world_empty_result_without_hits(monkeypatch):
    from backend_v2.api import education as education_api
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    from backend_v2.retrieval.service import RetrievalResult

    class FakeEmbedding:
        pass

    class FakeStore:
        pass

    class FakeRuntime:
        vector_store = FakeStore()
        embedding = FakeEmbedding()
        llm_orchestrator = _orchestrator(lambda payload: "unused")

    class EmptyRetrievalService:
        def __init__(self, *args, **kwargs):
            pass

        def retrieve(self, request):
            return RetrievalResult([], [], "test", "test", 8, {})

    monkeypatch.setattr(education_api, "runtime", FakeRuntime())
    monkeypatch.setattr(education_api, "RetrievalService", EmptyRetrievalService)
    client = TestClient(create_app())

    response = client.post(
        "/api/education/tasks/generate",
        json={
            "task_type": "quiz",
            "difficulty": "medium",
            "question_count": 2,
            "topic": "مبحث بدون منبع",
        },
    )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["generated"] is False
    assert body["items"] == []
    assert body["reasons"] == ["no_supported_sources"]
