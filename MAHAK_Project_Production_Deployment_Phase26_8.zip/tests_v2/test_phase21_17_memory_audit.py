from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.repositories.memory_audit import MemoryAuditRepository
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _import_payload(user_id: str, key: str = "q:1") -> dict:
    return {
        "user_id": user_id,
        "format_version": "1.0",
        "records": [
            {
                "user_id": user_id,
                "memory_type": "previous_question",
                "memory_key": key,
                "value": {"question": "2+2?"},
                "confidence": 1.0,
                "source": "snapshot",
            }
        ],
    }


def test_delete_clear_prune_and_import_create_non_content_audit_events():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="audit-user",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra"},
        )
        memory.remember(
            user_id="audit-user",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:2",
            value={"topic": "geometry"},
        )
        db.commit()

        rows = client.get("/api/memory/audit-user/records").json()["items"]
        first_id = rows[0]["id"]
        assert client.delete(f"/api/memory/audit-user/records/{first_id}").status_code == 200

        assert client.delete(
            "/api/memory/audit-user/records",
            params={"memory_type": "learning_history"},
        ).status_code == 200

        memory.remember(
            user_id="audit-user",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:3",
            value={"topic": "physics"},
        )
        memory.remember(
            user_id="audit-user",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:4",
            value={"topic": "chemistry"},
        )
        db.commit()
        assert client.post(
            "/api/memory/audit-user/prune",
            params={"max_records": 1, "memory_type": "learning_history"},
        ).status_code == 200

        response = client.post("/api/memory/audit-user/import", json=_import_payload("audit-user"))
        assert response.status_code == 201

        audit = client.get("/api/memory/audit-user/audit")
        assert audit.status_code == 200
        actions = [item["action"] for item in audit.json()["items"]]
        assert actions[:4] == ["import", "prune", "clear", "delete"]
        assert all("value" not in item for item in audit.json()["items"])
    finally:
        db.close()
        engine.dispose()


def test_audit_is_user_scoped_and_supports_action_filter():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        row_a = memory.remember(
            user_id="audit-a",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:a",
            value={"question": "A"},
        )
        memory.remember(
            user_id="audit-b",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:b",
            value={"question": "B"},
        )
        db.commit()

        assert client.delete(f"/api/memory/audit-a/records/{row_a.id}").status_code == 200
        assert client.delete("/api/memory/audit-b/records").json()["deleted_count"] == 1

        audit_a = client.get("/api/memory/audit-a/audit").json()
        assert audit_a["count"] == 1
        assert audit_a["items"][0]["action"] == "delete"

        filtered = client.get("/api/memory/audit-b/audit", params={"action": "clear"})
        assert filtered.status_code == 200
        assert filtered.json()["count"] == 1
        assert filtered.json()["items"][0]["action"] == "clear"

        cross = client.get("/api/memory/audit-a/audit", params={"action": "clear"})
        assert cross.json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_import_audit_contains_counts_policy_checksum_but_not_memory_content():
    client, db, engine = _client()
    try:
        payload = _import_payload("audit-import", "q:import")
        preview = client.post("/api/memory/audit-import/import/preview", json=payload)
        assert preview.status_code == 200
        payload["checksum"] = preview.json()["checksum"]
        payload["conflict_policy"] = "skip"

        imported = client.post("/api/memory/audit-import/import", json=payload)
        assert imported.status_code == 201
        audit = client.get("/api/memory/audit-import/audit", params={"action": "import"})
        item = audit.json()["items"][0]
        assert item["action"] == "import"
        assert item["affected_count"] == 1
        assert item["skipped_count"] == 0
        assert item["conflict_count"] == 0
        assert item["format_version"] == "1.0"
        assert item["conflict_policy"] == "skip"
        assert item["checksum"] == preview.json()["checksum"]
        assert "question" not in str(item)
    finally:
        db.close()
        engine.dispose()


def test_rejected_import_does_not_create_success_audit_event():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="audit-reject",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"grade": "10"},
        )
        db.commit()

        payload = {
            "user_id": "audit-reject",
            "format_version": "1.0",
            "conflict_policy": "reject",
            "records": [
                {
                    "user_id": "audit-reject",
                    "memory_type": "student_profile",
                    "memory_key": "profile",
                    "value": {"grade": "11"},
                    "confidence": 1.0,
                    "source": "snapshot",
                }
            ],
        }
        response = client.post("/api/memory/audit-reject/import", json=payload)
        assert response.status_code == 409
        audit = client.get("/api/memory/audit-reject/audit", params={"action": "import"})
        assert audit.status_code == 200
        assert audit.json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_memory_audit_repository_rejects_unknown_action():
    client, db, engine = _client()
    try:
        repository = MemoryAuditRepository(db)
        try:
            repository.create(user_id="audit-invalid", action="export")
        except ValueError as exc:
            assert "Unsupported memory audit action" in str(exc)
        else:
            raise AssertionError("unsupported action should fail")
    finally:
        db.close()
        engine.dispose()
