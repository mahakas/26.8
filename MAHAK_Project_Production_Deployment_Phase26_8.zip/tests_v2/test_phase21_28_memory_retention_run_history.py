from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryRetentionRun, MemoryRetentionRunResult
from backend_v2.database.repositories import MemoryRetentionRunRepository
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return session, engine


def _seed(db, user_id: str, *, days_old: int = 60) -> None:
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add(
        LearningMemory(
            user_id=user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION.value,
            memory_key="old",
            value_json={"q": "old"},
            created_at=now - timedelta(days=days_old),
            updated_at=now - timedelta(days=days_old),
        )
    )
    db.commit()


def test_scheduler_persists_run_and_per_user_results():
    db, engine = _db()
    try:
        _seed(db, "history-a")
        MemoryRetentionPolicyService(db).set(
            "history-a",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["history-a"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        run = db.get(MemoryRetentionRun, report.run_id)
        rows = MemoryRetentionRunRepository(db).list_results(report.run_id)
        assert run is not None
        assert run.status == "completed"
        assert run.deleted_count == 1
        assert len(rows) == 1
        assert rows[0].user_id == "history-a"
        assert rows[0].deleted_count == 1
    finally:
        db.close()
        engine.dispose()


def test_dry_run_persists_metadata_without_memory_audit_or_deletion():
    db, engine = _db()
    try:
        _seed(db, "history-dry")
        MemoryRetentionPolicyService(db).set(
            "history-dry",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["history-dry"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        assert report.dry_run is True
        assert report.would_delete_count == 1
        assert report.deleted_count == 0
        assert db.scalar(select(LearningMemory).where(LearningMemory.user_id == "history-dry")) is not None
        assert db.scalar(select(MemoryRetentionRunResult).where(MemoryRetentionRunResult.run_id == report.run_id)) is not None
    finally:
        db.close()
        engine.dispose()


def test_disabled_scheduler_does_not_persist_history():
    db, engine = _db()
    try:
        report = MemoryRetentionSchedulerService(db, enabled=False).run_with_report(user_ids=["disabled"])
        assert report.status == "disabled"
        assert db.scalar(select(MemoryRetentionRun).where(MemoryRetentionRun.run_id == report.run_id)) is None
    finally:
        db.close()
        engine.dispose()


def test_failed_user_is_persisted_without_hiding_other_user_success():
    db, engine = _db()
    try:
        _seed(db, "history-good")
        MemoryRetentionPolicyService(db).set(
            "history-good",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        from backend_v2.database.models import MemoryRetentionPolicy
        db.add(
            MemoryRetentionPolicy(
                user_id="history-bad",
                retention_days=30,
                max_delete=1,
                memory_type="invalid-type",
            )
        )
        db.commit()
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["history-bad", "history-good"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        rows = MemoryRetentionRunRepository(db).list_results(report.run_id)
        assert report.status == "completed_with_errors"
        assert {row.status for row in rows} == {"failed", "executed"}
        assert len(rows) == 2
        assert sum(row.deleted_count for row in rows) == 1
    finally:
        db.close()
        engine.dispose()
