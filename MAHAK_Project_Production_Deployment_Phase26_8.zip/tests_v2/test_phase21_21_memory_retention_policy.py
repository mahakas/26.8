from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionPolicy


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def test_policy_get_returns_safe_defaults_without_persisting():
    client, db, engine = _client()
    try:
        response = client.get("/api/memory/policy-user/retention/policy")
        assert response.status_code == 200
        assert response.json() == {
            "user_id": "policy-user",
            "retention_days": 365,
            "max_delete": 500,
            "memory_type": None,
            "configured": False,
        }
        assert db.query(MemoryRetentionPolicy).count() == 0
    finally:
        db.close()
        engine.dispose()


def test_policy_put_persists_and_is_user_scoped():
    client, db, engine = _client()
    try:
        response = client.put(
            "/api/memory/policy-user/retention/policy",
            json={"retention_days": 90, "max_delete": 25, "memory_type": "weak_area"},
        )
        assert response.status_code == 200
        assert response.json()["configured"] is True
        assert response.json()["retention_days"] == 90
        assert response.json()["max_delete"] == 25
        assert response.json()["memory_type"] == "weak_area"

        second = client.get("/api/memory/policy-user/retention/policy")
        assert second.status_code == 200
        assert second.json()["retention_days"] == 90
        assert second.json()["max_delete"] == 25
        assert second.json()["memory_type"] == "weak_area"

        other = client.get("/api/memory/other-user/retention/policy")
        assert other.status_code == 200
        assert other.json()["configured"] is False
    finally:
        db.close()
        engine.dispose()


def test_policy_put_rejects_invalid_values():
    client, db, engine = _client()
    try:
        assert client.put(
            "/api/memory/user/retention/policy",
            json={"retention_days": 0, "max_delete": 500},
        ).status_code == 422
        assert client.put(
            "/api/memory/user/retention/policy",
            json={"retention_days": 365, "max_delete": 501},
        ).status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_policy_delete_resets_to_defaults_and_is_idempotent():
    client, db, engine = _client()
    try:
        client.put(
            "/api/memory/reset-user/retention/policy",
            json={"retention_days": 30, "max_delete": 10, "memory_type": "previous_question"},
        )
        response = client.delete("/api/memory/reset-user/retention/policy")
        assert response.status_code == 200
        assert response.json() == {
            "user_id": "reset-user",
            "retention_days": 365,
            "max_delete": 500,
            "memory_type": None,
            "configured": False,
        }
        second = client.delete("/api/memory/reset-user/retention/policy")
        assert second.status_code == 200
        assert second.json()["configured"] is False
    finally:
        db.close()
        engine.dispose()


def test_policy_does_not_change_explicit_retention_contract():
    client, db, engine = _client()
    try:
        client.put(
            "/api/memory/contract-user/retention/policy",
            json={"retention_days": 7, "max_delete": 1},
        )
        response = client.post(
            "/api/memory/contract-user/retention/preview",
            params={"older_than": "2026-01-05T00:00:00Z", "max_delete": 1},
        )
        assert response.status_code == 200
        assert response.json()["max_delete"] == 1
    finally:
        db.close()
        engine.dispose()
