from pathlib import Path

import pytest

from backend_v2.core.enums import Capability
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import (
    OpenCVFrameSampler,
    SidecarTranscript,
    TranscriptSegment,
    VideoProcessor,
)


class FakeVision:
    def execute(self, capability, payload, *, metadata=None):
        class R:
            class Resp:
                output = "این فریم آموزشی شامل رابطه F = ma است."
                provider = "vision-test"
                model = "vision-v1"
            response = Resp()
        return R()


class FakeTranscriber:
    def transcribe(self, path: Path):
        return [TranscriptSegment(2.0, 4.0, "قانون دوم نیوتن: F = ma.")]


def test_opencv_sampler_is_ffmpeg_free_and_extracts_frames(tmp_path):
    cv2 = pytest.importorskip("cv2")
    video = tmp_path / "clip.mp4"
    writer = cv2.VideoWriter(str(video), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (160, 90))
    if not writer.isOpened():
        pytest.skip("OpenCV MP4 writer unavailable in this environment")
    for _ in range(30):
        writer.write((255 * __import__('numpy').ones((90, 160, 3), dtype='uint8')))
    writer.release()
    sampler = OpenCVFrameSampler(interval_seconds=1.0, max_frames=3)
    frames = sampler.sample(video, tmp_path / "frames")
    assert frames
    assert all(frame.path.exists() for frame in frames)
    assert frames[0].timestamp == 0.0


def test_phase18b_processor_combines_transcript_and_vision(tmp_path):
    cv2 = pytest.importorskip("cv2")
    video = tmp_path / "clip.mp4"
    writer = cv2.VideoWriter(str(video), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (160, 90))
    if not writer.isOpened():
        pytest.skip("OpenCV MP4 writer unavailable in this environment")
    import numpy as np
    for _ in range(30):
        writer.write(np.zeros((90, 160, 3), dtype=np.uint8))
    writer.release()
    processor = VideoProcessor(
        FakeVision(),
        transcriber=FakeTranscriber(),
        frame_sampler=OpenCVFrameSampler(interval_seconds=1.0, max_frames=2),
        frame_output_dir=tmp_path / "frames",
        vision_enabled=True,
    )
    result = IngestionPipeline(video_processor=processor, chunk_size=500, overlap=50).process(video)
    kinds = {chunk.metadata.get("kind") for chunk in result.chunks}
    assert "transcript" in kinds
    assert "frame" in kinds
    assert result.document.metadata["frame_backend"] == "OpenCVFrameSampler"
    assert result.document.metadata["transcription_backend"] == "FakeTranscriber"
    assert result.required_capabilities == frozenset()


def test_video_processor_keeps_capabilities_if_no_vision_transcription_result(tmp_path):
    video = tmp_path / "lesson.mp4"
    video.write_bytes(b"not-video")
    processor = VideoProcessor(None, transcriber=None, frame_sampler=type("NoFrames", (), {"sample": lambda *_a, **_k: []})(), vision_enabled=False)
    result = IngestionPipeline(video_processor=processor).process(video)
    assert Capability.TRANSCRIPTION in result.analysis.requires or result.required_capabilities

def test_phase18b_live_script_compiles():
    import py_compile
    py_compile.compile('scripts/live_video_smoke_phase18b.py', doraise=True)
