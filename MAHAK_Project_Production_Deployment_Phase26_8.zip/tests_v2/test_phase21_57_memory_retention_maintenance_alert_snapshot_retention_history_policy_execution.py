from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
)
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_run(db, run_id: str, completed_at: datetime) -> None:
    db.add(
        MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
            run_id=run_id,
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            older_than=completed_at - timedelta(days=30),
            retention_days=30,
            max_delete=500,
            configured=True,
            preview_bound=False,
            candidate_count=1,
            deleted_count=1,
        )
    )
    db.commit()


def test_policy_preview_uses_effective_defaults_and_is_read_only():
    db, engine = _db()
    try:
        old = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=400)
        _seed_run(db, "default-old", old)
        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).preview_policy()
        assert preview.configured is False
        assert preview.retention_days == 365
        assert preview.max_delete == 500
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert preview.read_only is True
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "default-old") is not None
    finally:
        db.close()
        engine.dispose()


def test_policy_preview_uses_persisted_policy():
    db, engine = _db()
    try:
        _seed_run(
            db,
            "policy-old",
            datetime.now(UTC).replace(tzinfo=None) - timedelta(days=20),
        )
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=10)
        db.commit()
        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).preview_policy()
        assert preview.configured is True
        assert preview.retention_days == 7
        assert preview.max_delete == 10
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_respects_max_delete_and_keeps_remaining_candidate():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "policy-old-a", now - timedelta(days=20))
        _seed_run(db, "policy-old-b", now - timedelta(days=10))
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=1)
        db.commit()

        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply_policy()
        assert result.configured is True
        assert result.retention_days == 7
        assert result.max_delete == 1
        assert result.candidate_count == 2
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "policy-old-a") is None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "policy-old-b") is not None
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_does_not_delete_new_runs():
    db, engine = _db()
    try:
        new = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=2)
        _seed_run(db, "policy-new", new)
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db).set(
            retention_days=7,
            max_delete=10,
        )
        db.commit()
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply_policy()
        assert result.candidate_count == 0
        assert result.deleted_count == 0
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "policy-new") is not None
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_uses_defaults_when_policy_is_not_configured():
    db, engine = _db()
    try:
        old = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=400)
        _seed_run(db, "default-apply", old)
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply_policy()
        assert result.configured is False
        assert result.retention_days == 365
        assert result.max_delete == 500
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "default-apply") is None
    finally:
        db.close()
        engine.dispose()


def test_injected_session_leaves_policy_apply_commit_to_caller():
    db, engine = _db()
    try:
        old = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=400)
        _seed_run(db, "rollback-apply", old)
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply_policy()
        assert result.deleted_count == 1
        db.rollback()
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "rollback-apply") is not None
    finally:
        db.close()
        engine.dispose()
