from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.education.recommendations import (
    EducationalRecommendationRequest,
    EducationalRecommendationService,
)
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _remember_weak(memory, topic, *, mastery, weakness, status="active", needs_retry=False, attempts=1):
    memory.remember(
        user_id="student-22-4",
        memory_type=MemoryType.WEAK_AREA,
        memory_key=f"weak_area:{topic.lower()}",
        value={
            "topic": topic,
            "status": status,
            "mastery_score": mastery,
            "weakness_score": weakness,
            "correctness_score": mastery,
            "needs_retry": needs_retry,
            "attempts": attempts,
        },
        confidence=1.0,
        source="test",
    )


def test_recommendation_prioritizes_active_weak_area_and_targets_remediation():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        _remember_weak(memory, "فیزیک", mastery=0.30, weakness=0.70, needs_retry=True)
        _remember_weak(memory, "ریاضی", mastery=0.65, weakness=0.35)
        db.commit()

        result = EducationalRecommendationService(memory).recommend(
            EducationalRecommendationRequest(user_id="student-22-4")
        )
        assert result.recommended is True
        assert result.topic == "فیزیک"
        assert result.recommendation_type == "targeted_remediation"
        assert result.difficulty.value == "easy"
        assert result.generation_request["topic"] == "فیزیک"
    finally:
        db.close()
        engine.dispose()


def test_preferred_topic_is_respected():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        _remember_weak(memory, "فیزیک", mastery=0.30, weakness=0.70)
        _remember_weak(memory, "ریاضی", mastery=0.40, weakness=0.60)
        db.commit()

        result = EducationalRecommendationService(memory).recommend(
            EducationalRecommendationRequest(user_id="student-22-4", topic="ریاضی")
        )
        assert result.topic == "ریاضی"
        assert "preferred_topic_applied" in result.reasons
    finally:
        db.close()
        engine.dispose()


def test_topic_fallback_works_without_history():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        result = EducationalRecommendationService(memory).recommend(
            EducationalRecommendationRequest(user_id="student-22-4", topic="حرکت شناسی")
        )
        assert result.recommended is True
        assert result.recommendation_type == "reinforcement"
        assert result.difficulty.value == "medium"
        assert result.generation_request["topic"] == "حرکت شناسی"
    finally:
        db.close()
        engine.dispose()


def test_no_history_and_no_topic_returns_no_recommendation():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        result = EducationalRecommendationService(memory).recommend(
            EducationalRecommendationRequest(user_id="student-22-4")
        )
        assert result.recommended is False
        assert "insufficient_learning_history" in result.reasons
    finally:
        db.close()
        engine.dispose()


def test_recommendation_endpoint_returns_generator_ready_payload():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        _remember_weak(memory, "قانون دوم نیوتن", mastery=0.50, weakness=0.50)
        db.commit()

        app = create_app()
        app.dependency_overrides[get_db] = lambda: (yield db)
        client = TestClient(app)
        response = client.post(
            "/api/education/recommendations/next",
            json={
                "user_id": "student-22-4",
                "task_type": "quiz",
                "question_count": 4,
            },
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["recommended"] is True
        assert body["topic"] == "قانون دوم نیوتن"
        assert body["generation_request"]["difficulty"] == "easy"
        assert body["generation_request"]["question_count"] == 4
    finally:
        db.close()
        engine.dispose()
