from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class CaptureProgressAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def __init__(self) -> None:
        self.progress = None

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.progress = kwargs.get("student_progress")
        return AgentResult(answer="answer", confidence=0.7)


def test_pipeline_passes_aggregated_progress_to_specialist_without_changing_result():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-21-5-pipeline",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"learning_level": "grade10"},
        )
        memory.remember(
            user_id="student-21-5-pipeline",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra", "agent_type": "GENERAL_AGENT", "citation_count": 1},
            confidence=0.8,
        )
        memory.remember(
            user_id="student-21-5-pipeline",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:latest",
            value={"question": "معادله را توضیح بده"},
        )
        db.commit()

        agent = CaptureProgressAgent()
        registry = AgentRegistry()
        registry.register(agent)
        pipeline = UnifiedAgentPipeline(
            AgentRouter(registry),
            TeacherAgent(),
            memory=MemoryIntegrationService(memory),
        )
        context = ConversationContext(
            conversation_id="conv-21-5",
            user_id="student-21-5-pipeline",
            mode=ChatMode.GENERAL,
            subject_id="math",
        )

        result = pipeline.execute("سلام", conversation_context=context)

        assert result == AgentResult(answer="answer", confidence=0.7)
        assert agent.progress is not None
        assert agent.progress.profile["learning_level"] == "grade10"
        assert agent.progress.latest_question == "معادله را توضیح بده"
        assert agent.progress.learning_history_count == 1
    finally:
        db.close()
        engine.dispose()
