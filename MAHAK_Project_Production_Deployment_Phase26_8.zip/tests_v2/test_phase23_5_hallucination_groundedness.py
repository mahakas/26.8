from __future__ import annotations

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import (
    EducationalGroundednessEvaluationRequest,
    EducationalGroundednessEvaluationService,
    EducationalGroundednessEvidenceItem,
)


def test_exact_evidence_is_fully_grounded():
    result = EducationalGroundednessEvaluationService().evaluate(
        EducationalGroundednessEvaluationRequest(
            answer="قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.",
            evidence_items=(EducationalGroundednessEvidenceItem("قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.", "physics.pdf"),),
        )
    )
    assert result.claim_count == 1
    assert result.supported_claim_count == 1
    assert result.unsupported_claim_count == 0
    assert result.groundedness_score == 1.0
    assert result.hallucination_risk == 0.0
    assert result.groundedness_band == "excellent"
    assert result.semantic_verification_available is False


def test_unsupported_claim_is_detected():
    result = EducationalGroundednessEvaluationService().evaluate(
        EducationalGroundednessEvaluationRequest(
            answer="قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است. پایتخت ژاپن لندن است.",
            evidence_items=(EducationalGroundednessEvidenceItem("قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.", "physics.pdf"),),
        )
    )
    assert result.claim_count == 2
    assert result.supported_claim_count == 1
    assert result.unsupported_claim_count == 1
    assert result.unsupported_claim_rate == 0.5
    assert 0.0 < result.groundedness_score < 1.0
    assert result.hallucination_risk == round(1.0 - result.groundedness_score, 6)


def test_best_single_evidence_prevents_cross_item_term_pooling():
    result = EducationalGroundednessEvaluationService().evaluate(
        EducationalGroundednessEvaluationRequest(
            answer="نیرو برابر جرم ضربدر شتاب است.",
            evidence_items=(
                EducationalGroundednessEvidenceItem("نیرو", "a.pdf"),
                EducationalGroundednessEvidenceItem("شتاب", "b.pdf"),
            ),
        )
    )
    assert result.groundedness_score < 1.0
    assert result.supported_claim_count == 0


def test_threshold_changes_support_classification_without_changing_score():
    request = EducationalGroundednessEvaluationRequest(
        answer="نیرو برابر جرم و شتاب است.",
        evidence_items=(EducationalGroundednessEvidenceItem("نیرو برابر جرم است.", "physics.pdf"),),
        claim_support_threshold=0.55,
    )
    low = EducationalGroundednessEvaluationService().evaluate(request)
    high = EducationalGroundednessEvaluationService().evaluate(
        EducationalGroundednessEvaluationRequest(
            answer=request.answer,
            evidence_items=request.evidence_items,
            claim_support_threshold=0.95,
        )
    )
    assert low.groundedness_score == high.groundedness_score
    assert low.supported_claim_count == 1
    assert high.supported_claim_count == 0


def test_empty_evidence_is_safe_and_explicit():
    result = EducationalGroundednessEvaluationService().evaluate(
        EducationalGroundednessEvaluationRequest(answer="این یک ادعای بدون منبع است.")
    )
    assert result.claim_count == 1
    assert result.supported_claim_count == 0
    assert result.unsupported_claim_rate == 1.0
    assert result.groundedness_score == 0.0
    assert result.hallucination_risk == 1.0
    assert result.groundedness_band == "poor"


def test_multiple_supported_claims_are_averaged_deterministically():
    request = EducationalGroundednessEvaluationRequest(
        answer="زمین به دور خورشید می‌چرخد. آب در صد درجه می‌جوشد.",
        evidence_items=(
            EducationalGroundednessEvidenceItem("زمین به دور خورشید می‌چرخد.", "a.pdf"),
            EducationalGroundednessEvidenceItem("آب در صد درجه می‌جوشد.", "b.pdf"),
        ),
    )
    first = EducationalGroundednessEvaluationService().evaluate(request)
    second = EducationalGroundednessEvaluationService().evaluate(request)
    assert first.as_dict() == second.as_dict()
    assert first.supported_claim_count == 2
    assert first.groundedness_score == 1.0


def test_batch_aggregates_groundedness_metrics():
    result = EducationalGroundednessEvaluationService.evaluate_batch(
        (
            EducationalGroundednessEvaluationRequest(
                answer="قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.",
                evidence_items=(EducationalGroundednessEvidenceItem("قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است."),),
            ),
            EducationalGroundednessEvaluationRequest(
                answer="ادعای ناشناخته است.",
                evidence_items=(),
            ),
        )
    )
    assert result.total_cases == 2
    assert result.evaluated_cases == 2
    assert result.failed_cases == 0
    assert result.average_groundedness_score == 0.5
    assert result.average_hallucination_risk == 0.5


def test_batch_fail_fast_reports_invalid_case():
    result = EducationalGroundednessEvaluationService.evaluate_batch(
        (
            EducationalGroundednessEvaluationRequest(answer="", evidence_items=()),
            EducationalGroundednessEvaluationRequest(answer="ok", evidence_items=()),
        ),
        fail_fast=True,
    )
    assert result.total_cases == 2
    assert result.evaluated_cases == 0
    assert result.failed_cases == 1


def test_groundedness_api_returns_structured_metrics():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/groundedness",
        json={
            "answer": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.",
            "evidence_items": [
                {"source_id": "physics.pdf", "text": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است."}
            ],
        },
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["groundedness_score"] == 1.0
    assert payload["hallucination_risk"] == 0.0
    assert payload["semantic_verification_available"] is False


def test_groundedness_batch_api_is_replay_stable():
    client = TestClient(create_app())
    request = {
        "cases": [
            {
                "case_id": "perfect",
                "request": {
                    "answer": "a b c",
                    "evidence_items": [{"text": "a b c", "source_id": "a.pdf"}],
                },
            },
            {
                "case_id": "unsupported",
                "request": {"answer": "x y z", "evidence_items": []},
            },
        ]
    }
    first = client.post("/api/evaluation/groundedness/batch", json=request)
    second = client.post("/api/evaluation/groundedness/batch", json=request)
    assert first.status_code == 200, first.text
    assert second.status_code == 200, second.text
    assert first.json() == second.json()
    assert first.json()["evaluated_cases"] == 2
