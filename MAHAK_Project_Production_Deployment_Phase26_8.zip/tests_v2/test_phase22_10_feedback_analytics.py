from dataclasses import dataclass

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.education.recommendation_feedback import EducationalRecommendationFeedbackRequest
from backend_v2.education.recommendation_feedback_analytics import EducationalRecommendationFeedbackAnalyticsService
from backend_v2.education.recommendation_feedback_history import EducationalRecommendationFeedbackHistoryService
from backend_v2.memory.service import MemoryService


@dataclass(frozen=True)
class _FakeResult:
    outcome: str
    feedback_action: str
    topic: str = "قانون دوم نیوتن"
    difficulty: str | None = "medium"
    completion_percent: float = 100.0
    mastery_gap: float = 0.0
    latest_score: float | None = 1.0
    remediation_share: float = 0.0


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _record(db, feedback_id, *, plan_id="analytics-001", completion=100.0, gap=0.0, outcome="completed", action="advance"):
    history = EducationalRecommendationFeedbackHistoryService(MemoryService(db))
    request = EducationalRecommendationFeedbackRequest(
        user_id="student-22-10",
        learning_plan_id=plan_id,
        question_count=5,
    )
    result = _FakeResult(
        outcome=outcome,
        feedback_action=action,
        completion_percent=completion,
        mastery_gap=gap,
        latest_score=max(0.0, min(1.0, completion / 100.0)),
    )
    return history.record(request, result, feedback_id=feedback_id)


def test_empty_feedback_history_is_stable_and_read_only():
    db, engine = _db()
    try:
        result = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        ).analyze("student-22-10")
        assert result.total_feedback == 0
        assert result.latest_outcome is None
        assert result.latest_action is None
        assert result.trend == "insufficient_history"
        assert result.average_completion_percent == 0.0
        assert result.average_mastery_gap == 0.0
    finally:
        db.close()
        engine.dispose()


def test_feedback_analytics_aggregates_counts_rates_and_averages():
    db, engine = _db()
    try:
        _record(db, "a-1", completion=100.0, gap=0.0, outcome="completed", action="advance")
        _record(db, "a-2", completion=80.0, gap=0.2, outcome="at_risk", action="remediate")
        _record(db, "a-3", completion=90.0, gap=0.1, outcome="on_track", action="reinforce")
        result = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        ).analyze("student-22-10", window_size=2)
        assert result.total_feedback == 3
        assert result.outcome_counts == {"on_track": 1, "at_risk": 1, "completed": 1}
        assert result.action_counts == {"reinforce": 1, "remediate": 1, "advance": 1}
        assert result.remediation_rate == pytest.approx(1 / 3)
        assert result.advancement_rate == pytest.approx(1 / 3)
        assert result.reinforcement_rate == pytest.approx(1 / 3)
        assert result.average_completion_percent == pytest.approx(90.0)
        assert result.average_mastery_gap == pytest.approx(0.1)
    finally:
        db.close()
        engine.dispose()


def test_improving_trend_uses_recent_vs_previous_windows():
    db, engine = _db()
    try:
        _record(db, "t-1", completion=70.0, gap=0.2)
        _record(db, "t-2", completion=70.0, gap=0.2)
        _record(db, "t-3", completion=100.0, gap=0.0)
        _record(db, "t-4", completion=100.0, gap=0.0)
        result = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        ).analyze("student-22-10", window_size=2)
        assert result.trend == "improving"
        assert result.completion_delta_percent == pytest.approx(30.0)
        assert result.mastery_gap_delta == pytest.approx(-0.2)
    finally:
        db.close()
        engine.dispose()


def test_declining_trend_is_detected():
    db, engine = _db()
    try:
        _record(db, "t-1", completion=90.0, gap=0.0)
        _record(db, "t-2", completion=90.0, gap=0.0)
        _record(db, "t-3", completion=60.0, gap=0.3)
        _record(db, "t-4", completion=60.0, gap=0.3)
        result = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        ).analyze("student-22-10", window_size=2)
        assert result.trend == "declining"
        assert result.completion_delta_percent == pytest.approx(-30.0)
        assert result.mastery_gap_delta == pytest.approx(0.3)
    finally:
        db.close()
        engine.dispose()


def test_plan_scope_keeps_feedback_analytics_isolated():
    db, engine = _db()
    try:
        _record(db, "p-1", plan_id="plan-a", completion=100.0, gap=0.0)
        _record(db, "p-2", plan_id="plan-b", completion=50.0, gap=0.5)
        result = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        ).analyze("student-22-10", learning_plan_id="plan-a")
        assert result.learning_plan_id == "plan-a"
        assert result.total_feedback == 1
        assert result.latest_outcome == "completed"
        assert result.latest_action == "advance"
    finally:
        db.close()
        engine.dispose()


def test_feedback_analytics_endpoint_uses_request_database():
    db, engine = _db()
    try:
        _record(db, "api-1", completion=100.0, gap=0.0)
        client = TestClient(_app(db))
        response = client.get(
            "/api/education/recommendations/feedback/analytics",
            params={"user_id": "student-22-10", "window_size": 2},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total_feedback"] == 1
        assert body["latest_action"] == "advance"
        assert body["trend"] == "insufficient_history"
    finally:
        db.close()
        engine.dispose()


def test_feedback_analytics_validates_window_and_limit():
    db, engine = _db()
    try:
        service = EducationalRecommendationFeedbackAnalyticsService(
            EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        )
        with pytest.raises(ValueError):
            service.analyze("student-22-10", limit=0)
        with pytest.raises(ValueError):
            service.analyze("student-22-10", window_size=0)
    finally:
        db.close()
        engine.dispose()
