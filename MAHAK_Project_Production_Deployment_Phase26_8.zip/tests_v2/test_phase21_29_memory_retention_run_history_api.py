from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryRetentionRun
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed_policy_and_memory(db, user_id: str):
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add(
        LearningMemory(
            user_id=user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION.value,
            memory_key=f"old:{user_id}",
            value_json={"question": f"old-{user_id}"},
            created_at=now - timedelta(days=60),
            updated_at=now - timedelta(days=60),
        )
    )
    MemoryRetentionPolicyService(db).set(
        user_id,
        retention_days=30,
        max_delete=1,
        memory_type=MemoryType.PREVIOUS_QUESTION,
    )
    db.commit()


def test_history_is_user_scoped_and_excludes_memory_content():
    client, db, engine = _client()
    try:
        _seed_policy_and_memory(db, "history-api-a")
        _seed_policy_and_memory(db, "history-api-b")
        MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["history-api-a", "history-api-b"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        response = client.get("/api/memory/history-api-a/retention/runs")
        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 1
        item = payload["items"][0]
        assert item["user_id"] == "history-api-a"
        assert item["result_status"] == "planned"
        assert "value" not in item
        assert "memory_key" not in item
        assert "user_count" not in item
    finally:
        db.close()
        engine.dispose()


def test_history_cursor_paginates_without_duplicates_or_gaps():
    client, db, engine = _client()
    try:
        _seed_policy_and_memory(db, "history-page")
        service = MemoryRetentionSchedulerService(db, enabled=True)
        for index in range(3):
            service.run_with_report(
                user_ids=["history-page"],
                now=datetime(2026, 9, 19, 10 + index, tzinfo=UTC),
                dry_run=True,
            )

        seen = []
        cursor = None
        counts = []
        for _ in range(3):
            params = {"limit": 2}
            if cursor:
                params["cursor"] = cursor
            response = client.get("/api/memory/history-page/retention/runs", params=params)
            assert response.status_code == 200
            payload = response.json()
            counts.append(payload["count"])
            seen.extend(item["run_id"] for item in payload["items"])
            cursor = payload["next_cursor"]
            if not cursor:
                break

        assert counts == [2, 1]
        assert len(seen) == 3
        assert len(set(seen)) == 3
    finally:
        db.close()
        engine.dispose()


def test_history_filters_by_result_status_and_dry_run():
    client, db, engine = _client()
    try:
        _seed_policy_and_memory(db, "history-filter")
        service = MemoryRetentionSchedulerService(db, enabled=True)
        service.run_with_report(
            user_ids=["history-filter"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        service.run_with_report(
            user_ids=["history-filter"],
            now=datetime(2026, 9, 20, tzinfo=UTC),
            dry_run=False,
        )

        planned = client.get(
            "/api/memory/history-filter/retention/runs",
            params={"result_status": "planned", "dry_run": "true"},
        )
        assert planned.status_code == 200
        assert planned.json()["count"] == 1

        executed = client.get(
            "/api/memory/history-filter/retention/runs",
            params={"result_status": "executed", "dry_run": "false"},
        )
        assert executed.status_code == 200
        assert executed.json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_history_rejects_invalid_cursor_and_filters():
    client, db, engine = _client()
    try:
        invalid_cursor = client.get(
            "/api/memory/history-invalid/retention/runs",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert invalid_cursor.status_code == 422

        invalid_status = client.get(
            "/api/memory/history-invalid/retention/runs",
            params={"result_status": "unknown"},
        )
        assert invalid_status.status_code == 422

        invalid_run_status = client.get(
            "/api/memory/history-invalid/retention/runs",
            params={"run_status": "disabled"},
        )
        assert invalid_run_status.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_history_is_read_only_and_does_not_change_persistent_rows():
    client, db, engine = _client()
    try:
        _seed_policy_and_memory(db, "history-readonly")
        MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["history-readonly"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        before = db.scalar(select(MemoryRetentionRun).where(MemoryRetentionRun.run_id.is_not(None)))
        response = client.get("/api/memory/history-readonly/retention/runs")
        assert response.status_code == 200
        after = db.scalar(select(MemoryRetentionRun).where(MemoryRetentionRun.run_id == before.run_id))
        assert before is not None
        assert after is not None
        assert before.created_at == after.created_at
    finally:
        db.close()
        engine.dispose()
