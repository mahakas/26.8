from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_run(db, run_id: str, completed_at: datetime) -> None:
    db.add(
        MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
            run_id=run_id,
            started_at=completed_at - timedelta(seconds=1),
            completed_at=completed_at,
            older_than=completed_at - timedelta(days=30),
            candidate_count=1,
            deleted_count=1,
            retention_days=30,
            max_delete=500,
            configured=True,
            preview_bound=True,
        )
    )
    db.commit()


def test_preview_is_read_only_and_respects_limit():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "old-a", cutoff - timedelta(days=2))
        _seed_run(db, "old-b", cutoff - timedelta(days=1))
        _seed_run(db, "new-c", cutoff + timedelta(days=1))

        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).preview(
            older_than=cutoff, max_delete=1
        )
        assert preview.candidate_count == 2
        assert preview.would_delete_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-a") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-b") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "new-c") is not None
    finally:
        db.close()
        engine.dispose()


def test_apply_deletes_oldest_history_rows_only():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "old-a", cutoff - timedelta(days=2))
        _seed_run(db, "old-b", cutoff - timedelta(days=1))
        _seed_run(db, "new-c", cutoff + timedelta(days=1))

        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply(
            older_than=cutoff, max_delete=1
        )
        assert result.candidate_count == 2
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-a") is None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-b") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "new-c") is not None
    finally:
        db.close()
        engine.dispose()


def test_apply_can_remove_all_matching_history_rows_without_touching_new_rows():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "old-a", cutoff - timedelta(days=2))
        _seed_run(db, "old-b", cutoff - timedelta(days=1))
        _seed_run(db, "new-c", cutoff + timedelta(days=1))

        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply(
            older_than=cutoff, max_delete=10
        )
        assert result.deleted_count == 2
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-a") is None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-b") is None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "new-c") is not None
    finally:
        db.close()
        engine.dispose()


def test_future_cutoff_and_invalid_limits_are_rejected():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        for kwargs in (
            {"older_than": datetime.now(UTC) + timedelta(days=1)},
            {"older_than": datetime.now(UTC), "max_delete": 0},
            {"older_than": datetime.now(UTC), "max_delete": 501},
            {"older_than": datetime.now(UTC), "max_delete": True},
        ):
            try:
                service.preview(**kwargs)
            except ValueError:
                pass
            else:
                raise AssertionError("expected ValueError")
    finally:
        db.close()
        engine.dispose()


def test_injected_session_leaves_commit_to_caller():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "tx-a", cutoff - timedelta(days=2))
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply(
            older_than=cutoff, max_delete=10
        )
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "tx-a") is None
        db.rollback()
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "tx-a") is not None
    finally:
        db.close()
        engine.dispose()


def test_cleanup_never_targets_snapshot_rows():
    # The service only deletes the execution-history model; snapshot rows are outside its scope by construction.
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "old-a", cutoff - timedelta(days=2))
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply(
            older_than=cutoff, max_delete=10
        )
        assert result.deleted_count == 1
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionRun).count() == 0
    finally:
        db.close()
        engine.dispose()
