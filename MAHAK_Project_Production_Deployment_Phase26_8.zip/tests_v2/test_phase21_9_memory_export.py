from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(memory: MemoryService, user_id: str):
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.STUDENT_PROFILE,
        memory_key="profile",
        value={"grade": "10", "subject": "physics"},
    )
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.WEAK_AREA,
        memory_key="algebra",
        value={"topic": "algebra", "status": "active", "mastery_score": 0.35},
        confidence=0.9,
    )
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key="lesson-1",
        value={"topic": "algebra", "citation_count": 2, "agent_type": "document"},
        confidence=0.8,
    )
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.PREVIOUS_QUESTION,
        memory_key="q-1",
        value={"question": "What is x?"},
    )


def test_export_returns_user_scoped_snapshot_and_progress():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        _seed(memory, "student-export-21-9")
        memory.remember(
            user_id="other-export-21-9",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="other-q",
            value={"question": "private"},
        )
        db.commit()

        response = client.get("/api/memory/student-export-21-9/export")
        assert response.status_code == 200
        body = response.json()
        assert body["format_version"] == "1.0"
        assert body["user_id"] == "student-export-21-9"
        assert body["count"] == 4
        assert {item["memory_key"] for item in body["records"]} == {
            "profile", "algebra", "lesson-1", "q-1"
        }
        assert body["progress"]["active_weak_areas"] == ["algebra"]
        assert body["progress"]["learning_history_count"] == 1
        assert body["progress"]["latest_question"] == "What is x?"
        assert body["progress"]["total_citations"] == 2
    finally:
        db.close()
        engine.dispose()


def test_export_limit_is_honored_consistently():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        _seed(memory, "student-export-limit")
        db.commit()

        response = client.get(
            "/api/memory/student-export-limit/export",
            params={"limit": 2},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["count"] == 2
        assert len(body["records"]) == 2
        assert body["progress"]["learning_history_count"] <= 1
    finally:
        db.close()
        engine.dispose()


def test_export_is_read_only_and_does_not_change_memory_count():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        _seed(memory, "student-export-readonly")
        db.commit()

        before = client.get("/api/memory/student-export-readonly/records").json()["count"]
        response = client.get("/api/memory/student-export-readonly/export")
        after = client.get("/api/memory/student-export-readonly/records").json()["count"]

        assert response.status_code == 200
        assert before == 4
        assert after == before
    finally:
        db.close()
        engine.dispose()


def test_export_rejects_invalid_limit():
    client, db, engine = _client()
    try:
        assert client.get(
            "/api/memory/student-export-invalid/export",
            params={"limit": 0},
        ).status_code == 422
        assert client.get(
            "/api/memory/student-export-invalid/export",
            params={"limit": 501},
        ).status_code == 422
    finally:
        db.close()
        engine.dispose()
