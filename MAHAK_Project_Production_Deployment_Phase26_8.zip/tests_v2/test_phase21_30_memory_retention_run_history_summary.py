from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryRetentionRun
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, user_id: str):
    now = datetime(2026, 9, 19, tzinfo=UTC).replace(tzinfo=None)
    db.add(
        LearningMemory(
            user_id=user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION.value,
            memory_key=f"old:{user_id}",
            value_json={"question": "old"},
            created_at=now - timedelta(days=60),
            updated_at=now - timedelta(days=60),
        )
    )
    MemoryRetentionPolicyService(db).set(
        user_id,
        retention_days=30,
        max_delete=1,
        memory_type=MemoryType.PREVIOUS_QUESTION,
    )
    db.commit()


def test_summary_is_user_scoped_and_aggregates_run_metrics():
    client, db, engine = _client()
    try:
        _seed(db, "summary-a")
        _seed(db, "summary-b")
        service = MemoryRetentionSchedulerService(db, enabled=True)
        service.run_with_report(
            user_ids=["summary-a", "summary-b"],
            now=datetime(2026, 9, 19, 10, tzinfo=UTC),
            dry_run=True,
        )
        service.run_with_report(
            user_ids=["summary-a", "summary-b"],
            now=datetime(2026, 9, 20, 10, tzinfo=UTC),
            dry_run=False,
        )
        response = client.get("/api/memory/summary-a/retention/runs/summary")
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 2
        assert payload["result_count"] == 2
        assert payload["dry_run_count"] == 1
        assert payload["planned_result_count"] == 1
        assert payload["executed_result_count"] == 1
        assert payload["deleted_count"] == 1
        assert payload["read_only"] is True
    finally:
        db.close()
        engine.dispose()


def test_summary_filters_by_status_dry_run_and_time_window():
    client, db, engine = _client()
    try:
        _seed(db, "summary-filter")
        service = MemoryRetentionSchedulerService(db, enabled=True)
        service.run_with_report(
            user_ids=["summary-filter"],
            now=datetime(2026, 9, 19, 10, tzinfo=UTC),
            dry_run=True,
        )
        service.run_with_report(
            user_ids=["summary-filter"],
            now=datetime(2026, 9, 20, 10, tzinfo=UTC),
            dry_run=False,
        )
        response = client.get(
            "/api/memory/summary-filter/retention/runs/summary",
            params={
                "result_status": "planned",
                "dry_run": "true",
                "start_at": "2026-09-19T00:00:00Z",
                "end_at": "2026-09-20T00:00:00Z",
            },
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 1
        assert payload["planned_result_count"] == 1
        assert payload["executed_result_count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_summary_is_read_only():
    client, db, engine = _client()
    try:
        _seed(db, "summary-readonly")
        MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["summary-readonly"],
            now=datetime(2026, 9, 19, 10, tzinfo=UTC),
            dry_run=True,
        )
        before = db.scalar(select(MemoryRetentionRun).where(MemoryRetentionRun.run_id.is_not(None)))
        response = client.get("/api/memory/summary-readonly/retention/runs/summary")
        assert response.status_code == 200
        after = db.scalar(select(MemoryRetentionRun).where(MemoryRetentionRun.run_id == before.run_id))
        assert before is not None
        assert after is not None
        assert before.completed_at == after.completed_at
    finally:
        db.close()
        engine.dispose()


def test_summary_rejects_invalid_filters():
    client, db, engine = _client()
    try:
        for params in (
            {"run_status": "disabled"},
            {"result_status": "unknown"},
            {"start_at": "2026-09-20T00:00:00Z", "end_at": "2026-09-19T00:00:00Z"},
        ):
            response = client.get("/api/memory/summary-invalid/retention/runs/summary", params=params)
            assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
