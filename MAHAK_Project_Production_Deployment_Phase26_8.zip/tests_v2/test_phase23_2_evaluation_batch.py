from __future__ import annotations

import json

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import EducationalAnswerEvaluationRequest, EducationalEvaluationBatchRunner, EducationalEvaluationCase


def _case(case_id: str, answer: str = "پاسخ درست") -> EducationalEvaluationCase:
    return EducationalEvaluationCase(
        case_id=case_id,
        request=EducationalAnswerEvaluationRequest(
            question="سؤال",
            answer=answer,
            expected_answer="پاسخ درست",
            expected_source_ids=("lesson.pdf",),
            retrieved_source_ids=("lesson.pdf",),
            cited_source_ids=("lesson.pdf",),
            evidence_texts=("پاسخ درست",),
        ),
    )


def test_batch_runner_aggregates_multiple_cases():
    result = EducationalEvaluationBatchRunner().run((_case("a"), _case("b", "پاسخ ناقص")), dataset_id="physics-v1")
    assert result.dataset_id == "physics-v1"
    assert result.total_cases == 2
    assert result.evaluated_cases == 2
    assert result.failed_cases == 0
    assert result.average_overall_score is not None
    assert result.quality_band_counts["excellent"] == 1


def test_batch_runner_handles_case_failure_without_stopping():
    bad = EducationalEvaluationCase(
        case_id="bad",
        request=EducationalAnswerEvaluationRequest(question="", answer="x"),
    )
    result = EducationalEvaluationBatchRunner().run((_case("good"), bad), fail_fast=False)
    assert result.evaluated_cases == 1
    assert result.failed_cases == 1
    assert result.errors[0]["case_id"] == "bad"


def test_batch_runner_fail_fast_stops_after_first_failure():
    bad = EducationalEvaluationCase(
        case_id="bad",
        request=EducationalAnswerEvaluationRequest(question="", answer="x"),
    )
    result = EducationalEvaluationBatchRunner().run((bad, _case("later")), fail_fast=True)
    assert result.evaluated_cases == 0
    assert result.failed_cases == 1
    assert result.total_cases == 2


def test_jsonl_dataset_loader_is_deterministic(tmp_path):
    dataset = tmp_path / "evaluation.jsonl"
    rows = [
        {"case_id": "a", "request": {"question": "سؤال", "answer": "پاسخ", "expected_answer": "پاسخ"}},
        {"case_id": "b", "request": {"question": "سؤال 2", "answer": "پاسخ 2", "expected_answer": "پاسخ 2"}},
    ]
    dataset.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows), encoding="utf-8")
    cases = EducationalEvaluationBatchRunner.load_jsonl(dataset)
    assert [case.case_id for case in cases] == ["a", "b"]


def test_jsonl_dataset_loader_rejects_missing_case_id(tmp_path):
    dataset = tmp_path / "bad.jsonl"
    dataset.write_text(json.dumps({"request": {"question": "q", "answer": "a"}}), encoding="utf-8")
    try:
        EducationalEvaluationBatchRunner.load_jsonl(dataset)
    except ValueError as exc:
        assert "case_id" in str(exc)
    else:
        raise AssertionError("missing case_id should fail")


def test_batch_api_returns_aggregate_report():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/batch",
        json={
            "dataset_id": "api-smoke",
            "cases": [
                {
                    "case_id": "c1",
                    "request": {
                        "question": "قانون دوم نیوتن چیست؟",
                        "answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
                        "expected_answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
                        "expected_source_ids": ["physics.pdf"],
                        "retrieved_source_ids": ["physics.pdf"],
                        "cited_source_ids": ["physics.pdf"],
                        "evidence_texts": ["قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است."],
                    },
                },
            ],
        },
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["total_cases"] == 1
    assert payload["evaluated_cases"] == 1
    assert payload["average_overall_score"] == 1.0


def test_batch_api_rejects_empty_dataset():
    client = TestClient(create_app())
    response = client.post("/api/evaluation/batch", json={"cases": []})
    assert response.status_code == 422
