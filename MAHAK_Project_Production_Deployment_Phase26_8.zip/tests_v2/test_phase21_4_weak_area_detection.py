from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType
from backend_v2.memory.weak_area import EvaluationSignals, WeakAreaDetector, WeakAreaMemoryUpdater


def _db():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _context() -> ConversationContext:
    return ConversationContext(
        conversation_id="conv-21-4",
        user_id="student-21-4",
        mode=ChatMode.GENERAL,
        grade_id="10",
        subject_id="math",
    )


def test_detector_marks_low_mastery_as_active_weak_area():
    assessment = WeakAreaDetector().assess(
        EvaluationSignals(
            topic="algebra",
            mastery_score=0.3,
            correctness_score=0.4,
            evaluator_confidence=0.9,
        )
    )
    assert assessment.status == "active"
    assert assessment.weakness_score >= 0.6
    assert assessment.confidence >= 0.7
    assert "low_mastery" in assessment.reasons


def test_updater_is_controlled_and_deduplicates_equal_signal():
    db, engine = _db()
    try:
        service = MemoryService(db)
        updater = WeakAreaMemoryUpdater(service)
        context = _context()
        signals = EvaluationSignals(topic="algebra", mastery_score=0.3, evaluator_confidence=0.9)

        updater.update(context, signals)
        db.commit()
        first = service.latest(
            context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
        )
        assert first is not None

        updater.update(context, signals)
        db.commit()
        rows = service.list(context.user_id, memory_type=MemoryType.WEAK_AREA)
        assert len(rows) == 1
    finally:
        db.close()
        engine.dispose()


def test_strong_evaluation_can_resolve_existing_weak_area():
    db, engine = _db()
    try:
        service = MemoryService(db)
        updater = WeakAreaMemoryUpdater(service)
        context = _context()

        updater.update(
            context,
            EvaluationSignals(topic="algebra", mastery_score=0.3, evaluator_confidence=0.9),
        )
        db.commit()
        updater.update(
            context,
            EvaluationSignals(
                topic="algebra",
                mastery_score=0.9,
                correctness_score=0.9,
                evaluator_confidence=0.95,
            ),
        )
        db.commit()

        latest = service.latest(
            context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
        )
        assert latest is not None
        assert latest.value["status"] == "resolved"
    finally:
        db.close()
        engine.dispose()
