from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        try:
            yield db
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def test_memory_records_endpoint_is_user_scoped_and_typed():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "2+2?"},
            confidence=0.9,
            source="test",
        )
        memory.remember(
            user_id="other-user",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:2",
            value={"question": "3+3?"},
        )
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra"},
        )
        db.commit()

        response = client.get("/api/memory/student-api/records", params={"memory_type": "previous_question"})
        assert response.status_code == 200
        payload = response.json()
        assert payload["user_id"] == "student-api"
        assert payload["count"] == 1
        assert payload["items"][0]["memory_type"] == "previous_question"
        assert payload["items"][0]["value"]["question"] == "2+2?"
    finally:
        db.close()
        engine.dispose()


def test_memory_progress_endpoint_uses_existing_aggregation():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"learning_level": "grade10"},
        )
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak:algebra",
            value={"topic": "algebra", "status": "active", "mastery_score": 0.35},
        )
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra", "agent_type": "DOCUMENT_AGENT", "citation_count": 2},
            confidence=0.8,
        )
        memory.remember(
            user_id="student-api",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "این معادله چیست؟"},
        )
        db.commit()

        response = client.get("/api/memory/student-api/progress")
        assert response.status_code == 200
        payload = response.json()
        assert payload["profile"]["learning_level"] == "grade10"
        assert payload["active_weak_areas"] == ["algebra"]
        assert payload["learning_history_count"] == 1
        assert payload["previous_question_count"] == 1
        assert payload["average_confidence"] == 0.8
        assert payload["total_citations"] == 2
        assert payload["agent_counts"] == {"DOCUMENT_AGENT": 1}
        assert payload["latest_question"] == "این معادله چیست؟"
        assert payload["mastery_by_topic"] == {"algebra": 0.35}
    finally:
        db.close()
        engine.dispose()


def test_memory_api_validates_limit():
    client, db, engine = _client()
    try:
        response = client.get("/api/memory/student-api/records", params={"limit": 0})
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
