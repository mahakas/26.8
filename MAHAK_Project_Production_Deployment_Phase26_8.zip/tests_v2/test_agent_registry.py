from backend_v2.agents.base import BaseAgent
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.types import AgentResult, AgentType


class DummyAgent(BaseAgent):
    agent_type = AgentType.VIDEO

    def execute(self, query: str, **kwargs) -> AgentResult:
        return AgentResult(answer=query)


def test_register_and_get_agent():
    registry = AgentRegistry()
    agent = DummyAgent()
    registry.register(agent)
    assert registry.get(AgentType.VIDEO) is agent


def test_duplicate_registration():
    registry = AgentRegistry()
    registry.register(DummyAgent())
    try:
        registry.register(DummyAgent())
        assert False
    except ValueError as exc:
        assert "already registered" in str(exc)


def test_missing_agent():
    registry = AgentRegistry()
    try:
        registry.get(AgentType.VIDEO)
        assert False
    except KeyError as exc:
        assert "not registered" in str(exc)
