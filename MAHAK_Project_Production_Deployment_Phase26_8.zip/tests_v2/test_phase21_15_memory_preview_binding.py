from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _record(user_id: str, value: str, key: str = "profile"):
    return {
        "id": f"snapshot-{value}-{key}",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": key,
        "value": {"grade": value},
        "confidence": 1.0,
        "source": "snapshot",
    }


def test_preview_returns_execution_binding_token():
    client, db, engine = _client()
    try:
        user_id = "student-21-15-token"
        response = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={"user_id": user_id, "records": [_record(user_id, "10")]},
        )
        assert response.status_code == 200
        token = response.json()["preview_token"]
        assert len(token) == 64
    finally:
        db.close()
        engine.dispose()


def test_matching_preview_token_allows_import():
    client, db, engine = _client()
    try:
        user_id = "student-21-15-match"
        record = _record(user_id, "10")
        preview = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={"user_id": user_id, "records": [record]},
        )
        token = preview.json()["preview_token"]
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "preview_token": token, "records": [record]},
        )
        assert response.status_code == 201
        assert response.json()["imported_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_preview_token_rejects_relevant_state_change():
    client, db, engine = _client()
    try:
        user_id = "student-21-15-state-change"
        record = _record(user_id, "10")
        preview = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={"user_id": user_id, "records": [record]},
        )
        token = preview.json()["preview_token"]

        changed = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record(user_id, "11")]},
        )
        assert changed.status_code == 201

        response = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "preview_token": token, "records": [record]},
        )
        assert response.status_code == 409
        assert "state changed" in response.json()["detail"]
    finally:
        db.close()
        engine.dispose()


def test_preview_token_rejects_payload_or_policy_change():
    client, db, engine = _client()
    try:
        user_id = "student-21-15-payload-change"
        record = _record(user_id, "10")
        preview = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={"user_id": user_id, "records": [record]},
        )
        token = preview.json()["preview_token"]

        payload_changed = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "preview_token": token,
                "records": [_record(user_id, "10", key="other-profile")],
            },
        )
        assert payload_changed.status_code == 409

        policy_changed = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "preview_token": token,
                "conflict_policy": "skip",
                "records": [record],
            },
        )
        assert policy_changed.status_code == 409
    finally:
        db.close()
        engine.dispose()


def test_import_without_preview_token_keeps_legacy_behavior():
    client, db, engine = _client()
    try:
        user_id = "student-21-15-legacy"
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record(user_id, "10")]},
        )
        assert response.status_code == 201
        assert response.json()["imported_count"] == 1
    finally:
        db.close()
        engine.dispose()
