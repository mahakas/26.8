from __future__ import annotations

from dataclasses import dataclass

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.document import DocumentAgent
from backend_v2.agents.multimodal import MultimodalTeacherService
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.video import VideoAgent
from backend_v2.agents.vision import VisionAgent
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from backend_v2.api import teacher as teacher_api
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.core.enums import Capability
from backend_v2.retrieval.service import RetrievalService
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.vectorstores.embedding import EmbeddingResult
from backend_v2.vectorstores.memory import InMemoryVectorStore
from backend_v2.vectorstores.base import VectorRecord


@dataclass
class FixedEmbedding:
    def embed(self, texts):
        return EmbeddingResult(
            vectors=[[1.0, 0.0] for _ in texts],
            provider="test",
            model="fixed",
            dimension=2,
        )


def _orchestrator():
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            "phase25-1-teacher",
            {Capability.CHAT},
            handler=lambda payload: {"answer": "توضیح یکپارچه آموزشی"},
            default_model="teacher-v1",
        )
    )
    return ProviderOrchestrator(registry, ProviderHealthManager())


def _service():
    store = InMemoryVectorStore()
    store.upsert(
        [
            VectorRecord("doc-1", [1.0, 0.0], "قانون دوم نیوتن در کتاب.", {"source_type": "pdf", "source_id": "book.pdf", "title": "کتاب فیزیک", "page": 4}),
            VectorRecord("image-1", [1.0, 0.0], "نمودار نیرو و شتاب.", {"source_type": "image", "source_id": "diagram.png", "image_id": "img-1", "path": "diagram.png"}),
            VectorRecord("video-1", [1.0, 0.0], "قانون دوم نیوتن توضیح داده می‌شود.", {"source_type": "video", "source_id": "lesson.mp4", "start_time_seconds": 54.5, "end_time_seconds": 57.3, "frame_path": "frame-054.jpg"}),
        ],
        collection="mahak_knowledge",
    )
    retrieval = RetrievalService(store, FixedEmbedding())
    registry = AgentRegistry()
    registry.register(DocumentAgent())
    registry.register(VisionAgent())
    registry.register(VideoAgent(retrieval, collection="mahak_knowledge", top_k=3, candidate_k=6, min_score=0.0))
    registry.register(__import__("backend_v2.agents.general", fromlist=["GeneralAgent"]).GeneralAgent())
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    memory = MemoryService(Session())
    return (
        MultimodalTeacherService(
            registry,
            TeacherAgent(_orchestrator()),
            retrieval,
            memory=MemoryIntegrationService(memory),
            collection="mahak_knowledge",
        ),
        engine,
        memory,
    )


def test_router_detects_multiple_modalities_without_breaking_classify():
    router = AgentRouter(AgentRegistry())
    routes = router.classify_many("این ویدیو و تصویر و صفحه کتاب را مقایسه کن")
    assert [item.agent_type for item in routes] == [AgentType.VIDEO, AgentType.IMAGE, AgentType.DOCUMENT]
    assert router.classify("این ویدیو را توضیح بده").agent_type is AgentType.VIDEO


def test_retrieval_scope_supports_source_types():
    scope = RetrievalScope(source_types=("image", "video"), session_file_ids=("f1",))
    assert scope.as_filters() == {
        "session_file_id": {"$in": ["f1"]},
        "source_type": {"$in": ["image", "video"]},
    }


def test_multimodal_service_merges_document_image_video_evidence():
    service, engine, _ = _service()
    try:
        context = ConversationContext(
            conversation_id="phase25-1",
            user_id=None,
            mode=ChatMode.EDUCATIONAL,
        )
        execution = service.execute(
            "این ویدیو و تصویر و صفحه کتاب را توضیح بده",
            context=context,
            top_k=3,
            min_score=0.0,
        )
        assert [route.agent_type for route in execution.routes] == [AgentType.VIDEO, AgentType.IMAGE, AgentType.DOCUMENT]
        assert {item["type"] for item in execution.result.evidence} == {"video", "image", "document"}
        assert execution.result.citations
        assert execution.result.confidence > 0
        assert execution.result.answer == "توضیح یکپارچه آموزشی"
    finally:
        engine.dispose()


def test_multimodal_service_respects_explicit_modalities():
    service, engine, _ = _service()
    try:
        context = ConversationContext("phase25-1-explicit", None, ChatMode.EDUCATIONAL)
        execution = service.execute(
            "فقط تصویر را تحلیل کن",
            context=context,
            modalities=("image",),
            top_k=3,
            min_score=0.0,
        )
        assert [route.agent_type for route in execution.routes] == [AgentType.IMAGE]
        assert execution.result.evidence[0]["type"] == "image"
    finally:
        engine.dispose()




def test_explicit_modality_overrides_query_keyword_routing():
    service, engine, _ = _service()
    try:
        context = ConversationContext("phase25-1-override", None, ChatMode.EDUCATIONAL)
        execution = service.execute(
            "فقط درباره قانون دوم توضیح بده",
            context=context,
            modalities=("image",),
            top_k=3,
            min_score=0.0,
        )
        assert [route.agent_type for route in execution.routes] == [AgentType.IMAGE]
        assert execution.result.evidence
        assert execution.result.evidence[0]["type"] == "image"
    finally:
        engine.dispose()


def test_multimodal_service_records_memory_for_authenticated_context():
    service, engine, memory = _service()
    try:
        context = ConversationContext("phase25-1-memory", "student-25-1", ChatMode.EDUCATIONAL)
        service.execute("این تصویر را توضیح بده", context=context, modalities=("image",), top_k=2, min_score=0.0)
        assert memory.latest(
            context.user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key=f"conversation:{context.conversation_id}:latest_question",
        ) is not None
    finally:
        engine.dispose()


def test_teacher_api_requires_chat_permission_and_exposes_unified_contract(monkeypatch):
    service, engine, _ = _service()
    fake_user = User(id="user-25-1", email="phase25-1@example.com", password_hash="x", display_name="Phase 25", role="student")
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: fake_user
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    app.dependency_overrides[get_db] = lambda: Session()
    monkeypatch.setattr(teacher_api, "build_teacher_service", lambda: service)
    try:
        client = TestClient(app)
        response = client.post(
            "/api/teacher/ask",
            json={
                "conversation_id": "phase25-api",
                "query": "این ویدیو و تصویر را توضیح بده",
                "mode": "educational",
            },
        )
        assert response.status_code == 200, response.text
        payload = response.json()
        assert payload["found"] is True
        assert payload["agents"] == ["VIDEO_AGENT", "IMAGE_AGENT"]
        assert {item["type"] for item in payload["evidence"]} == {"video", "image"}
        assert payload["route_trace"]
        assert payload["interaction_id"]
    finally:
        engine.dispose()




def test_teacher_api_requires_authentication():
    client = TestClient(create_app())
    response = client.post(
        "/api/teacher/ask",
        json={"conversation_id": "phase25-unauth", "query": "این تصویر را تحلیل کن"},
    )
    assert response.status_code == 401


def test_teacher_api_rejects_general_mode_with_non_general_modality():
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: User(id="user-25-1", email="phase25-1@example.com", password_hash="x", display_name="Phase 25", role="student")
    response = TestClient(app).post(
        "/api/teacher/ask",
        json={
            "conversation_id": "phase25-invalid",
            "query": "سلام",
            "mode": "general",
            "modalities": ["video"],
        },
    )
    assert response.status_code == 422
