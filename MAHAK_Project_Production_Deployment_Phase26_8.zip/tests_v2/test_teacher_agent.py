from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType


def _source_result() -> AgentResult:
    return AgentResult(
        answer="3x = 9, پس x = 3.",
        evidence=[
            {"type": "document", "text": "3x = 9", "page": 12},
        ],
        citations=[
            {"source_id": "math-1", "title": "Algebra", "page": 12},
        ],
        confidence=0.84,
    )


def test_teacher_agent_preserves_source_contract_without_provider():
    agent = TeacherAgent()
    source = _source_result()

    result = agent.execute("x را به زبان ساده توضیح بده", source_result=source)

    assert agent.agent_type is AgentType.TEACHER
    assert result.answer == source.answer
    assert result.evidence == source.evidence
    assert result.citations == source.citations
    assert result.confidence == source.confidence
