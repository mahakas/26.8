from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService, RetentionSchedulerRunReport
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return session, engine


def _seed(db, user_id: str):
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add(
        LearningMemory(
            user_id=user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION.value,
            memory_key="old",
            value_json={"q": "old"},
            created_at=now - timedelta(days=60),
            updated_at=now - timedelta(days=60),
        )
    )
    db.commit()


def test_run_with_report_aggregates_dry_run_without_mutation():
    db, engine = _db()
    try:
        _seed(db, "report-a")
        _seed(db, "report-b")
        for user_id in ("report-a", "report-b"):
            MemoryRetentionPolicyService(db).set(
                user_id,
                retention_days=30,
                max_delete=1,
                memory_type=MemoryType.PREVIOUS_QUESTION,
            )
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["report-a", "report-b"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        assert isinstance(report, RetentionSchedulerRunReport)
        assert report.status == "completed"
        assert report.dry_run is True
        assert report.user_count == 2
        assert report.planned_count == 2
        assert report.failed_count == 0
        assert report.candidate_count == 2
        assert report.would_delete_count == 2
        assert report.deleted_count == 0
        assert len(report.run_id) == 36
        assert report.completed_at >= report.started_at
        assert db.scalar(select(LearningMemory.id).where(LearningMemory.user_id == "report-a")) is not None
    finally:
        db.close()
        engine.dispose()


def test_run_with_report_disabled_is_explicit():
    db, engine = _db()
    try:
        report = MemoryRetentionSchedulerService(db, enabled=False).run_with_report(user_ids=["disabled"])
        assert report.status == "disabled"
        assert report.user_count == 0
        assert report.executed_count == 0
        assert report.failed_count == 0
        assert len(report.results) == 1
        assert report.results[0].status == "disabled"
    finally:
        db.close()
        engine.dispose()


def test_run_with_report_preserves_per_user_failures_and_successes():
    db, engine = _db()
    try:
        _seed(db, "good")
        MemoryRetentionPolicyService(db).set(
            "good",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        from backend_v2.database.models import MemoryRetentionPolicy
        db.add(
            MemoryRetentionPolicy(
                user_id="bad",
                retention_days=30,
                max_delete=1,
                memory_type="not-a-memory-type",
            )
        )
        db.commit()
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["bad", "good"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        assert report.status == "completed_with_errors"
        assert report.user_count == 2
        assert report.failed_count == 1
        assert report.executed_count == 1
        assert report.deleted_count == 1
        assert {row.user_id for row in report.results} == {"bad", "good"}
    finally:
        db.close()
        engine.dispose()
