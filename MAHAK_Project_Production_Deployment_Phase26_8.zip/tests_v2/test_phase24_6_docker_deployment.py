from __future__ import annotations

from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[1]


def _read(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


def test_dockerfile_is_non_root_and_has_readiness_healthcheck():
    content = _read("Dockerfile")
    assert "FROM python:3.12-slim-bookworm" in content
    assert "useradd --uid 10001" in content
    assert "USER 10001:10001" in content
    assert "/api/health/ready" in content
    assert 'CMD ["uvicorn", "backend_v2.api.app:app"' in content


def test_compose_has_persistent_volume_and_hardening_defaults():
    content = _read("compose.yaml")
    assert "mahak_data:/app/data" in content
    assert "read_only: true" in content
    assert "no-new-privileges:true" in content
    assert "cap_drop:" in content
    assert "- ALL" in content
    assert "test:" in content and "/api/health/ready" in content


def test_compose_preserves_single_worker_semantics_for_process_local_state():
    content = _read("compose.yaml")
    assert "WEB_CONCURRENCY" in content
    assert "WEB_CONCURRENCY:-1" in content


def test_production_env_template_contains_required_security_settings():
    content = _read(".env.production.example")
    for key in (
        "APP_ENV=production",
        "APP_DEBUG=false",
        "MAHAK_SECRET_KEY=",
        "ALLOWED_HOSTS=",
        "SECURITY_HEADERS_ENABLED=true",
        "RATE_LIMIT_ENABLED=true",
        "API_DOCS_ENABLED=false",
        "VECTOR_STORE_BACKEND=chroma",
    ):
        assert key in content


def test_dockerignore_excludes_secrets_caches_and_large_media():
    content = _read(".dockerignore")
    for entry in (".env", ".env.*", "__pycache__", ".pytest_cache", "*.mp4", "*.mov", "*.zip"):
        assert entry in content
    assert "!.env.production.example" in content


def test_deployment_docs_and_smoke_exist():
    assert (ROOT / "README_PHASE24_6.md").exists()
    assert (ROOT / "ROADMAP_STATUS_PHASE24_6.md").exists()
    assert (ROOT / "scripts/smoke_docker_deployment_phase24_6.py").exists()


def test_docker_cli_status_is_explicitly_reportable():
    docker_path = shutil.which("docker")
    if not docker_path:
        assert "Docker build was not available" in (ROOT / "README_PHASE24_6.md").read_text(encoding="utf-8")
        return
    docker = subprocess.run([docker_path, "--version"], capture_output=True, text=True)
    assert docker.returncode == 0
