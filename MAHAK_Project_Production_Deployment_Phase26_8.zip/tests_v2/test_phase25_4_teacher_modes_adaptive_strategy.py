from backend_v2.agents.teaching_strategy import (
    AdaptiveTeachingStrategyPlanner,
    TeachingMode,
)
from backend_v2.agents.types import AgentResult
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.chat.context import ConversationContext
from backend_v2.memory.personalization import PersonalizationContext
from backend_v2.memory.progress import StudentProgressProfile
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.orchestrator import ProviderOrchestrator


def _teacher():
    registry = ProviderRegistry()
    registry.register(MockProviderAdapter(
        "phase25-4",
        {Capability.CHAT},
        handler=lambda payload: {"answer": "پاسخ آموزشی تطبیقی"},
        default_model="adaptive-v1",
    ))
    return TeacherAgent(ProviderOrchestrator(registry, ProviderHealthManager()))


def test_auto_mode_selects_remediation_for_active_weak_area():
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.AUTO,
        query="قانون دوم نیرو را توضیح بده",
        personalization=PersonalizationContext(weak_areas=("قانون دوم نیرو",), learning_level="beginner"),
        student_progress=StudentProgressProfile("u", {}, active_weak_areas=("قانون دوم نیرو",), average_confidence=0.42),
        source_confidence=0.9,
    )
    assert strategy.mode is TeachingMode.REMEDIATION
    assert strategy.scaffolding == "high"
    assert "قانون دوم نیرو" in strategy.focus


def test_auto_mode_detects_practice_summary_and_exam_intent():
    planner = AdaptiveTeachingStrategyPlanner()
    assert planner.plan(query="یک تمرین حل کن").mode is TeachingMode.PRACTICE
    assert planner.plan(query="این درس را خلاصه کن").mode is TeachingMode.SUMMARY
    assert planner.plan(query="برای امتحان آماده‌ام کن").mode is TeachingMode.EXAM


def test_explicit_mode_overrides_auto_policy():
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.SOCRATIC,
        query="خلاصه این درس را بده",
    )
    assert strategy.mode is TeachingMode.SOCRATIC
    assert strategy.interaction_style == "guided_questions"


def test_teacher_prompt_contains_adaptive_strategy_without_changing_evidence():
    source = AgentResult(
        "خام",
        [{"type": "document", "text": "قانون دوم نیرو"}],
        [{"source_id": "book", "page": 4}],
        0.8,
    )
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.REMEDIATION,
        query="توضیح بده",
        personalization=PersonalizationContext(weak_areas=("قانون دوم نیرو",)),
    )
    result = _teacher().execute(
        "توضیح بده",
        source_result=source,
        teaching_strategy=strategy.as_dict(),
    )
    assert result.answer == "پاسخ آموزشی تطبیقی"
    assert result.evidence == source.evidence
    assert result.citations == source.citations


def test_strategy_is_json_ready_and_bounded():
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.EXPLAIN,
        query="توضیح بده",
        source_confidence=1.0,
    )
    payload = strategy.as_dict()
    assert payload["mode"] == "explain"
    assert isinstance(payload["focus"], list)
    assert isinstance(payload["rationale"], list)
