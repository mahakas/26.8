from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import (
    MemoryRetentionMaintenanceAlertSnapshot,
    MemoryRetentionMaintenanceAlertSnapshotRetentionRun,
)
from backend_v2.memory import MemoryRetentionMaintenanceAlertSnapshotRetentionService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return session, engine


def _client():
    db, engine = _db()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, snapshot_id: str, captured_at: datetime):
    db.add(
        MemoryRetentionMaintenanceAlertSnapshot(
            snapshot_id=snapshot_id,
            captured_at=captured_at,
            health="healthy",
            ready=True,
            severity="none",
            stale_after_seconds=86400,
            alert_count=0,
            alert_codes="",
            assume_enabled=False,
            use_policy=False,
        )
    )


def test_policy_apply_persists_content_free_execution_history():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()

        result = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).apply_policy()
        row = db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, result.run_id)

        assert row is not None
        assert row.run_id == result.run_id
        assert row.older_than == result.older_than
        assert row.candidate_count == 1
        assert row.deleted_count == 1
        assert row.retention_days == 30
        assert row.max_delete == 500
        assert row.configured is False
        assert row.preview_bound is False
        assert not hasattr(row, "snapshot_content")
        assert not hasattr(row, "alert_message")
    finally:
        db.close()
        engine.dispose()


def test_preview_bound_apply_marks_history():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()

        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        token = service.preview_policy().preview_token
        assert token
        result = service.apply_policy(preview_token=token)
        row = db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, result.run_id)

        assert row is not None
        assert row.preview_bound is True
    finally:
        db.close()
        engine.dispose()


def test_each_successful_execution_gets_a_distinct_run_id():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        first = service.apply_policy()
        second = service.apply_policy()
        assert first.run_id != second.run_id
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshotRetentionRun)) == 2
    finally:
        db.close()
        engine.dispose()


def test_history_repository_cursor_paginates_without_gaps():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        service.apply_policy()
        service.apply_policy()
        db.commit()

        from backend_v2.database.repositories import MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository

        repo = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db)
        first, cursor = repo.list_all(limit=2)
        second, next_cursor = repo.list_all(limit=2, cursor=cursor)

        assert len(first) == 2
        assert len(second) == 1
        assert next_cursor is None
        assert {row.run_id for row in first}.isdisjoint({row.run_id for row in second})
    finally:
        db.close()
        engine.dispose()


def test_history_api_is_read_only_and_supports_filters():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old-1", now - timedelta(days=40))
        _seed(db, "old-2", now - timedelta(days=41))
        db.commit()

        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        token = service.preview_policy().preview_token
        assert token
        first = service.apply_policy(preview_token=token)
        second = service.apply_policy()
        db.commit()

        before = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshotRetentionRun))
        response = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs",
            params={"preview_bound": "true"},
        )
        after = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshotRetentionRun))

        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 1
        assert payload["read_only"] is True
        assert payload["items"][0]["run_id"] == first.run_id
        assert payload["items"][0]["preview_bound"] is True
        assert after == before
        assert second.run_id != first.run_id
    finally:
        db.close()
        engine.dispose()


def test_history_api_cursor_and_time_range_validation():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        service.apply_policy()
        db.commit()

        first = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs",
            params={"limit": 1},
        )
        assert first.status_code == 200
        cursor = first.json()["next_cursor"]
        assert cursor

        second = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs",
            params={"limit": 1, "cursor": cursor},
        )
        assert second.status_code == 200
        assert second.json()["count"] == 1

        bad = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs",
            params={
                "start_at": "2026-09-20T00:00:00Z",
                "end_at": "2026-09-19T00:00:00Z",
            },
        )
        assert bad.status_code == 422

        invalid = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert invalid.status_code == 422
    finally:
        db.close()
        engine.dispose()
