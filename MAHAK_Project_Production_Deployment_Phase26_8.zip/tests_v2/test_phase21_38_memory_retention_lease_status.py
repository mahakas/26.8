from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_status_reports_available_without_lease():
    db, engine = _db()
    try:
        status = MemoryRetentionMaintenanceLeaseService(db).status(
            now=datetime(2026, 9, 19, 12, 0, 0)
        )
        assert status.state == "available"
        assert status.acquired_at is None
        assert status.expires_at is None
        assert status.remaining_seconds == 0
    finally:
        db.close(); engine.dispose()


def test_status_reports_held_without_revealing_owner_token():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0)
        handle = service.acquire(ttl_seconds=60, now=now)
        status = service.status(now=now + timedelta(seconds=20))
        assert status.state == "held"
        assert status.acquired_at == handle.acquired_at
        assert status.expires_at == handle.expires_at
        assert status.remaining_seconds == 40
        assert not hasattr(status, "owner_token")
        assert service.release(handle) is True
    finally:
        db.close(); engine.dispose()


def test_status_reports_expired_without_mutating_or_reclaiming():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0)
        handle = service.acquire(ttl_seconds=10, now=now)
        status = service.status(now=now + timedelta(seconds=11))
        assert status.state == "expired"
        assert status.remaining_seconds == 0
        # status() is observational; another acquire still performs the actual reclaim.
        replacement = service.acquire(ttl_seconds=30, now=now + timedelta(seconds=11))
        assert replacement.owner_token != handle.owner_token
        assert service.release(replacement) is True
    finally:
        db.close(); engine.dispose()


def test_status_does_not_change_expiration():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0)
        handle = service.acquire(ttl_seconds=120, now=now)
        before = service.status(now=now + timedelta(seconds=30))
        after = service.status(now=now + timedelta(seconds=30))
        assert before.expires_at == after.expires_at == handle.expires_at
        assert before.remaining_seconds == after.remaining_seconds == 90
        assert service.release(handle) is True
    finally:
        db.close(); engine.dispose()


def test_status_respects_time_zone_normalization():
    from datetime import UTC
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0, tzinfo=UTC)
        handle = service.acquire(ttl_seconds=30, now=now)
        status = service.status(now=now.replace(tzinfo=UTC))
        assert status.state == "held"
        assert status.expires_at == handle.expires_at
        assert status.remaining_seconds == 30
        assert service.release(handle) is True
    finally:
        db.close(); engine.dispose()
