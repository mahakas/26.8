from backend_v2.agents.evidence_fusion import CrossModalEvidenceFusion
from backend_v2.agents.types import AgentResult
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.core.enums import Capability


def _teacher():
    registry = ProviderRegistry()
    registry.register(MockProviderAdapter(
        "phase25-3",
        {Capability.CHAT},
        handler=lambda payload: {"answer": "توضیح تلفیقی"},
        default_model="fusion-v1",
    ))
    return TeacherAgent(ProviderOrchestrator(registry, ProviderHealthManager()))


def test_fusion_deduplicates_evidence_and_citations():
    fusion = CrossModalEvidenceFusion()
    item = {"type": "video", "transcript": "قانون دوم نیرو شتاب"}
    result, report = fusion.fuse([
        AgentResult("a", [item], [{"source_id": "v1", "start_time_seconds": 1.0}], 0.8),
        AgentResult("b", [dict(item)], [{"source_id": "v1", "start_time_seconds": 1.0}], 0.9),
    ])
    assert len(result.evidence) == 1
    assert len(result.citations) == 1
    assert report.evidence_count == 1


def test_fusion_detects_cross_modal_corroboration():
    fusion = CrossModalEvidenceFusion()
    result, report = fusion.fuse([
        AgentResult("doc", [{"type": "document", "text": "قانون دوم نیرو شتاب"}], [], 0.8),
        AgentResult("img", [{"type": "image", "text": "نمودار نیرو شتاب"}], [], 0.7),
        AgentResult("audio", [{"type": "audio", "transcript": "رابطه نیرو شتاب"}], [], 0.7),
    ])
    assert {"document", "image", "audio"} == set(report.modalities)
    assert report.cross_modal_links
    assert report.corroboration_score > 0
    assert result.confidence > 0.7


def test_fusion_never_creates_new_evidence():
    result, report = CrossModalEvidenceFusion().fuse([
        AgentResult("x", [{"type": "document", "text": "متن اصلی"}], [], 0.5),
    ])
    assert result.evidence == [{"type": "document", "text": "متن اصلی"}]
    assert report.evidence_count == 1


def test_fusion_teacher_preserves_evidence_and_citations():
    source = AgentResult(
        "raw",
        [{"type": "video", "transcript": "قانون دوم نیرو شتاب"}, {"type": "image", "text": "نمودار نیرو شتاب"}],
        [{"source_id": "video-1", "start_time_seconds": 2.0}],
        0.85,
    )
    report = CrossModalEvidenceFusion().fuse([source])[1].as_dict()
    result = _teacher().execute("مقایسه کن", source_result=source, fusion_report=report)
    assert result.answer == "توضیح تلفیقی"
    assert result.evidence == source.evidence
    assert result.citations == source.citations


def test_fusion_confidence_is_bounded():
    results = [AgentResult("x", [{"type": "document", "text": "a b c"}], [], 1.0) for _ in range(4)]
    _, report = CrossModalEvidenceFusion().fuse(results)
    assert 0.0 <= report.fused_confidence <= 1.0
