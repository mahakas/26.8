from __future__ import annotations

from dataclasses import replace

import pytest

from backend_v2.core.config import AppSettings, ConfigurationError, settings


def test_default_configuration_remains_development_and_mock_safe():
    assert settings.environment == "development"
    assert settings.debug is False
    assert settings.vector_store_backend == "memory"


def test_safe_dict_never_contains_secret_value():
    configured = AppSettings(secret_key="super-secret-value-123")
    safe = configured.safe_dict()
    assert safe["secret_configured"] is True
    assert "secret_key" not in safe
    assert "super-secret-value-123" not in repr(safe)
    assert "super-secret-value-123" not in repr(configured)


def test_production_requires_secret_and_hosts():
    with pytest.raises(ConfigurationError, match="MAHAK_SECRET_KEY is required"):
        AppSettings(environment="production", allowed_hosts=("example.com",)).validate()

    with pytest.raises(ConfigurationError, match="ALLOWED_HOSTS"):
        AppSettings(
            environment="production",
            secret_key="x" * 32,
            allowed_hosts=(),
        ).validate()


def test_production_rejects_debug_and_short_secret():
    with pytest.raises(ConfigurationError, match="APP_DEBUG"):
        AppSettings(
            environment="production",
            debug=True,
            secret_key="x" * 32,
            allowed_hosts=("example.com",),
        ).validate()

    with pytest.raises(ConfigurationError, match="at least 32 characters"):
        AppSettings(
            environment="production",
            secret_key="too-short",
            allowed_hosts=("example.com",),
        ).validate()


def test_validation_rejects_invalid_scalars():
    for invalid in (
        replace(settings, environment="invalid"),
        replace(settings, log_level="TRACE"),
        replace(settings, max_context_messages=0),
        replace(settings, retrieval_top_k=0),
        replace(settings, retrieval_min_score=1.5),
        replace(settings, pdf_render_dpi=0),
        replace(settings, pdf_min_text_chars_per_page=-1),
    ):
        with pytest.raises(ConfigurationError):
            invalid.validate()


def test_production_configuration_can_validate_when_complete():
    configured = AppSettings(
        environment="production",
        debug=False,
        secret_key="x" * 64,
        allowed_hosts=("api.example.com",),
        cors_origins=("https://app.example.com",),
        log_level="WARNING",
    )
    configured.validate()
    assert configured.is_production is True
    assert configured.secret_configured is True
