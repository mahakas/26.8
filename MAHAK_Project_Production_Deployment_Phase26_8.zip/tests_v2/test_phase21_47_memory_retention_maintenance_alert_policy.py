from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertPolicy, MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_alert_policy import MemoryRetentionMaintenanceAlertPolicyService


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, *, completed_at=datetime(2026, 9, 18, 0, 0)):
    db.add(
        MemoryRetentionMaintenanceRun(
            run_id="phase21-47-alert-run",
            status="completed",
            started_at=completed_at,
            completed_at=completed_at,
            dry_run=False,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=1,
            memory_planned_count=1,
            memory_executed_count=1,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=0,
            memory_would_delete_count=0,
            memory_deleted_count=0,
            history_status="completed",
            history_configured=True,
            history_retention_days=365,
            history_max_delete=500,
            history_candidate_count=0,
            history_would_delete_count=0,
            history_deleted_count=0,
        )
    )
    db.commit()


def test_alert_policy_defaults_and_persistence():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertPolicyService(db)
        default = service.get()
        assert default.stale_after_seconds == 86_400
        assert default.configured is False

        configured = service.set(stale_after_seconds=3_600)
        db.commit()
        assert configured.stale_after_seconds == 3_600
        assert configured.configured is True
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertPolicy)) == 1

        persisted = MemoryRetentionMaintenanceAlertPolicyService(db).get()
        assert persisted.stale_after_seconds == 3_600
        assert persisted.configured is True
    finally:
        db.close()
        engine.dispose()


def test_alert_policy_validation_and_reset():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertPolicyService(db)
        for invalid in (59, 31_536_001, True, False):
            try:
                service.set(stale_after_seconds=invalid)  # type: ignore[arg-type]
            except ValueError:
                pass
            else:
                raise AssertionError("invalid threshold should fail")
        assert service.reset() is False
        service.set(stale_after_seconds=1_800)
        db.commit()
        assert service.reset() is True
        db.commit()
        assert service.get().configured is False
    finally:
        db.close()
        engine.dispose()


def test_alert_policy_status_endpoint_is_read_only():
    client, db, engine = _client()
    try:
        before = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertPolicy))
        response = client.get("/api/memory/maintenance/alerts/policy")
        assert response.status_code == 200
        payload = response.json()
        assert payload["stale_after_seconds"] == 86_400
        assert payload["configured"] is False
        assert payload["read_only"] is True
        after = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertPolicy))
        assert after == before
    finally:
        db.close()
        engine.dispose()


def test_alerts_use_persisted_policy_only_when_opted_in():
    client, db, engine = _client()
    try:
        _seed(db, completed_at=(datetime.now(UTC).replace(tzinfo=None) - timedelta(hours=2)))
        MemoryRetentionMaintenanceAlertPolicyService(db).set(stale_after_seconds=3_600)
        db.commit()

        legacy_payload = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true"},
        ).json()
        assert legacy_payload["stale_after_seconds"] == 86_400
        assert all(alert["code"] != "stale_last_run" for alert in legacy_payload["alerts"])

        policy_payload = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true", "use_policy": "true"},
        ).json()
        assert policy_payload["stale_after_seconds"] == 3_600
        assert any(alert["code"] == "stale_last_run" for alert in policy_payload["alerts"])
    finally:
        db.close()
        engine.dispose()


def test_explicit_threshold_overrides_persisted_policy():
    client, db, engine = _client()
    try:
        _seed(db)
        MemoryRetentionMaintenanceAlertPolicyService(db).set(stale_after_seconds=31_536_000)
        db.commit()
        payload = client.get(
            "/api/memory/maintenance/alerts",
            params={
                "assume_enabled": "true",
                "use_policy": "true",
                "stale_after_seconds": 3_600,
            },
        ).json()
        assert payload["stale_after_seconds"] == 3_600
        assert any(alert["code"] == "stale_last_run" for alert in payload["alerts"])
    finally:
        db.close()
        engine.dispose()
