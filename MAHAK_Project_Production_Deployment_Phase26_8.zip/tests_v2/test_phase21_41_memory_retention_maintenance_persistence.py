from datetime import UTC, datetime

from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_enabled_run_persists_unified_report():
    db, engine = _db()
    try:
        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=[],
            now=datetime(2026, 9, 1, tzinfo=UTC),
            dry_run=True,
            cleanup_history=False,
        )
        row = db.get(MemoryRetentionMaintenanceRun, report.run_id)
        assert row is not None
        assert row.run_id == report.memory_report.run_id
        assert row.status == report.status
        assert row.dry_run is True
        assert row.cleanup_history is False
        assert row.history_status is None
    finally:
        db.close(); engine.dispose()


def test_history_result_is_persisted_without_memory_content():
    db, engine = _db()
    try:
        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=[],
            now=datetime.now(UTC),
            dry_run=True,
            cleanup_history=True,
        )
        row = db.get(MemoryRetentionMaintenanceRun, report.run_id)
        assert row is not None
        assert row.cleanup_history is True
        assert row.history_status == "planned"
        assert not hasattr(row, "value_json")
        assert not hasattr(row, "memory_key")
    finally:
        db.close(); engine.dispose()


def test_disabled_run_is_not_persisted():
    db, engine = _db()
    try:
        report = MemoryRetentionMaintenanceService(db, enabled=False).run_with_report()
        assert report.status == "disabled"
        assert db.get(MemoryRetentionMaintenanceRun, report.run_id) is None
    finally:
        db.close(); engine.dispose()


def test_failed_history_cleanup_still_persists_maintenance_report(monkeypatch):
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceService(db, enabled=True)

        def fail(*args, **kwargs):
            raise RuntimeError("history cleanup failure")

        monkeypatch.setattr(service, "_run_history_cleanup", fail)
        report = service.run_with_report(user_ids=[], dry_run=False, cleanup_history=True)

        assert report.status == "completed_with_errors"
        assert report.history is not None
        assert report.history.status == "failed"
        row = db.get(MemoryRetentionMaintenanceRun, report.run_id)
        assert row is not None
        assert row.history_status == "failed"
        assert row.history_error == "history cleanup failure"
    finally:
        db.close(); engine.dispose()
