from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, user_id: str):
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=5),
                updated_at=now - timedelta(days=5),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.STUDENT_PROFILE.value,
                memory_key="profile",
                value_json={"grade": 10},
                created_at=now - timedelta(days=90),
                updated_at=now - timedelta(days=90),
            ),
        ]
    )
    db.commit()


def test_default_status_is_read_only_and_uses_safe_defaults():
    client, db, engine = _client()
    try:
        _seed(db, "status-default")
        before = db.query(LearningMemory).filter(LearningMemory.user_id == "status-default").count()
        response = client.get("/api/memory/status-default/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["retention_days"] == 365
        assert payload["max_delete"] == 500
        assert payload["configured"] is False
        assert payload["candidate_count"] == 0
        assert payload["would_delete_count"] == 0
        assert payload["automatic_execution_enabled"] is False
        assert payload["execution_mode"] == "explicit_only"
        assert payload["read_only"] is True
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "status-default").count() == before
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "status-default").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_configured_status_uses_policy_filter_and_delete_cap():
    client, db, engine = _client()
    try:
        _seed(db, "status-configured")
        configured = client.put(
            "/api/memory/status-configured/retention/policy",
            json={"retention_days": 30, "max_delete": 1, "memory_type": "previous_question"},
        )
        assert configured.status_code == 200
        response = client.get("/api/memory/status-configured/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["configured"] is True
        assert payload["retention_days"] == 30
        assert payload["max_delete"] == 1
        assert payload["memory_type"] == "previous_question"
        assert payload["candidate_count"] == 1
        assert payload["would_delete_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_status_exposes_latest_retention_execution_without_leaking_memory_content():
    client, db, engine = _client()
    try:
        _seed(db, "status-last-exec")
        configured = client.put(
            "/api/memory/status-last-exec/retention/policy",
            json={"retention_days": 30, "max_delete": 10, "memory_type": "previous_question"},
        )
        assert configured.status_code == 200
        applied = client.post("/api/memory/status-last-exec/retention/policy/apply")
        assert applied.status_code == 200
        assert applied.json()["deleted_count"] == 1

        response = client.get("/api/memory/status-last-exec/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["last_execution_at"] is not None
        assert payload["last_deleted_count"] == 1
        assert payload["last_execution_memory_type"] == "previous_question"
        assert "value" not in payload
        assert "memory_key" not in payload
        assert "profile" not in response.text
    finally:
        db.close()
        engine.dispose()


def test_status_is_user_scoped():
    client, db, engine = _client()
    try:
        _seed(db, "status-owner")
        client.put(
            "/api/memory/status-owner/retention/policy",
            json={"retention_days": 30, "max_delete": 10, "memory_type": "previous_question"},
        )
        response = client.get("/api/memory/status-other/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["user_id"] == "status-other"
        assert payload["candidate_count"] == 0
        assert payload["last_execution_at"] is None
    finally:
        db.close()
        engine.dispose()


def test_status_does_not_create_audit_or_memory_rows():
    client, db, engine = _client()
    try:
        _seed(db, "status-pure-read")
        before_memories = list(db.scalars(select(LearningMemory).where(LearningMemory.user_id == "status-pure-read")))
        before_audits = db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "status-pure-read").count()
        response = client.get("/api/memory/status-pure-read/retention/status")
        assert response.status_code == 200
        after_memories = list(db.scalars(select(LearningMemory).where(LearningMemory.user_id == "status-pure-read")))
        after_audits = db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "status-pure-read").count()
        assert [row.id for row in after_memories] == [row.id for row in before_memories]
        assert after_audits == before_audits == 0
    finally:
        db.close()
        engine.dispose()
