from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def test_delete_is_scoped_to_memory_owner():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        owner = memory.remember(
            user_id="student-owner",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "2+2?"},
        )
        other = memory.remember(
            user_id="student-other",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "3+3?"},
        )
        db.commit()

        assert memory.delete("student-other", owner.id) is False
        assert memory.latest(
            "student-owner",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
        ) is not None
        assert memory.delete("student-owner", owner.id) is True
        assert memory.latest(
            "student-owner",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
        ) is None
        assert memory.latest(
            "student-other",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
        ) is not None
        assert other.id != owner.id
    finally:
        db.close()
        engine.dispose()


def test_clear_can_filter_by_type_and_conversation():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        context_a = dict(
            user_id="student-clear",
            conversation_id="conv-a",
        )
        memory.remember(
            **context_a,
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "x"},
        )
        memory.remember(
            **context_a,
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra"},
        )
        memory.remember(
            user_id="student-clear",
            conversation_id="conv-b",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:2",
            value={"question": "y"},
        )
        db.commit()

        assert memory.clear(
            "student-clear",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            conversation_id="conv-a",
        ) == 1
        remaining = memory.list("student-clear")
        assert len(remaining) == 2
        assert any(record.memory_key == "turn:1" for record in remaining)
        assert any(record.memory_key == "q:2" for record in remaining)
    finally:
        db.close()
        engine.dispose()


def test_prune_keeps_newest_records_only_and_can_be_type_specific():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        for index in range(4):
            memory.remember(
                user_id="student-prune",
                memory_type=MemoryType.LEARNING_HISTORY,
                memory_key=f"turn:{index}",
                value={"index": index},
            )
        memory.remember(
            user_id="student-prune",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"grade": "10"},
        )
        db.commit()

        assert memory.prune(
            "student-prune",
            max_records=2,
            memory_type=MemoryType.LEARNING_HISTORY,
        ) == 2
        rows = memory.list("student-prune", memory_type=MemoryType.LEARNING_HISTORY)
        assert len(rows) == 2
        assert {row.value["index"] for row in rows} == {2, 3}
        assert len(memory.list("student-prune", memory_type=MemoryType.STUDENT_PROFILE)) == 1
    finally:
        db.close()
        engine.dispose()


def test_lifecycle_validation_rejects_invalid_values():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        for callback, message in (
            (lambda: memory.delete("student", ""), "memory_id"),
            (lambda: memory.clear("student", conversation_id=""), "conversation_id"),
            (lambda: memory.prune("student", max_records=0), "max_records"),
        ):
            try:
                callback()
            except ValueError as exc:
                assert message in str(exc)
            else:
                raise AssertionError(f"Expected ValueError containing {message!r}")
    finally:
        db.close()
        engine.dispose()
