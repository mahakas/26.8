from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def test_progress_aggregates_profile_weak_areas_and_history():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"explanation_style": "step_by_step", "learning_level": "grade10"},
            confidence=0.9,
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
            value={"topic": "algebra", "status": "active", "mastery_score": 0.3},
            confidence=0.8,
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra", "agent_type": "VIDEO_AGENT", "citation_count": 2},
            confidence=0.6,
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:2",
            value={"topic": "geometry", "agent_type": "DOCUMENT_AGENT", "citation_count": 1},
            confidence=0.9,
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:latest",
            value={"question": "این معادله را توضیح بده"},
        )
        db.commit()

        profile = MemoryProgressService(memory).build("student-21-5")

        assert profile.profile["learning_level"] == "grade10"
        assert profile.active_weak_areas == ("algebra",)
        assert profile.learning_history_count == 2
        assert profile.previous_question_count == 1
        assert profile.average_confidence == 0.75
        assert profile.total_citations == 3
        assert dict(profile.agent_counts) == {"DOCUMENT_AGENT": 1, "VIDEO_AGENT": 1}
        assert profile.recent_topics == ("geometry", "algebra")
        assert profile.latest_question == "این معادله را توضیح بده"
        assert dict(profile.mastery_by_topic)["algebra"] == 0.3
    finally:
        db.close()
        engine.dispose()


def test_latest_profile_and_weak_area_state_are_used():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"learning_level": "grade9"},
        )
        db.commit()
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"learning_level": "grade10"},
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
            value={"topic": "algebra", "status": "active", "mastery_score": 0.3},
        )
        memory.remember(
            user_id="student-21-5",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
            value={"topic": "algebra", "status": "resolved", "mastery_score": 0.9},
        )
        db.commit()

        profile = MemoryProgressService(memory).build("student-21-5")

        assert profile.profile["learning_level"] == "grade10"
        assert profile.active_weak_areas == ()
        assert profile.resolved_weak_areas == ("algebra",)
        assert dict(profile.mastery_by_topic)["algebra"] == 0.9
    finally:
        db.close()
        engine.dispose()
