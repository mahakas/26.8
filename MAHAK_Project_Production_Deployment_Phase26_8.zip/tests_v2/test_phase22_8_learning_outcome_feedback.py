from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _grade(client, attempt_id: str, answer: str):
    response = client.post(
        "/api/education/attempts/grade",
        json={
            "user_id": "student-22-8",
            "attempt_id": attempt_id,
            "task_type": "quiz",
            "topic": "قانون دوم نیوتن",
            "items": [
                {
                    "item_id": "q1",
                    "question_type": "multiple_choice",
                    "question": "نیرو برابر چیست؟",
                    "topic": "قانون دوم نیوتن",
                    "answer": answer,
                    "correct_answer": "F=ma",
                    "options": ["F=ma", "F=m/a"],
                    "difficulty": "medium",
                }
            ],
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def _start(client, plan_id: str, **overrides):
    payload = {
        "user_id": "student-22-8",
        "plan_id": plan_id,
        "total_sessions": 1,
        "session_steps": 1,
        "topic": "قانون دوم نیوتن",
        "mastery_target": 0.75,
        "max_remediation_sessions": 2,
    }
    payload.update(overrides)
    response = client.post("/api/education/learning-plans/start", json=payload)
    assert response.status_code == 200, response.text
    return response.json()


def _feedback(client, plan_id: str):
    return client.post(
        "/api/education/recommendations/feedback",
        json={
            "user_id": "student-22-8",
            "learning_plan_id": plan_id,
            "task_type": "quiz",
            "question_count": 4,
        },
    )


def test_feedback_action_policy_maps_outcomes_to_loop_actions():
    from backend_v2.education.recommendation_feedback import EducationalRecommendationFeedbackService

    assert EducationalRecommendationFeedbackService._feedback_action("completed", 1) == "advance"
    assert EducationalRecommendationFeedbackService._feedback_action("at_risk", 1) == "remediate"
    assert EducationalRecommendationFeedbackService._feedback_action("blocked", 3) == "stop"
    assert EducationalRecommendationFeedbackService._feedback_action("on_track", 0) == "continue"
    assert EducationalRecommendationFeedbackService._feedback_action("on_track", 1) == "reinforce"


def test_feedback_returns_404_for_unknown_learning_plan():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        response = _feedback(client, "missing-22-8")
        assert response.status_code == 404
        assert response.json()["detail"] == "Educational learning plan was not found"
    finally:
        db.close()
        engine.dispose()


def test_empty_plan_feedback_keeps_learning_loop_on_track():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "feedback-001")
        response = _feedback(client, "feedback-001")
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["evaluated"] is True
        assert body["outcome"] == "on_track"
        assert body["plan_status"] == "active"
        assert body["feedback_action"] == "continue"
        assert body["topic"] == "قانون دوم نیوتن"
        assert body["recommendation"]["topic"] == "قانون دوم نیوتن"
        assert body["recommendation"]["generation_request"]["learning_plan_outcome"] == "on_track"
    finally:
        db.close()
        engine.dispose()


def test_at_risk_feedback_drives_targeted_remediation_generation():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "feedback-002")
        _grade(client, "feedback-at-risk", "F=m/a")
        advanced = client.post(
            "/api/education/learning-plans/feedback-002/advance",
            json={"user_id": "student-22-8", "attempt_id": "feedback-at-risk"},
        )
        assert advanced.status_code == 200, advanced.text

        response = _feedback(client, "feedback-002")
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["outcome"] == "at_risk"
        assert body["feedback_action"] == "remediate"
        assert body["recommendation"]["recommendation_type"] == "targeted_remediation"
        assert body["recommendation"]["generation_request"]["feedback_action"] == "remediate"
        assert body["recommendation"]["generation_request"]["learning_plan_outcome"] == "at_risk"
        assert body["mastery_gap"] > 0.0
        assert body["remediation_share"] > 0.0
    finally:
        db.close()
        engine.dispose()


def test_completed_feedback_drives_advancement_generation():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "feedback-003")
        _grade(client, "feedback-complete", "F=ma")
        advanced = client.post(
            "/api/education/learning-plans/feedback-003/advance",
            json={"user_id": "student-22-8", "attempt_id": "feedback-complete"},
        )
        assert advanced.status_code == 200, advanced.text
        assert advanced.json()["status"] == "completed"

        response = _feedback(client, "feedback-003")
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["outcome"] == "completed"
        assert body["feedback_action"] == "advance"
        assert body["recommendation"]["recommendation_type"] == "advancement"
        assert body["recommendation"]["difficulty"] == "hard"
        assert body["recommendation"]["generation_request"]["feedback_action"] == "advance"
        assert body["recommendation"]["generation_request"]["completion_percent"] == 100.0
    finally:
        db.close()
        engine.dispose()


def test_blocked_feedback_stops_recommendation_and_requests_new_plan():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "feedback-004", max_remediation_sessions=1)
        _grade(client, "feedback-block-1", "F=m/a")
        first = client.post(
            "/api/education/learning-plans/feedback-004/advance",
            json={"user_id": "student-22-8", "attempt_id": "feedback-block-1"},
        )
        assert first.status_code == 200, first.text
        assert first.json()["status"] == "active"

        _grade(client, "feedback-block-2", "F=m/a")
        second = client.post(
            "/api/education/learning-plans/feedback-004/advance",
            json={"user_id": "student-22-8", "attempt_id": "feedback-block-2"},
        )
        assert second.status_code == 200, second.text
        assert second.json()["status"] == "blocked"

        response = _feedback(client, "feedback-004")
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["outcome"] == "blocked"
        assert body["feedback_action"] == "stop"
        assert body["recommendation"] is None
        assert body["completion_percent"] == 100.0
        assert "blocked_plan_requires_new_plan" in body["reasons"]
    finally:
        db.close()
        engine.dispose()


def test_feedback_endpoint_is_read_only_and_stable():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "feedback-005")
        first = _feedback(client, "feedback-005")
        second = _feedback(client, "feedback-005")
        assert first.status_code == 200
        assert second.status_code == 200
        assert first.json() == second.json()
    finally:
        db.close()
        engine.dispose()
