from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceLease
from backend_v2.memory.retention_maintenance import (
    MemoryRetentionMaintenanceDistributedBusyError,
    MemoryRetentionMaintenanceService,
)
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_persistent_lease_rejects_second_owner_and_release_allows_next_owner():
    db, engine = _db()
    try:
        first = MemoryRetentionMaintenanceLeaseService(db)
        second = MemoryRetentionMaintenanceLeaseService(db)
        handle = first.acquire(ttl_seconds=60)
        try:
            try:
                second.acquire(ttl_seconds=60)
            except Exception as exc:
                assert "already held" in str(exc)
            else:
                raise AssertionError("Expected second persistent lease acquisition to fail")
        finally:
            assert first.release(handle) is True
        replacement = second.acquire(ttl_seconds=60)
        assert second.release(replacement) is True
    finally:
        db.close()
        engine.dispose()


def test_expired_persistent_lease_is_reclaimed():
    db, engine = _db()
    try:
        old = datetime(2026, 9, 19, 10, 0, 0)
        db.add(
            MemoryRetentionMaintenanceLease(
                lock_name="memory-retention-maintenance",
                owner_token="stale-owner",
                acquired_at=old - timedelta(seconds=60),
                expires_at=old - timedelta(seconds=1),
            )
        )
        db.commit()
        service = MemoryRetentionMaintenanceLeaseService(db)
        handle = service.acquire(ttl_seconds=30, now=old)
        assert handle.owner_token != "stale-owner"
        assert service.release(handle) is True
    finally:
        db.close()
        engine.dispose()


def test_persistent_guard_is_disabled_without_mutation():
    db, engine = _db()
    try:
        report = MemoryRetentionMaintenanceService(db, enabled=False).run_with_persistent_guard()
        assert report.status == "disabled"
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
    finally:
        db.close()
        engine.dispose()


def test_persistent_guard_runs_existing_maintenance_contract():
    db, engine = _db()
    try:
        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_persistent_guard(
            dry_run=True,
            cleanup_history=False,
        )
        assert report.status == "completed"
        assert report.memory_report.dry_run is True
        assert report.history is None
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
    finally:
        db.close()
        engine.dispose()


def test_persistent_guard_releases_lease_after_failure(monkeypatch):
    db, engine = _db()
    try:
        def _fail(*args, **kwargs):
            raise RuntimeError("maintenance failed")
        monkeypatch.setattr(
            "backend_v2.memory.retention_maintenance.MemoryRetentionSchedulerService.run_with_report",
            _fail,
        )
        service = MemoryRetentionMaintenanceService(db, enabled=True)
        try:
            service.run_with_persistent_guard(cleanup_history=False)
        except RuntimeError as exc:
            assert str(exc) == "maintenance failed"
        else:
            raise AssertionError("Expected persistent-guarded maintenance to fail")
        monkeypatch.undo()
        report = service.run_with_persistent_guard(dry_run=True, cleanup_history=False)
        assert report.status == "completed"
    finally:
        db.close()
        engine.dispose()


def test_persistent_guard_maps_cross_process_busy_to_existing_busy_family():
    db, engine = _db()
    try:
        lease = MemoryRetentionMaintenanceLeaseService(db)
        handle = lease.acquire(ttl_seconds=60)
        try:
            service = MemoryRetentionMaintenanceService(db, enabled=True)
            try:
                service.run_with_persistent_guard(cleanup_history=False)
            except MemoryRetentionMaintenanceDistributedBusyError as exc:
                assert "already held" in str(exc)
            else:
                raise AssertionError("Expected distributed busy guard")
        finally:
            lease.release(handle)
    finally:
        db.close()
        engine.dispose()


def test_persistent_lease_is_shared_by_independent_file_sessions(tmp_path):
    db_path = tmp_path / "maintenance_lease.db"
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db1 = Session()
    db2 = Session()
    try:
        first = MemoryRetentionMaintenanceLeaseService(db1).acquire(ttl_seconds=60)
        try:
            try:
                MemoryRetentionMaintenanceLeaseService(db2).acquire(ttl_seconds=60)
            except Exception as exc:
                assert "already held" in str(exc)
            else:
                raise AssertionError("Expected independent DB session to observe the lease")
        finally:
            MemoryRetentionMaintenanceLeaseService(db1).release(first)
    finally:
        db1.close()
        db2.close()
        engine.dispose()
