from __future__ import annotations

from pathlib import Path

from backend_v2.agents.audio import AudioAgent
from backend_v2.agents.general import GeneralAgent
from backend_v2.agents.document import DocumentAgent
from backend_v2.agents.vision import VisionAgent
from backend_v2.agents.video import VideoAgent
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.multimodal import MultimodalTeacherService
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import Capability, ChatMode, SourceType
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.api import teacher as teacher_api
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from backend_v2.ingestion.analyzer import FileAnalyzer
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.media import AudioLoader
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.audio import AudioProcessor
from backend_v2.ingestion.processors.video import TranscriptSegment
from backend_v2.schemas.teacher import TeacherModality
from backend_v2.vectorstores.base import VectorHit


def test_audio_extensions_are_supported_and_require_transcription(tmp_path):
    path = tmp_path / "lesson.mp3"
    path.write_bytes(b"audio")
    analysis = FileAnalyzer().analyze(path)
    assert analysis.source_type is SourceType.AUDIO
    assert Capability.TRANSCRIPTION in analysis.requires


def test_audio_loader_preserves_audio_identity(tmp_path):
    path = tmp_path / "lecture.wav"
    path.write_bytes(b"audio")
    analysis = FileAnalyzer().analyze(path)
    document = AudioLoader().load(analysis)
    assert document.source_type is SourceType.AUDIO
    assert document.metadata["audio_id"] == "lecture"
    assert document.metadata["source_type"] == "audio"
    assert document.requires == frozenset({Capability.TRANSCRIPTION})


def test_audio_processor_uses_srt_sidecar_without_external_transcriber(tmp_path):
    audio = tmp_path / "lesson.mp3"
    sidecar = tmp_path / "lesson.srt"
    audio.write_bytes(b"not-real-audio")
    sidecar.write_text(
        "1\n00:00:01,250 --> 00:00:03,500\nسلام امروز درباره انرژی صحبت می‌کنیم.\n\n"
        "2\n00:00:04,100 --> 00:00:05,900\nانرژی جنبشی به جرم و سرعت بستگی دارد.\n",
        encoding="utf-8",
    )
    result = IngestionPipeline(chunk_size=400, overlap=40).process(audio)
    assert result.document.metadata["transcript_present"] is True
    assert result.document.metadata["transcript_segment_count"] == 2
    assert result.required_capabilities == frozenset()
    assert len(result.chunks) == 2
    assert result.chunks[0].metadata["source_type"] == "audio"
    assert result.chunks[0].metadata["start_time_seconds"] == 1.25
    assert result.chunks[0].metadata["end_time_seconds"] == 3.5


def test_audio_processor_uses_injected_transcriber(tmp_path):
    class StubTranscriber:
        def transcribe(self, path: Path):
            return [TranscriptSegment(10.5, 12.25, "F = ma در این بخش توضیح داده می‌شود.")]

    audio = tmp_path / "physics.m4a"
    audio.write_bytes(b"audio")
    processor = AudioProcessor(transcriber=StubTranscriber())
    result = processor.process(
        ExtractedDocument(SourceType.AUDIO, "", "physics", {"audio_id": "physics"}),
        audio,
    )
    assert result.document.text.startswith("F = ma")
    assert result.document.metadata["transcription_backend"] == "StubTranscriber"
    assert result.document.metadata["transcript_language"] == "fa"
    assert result.document.requires == frozenset()


def test_missing_transcript_keeps_transcription_capability(tmp_path):
    audio = tmp_path / "silent.ogg"
    audio.write_bytes(b"audio")
    result = IngestionPipeline().process(audio)
    assert result.chunks == ()
    assert result.required_capabilities == frozenset({Capability.TRANSCRIPTION})
    assert result.document.metadata["transcript_present"] is False
    assert any("no transcript available" in warning for warning in result.warnings)


def test_audio_agent_returns_timestamped_evidence_and_citations():
    agent = AudioAgent()
    hit = VectorHit(
        "audio-1",
        0.87,
        "انرژی جنبشی با سرعت افزایش می‌یابد.",
        {
            "source_id": "lecture.mp3",
            "title": "درس انرژی",
            "source_type": "audio",
            "audio_id": "lecture",
            "start_time_seconds": 14.2,
            "end_time_seconds": 18.6,
        },
    )
    result = agent.execute("انرژی جنبشی چیست؟", hits=[hit])
    assert result.confidence == 0.87
    assert result.evidence[0]["type"] == "audio"
    assert result.evidence[0]["timestamp"] == {"start": 14.2, "end": 18.6}
    assert result.citations[0]["start_time_seconds"] == 14.2
    assert result.citations[0]["end_time_seconds"] == 18.6


def test_router_and_explicit_modality_support_audio():
    registry = AgentRegistry()
    registry.register(AudioAgent())
    registry.register(__import__("backend_v2.agents.general", fromlist=["GeneralAgent"]).GeneralAgent())
    router = AgentRouter(registry)
    assert router.classify("صدا و گفتار این درس را توضیح بده").agent_type is AgentType.AUDIO


def test_multimodal_source_scope_includes_audio_and_explicit_alias():
    from backend_v2.agents.document import DocumentAgent
    from backend_v2.agents.general import GeneralAgent
    from backend_v2.agents.vision import VisionAgent
    from backend_v2.agents.video import VideoAgent

    registry = AgentRegistry()
    registry.register(AudioAgent())
    registry.register(DocumentAgent())
    registry.register(VisionAgent())
    registry.register(VideoAgent(None))
    registry.register(GeneralAgent())
    service = MultimodalTeacherService(registry, __import__("backend_v2.agents.teacher", fromlist=["TeacherAgent"]).TeacherAgent())
    assert service.SOURCE_TYPES[AgentType.AUDIO] == ("audio",)
    context = ConversationContext("phase25-2", None, ChatMode.EDUCATIONAL)
    execution = service.execute("سؤال درباره صوت", context=context, modalities=(TeacherModality.AUDIO,), top_k=1)
    assert execution.routes[0].agent_type is AgentType.AUDIO
    assert execution.result.evidence == []


def test_teacher_api_accepts_explicit_audio_modality(monkeypatch):
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    registry = AgentRegistry()
    registry.register(AudioAgent())
    registry.register(DocumentAgent())
    registry.register(VisionAgent())
    registry.register(VideoAgent(None))
    registry.register(GeneralAgent())
    service = MultimodalTeacherService(registry, TeacherAgent())
    user = User(
        id="user-phase25-2",
        email="phase25-2@example.com",
        password_hash="x",
        display_name="Phase 25.2",
        role="student",
    )
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: user
    app.dependency_overrides[get_db] = lambda: Session()
    monkeypatch.setattr(teacher_api, "build_teacher_service", lambda: service)
    try:
        from fastapi.testclient import TestClient
        response = TestClient(app).post(
            "/api/teacher/ask",
            json={
                "conversation_id": "phase25-2-api",
                "query": "این فایل صوتی را توضیح بده",
                "mode": "educational",
                "modalities": ["audio"],
            },
        )
        assert response.status_code == 200, response.text
        payload = response.json()
        assert payload["agents"] == ["AUDIO_AGENT"]
        assert payload["modalities"] == ["audio"]
    finally:
        engine.dispose()
