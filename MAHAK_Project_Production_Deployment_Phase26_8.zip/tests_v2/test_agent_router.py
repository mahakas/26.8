from backend_v2.agents.base import BaseAgent
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentResult, AgentType


class DummyAgent(BaseAgent):
    def __init__(self, agent_type):
        self.agent_type = agent_type

    def execute(self, query: str, **kwargs):
        return AgentResult(answer=query)


def build_router():
    registry = AgentRegistry()
    for agent_type in AgentType:
        registry.register(DummyAgent(agent_type))
    return AgentRouter(registry)


def test_video_routes_to_video_agent():
    router = build_router()
    assert router.classify("show video timestamp").agent_type == AgentType.VIDEO


def test_image_routes_to_image_agent():
    router = build_router()
    assert router.classify("explain this image").agent_type == AgentType.IMAGE


def test_default_routes_to_general():
    router = build_router()
    assert router.classify("hello").agent_type == AgentType.GENERAL
