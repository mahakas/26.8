from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _export_payload(user_id: str):
    return {
        "format_version": "1.0",
        "user_id": user_id,
        "records": [
            {
                "id": "old-profile-id",
                "user_id": user_id,
                "memory_type": "student_profile",
                "memory_key": "profile",
                "value": {"grade": "10"},
                "confidence": 1.0,
                "source": "system",
            },
            {
                "id": "old-question-id",
                "user_id": user_id,
                "memory_type": "previous_question",
                "memory_key": "q-1",
                "value": {"question": "What is x?"},
                "confidence": 0.9,
                "source": "chat",
            },
        ],
    }


def test_import_restores_records_without_reusing_export_ids():
    client, db, engine = _client()
    try:
        response = client.post(
            "/api/memory/student-import-21-10/import",
            json=_export_payload("student-import-21-10"),
        )
        assert response.status_code == 201
        assert response.json() == {
            "format_version": "1.0",
            "user_id": "student-import-21-10",
            "imported_count": 2,
            "skipped_count": 0,
        }
        records = client.get("/api/memory/student-import-21-10/records").json()["items"]
        assert len(records) == 2
        assert {item["memory_key"] for item in records} == {"profile", "q-1"}
        assert {item["id"] for item in records}.isdisjoint({"old-profile-id", "old-question-id"})
    finally:
        db.close()
        engine.dispose()


def test_import_requires_same_user_scope():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-source")
        response = client.post(
            "/api/memory/student-import-target/import",
            json=payload,
        )
        assert response.status_code == 422
        assert client.get("/api/memory/student-import-target/records").json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_import_rejects_record_owned_by_another_user():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-21-10")
        payload["records"][1]["user_id"] = "other-student"
        response = client.post(
            "/api/memory/student-import-21-10/import",
            json=payload,
        )
        assert response.status_code == 422
        assert client.get("/api/memory/student-import-21-10/records").json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_import_rejects_unknown_format_version():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-version")
        payload["format_version"] = "2.0"
        response = client.post(
            "/api/memory/student-import-version/import",
            json=payload,
        )
        assert response.status_code == 422
        assert client.get("/api/memory/student-import-version/records").json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_import_is_append_only_and_exportable_after_restore():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="student-import-append",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="existing",
            value={"topic": "physics"},
        )
        db.commit()

        response = client.post(
            "/api/memory/student-import-append/import",
            json=_export_payload("student-import-append"),
        )
        assert response.status_code == 201
        assert client.get("/api/memory/student-import-append/records").json()["count"] == 3
        exported = client.get("/api/memory/student-import-append/export").json()
        assert exported["count"] == 3
    finally:
        db.close()
        engine.dispose()


def test_repeated_import_is_idempotent_and_skips_existing_content():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-idempotent")
        first = client.post("/api/memory/student-import-idempotent/import", json=payload)
        second = client.post("/api/memory/student-import-idempotent/import", json=payload)

        assert first.status_code == 201
        assert second.status_code == 201
        assert first.json()["imported_count"] == 2
        assert first.json()["skipped_count"] == 0
        assert second.json()["imported_count"] == 0
        assert second.json()["skipped_count"] == 2
        assert client.get("/api/memory/student-import-idempotent/records").json()["count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_import_ignores_historical_ids_when_fingerprinting_duplicates():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-id-agnostic")
        first = client.post("/api/memory/student-import-id-agnostic/import", json=payload)
        payload["records"][0]["id"] = "different-historical-id"
        second = client.post("/api/memory/student-import-id-agnostic/import", json=payload)

        assert first.status_code == 201
        assert second.status_code == 201
        assert second.json()["imported_count"] == 0
        assert second.json()["skipped_count"] == 2
        assert client.get("/api/memory/student-import-id-agnostic/records").json()["count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_changed_content_is_imported_as_a_new_memory():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-changed")
        first = client.post("/api/memory/student-import-changed/import", json=payload)
        payload["records"][1]["value"] = {"question": "What is y?"}
        second = client.post("/api/memory/student-import-changed/import", json=payload)

        assert first.status_code == 201
        assert second.status_code == 201
        assert second.json()["imported_count"] == 1
        assert second.json()["skipped_count"] == 1
        assert client.get("/api/memory/student-import-changed/records").json()["count"] == 3
    finally:
        db.close()
        engine.dispose()


def test_duplicate_records_inside_same_import_are_created_once():
    client, db, engine = _client()
    try:
        payload = _export_payload("student-import-batch-dup")
        payload["records"].append(dict(payload["records"][0]))
        response = client.post("/api/memory/student-import-batch-dup/import", json=payload)

        assert response.status_code == 201
        assert response.json()["imported_count"] == 2
        assert response.json()["skipped_count"] == 1
        assert client.get("/api/memory/student-import-batch-dup/records").json()["count"] == 2
    finally:
        db.close()
        engine.dispose()
