from dataclasses import dataclass

from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.video import VideoAgent
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalService
from backend_v2.vectorstores.base import VectorRecord
from backend_v2.vectorstores.embedding import EmbeddingResult
from backend_v2.vectorstores.memory import InMemoryVectorStore


@dataclass
class FixedEmbeddingService:
    def embed(self, texts):
        return EmbeddingResult(
            vectors=[[1.0, 0.0] for _ in texts],
            provider="test-embedding",
            model="fixed-v1",
            dimension=2,
        )


def _retrieval() -> RetrievalService:
    store = InMemoryVectorStore()
    store.upsert(
        [
            VectorRecord(
                "video-hit-1",
                [1.0, 0.0],
                "قانون دوم نیوتن در ویدیو و رابطه F = ma.",
                {
                    "source_id": "video-1",
                    "title": "Physics lecture",
                    "source_type": "video",
                    "kind": "transcript",
                    "start_time_seconds": 54.5,
                    "end_time_seconds": 57.3,
                    "frame_path": "frames/frame-054.jpg",
                    "frame_timestamp_seconds": 55.0,
                    "grade_id": "10",
                    "subject_id": "physics",
                },
            )
        ],
        collection="video-test",
    )
    return RetrievalService(store, FixedEmbeddingService())


def test_video_agent_uses_existing_retrieval_service():
    service = _retrieval()
    agent = VideoAgent(
        service,
        collection="video-test",
        scope=RetrievalScope(grade_id="10", subject_id="physics"),
    )

    result = agent.execute("قانون دوم نیوتن در ویدیو")

    assert result.evidence
    assert result.citations
    assert result.evidence[0]["timestamp"] == {"start": 54.5, "end": 57.3}
    assert result.evidence[0]["frame_path"] == "frames/frame-054.jpg"
    assert result.citations[0]["start_time_seconds"] == 54.5
    assert result.citations[0]["end_time_seconds"] == 57.3


def test_router_can_execute_video_agent_against_existing_retrieval():
    registry = AgentRegistry()
    registry.register(
        VideoAgent(
            _retrieval(),
            collection="video-test",
            scope=RetrievalScope(grade_id="10", subject_id="physics"),
        )
    )
    router = AgentRouter(registry)

    result = router.execute("show the video timestamp for newton law")

    assert result.citations[0]["title"] == "Physics lecture"
    assert result.citations[0]["frame_path"] == "frames/frame-054.jpg"
