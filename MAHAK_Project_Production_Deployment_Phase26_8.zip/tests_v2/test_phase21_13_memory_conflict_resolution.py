from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _record_payload(user_id: str, value: str):
    return {
        "id": "snapshot-id",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": "profile",
        "value": {"grade": value},
        "confidence": 1.0,
        "source": "snapshot",
    }


def test_append_policy_preserves_existing_behavior_and_reports_conflict():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-append"
        assert client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record_payload(user_id, "10")]},
        ).status_code == 201
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record_payload(user_id, "11")]},
        )
        assert response.status_code == 201
        assert response.json()["imported_count"] == 1
        assert response.json()["conflict_count"] == 1
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_skip_policy_reports_and_avoids_logical_conflict():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-skip"
        seed = _record_payload(user_id, "10")
        assert client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [seed]},
        ).status_code == 201
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "conflict_policy": "skip",
                "records": [_record_payload(user_id, "11")],
            },
        )
        assert response.status_code == 201
        assert response.json()["imported_count"] == 0
        assert response.json()["skipped_count"] == 1
        assert response.json()["conflict_count"] == 1
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_reject_policy_is_transactional_and_does_not_partially_import():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-reject"
        seed = _record_payload(user_id, "10")
        assert client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [seed]},
        ).status_code == 201
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "conflict_policy": "reject",
                "records": [
                    _record_payload(user_id, "11"),
                    {
                        **_record_payload(user_id, "12"),
                        "memory_key": "new-profile",
                    },
                ],
            },
        )
        assert response.status_code == 409
        assert response.json()["detail"]["conflict_count"] == 1
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_repeated_exact_duplicate_is_not_counted_as_conflict():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-duplicate"
        payload = {"user_id": user_id, "records": [_record_payload(user_id, "10")]}
        assert client.post(f"/api/memory/{user_id}/import", json=payload).status_code == 201
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={**payload, "conflict_policy": "skip"},
        )
        assert response.status_code == 201
        assert response.json()["skipped_count"] == 1
        assert "conflict_count" not in response.json()
    finally:
        db.close()
        engine.dispose()


def test_conflict_inside_same_batch_is_resolved_by_policy():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-batch"
        first = _record_payload(user_id, "10")
        second = _record_payload(user_id, "11")
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "conflict_policy": "skip",
                "records": [first, second],
            },
        )
        assert response.status_code == 201
        assert response.json()["imported_count"] == 1
        assert response.json()["skipped_count"] == 1
        assert response.json()["conflict_count"] == 1
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_invalid_conflict_policy_is_rejected():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-invalid"
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "conflict_policy": "replace",
                "records": [],
            },
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_default_policy_response_keeps_legacy_shape():
    client, db, engine = _client()
    try:
        user_id = "student-conflict-legacy-response"
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record_payload(user_id, "10")]},
        )
        assert response.status_code == 201
        assert "conflict_policy" not in response.json()
        assert "conflict_count" not in response.json()
    finally:
        db.close()
        engine.dispose()