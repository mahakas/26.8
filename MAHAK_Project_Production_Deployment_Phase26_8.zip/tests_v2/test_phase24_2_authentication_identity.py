from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.auth.passwords import verify_password
from backend_v2.auth.tokens import create_access_token, decode_access_token
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import AuthSession, User


def _client():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), engine, Session, app


def test_register_stores_hashed_password_and_returns_identity():
    client, engine, Session, app = _client()
    response = client.post(
        "/api/auth/register",
        json={"email": " Student@Example.com ", "password": "StrongPass123!", "display_name": "  Student  One "},
    )
    assert response.status_code == 201, response.text
    payload = response.json()
    assert payload["email"] == "student@example.com"
    assert payload["display_name"] == "Student One"
    assert payload["is_active"] is True
    assert "password" not in payload

    db = Session()
    user = db.query(User).filter_by(email="student@example.com").one()
    assert user.password_hash != "StrongPass123!"
    assert verify_password("StrongPass123!", user.password_hash)
    db.close()
    engine.dispose()


def test_login_issues_access_and_refresh_tokens():
    client, engine, Session, app = _client()
    client.post("/api/auth/register", json={"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"})
    response = client.post("/api/auth/login", json={"email": "STUDENT@EXAMPLE.COM", "password": "StrongPass123!"})
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["token_type"] == "bearer"
    assert payload["access_token"]
    assert payload["refresh_token"]
    assert payload["expires_in"] == 30 * 60
    assert payload["user"]["email"] == "student@example.com"
    db = Session()
    assert db.query(AuthSession).count() == 1
    db.close()
    engine.dispose()


def test_me_requires_bearer_and_resolves_identity():
    client, engine, Session, app = _client()
    assert client.get("/api/auth/me").status_code == 401
    client.post("/api/auth/register", json={"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"})
    login = client.post("/api/auth/login", json={"email": "student@example.com", "password": "StrongPass123!"}).json()
    response = client.get("/api/auth/me", headers={"Authorization": f"Bearer {login['access_token']}"})
    assert response.status_code == 200, response.text
    assert response.json()["email"] == "student@example.com"
    engine.dispose()


def test_invalid_password_is_rejected_without_leaking_identity():
    client, engine, Session, app = _client()
    client.post("/api/auth/register", json={"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"})
    response = client.post("/api/auth/login", json={"email": "student@example.com", "password": "wrong-password"})
    assert response.status_code == 401
    assert response.json()["detail"] == "invalid email or password"
    engine.dispose()


def test_refresh_rotates_token_and_old_refresh_is_rejected():
    client, engine, Session, app = _client()
    client.post("/api/auth/register", json={"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"})
    first = client.post("/api/auth/login", json={"email": "student@example.com", "password": "StrongPass123!"}).json()
    second_response = client.post("/api/auth/refresh", json={"refresh_token": first["refresh_token"]})
    assert second_response.status_code == 200, second_response.text
    second = second_response.json()
    assert second["refresh_token"] != first["refresh_token"]
    assert client.post("/api/auth/refresh", json={"refresh_token": first["refresh_token"]}).status_code == 401
    engine.dispose()


def test_logout_revokes_refresh_session():
    client, engine, Session, app = _client()
    client.post("/api/auth/register", json={"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"})
    login = client.post("/api/auth/login", json={"email": "student@example.com", "password": "StrongPass123!"}).json()
    assert client.post("/api/auth/logout", json={"refresh_token": login["refresh_token"]}).status_code == 204
    assert client.post("/api/auth/refresh", json={"refresh_token": login["refresh_token"]}).status_code == 401
    engine.dispose()


def test_duplicate_registration_is_conflict():
    client, engine, Session, app = _client()
    body = {"email": "student@example.com", "password": "StrongPass123!", "display_name": "Student"}
    assert client.post("/api/auth/register", json=body).status_code == 201
    duplicate = client.post("/api/auth/register", json=body)
    assert duplicate.status_code == 409
    assert duplicate.json()["detail"] == "email is already registered"
    engine.dispose()


def test_access_token_signature_and_expiry_are_enforced():
    token = create_access_token("user-1", expires_in_seconds=60)
    payload = decode_access_token(token)
    assert payload["sub"] == "user-1"
    assert payload["type"] == "access"

    header, body, signature = token.split(".")
    tampered = f"{header}.{body[:-1]}{'A' if body[-1] != 'A' else 'B'}.{signature}"
    try:
        decode_access_token(tampered)
    except ValueError:
        pass
    else:
        raise AssertionError("tampered token must be rejected")
