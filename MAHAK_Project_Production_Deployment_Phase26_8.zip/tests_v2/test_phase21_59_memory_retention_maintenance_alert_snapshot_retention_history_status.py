from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
)
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
)


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed_run(db, run_id: str, completed_at: datetime, *, preview_bound: bool = False) -> None:
    db.add(
        MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
            run_id=run_id,
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            older_than=completed_at - timedelta(days=30),
            retention_days=30,
            max_delete=500,
            configured=True,
            preview_bound=preview_bound,
            candidate_count=3,
            deleted_count=2,
        )
    )
    db.commit()


def test_default_status_is_read_only_and_uses_safe_defaults():
    client, db, engine = _client()
    try:
        before = db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionRun).count()
        response = client.get("/api/memory/maintenance/alert-snapshots/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["retention_days"] == 365
        assert payload["max_delete"] == 500
        assert payload["configured"] is False
        assert payload["candidate_count"] == 0
        assert payload["would_delete_count"] == 0
        assert payload["automatic_execution_enabled"] is False
        assert payload["execution_mode"] == "explicit_only"
        assert payload["last_execution_at"] is None
        assert payload["last_candidate_count"] is None
        assert payload["last_deleted_count"] is None
        assert payload["last_preview_bound"] is None
        assert payload["read_only"] is True
        assert "preview_token" not in payload
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionRun).count() == before
    finally:
        db.close()
        engine.dispose()


def test_configured_status_uses_policy_and_current_candidate_set():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "status-old", now - timedelta(days=20))
        _seed_run(db, "status-new", now - timedelta(days=2))
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=1)
        db.commit()

        response = client.get("/api/memory/maintenance/alert-snapshots/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["configured"] is True
        assert payload["retention_days"] == 7
        assert payload["max_delete"] == 1
        assert payload["candidate_count"] == 1
        assert payload["would_delete_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_status_exposes_latest_execution_without_history_content():
    client, db, engine = _client()
    try:
        completed_at = datetime.now(UTC).replace(tzinfo=None) - timedelta(hours=1)
        _seed_run(db, "status-latest", completed_at, preview_bound=True)
        response = client.get("/api/memory/maintenance/alert-snapshots/retention/status")
        assert response.status_code == 200
        payload = response.json()
        assert payload["last_execution_at"] is not None
        assert payload["last_candidate_count"] == 3
        assert payload["last_deleted_count"] == 2
        assert payload["last_preview_bound"] is True
        assert "run_id" not in payload
        assert "candidate_ids" not in response.text
    finally:
        db.close()
        engine.dispose()


def test_status_uses_most_recent_started_execution():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "status-older", now - timedelta(hours=2))
        _seed_run(db, "status-newer", now - timedelta(minutes=10), preview_bound=False)
        response = client.get("/api/memory/maintenance/alert-snapshots/retention/status")
        payload = response.json()
        assert response.status_code == 200
        assert payload["last_deleted_count"] == 2
        assert payload["last_preview_bound"] is False
    finally:
        db.close()
        engine.dispose()


def test_service_status_does_not_persist_or_delete_rows():
    db_engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(db_engine)
    db = sessionmaker(bind=db_engine, autoflush=False, expire_on_commit=False)()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "service-status", now - timedelta(days=400))
        before_ids = list(db.scalars(select(MemoryRetentionMaintenanceAlertSnapshotRetentionRun.run_id)).all())
        status = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).status()
        after_ids = list(db.scalars(select(MemoryRetentionMaintenanceAlertSnapshotRetentionRun.run_id)).all())
        assert status.read_only is True
        assert before_ids == after_ids == ["service-status"]
    finally:
        db.close()
        db_engine.dispose()


def test_status_would_delete_count_respects_policy_cap():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        for index in range(3):
            _seed_run(db, f"cap-{index}", now - timedelta(days=10 + index))
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db).set(
            retention_days=7,
            max_delete=2,
        )
        db.commit()
        payload = client.get("/api/memory/maintenance/alert-snapshots/retention/status").json()
        assert payload["candidate_count"] == 3
        assert payload["would_delete_count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_status_is_independent_of_preview_binding():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "preview-status", now - timedelta(days=400))
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview_policy()
        assert preview.preview_token
        payload = client.get("/api/memory/maintenance/alert-snapshots/retention/status").json()
        assert payload["candidate_count"] == 1
        assert "preview_token" not in payload
    finally:
        db.close()
        engine.dispose()
