from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, user_id: str) -> None:
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-question",
                value_json={"q": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent-question",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=5),
                updated_at=now - timedelta(days=5),
            ),
        ]
    )
    db.commit()


def _policy(client: TestClient, user_id: str, retention_days: int = 30, max_delete: int = 10):
    response = client.put(
        f"/api/memory/{user_id}/retention/policy",
        json={
            "retention_days": retention_days,
            "max_delete": max_delete,
            "memory_type": "previous_question",
        },
    )
    assert response.status_code == 200


def test_policy_preview_returns_binding_token_and_is_read_only():
    client, db, engine = _client()
    try:
        _seed(db, "binding-preview")
        _policy(client, "binding-preview")
        before = db.query(LearningMemory).filter(LearningMemory.user_id == "binding-preview").count()
        response = client.post("/api/memory/binding-preview/retention/policy/preview")
        assert response.status_code == 200
        payload = response.json()
        assert len(payload["preview_token"]) > 64
        assert payload["candidate_count"] == 1
        after = db.query(LearningMemory).filter(LearningMemory.user_id == "binding-preview").count()
        assert before == after == 2
    finally:
        db.close()
        engine.dispose()


def test_bound_apply_uses_same_preview_cutoff_and_deletes_expected_record():
    client, db, engine = _client()
    try:
        _seed(db, "binding-apply")
        _policy(client, "binding-apply")
        preview = client.post("/api/memory/binding-apply/retention/policy/preview")
        token = preview.json()["preview_token"]
        response = client.post(
            "/api/memory/binding-apply/retention/policy/apply",
            params={"preview_token": token},
        )
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 1
        remaining = list(
            db.scalars(select(LearningMemory).where(LearningMemory.user_id == "binding-apply"))
        )
        assert [row.memory_key for row in remaining] == ["recent-question"]
    finally:
        db.close()
        engine.dispose()


def test_bound_apply_rejects_changed_memory_state_and_preserves_data():
    client, db, engine = _client()
    try:
        _seed(db, "binding-state")
        _policy(client, "binding-state")
        preview = client.post("/api/memory/binding-state/retention/policy/preview")
        token = preview.json()["preview_token"]
        db.add(
            LearningMemory(
                user_id="binding-state",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="new-expired",
                value_json={"q": "new"},
                created_at=datetime.now(UTC).replace(tzinfo=None) - timedelta(days=90),
                updated_at=datetime.now(UTC).replace(tzinfo=None) - timedelta(days=90),
            )
        )
        db.commit()
        response = client.post(
            "/api/memory/binding-state/retention/policy/apply",
            params={"preview_token": token},
        )
        assert response.status_code == 409
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "binding-state").count() == 3
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "binding-state").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_bound_apply_rejects_changed_policy_and_preserves_data():
    client, db, engine = _client()
    try:
        _seed(db, "binding-policy")
        _policy(client, "binding-policy", retention_days=30, max_delete=10)
        preview = client.post("/api/memory/binding-policy/retention/policy/preview")
        token = preview.json()["preview_token"]
        _policy(client, "binding-policy", retention_days=10, max_delete=10)
        response = client.post(
            "/api/memory/binding-policy/retention/policy/apply",
            params={"preview_token": token},
        )
        assert response.status_code == 409
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "binding-policy").count() == 2
    finally:
        db.close()
        engine.dispose()


def test_invalid_preview_token_returns_422_and_unbound_apply_remains_compatible():
    client, db, engine = _client()
    try:
        _seed(db, "binding-invalid")
        _policy(client, "binding-invalid")
        invalid = client.post(
            "/api/memory/binding-invalid/retention/policy/apply",
            params={"preview_token": "x" * 64},
        )
        assert invalid.status_code == 409 or invalid.status_code == 422
        unbound = client.post("/api/memory/binding-invalid/retention/policy/apply")
        assert unbound.status_code == 200
        assert unbound.json()["deleted_count"] == 1
    finally:
        db.close()
        engine.dispose()
