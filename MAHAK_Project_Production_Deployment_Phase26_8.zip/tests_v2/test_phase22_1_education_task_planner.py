from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.education import (
    EducationalDifficulty,
    EducationalTaskPlanner,
    EducationalTaskPlanningRequest,
)
from backend_v2.memory.progress import StudentProgressProfile


def test_adaptive_difficulty_uses_active_weak_area():
    progress = StudentProgressProfile(
        user_id="student-1",
        profile={},
        active_weak_areas=("قانون دوم نیوتن",),
        mastery_by_topic=(("قانون دوم نیوتن", 0.35),),
    )
    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            topic="قانون دوم نیوتن",
            difficulty=EducationalDifficulty.ADAPTIVE,
            question_count=6,
        ),
        progress=progress,
    )
    assert plan.difficulty == EducationalDifficulty.EASY
    assert plan.memory_used is True
    assert "active_weak_area" in plan.reasons


def test_adaptive_difficulty_uses_high_mastery_for_hard_tasks():
    progress = StudentProgressProfile(
        user_id="student-1",
        profile={},
        mastery_by_topic=(("مشتق", 0.92),),
    )
    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            topic="مشتق",
            difficulty=EducationalDifficulty.ADAPTIVE,
            question_count=5,
        ),
        progress=progress,
    )
    assert plan.difficulty == EducationalDifficulty.HARD


def test_explicit_difficulty_is_respected():
    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            difficulty=EducationalDifficulty.HARD,
            question_count=3,
            topic="فیزیک",
        )
    )
    assert plan.difficulty == EducationalDifficulty.HARD
    assert "explicit_difficulty_requested" in plan.reasons


def test_default_focus_uses_weak_areas_then_recent_topics():
    progress = StudentProgressProfile(
        user_id="student-1",
        profile={},
        active_weak_areas=("جبر", "معادله"),
        recent_topics=("فیزیک", "هندسه"),
    )
    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(question_count=4),
        progress=progress,
    )
    assert plan.topic == "جبر"
    assert plan.focus_topics[:2] == ("جبر", "معادله")


def test_plan_endpoint_without_user_memory():
    client = TestClient(create_app())
    response = client.post(
        "/api/education/tasks/plan",
        json={
            "task_type": "quiz",
            "difficulty": "adaptive",
            "question_count": 4,
            "topic": "قانون دوم نیوتن",
            "grade_id": "10",
            "subject_id": "physics",
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["topic"] == "قانون دوم نیوتن"
    assert body["question_count"] == 4
    assert body["content_generation"] == "deferred_to_phase22_2"
