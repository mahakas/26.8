from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _grade(client, *, attempt_id: str, answer: str, topic: str = "قانون دوم نیوتن"):
    response = client.post(
        "/api/education/attempts/grade",
        json={
            "user_id": "student-22-5",
            "attempt_id": attempt_id,
            "task_type": "quiz",
            "topic": topic,
            "items": [
                {
                    "item_id": "q1",
                    "question_type": "multiple_choice",
                    "question": "نیرو برابر چیست؟",
                    "topic": topic,
                    "answer": answer,
                    "correct_answer": "F=ma",
                    "options": ["F=ma", "F=m/a"],
                    "difficulty": "medium",
                }
            ],
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def test_start_learning_session_returns_first_adaptive_step():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        response = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-001",
                "total_steps": 3,
                "question_count": 4,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["status"] == "active"
        assert body["current_step"] == 1
        assert body["completed_steps"] == 0
        assert body["recommendation"]["topic"] == "قانون دوم نیوتن"
        assert body["recommendation"]["generation_request"]["question_count"] == 4
    finally:
        db.close()
        engine.dispose()


def test_advance_uses_real_attempt_result_and_adapts_next_step():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-002",
                "total_steps": 3,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text

        graded = _grade(client, attempt_id="attempt-002", answer="F=m/a")
        assert graded["total_score"] == 0.0

        advanced = client.post(
            "/api/education/sessions/session-002/advance",
            json={"user_id": "student-22-5", "attempt_id": "attempt-002"},
        )
        assert advanced.status_code == 200, advanced.text
        body = advanced.json()
        assert body["completed_steps"] == 1
        assert body["current_step"] == 2
        assert body["status"] == "active"
        assert body["step_results"][0]["attempt_id"] == "attempt-002"
        assert body["step_results"][0]["score"] == 0.0
        assert body["recommendation"]["topic"] == "قانون دوم نیوتن"
        assert body["recommendation"]["recommendation_type"] == "targeted_remediation"
        assert body["recommendation"]["difficulty"] == "easy"
        assert "next_step_adapted" in body["reasons"]
    finally:
        db.close()
        engine.dispose()


def test_replaying_same_attempt_is_idempotent():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-003",
                "total_steps": 2,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text
        _grade(client, attempt_id="attempt-003", answer="F=ma")

        first = client.post(
            "/api/education/sessions/session-003/advance",
            json={"user_id": "student-22-5", "attempt_id": "attempt-003"},
        )
        replay = client.post(
            "/api/education/sessions/session-003/advance",
            json={"user_id": "student-22-5", "attempt_id": "attempt-003"},
        )
        assert first.status_code == 200
        assert replay.status_code == 200
        body = replay.json()
        assert body["idempotent_replay"] is True
        assert body["completed_steps"] == 1
        assert len(body["step_results"]) == 1
    finally:
        db.close()
        engine.dispose()


def test_two_step_session_completes_after_second_attempt():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-004",
                "total_steps": 2,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text

        _grade(client, attempt_id="attempt-004a", answer="F=ma")
        first = client.post(
            "/api/education/sessions/session-004/advance",
            json={"user_id": "student-22-5", "attempt_id": "attempt-004a"},
        )
        assert first.status_code == 200

        _grade(client, attempt_id="attempt-004b", answer="F=ma")
        second = client.post(
            "/api/education/sessions/session-004/advance",
            json={"user_id": "student-22-5", "attempt_id": "attempt-004b"},
        )
        assert second.status_code == 200, second.text
        body = second.json()
        assert body["status"] == "completed"
        assert body["completed_steps"] == 2
        assert body["recommendation"] is None
        assert len(body["step_results"]) == 2
    finally:
        db.close()
        engine.dispose()


def test_get_session_returns_persisted_state_and_start_is_idempotent():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        first = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-005",
                "total_steps": 2,
                "topic": "قانون دوم نیوتن",
            },
        )
        second = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "student-22-5",
                "session_id": "session-005",
                "total_steps": 2,
                "topic": "موضوع دیگر",
            },
        )
        fetched = client.get(
            "/api/education/sessions/session-005",
            params={"user_id": "student-22-5"},
        )
        assert first.status_code == 200
        assert second.status_code == 200
        assert fetched.status_code == 200
        assert second.json()["session_id"] == "session-005"
        assert second.json()["target_topic"] == "قانون دوم نیوتن"
        assert fetched.json() == second.json()
    finally:
        db.close()
        engine.dispose()
