from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionRun, MemoryRetentionRunResult
from backend_v2.memory.retention_run_history import MemoryRetentionRunHistoryService
from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_run(db, run_id: str, completed_at: datetime, user_id: str) -> None:
    db.add(
        MemoryRetentionRun(
            run_id=run_id,
            status="completed",
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            dry_run=False,
            user_count=1,
            planned_count=0,
            executed_count=1,
            skipped_count=0,
            failed_count=0,
            candidate_count=1,
            would_delete_count=1,
            deleted_count=1,
        )
    )
    db.add(
        MemoryRetentionRunResult(
            run_id=run_id,
            user_id=user_id,
            status="executed",
            candidate_count=1,
            deleted_count=1,
            would_delete_count=1,
            dry_run=False,
            retention_days=30,
            executed_at=completed_at,
        )
    )
    db.commit()


def test_policy_preview_uses_effective_defaults_and_is_read_only():
    db, engine = _db()
    try:
        old = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=400)
        _seed_run(db, "default-old", old, "student")
        preview = MemoryRetentionRunHistoryService(db).preview_policy()
        assert preview.configured is False
        assert preview.retention_days == 365
        assert preview.max_delete == 500
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert db.get(MemoryRetentionRun, "default-old") is not None
    finally:
        db.close()
        engine.dispose()


def test_policy_preview_uses_persisted_policy():
    db, engine = _db()
    try:
        _seed_run(db, "policy-old", datetime.now(UTC).replace(tzinfo=None) - timedelta(days=20), "student")
        policy = MemoryRetentionRunHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=10)
        db.commit()
        preview = MemoryRetentionRunHistoryService(db).preview_policy()
        assert preview.configured is True
        assert preview.retention_days == 7
        assert preview.max_delete == 10
        assert preview.candidate_count == 1
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_respects_max_delete_and_keeps_remaining_candidates():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "policy-old-a", now - timedelta(days=20), "a")
        _seed_run(db, "policy-old-b", now - timedelta(days=10), "b")
        policy = MemoryRetentionRunHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=1)
        db.commit()
        result = MemoryRetentionRunHistoryService(db).apply_policy()
        assert result.configured is True
        assert result.retention_days == 7
        assert result.max_delete == 1
        assert result.candidate_count == 2
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionRun, "policy-old-a") is None
        assert db.get(MemoryRetentionRun, "policy-old-b") is not None
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_deletes_parent_and_child_rows():
    db, engine = _db()
    try:
        old = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=20)
        _seed_run(db, "policy-delete", old, "student")
        MemoryRetentionRunHistoryPolicyService(db).set(retention_days=7, max_delete=10)
        db.commit()
        MemoryRetentionRunHistoryService(db).apply_policy()
        assert db.get(MemoryRetentionRun, "policy-delete") is None
        assert db.scalar(
            select(MemoryRetentionRunResult).where(MemoryRetentionRunResult.run_id == "policy-delete")
        ) is None
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_does_not_delete_new_runs():
    db, engine = _db()
    try:
        new = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=2)
        _seed_run(db, "policy-new", new, "student")
        MemoryRetentionRunHistoryPolicyService(db).set(retention_days=7, max_delete=10)
        db.commit()
        result = MemoryRetentionRunHistoryService(db).apply_policy()
        assert result.candidate_count == 0
        assert result.deleted_count == 0
        assert db.get(MemoryRetentionRun, "policy-new") is not None
    finally:
        db.close()
        engine.dispose()
