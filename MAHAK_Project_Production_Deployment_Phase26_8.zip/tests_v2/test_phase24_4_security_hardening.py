from __future__ import annotations

from dataclasses import replace

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api import app as app_module
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.core.config import AppSettings, ConfigurationError
from backend_v2.database.connection import Base
from backend_v2.security.hardening import InMemoryRateLimiter, client_ip


def _client(*, limiter=None):
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    if limiter is not None:
        from backend_v2.security.hardening import RateLimitMiddleware

        app.add_middleware(RateLimitMiddleware, limiter=limiter, requests=2, window_seconds=60, auth_requests=2, auth_window_seconds=60)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), engine


def test_security_headers_are_present_by_default():
    client, engine = _client()
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "no-referrer"
    assert response.headers["Permissions-Policy"] == "geolocation=(), microphone=(), camera=()"
    engine.dispose()


def test_auth_responses_are_not_cacheable():
    client, engine = _client()
    response = client.post(
        "/api/auth/register",
        json={"email": "cache@example.com", "password": "StrongPass123!", "display_name": "Cache"},
    )
    assert response.status_code == 201
    assert response.headers["Cache-Control"] == "no-store"
    engine.dispose()


def test_in_memory_rate_limiter_is_deterministic():
    limiter = InMemoryRateLimiter()
    assert limiter.check("client", limit=2, window_seconds=60).allowed
    decision = limiter.check("client", limit=2, window_seconds=60)
    assert decision.allowed
    assert decision.remaining == 0
    blocked = limiter.check("client", limit=2, window_seconds=60)
    assert not blocked.allowed
    assert blocked.retry_after >= 1


def test_auth_route_rate_limit_returns_429_and_retry_after():
    from fastapi import FastAPI
    from backend_v2.security.hardening import RateLimitMiddleware

    limiter = InMemoryRateLimiter()
    app = FastAPI()
    app.add_middleware(
        RateLimitMiddleware,
        limiter=limiter,
        requests=120,
        window_seconds=60,
        auth_requests=1,
        auth_window_seconds=60,
    )

    @app.post("/api/auth/login")
    def login():
        return {"detail": "invalid email or password"}

    client = TestClient(app)
    assert client.post("/api/auth/login").status_code == 200
    blocked = client.post("/api/auth/login")
    assert blocked.status_code == 429
    assert blocked.json()["detail"] == "rate limit exceeded"
    assert int(blocked.headers["Retry-After"]) >= 1


def test_generic_api_rate_limit_is_separate_from_auth_limit():
    from fastapi import FastAPI
    from backend_v2.security.hardening import RateLimitMiddleware

    app = FastAPI()
    app.add_middleware(
        RateLimitMiddleware,
        limiter=InMemoryRateLimiter(),
        requests=2,
        window_seconds=60,
        auth_requests=10,
        auth_window_seconds=60,
    )

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    client = TestClient(app)
    assert client.get("/api/health").status_code == 200
    assert client.get("/api/health").status_code == 200
    assert client.get("/api/health").status_code == 429


def test_rate_limit_headers_are_exposed_on_success():
    from fastapi import FastAPI
    from backend_v2.security.hardening import RateLimitMiddleware

    app = FastAPI()
    app.add_middleware(
        RateLimitMiddleware,
        limiter=InMemoryRateLimiter(),
        requests=2,
        window_seconds=60,
        auth_requests=10,
        auth_window_seconds=60,
    )

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    response = TestClient(app).get("/api/health")
    assert response.headers["X-RateLimit-Limit"] == "2"
    assert response.headers["X-RateLimit-Remaining"] == "1"


def test_forwarded_ip_helper_uses_real_client_by_default():
    from types import SimpleNamespace
    from starlette.requests import Request

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/",
        "headers": [(b"x-forwarded-for", b"203.0.113.5")],
        "client": ("127.0.0.1", 1234),
        "server": ("testserver", 80),
        "scheme": "http",
        "query_string": b"",
    }
    request = Request(scope)
    assert client_ip(request) == "127.0.0.1"



def test_production_settings_reject_wildcard_cors():
    settings = AppSettings(
        environment="production",
        debug=False,
        secret_key="s" * 48,
        allowed_hosts=("api.example.com",),
        cors_origins=("*",),
    )
    try:
        settings.validate()
    except ConfigurationError as exc:
        assert "wildcard CORS_ORIGINS" in str(exc)
    else:
        raise AssertionError("production wildcard CORS must be rejected")


def test_production_docs_default_to_disabled():
    production = AppSettings(
        environment="production",
        debug=False,
        secret_key="s" * 48,
        allowed_hosts=("api.example.com",),
    )
    development = AppSettings(environment="development")
    assert production.api_docs_enabled is False
    assert development.api_docs_enabled is True


def test_existing_auth_and_rbac_paths_remain_available():
    client, engine = _client()
    registered = client.post(
        "/api/auth/register",
        json={"email": "compat@example.com", "password": "StrongPass123!", "display_name": "Compat"},
    )
    assert registered.status_code == 201
    login = client.post("/api/auth/login", json={"email": "compat@example.com", "password": "StrongPass123!"})
    assert login.status_code == 200
    token = login.json()["access_token"]
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    engine.dispose()
