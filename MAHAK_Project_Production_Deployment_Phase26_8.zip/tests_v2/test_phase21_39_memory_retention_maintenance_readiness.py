from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionPolicy
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService
from backend_v2.memory.retention_maintenance_readiness import (
    MemoryRetentionMaintenanceReadinessService,
)
from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_disabled_readiness_is_not_ready_and_is_read_only():
    db, engine = _db()
    try:
        now = datetime(2026, 9, 19, 12, 0, 0, tzinfo=UTC)
        snapshot = MemoryRetentionMaintenanceReadinessService(db, enabled=False).snapshot(now=now)
        assert snapshot.ready is False
        assert snapshot.reasons == ("maintenance_disabled",)
        assert snapshot.execution_mode == "explicit_only"
        assert snapshot.automatic_execution_enabled is False
        assert snapshot.read_only is True
        assert snapshot.lease.state == "available"
    finally:
        db.close(); engine.dispose()


def test_enabled_readiness_is_ready_when_lease_is_available():
    db, engine = _db()
    try:
        snapshot = MemoryRetentionMaintenanceReadinessService(db, enabled=True).snapshot(
            now=datetime(2026, 9, 19, 12, 0, 0)
        )
        assert snapshot.ready is True
        assert snapshot.reasons == ()
        assert snapshot.lease.state == "available"
        assert snapshot.configured_memory_policy_users == 0
        assert snapshot.run_history_policy.configured is False
    finally:
        db.close(); engine.dispose()


def test_readiness_reports_held_lease_without_mutating_it():
    db, engine = _db()
    try:
        now = datetime(2026, 9, 19, 12, 0, 0)
        lease_service = MemoryRetentionMaintenanceLeaseService(db)
        handle = lease_service.acquire(ttl_seconds=60, now=now)
        snapshot = MemoryRetentionMaintenanceReadinessService(db, enabled=True).snapshot(
            now=now + timedelta(seconds=15)
        )
        assert snapshot.ready is False
        assert snapshot.reasons == ("maintenance_lease_held",)
        assert snapshot.lease.state == "held"
        assert snapshot.lease.expires_at == handle.expires_at
        assert lease_service.status(now=now + timedelta(seconds=15)).expires_at == handle.expires_at
        assert lease_service.release(handle) is True
    finally:
        db.close(); engine.dispose()


def test_expired_lease_is_represented_as_reclaimable_readiness():
    db, engine = _db()
    try:
        now = datetime(2026, 9, 19, 12, 0, 0)
        service = MemoryRetentionMaintenanceLeaseService(db)
        handle = service.acquire(ttl_seconds=10, now=now)
        snapshot = MemoryRetentionMaintenanceReadinessService(db, enabled=True).snapshot(
            now=now + timedelta(seconds=11)
        )
        assert snapshot.ready is True
        assert snapshot.reasons == ()
        assert snapshot.lease.state == "expired"
        replacement = service.acquire(ttl_seconds=30, now=now + timedelta(seconds=11))
        assert replacement.owner_token != handle.owner_token
        assert service.release(replacement) is True
    finally:
        db.close(); engine.dispose()


def test_snapshot_reflects_configured_memory_users_and_history_policy():
    db, engine = _db()
    try:
        db.add_all(
            [
                MemoryRetentionPolicy(user_id="user-a", retention_days=30, max_delete=10),
                MemoryRetentionPolicy(user_id="user-b", retention_days=60, max_delete=20),
            ]
        )
        MemoryRetentionRunHistoryPolicyService(db).set(retention_days=14, max_delete=7)
        db.commit()
        snapshot = MemoryRetentionMaintenanceReadinessService(db, enabled=True).snapshot(
            now=datetime(2026, 9, 19, 12, 0, 0)
        )
        assert snapshot.ready is True
        assert snapshot.configured_memory_policy_users == 2
        assert snapshot.run_history_policy.configured is True
        assert snapshot.run_history_policy.retention_days == 14
        assert snapshot.run_history_policy.max_delete == 7
    finally:
        db.close(); engine.dispose()
