from __future__ import annotations

from pathlib import Path

from docx import Document

from backend_v2.ingestion.analyzer import FileAnalyzer
from backend_v2.ingestion.loaders.docx import DocxLoader
from backend_v2.ingestion.loaders.html import HtmlLoader
from backend_v2.ingestion.loaders.text import TextLoader
from backend_v2.ingestion.processors.chunk import TextChunker
from backend_v2.ingestion.pipeline import IngestionPipeline


def test_markdown_heading_aware_chunks(tmp_path):
    path = tmp_path / "physics.md"
    path.write_text("# فیزیک\n\nمقدمه.\n\n## قانون دوم نیوتن\n\nنیرو برابر جرم ضربدر شتاب است.\n\n### مثال\n\nیک مثال آموزشی.", encoding="utf-8")
    result = IngestionPipeline(chunk_size=400, overlap=20).process(path)
    assert result.chunks
    laws = [c for c in result.chunks if c.metadata.get("heading") == "قانون دوم نیوتن"]
    assert laws
    assert laws[0].metadata["section"] == "فیزیک > قانون دوم نیوتن"
    assert "نیرو برابر جرم ضربدر شتاب" in laws[0].text


def test_docx_heading_structure_is_preserved(tmp_path):
    path = tmp_path / "physics.docx"
    doc = Document()
    doc.add_heading("فیزیک دهم", level=1)
    doc.add_paragraph("درس فیزیک")
    doc.add_heading("قانون دوم نیوتن", level=2)
    doc.add_paragraph("نیرو برابر جرم ضربدر شتاب است.")
    doc.save(path)
    result = IngestionPipeline(chunk_size=400, overlap=20).process(path)
    law = next(c for c in result.chunks if c.metadata.get("heading") == "قانون دوم نیوتن")
    assert law.metadata["heading_level"] == 2
    assert law.metadata["section"] == "فیزیک دهم > قانون دوم نیوتن"


def test_html_heading_structure_is_preserved(tmp_path):
    path = tmp_path / "physics.html"
    path.write_text("""<html><head><title>فیزیک</title></head><body><h1>فیزیک دهم</h1><p>مقدمه</p><h2>قانون دوم نیوتن</h2><p>F = ma</p></body></html>""", encoding="utf-8")
    result = IngestionPipeline(chunk_size=400, overlap=20).process(path)
    law = next(c for c in result.chunks if c.metadata.get("heading") == "قانون دوم نیوتن")
    assert law.metadata["section"] == "فیزیک دهم > قانون دوم نیوتن"


def test_markdown_without_headings_remains_plain(tmp_path):
    path = tmp_path / "notes.md"
    path.write_text("قانون دوم نیوتن.\n\nF = ma", encoding="utf-8")
    result = IngestionPipeline().process(path)
    assert result.chunks
    assert "heading" not in result.chunks[0].metadata


def test_txt_loader_does_not_invent_sections(tmp_path):
    path = tmp_path / "notes.txt"
    path.write_text("بخش اول\n\nمتن آموزشی", encoding="utf-8")
    result = IngestionPipeline().process(path)
    assert result.chunks
    assert "section" not in result.chunks[0].metadata


def test_structured_metadata_is_not_copied_into_each_chunk(tmp_path):
    path = tmp_path / "doc.md"
    path.write_text("# عنوان\n\nمتن", encoding="utf-8")
    result = IngestionPipeline().process(path)
    assert result.chunks
    assert "structured_blocks" not in result.chunks[0].metadata


def test_docx_tables_keep_section_context(tmp_path):
    path = tmp_path / "table.docx"
    doc = Document()
    doc.add_heading("فصل ۱", level=1)
    table = doc.add_table(rows=1, cols=2)
    table.rows[0].cells[0].text = "کمیت"
    table.rows[0].cells[1].text = "واحد"
    doc.save(path)
    result = IngestionPipeline().process(path)
    row = next(c for c in result.chunks if "کمیت" in c.text)
    assert row.metadata["section"] == "فصل ۱"
    assert row.metadata["kind"] == "table_row"


def test_html_og_url_is_preserved(tmp_path):
    path = tmp_path / "article.html"
    path.write_text("""<html><head><meta property='og:url' content='https://example.com/physics'></head><body><h1>فیزیک</h1><p>مطلب</p></body></html>""", encoding="utf-8")
    result = IngestionPipeline().process(path)
    assert result.chunks[0].metadata["url"] == "https://example.com/physics"
