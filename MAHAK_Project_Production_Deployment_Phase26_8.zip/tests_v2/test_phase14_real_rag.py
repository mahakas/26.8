from __future__ import annotations
import pytest
from backend_v2.ingestion.document import ContentChunk, SourceLocation
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.runtime import V2Runtime
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService

def test_knowledge_index_adds_scope_and_embedding_metadata(monkeypatch):
    monkeypatch.setenv("MAHAK_PROVIDER_MODE", "mock")
    monkeypatch.setenv("VECTOR_STORE_BACKEND", "memory")
    runtime = V2Runtime()
    service = KnowledgeIndexService(runtime.vector_store, runtime.embedding)
    spec = IndexSpec("physics10", "mock-profile", "mock-v1", 8)
    result = service.index_chunks([ContentChunk("c1", "قانون دوم نیوتن F=ma", 0, {}, SourceLocation(page=4))],
                                  index_spec=spec, source_id="src-1", title="فیزیک دهم",
                                  scope_metadata={"grade_id":"10", "subject_id":"physics"})
    assert result.indexed == 1
    hits = runtime.vector_store.search([1.0] + [0.0] * 7, collection=result.collection, top_k=1,
                                       filters={"grade_id":"10", "subject_id":"physics"})
    assert hits and hits[0].metadata["source_id"] == "src-1"
    assert hits[0].metadata["embedding_dimension"] == 8
    assert hits[0].metadata["page"] == 4

def test_knowledge_index_rejects_dimension_mismatch(monkeypatch):
    monkeypatch.setenv("MAHAK_PROVIDER_MODE", "mock")
    monkeypatch.setenv("VECTOR_STORE_BACKEND", "memory")
    runtime = V2Runtime()
    service = KnowledgeIndexService(runtime.vector_store, runtime.embedding)
    spec = IndexSpec("physics10", "bge-m3", "v1", 1024)
    with pytest.raises(ValueError, match="dimension"):
        service.index_chunks([ContentChunk("c1", "متن", 0)], index_spec=spec, source_id="s", title="t")

def test_chroma_multi_field_filter_is_supported(tmp_path):
    try:
        from backend_v2.vectorstores.chroma import ChromaVectorStore
        from backend_v2.vectorstores.base import VectorRecord
        store = ChromaVectorStore(tmp_path / "chroma")
    except (RuntimeError, ImportError):
        pytest.skip("chromadb is not installed in this test environment")
    store.upsert([
        VectorRecord("c1", [1.0, 0.0], "قانون دوم نیوتن", {"grade_id": "10", "subject_id": "physics"}),
        VectorRecord("c2", [0.0, 1.0], "شیمی", {"grade_id": "10", "subject_id": "chemistry"}),
    ], collection="multi-filter")
    hits = store.search([1.0, 0.0], collection="multi-filter", top_k=3,
                        filters={"grade_id": "10", "subject_id": "physics"})
    assert [hit.id for hit in hits] == ["c1"]


def test_chroma_integration_is_available_or_explicitly_skipped(tmp_path):
    try:
        from backend_v2.vectorstores.chroma import ChromaVectorStore
        store = ChromaVectorStore(tmp_path / "chroma")
    except (RuntimeError, ImportError):
        pytest.skip("chromadb is not installed in this test environment")
    assert store.health_check()
