from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.education import EducationalAnswerSubmission, EducationalAttemptGrader, EducationalAttemptRequest
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _attempt(*, attempt_id="attempt-22-3", answer="F=ma"):
    return EducationalAttemptRequest(
        user_id="student-22-3",
        attempt_id=attempt_id,
        task_type="quiz",
        topic="قانون دوم نیوتن",
        grade_id="10",
        subject_id="physics",
        items=(
            EducationalAnswerSubmission(
                item_id="q1",
                question_type="multiple_choice",
                question="کدام رابطه درست است؟",
                topic="قانون دوم نیوتن",
                answer=answer,
                correct_answer="F=ma",
                options=("F=ma", "F=m/a"),
            ),
            EducationalAnswerSubmission(
                item_id="q2",
                question_type="short_answer",
                question="رابطه نیرو و شتاب چیست؟",
                topic="قانون دوم نیوتن",
                answer="نیرو برابر جرم ضربدر شتاب است",
                correct_answer="نیرو برابر جرم ضربدر شتاب است",
            ),
        ),
    )


def test_grading_updates_mastery_and_weak_area_for_low_score():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        result = EducationalAttemptGrader(memory).grade(_attempt(answer="F=m/a"))
        db.commit()

        assert result.total_score == 0.5
        assert result.correct_count == 1
        assert result.partial_count == 0
        assert result.incorrect_count == 1
        assert dict(result.mastery_by_topic)["قانون دوم نیوتن"] == 0.5

        profile = MemoryProgressService(memory).build("student-22-3")
        assert dict(profile.mastery_by_topic)["قانون دوم نیوتن"] == 0.5
        assert "قانون دوم نیوتن" in profile.active_weak_areas

        attempt = memory.latest(
            "student-22-3",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="attempt:attempt-22-3",
        )
        assert attempt is not None
    finally:
        db.close()
        engine.dispose()


def test_grading_idempotently_replays_same_attempt_without_duplicate_progress():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        grader = EducationalAttemptGrader(memory)
        first = grader.grade(_attempt())
        db.commit()
        memory_count_after_first = len(memory.list("student-22-3"))

        second = grader.grade(_attempt())
        db.commit()

        assert first.total_score == 1.0
        assert second.total_score == first.total_score
        assert second.idempotent_replay is True
        assert len(memory.list("student-22-3")) == memory_count_after_first
    finally:
        db.close()
        engine.dispose()


def test_strong_retry_resolves_existing_weak_area():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        grader = EducationalAttemptGrader(memory)
        grader.grade(_attempt(answer="F=m/a"))
        db.commit()

        resolved_request = EducationalAttemptRequest(
            user_id="student-22-3",
            attempt_id="attempt-22-3-retry",
            task_type="quiz",
            topic="قانون دوم نیوتن",
            items=(
                EducationalAnswerSubmission(
                    item_id="q1",
                    question_type="multiple_choice",
                    question="کدام رابطه درست است؟",
                    topic="قانون دوم نیوتن",
                    answer="F=ma",
                    correct_answer="F=ma",
                ),
            ),
        )
        result = grader.grade(resolved_request)
        db.commit()

        assert dict(result.mastery_by_topic)["قانون دوم نیوتن"] == 0.75
        assert dict(result.weak_area_status_by_topic)["قانون دوم نیوتن"] == "resolved"
        latest = memory.latest(
            "student-22-3",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:قانون دوم نیوتن".lower(),
        )
        assert latest is not None
        assert latest.value["status"] == "resolved"
    finally:
        db.close()
        engine.dispose()


def test_grade_attempt_endpoint_persists_and_returns_contract():
    db, engine = _db()
    try:
        app = create_app()

        def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db
        client = TestClient(app)
        response = client.post(
            "/api/education/attempts/grade",
            json={
                "user_id": "student-22-3-api",
                "attempt_id": "attempt-api-1",
                "task_type": "quiz",
                "topic": "قانون دوم نیوتن",
                "items": [
                    {
                        "item_id": "q1",
                        "question_type": "multiple_choice",
                        "question": "رابطه؟",
                        "topic": "قانون دوم نیوتن",
                        "answer": "F=ma",
                        "correct_answer": "F=ma",
                        "options": ["F=ma", "F=m/a"]
                    }
                ]
            },
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total_score"] == 1.0
        assert body["mastery_by_topic"]["قانون دوم نیوتن"] == 1.0
        assert body["idempotent_replay"] is False
    finally:
        db.close()
        engine.dispose()
