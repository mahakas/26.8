from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.auth.rbac import Permission, Role, role_has_permission
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User


def _client():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), engine, Session


def _register_and_login(client: TestClient, email: str):
    assert client.post(
        "/api/auth/register",
        json={"email": email, "password": "StrongPass123!", "display_name": email.split("@")[0]},
    ).status_code == 201
    response = client.post("/api/auth/login", json={"email": email, "password": "StrongPass123!"})
    assert response.status_code == 200, response.text
    return response.json()


def _set_role(Session, email: str, role: Role) -> None:
    db = Session()
    user = db.query(User).filter_by(email=email).one()
    user.role = role.value
    db.commit()
    db.close()


def test_default_role_is_student_and_permissions_are_scoped():
    client, engine, Session = _client()
    token = _register_and_login(client, "student@example.com")
    assert token["user"]["role"] == "student"
    assert role_has_permission(Role.STUDENT, Permission.CHAT_USE)
    assert not role_has_permission(Role.STUDENT, Permission.USERS_READ)
    engine.dispose()


def test_unauthenticated_admin_route_is_rejected():
    client, engine, Session = _client()
    response = client.get("/api/admin/access-check")
    assert response.status_code == 401
    engine.dispose()


def test_student_is_forbidden_from_admin_route():
    client, engine, Session = _client()
    token = _register_and_login(client, "student@example.com")
    response = client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {token['access_token']}"})
    assert response.status_code == 403
    assert response.json()["detail"] == "insufficient permission"
    engine.dispose()


def test_admin_can_list_users():
    client, engine, Session = _client()
    admin_token = _register_and_login(client, "admin@example.com")
    _register_and_login(client, "student@example.com")
    _set_role(Session, "admin@example.com", Role.ADMIN)
    response = client.get("/api/admin/users", headers={"Authorization": f"Bearer {admin_token['access_token']}"})
    assert response.status_code == 200, response.text
    assert {item["email"] for item in response.json()} == {"admin@example.com", "student@example.com"}
    engine.dispose()


def test_role_change_is_route_protected_and_updates_effective_permission():
    client, engine, Session = _client()
    admin_token = _register_and_login(client, "admin@example.com")
    student_token = _register_and_login(client, "student@example.com")
    _set_role(Session, "admin@example.com", Role.ADMIN)

    response = client.patch(
        "/api/admin/users/" + Session().query(User).filter_by(email="student@example.com").one().id + "/role",
        json={"role": "teacher"},
        headers={"Authorization": f"Bearer {admin_token['access_token']}"},
    )
    assert response.status_code == 200, response.text
    assert response.json()["role"] == "teacher"

    response = client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {student_token['access_token']}"})
    assert response.status_code == 403
    engine.dispose()


def test_role_change_prevents_admin_self_demotion():
    client, engine, Session = _client()
    admin_token = _register_and_login(client, "admin@example.com")
    _set_role(Session, "admin@example.com", Role.ADMIN)
    user_id = Session().query(User).filter_by(email="admin@example.com").one().id
    response = client.patch(
        f"/api/admin/users/{user_id}/role",
        json={"role": "teacher"},
        headers={"Authorization": f"Bearer {admin_token['access_token']}"},
    )
    assert response.status_code == 409
    assert response.json()["detail"] == "an administrator cannot change their own role"
    engine.dispose()


def test_role_update_reflects_immediately_without_token_reissue():
    client, engine, Session = _client()
    admin_token = _register_and_login(client, "admin@example.com")
    user_token = _register_and_login(client, "user@example.com")
    _set_role(Session, "admin@example.com", Role.ADMIN)
    user_id = Session().query(User).filter_by(email="user@example.com").one().id

    assert client.patch(
        f"/api/admin/users/{user_id}/role",
        json={"role": "admin"},
        headers={"Authorization": f"Bearer {admin_token['access_token']}"},
    ).status_code == 200
    response = client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {user_token['access_token']}"})
    assert response.status_code == 200
    engine.dispose()


def test_invalid_role_is_rejected():
    client, engine, Session = _client()
    admin_token = _register_and_login(client, "admin@example.com")
    _set_role(Session, "admin@example.com", Role.ADMIN)
    target = _register_and_login(client, "student@example.com")
    target_id = target["user"]["id"]
    response = client.patch(
        f"/api/admin/users/{target_id}/role",
        json={"role": "owner"},
        headers={"Authorization": f"Bearer {admin_token['access_token']}"},
    )
    assert response.status_code == 422
    engine.dispose()


def test_existing_auth_me_exposes_current_role_from_db():
    client, engine, Session = _client()
    token = _register_and_login(client, "teacher@example.com")
    _set_role(Session, "teacher@example.com", Role.TEACHER)
    response = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token['access_token']}"})
    assert response.status_code == 200
    assert response.json()["role"] == "teacher"
    engine.dispose()


def test_legacy_database_receives_additive_role_column(monkeypatch):
    import backend_v2.database.connection as connection_module

    legacy_engine = create_engine("sqlite://", future=True)
    with legacy_engine.begin() as conn:
        conn.execute(
            text(
                "CREATE TABLE users ("
                "id VARCHAR(36) PRIMARY KEY, "
                "email VARCHAR(320) NOT NULL, "
                "password_hash VARCHAR(512) NOT NULL, "
                "display_name VARCHAR(200) NOT NULL, "
                "is_active BOOLEAN NOT NULL DEFAULT 1, "
                "is_verified BOOLEAN NOT NULL DEFAULT 0, "
                "created_at DATETIME NOT NULL, "
                "updated_at DATETIME NOT NULL"
                ")"
            )
        )
    monkeypatch.setattr(connection_module, "engine", legacy_engine)
    connection_module._migrate_auth_role_column()
    columns = {item["name"] for item in inspect(legacy_engine).get_columns("users")}
    assert "role" in columns
    with legacy_engine.connect() as conn:
        conn.execute(
            text(
                "INSERT INTO users "
                "(id, email, password_hash, display_name, is_active, is_verified, created_at, updated_at) "
                "VALUES ('legacy-1', 'legacy@example.com', 'hash', 'Legacy', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
            )
        )
        value = conn.execute(text("SELECT role FROM users WHERE id='legacy-1'")).scalar_one()
    assert value == "student"
    legacy_engine.dispose()
