from __future__ import annotations

from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.database.repositories.memory_retention_run_history_policy import (
    MemoryRetentionRunHistoryPolicyRepository,
)
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db):
    db.add(
        MemoryRetentionMaintenanceRun(
            run_id="status-44-a",
            status="completed",
            started_at=datetime(2026, 9, 19, 10, 0),
            completed_at=datetime(2026, 9, 19, 10, 1),
            dry_run=False,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=2,
            memory_planned_count=2,
            memory_executed_count=2,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=5,
            memory_would_delete_count=4,
            memory_deleted_count=4,
            history_status="completed",
            history_configured=True,
            history_retention_days=365,
            history_max_delete=500,
            history_candidate_count=3,
            history_would_delete_count=3,
            history_deleted_count=3,
            history_error=None,
        )
    )
    MemoryRetentionRunHistoryPolicyRepository(db).upsert(retention_days=180, max_delete=50)
    db.commit()


def test_operational_status_returns_composed_read_only_snapshot():
    client, db, engine = _client()
    try:
        _seed(db)
        before = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        response = client.get("/api/memory/maintenance/status")
        assert response.status_code == 200
        payload = response.json()

        assert payload["ready"] is False
        assert payload["enabled"] is False
        assert payload["execution_mode"] == "explicit_only"
        assert payload["automatic_execution_enabled"] is False
        assert payload["read_only"] is True
        assert "maintenance_disabled" in payload["reasons"]
        assert payload["lease"]["state"] == "available"
        assert payload["run_history_policy"] == {
            "retention_days": 180,
            "max_delete": 50,
            "configured": True,
        }
        assert payload["summary"]["run_count"] == 1
        assert payload["summary"]["memory_deleted_count"] == 4
        assert payload["summary"]["history_deleted_count"] == 3
        assert payload["latest_run"]["run_id"] == "status-44-a"
        assert payload["latest_run"]["history_error"] is None

        after = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        assert after == before
        assert "user_id" not in payload
        assert "value" not in payload
        assert "memory_key" not in payload
    finally:
        db.close()
        engine.dispose()


def test_assume_enabled_changes_only_readiness_evaluation():
    client, db, engine = _client()
    try:
        response = client.get("/api/memory/maintenance/status", params={"assume_enabled": "true"})
        assert response.status_code == 200
        payload = response.json()
        assert payload["enabled"] is True
        assert payload["ready"] is True
        assert payload["reasons"] == []
        assert payload["read_only"] is True
    finally:
        db.close()
        engine.dispose()


def test_held_lease_makes_assumed_enabled_snapshot_not_ready():
    client, db, engine = _client()
    try:
        lease_now = datetime.now(UTC)
        lease = MemoryRetentionMaintenanceLeaseService(db).acquire(
            ttl_seconds=60,
            now=lease_now,
        )
        response = client.get(
            "/api/memory/maintenance/status",
            params={"assume_enabled": "true"},
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["enabled"] is True
        assert payload["ready"] is False
        assert "maintenance_lease_held" in payload["reasons"]
        assert payload["lease"]["state"] == "held"
        assert payload["lease"]["remaining_seconds"] > 0
        assert payload["read_only"] is True
        MemoryRetentionMaintenanceLeaseService(db).release(lease)
    finally:
        db.close()
        engine.dispose()
