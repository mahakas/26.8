from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
)
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_run(db, run_id: str, completed_at: datetime) -> None:
    db.add(
        MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
            run_id=run_id,
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            older_than=completed_at - timedelta(days=30),
            retention_days=30,
            max_delete=500,
            configured=True,
            preview_bound=False,
            candidate_count=1,
            deleted_count=1,
        )
    )
    db.commit()


def test_policy_preview_produces_token_and_is_read_only():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=400))
        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).preview_policy()
        assert preview.preview_token
        assert preview.read_only is True
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is not None
    finally:
        db.close()
        engine.dispose()


def test_matching_preview_token_reuses_cutoff_and_allows_apply():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=400))
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview_policy()
        result = service.apply_policy(preview_token=preview.preview_token)
        assert result.preview_bound is True
        assert result.older_than == preview.older_than
        assert result.candidate_count == preview.candidate_count
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is None
    finally:
        db.close()
        engine.dispose()


def test_preview_token_rejects_history_state_change_without_deleting():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=400))
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        token = service.preview_policy().preview_token
        _seed_run(db, "new-old", now - timedelta(days=401))
        try:
            service.apply_policy(preview_token=token)
            raise AssertionError("expected preview binding failure")
        except ValueError as exc:
            assert "state changed since preview" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "new-old") is not None
    finally:
        db.close()
        engine.dispose()


def test_preview_token_rejects_policy_change_without_deleting():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=20))
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=10)
        db.commit()
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        token = service.preview_policy().preview_token
        policy.set(retention_days=14, max_delete=10)
        db.commit()
        try:
            service.apply_policy(preview_token=token)
            raise AssertionError("expected policy binding failure")
        except ValueError as exc:
            assert "state changed since preview" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is not None
    finally:
        db.close()
        engine.dispose()


def test_invalid_preview_token_is_rejected():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        try:
            service.apply_policy(preview_token="not-a-valid-token")
            raise AssertionError("expected invalid token failure")
        except ValueError as exc:
            assert "Invalid maintenance alert snapshot retention history preview token" in str(exc)
    finally:
        db.close()
        engine.dispose()


def test_tampered_preview_token_is_rejected():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=400))
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        token = service.preview_policy().preview_token
        assert token
        tampered = token[:-1] + ("A" if token[-1] != "A" else "B")
        try:
            service.apply_policy(preview_token=tampered)
            raise AssertionError("expected tampered token failure")
        except ValueError as exc:
            assert "preview token" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is not None
    finally:
        db.close()
        engine.dispose()


def test_apply_without_token_remains_backward_compatible():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old", now - timedelta(days=400))
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db).apply_policy()
        assert result.preview_bound is False
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old") is None
    finally:
        db.close()
        engine.dispose()


def test_preview_token_keeps_max_delete_binding():
    db, engine = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_run(db, "old-a", now - timedelta(days=400))
        _seed_run(db, "old-b", now - timedelta(days=401))
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=365, max_delete=1)
        db.commit()
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview_policy()
        assert preview.candidate_count == 2
        assert preview.would_delete_count == 1
        policy.set(retention_days=365, max_delete=2)
        db.commit()
        try:
            service.apply_policy(preview_token=preview.preview_token)
            raise AssertionError("expected max_delete binding failure")
        except ValueError as exc:
            assert "state changed since preview" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-a") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "old-b") is not None
    finally:
        db.close()
        engine.dispose()
