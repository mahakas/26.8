from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot
from backend_v2.memory import (
    MemoryRetentionMaintenanceAlertSnapshotPolicyService,
    MemoryRetentionMaintenanceAlertSnapshotRetentionService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return engine, Session()


def _client():
    engine, db = _db()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, snapshot_id: str, captured_at: datetime):
    db.add(
        MemoryRetentionMaintenanceAlertSnapshot(
            snapshot_id=snapshot_id,
            captured_at=captured_at,
            health="healthy",
            ready=True,
            severity="none",
            stale_after_seconds=86400,
            alert_count=0,
            alert_codes="",
            assume_enabled=False,
            use_policy=False,
        )
    )


def test_preview_produces_token_and_is_read_only():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).preview_policy()
        assert preview.preview_token
        assert preview.read_only is True
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
    finally:
        db.close()
        engine.dispose()


def test_matching_token_allows_apply():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        token = service.preview_policy().preview_token
        assert token
        result = service.apply_policy(preview_token=token)
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is None
    finally:
        db.close()
        engine.dispose()


def test_token_rejects_new_snapshot_state_change():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        token = service.preview_policy().preview_token
        assert token
        _seed(db, "old-2", now - timedelta(days=41))
        db.commit()
        try:
            service.apply_policy(preview_token=token)
            raise AssertionError("expected preview binding failure")
        except ValueError as exc:
            assert "state changed since preview" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old-2") is not None
    finally:
        db.close()
        engine.dispose()


def test_token_rejects_policy_change():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        token = service.preview_policy().preview_token
        assert token
        MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=7, max_delete=500)
        db.commit()
        try:
            service.apply_policy(preview_token=token)
            raise AssertionError("expected policy binding failure")
        except ValueError as exc:
            assert "state changed since preview" in str(exc)
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is not None
    finally:
        db.close()
        engine.dispose()


def test_invalid_token_is_rejected():
    engine, db = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        try:
            service.apply_policy(preview_token="not-a-valid-token")
            raise AssertionError("expected invalid token failure")
        except ValueError as exc:
            assert "Invalid maintenance alert snapshot retention preview token" in str(exc)
    finally:
        db.close()
        engine.dispose()


def test_apply_without_token_keeps_legacy_behavior():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).apply_policy()
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is None
    finally:
        db.close()
        engine.dispose()


def test_api_policy_and_preview_binding_endpoints():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()

        policy = client.get("/api/memory/maintenance/alert-snapshots/retention/policy")
        assert policy.status_code == 200
        assert policy.json() == {
            "retention_days": 30,
            "max_delete": 500,
            "configured": False,
            "read_only": True,
        }

        saved = client.put(
            "/api/memory/maintenance/alert-snapshots/retention/policy",
            json={"retention_days": 30, "max_delete": 1},
        )
        assert saved.status_code == 200
        assert saved.json()["configured"] is True

        preview = client.post("/api/memory/maintenance/alert-snapshots/retention/policy/preview")
        assert preview.status_code == 200
        payload = preview.json()
        assert payload["candidate_count"] == 1
        assert payload["would_delete_count"] == 1
        assert payload["read_only"] is True
        token = payload["preview_token"]
        assert token

        applied = client.post(
            "/api/memory/maintenance/alert-snapshots/retention/policy/apply",
            params={"preview_token": token},
        )
        assert applied.status_code == 200
        assert applied.json()["deleted_count"] == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is None

        reset = client.delete("/api/memory/maintenance/alert-snapshots/retention/policy")
        assert reset.status_code == 200
        assert reset.json()["configured"] is False
    finally:
        db.close()
        engine.dispose()


def test_api_preview_token_rejects_state_change_with_409():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed(db, "old", now - timedelta(days=40))
        db.commit()
        token = client.post(
            "/api/memory/maintenance/alert-snapshots/retention/policy/preview"
        ).json()["preview_token"]
        _seed(db, "new-old", now - timedelta(days=41))
        db.commit()
        response = client.post(
            "/api/memory/maintenance/alert-snapshots/retention/policy/apply",
            params={"preview_token": token},
        )
        assert response.status_code == 409
        assert "state changed since preview" in response.json()["detail"]
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "old") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshot, "new-old") is not None
    finally:
        db.close()
        engine.dispose()
