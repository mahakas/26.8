from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryContext
from backend_v2.memory.personalization import MemoryPersonalizationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


class CaptureAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def __init__(self) -> None:
        self.personalization = None

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.personalization = kwargs.get("personalization_context")
        return AgentResult(answer="specialist answer", confidence=0.7)


def _db():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _teacher_orchestrator(captured: dict):
    registry = ProviderRegistry()
    provider = MockProviderAdapter(
        "phase21-3-teacher",
        {Capability.CHAT},
        lambda payload: captured.setdefault("payload", payload) or {"answer": "personalized answer"},
        default_model="teacher-memory-v1",
    )
    registry.register(provider, priority=1)
    return ProviderOrchestrator(registry, ProviderHealthManager())


def test_personalization_derives_safe_hints_from_memory():
    db, engine = _db()
    try:
        service = MemoryService(db)
        service.remember(
            user_id="student-21-3",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.3},
            confidence=0.8,
        )
        service.remember(
            user_id="student-21-3",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"explanation_style": "step_by_step", "learning_level": "grade10"},
            confidence=0.9,
        )
        service.remember(
            user_id="student-21-3",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="lesson-1",
            value={"topic": "equations"},
            confidence=0.9,
        )
        db.commit()

        context = MemoryContext(tuple(service.list("student-21-3")))
        result = MemoryPersonalizationService().build(context)

        assert result.weak_areas == ("algebra",)
        assert result.explanation_style == "step_by_step"
        assert result.learning_level == "grade10"
        assert result.recent_topics == ("equations",)
        assert "algebra" in result.guidance()
    finally:
        db.close()
        engine.dispose()


def test_pipeline_passes_personalization_to_specialist_agent():
    db, engine = _db()
    try:
        memory_service = MemoryService(db)
        context = ConversationContext(
            conversation_id="conv-21-3",
            user_id="student-21-3",
            mode=ChatMode.GENERAL,
        )
        memory_service.remember(
            user_id="student-21-3",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.2},
            confidence=0.9,
        )
        db.commit()

        agent = CaptureAgent()
        registry = AgentRegistry()
        registry.register(agent)
        from backend_v2.memory.integration import MemoryIntegrationService
        pipeline = UnifiedAgentPipeline(
            AgentRouter(registry),
            TeacherAgent(),
            memory=MemoryIntegrationService(memory_service),
        )
        # Explicit memory context verifies the personalization path while the injected service
        # keeps post-turn persistence on the same in-memory database.
        result = pipeline.execute(
            "سلام",
            conversation_context=context,
            memory_context=MemoryContext(tuple(memory_service.list("student-21-3"))),
        )

        assert result.answer == "specialist answer"
        assert agent.personalization is not None
        assert "algebra" in agent.personalization.weak_areas
    finally:
        db.close()
        engine.dispose()


def test_teacher_uses_personalization_without_changing_agent_result_contract():
    captured: dict = {}
    source = AgentResult(
        answer="x = 3",
        evidence=[{"type": "document", "page": 12}],
        citations=[{"title": "Physics", "page": 12}],
        confidence=0.7,
    )
    from backend_v2.memory.personalization import PersonalizationContext

    teacher = TeacherAgent(_teacher_orchestrator(captured))
    result = teacher.execute(
        "این جواب را آموزشی توضیح بده",
        source_result=source,
        personalization_context=PersonalizationContext(
            weak_areas=("algebra",),
            explanation_style="step_by_step",
            learning_level="grade10",
        ),
    )

    assert result.evidence == source.evidence
    assert result.citations == source.citations
    assert result.confidence == source.confidence
    messages = captured["payload"]["messages"]
    user_prompt = messages[-1]["content"]
    assert "algebra" in user_prompt
    assert "step_by_step" in user_prompt
