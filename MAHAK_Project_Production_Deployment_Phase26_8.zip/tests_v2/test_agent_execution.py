from backend_v2.agents.base import BaseAgent
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentResult, AgentType


class RecordingAgent(BaseAgent):
    def __init__(self, agent_type):
        self.agent_type = agent_type
        self.called = False

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.called = True
        return AgentResult(answer=f"handled:{query}", confidence=0.9)


def test_router_executes_selected_agent():
    registry = AgentRegistry()
    video = RecordingAgent(AgentType.VIDEO)
    registry.register(video)

    router = AgentRouter(registry)
    result = router.execute("analyze video timestamp")

    assert video.called is True
    assert result.answer == "handled:analyze video timestamp"
    assert result.confidence == 0.9
