from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType


class StubAgent(BaseAgent):
    def __init__(self, agent_type: AgentType, answer: str) -> None:
        self.agent_type = agent_type
        self.answer = answer
        self.called = False

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.called = True
        return AgentResult(
            answer=self.answer,
            evidence=[{"type": self.agent_type.value, "text": query}],
            citations=[{"title": f"{self.agent_type.value} source"}],
            confidence=0.7,
        )


def _pipeline(agent: StubAgent) -> tuple[UnifiedAgentPipeline, StubAgent]:
    registry = AgentRegistry()
    registry.register(agent)
    router = AgentRouter(registry)
    return UnifiedAgentPipeline(router, TeacherAgent()), agent


def test_unified_pipeline_routes_and_executes_specialist_then_teacher():
    pipeline, video = _pipeline(StubAgent(AgentType.VIDEO, "video evidence answer"))

    result = pipeline.execute("این ویدیو را توضیح بده")

    assert video.called is True
    assert result.answer == "video evidence answer"
    assert result.evidence == [{"type": AgentType.VIDEO.value, "text": "این ویدیو را توضیح بده"}]
    assert result.citations == [{"title": "VIDEO_AGENT source"}]
    assert result.confidence == 0.7


def test_unified_pipeline_exposes_route_trace():
    pipeline, _ = _pipeline(StubAgent(AgentType.DOCUMENT, "document answer"))

    trace = pipeline.execute_with_trace("این کتاب را توضیح بده")

    assert trace.agent_type is AgentType.DOCUMENT
    assert trace.specialist_result.answer == "document answer"
    assert trace.result.answer == "document answer"


def test_unified_pipeline_supports_all_router_agent_types():
    cases = [
        (AgentType.DOCUMENT, "صفحه دوم کتاب را توضیح بده"),
        (AgentType.IMAGE, "این تصویر را تحلیل کن"),
        (AgentType.VIDEO, "این ویدیو را توضیح بده"),
        (AgentType.GENERAL, "سلام"),
    ]

    for agent_type, query in cases:
        pipeline, agent = _pipeline(StubAgent(agent_type, f"{agent_type.value} answer"))
        trace = pipeline.execute_with_trace(query)

        assert agent.called is True
        assert trace.agent_type is agent_type
        assert trace.result.answer == f"{agent_type.value} answer"
        assert trace.result.evidence
        assert trace.result.citations


def test_unified_pipeline_rejects_empty_query():
    pipeline, _ = _pipeline(StubAgent(AgentType.GENERAL, "general answer"))

    try:
        pipeline.execute("   ")
    except ValueError as exc:
        assert "cannot be empty" in str(exc)
    else:
        raise AssertionError("Expected ValueError for an empty query")
