from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.repositories import MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository
from backend_v2.memory import MemoryRetentionMaintenanceAlertSnapshotRetentionService
from backend_v2.memory.retention_maintenance_alert_snapshot_policy import MemoryRetentionMaintenanceAlertSnapshotPolicyService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return session, engine


def _client():
    db, engine = _db()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def test_summary_aggregates_execution_metrics():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        policy = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
        assert policy.configured is True
        token = service.preview_policy().preview_token
        assert token
        service.apply_policy(preview_token=token)
        service.apply_policy()
        db.commit()

        summary = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).summary()
        assert summary["run_count"] == 3
        assert summary["configured_run_count"] == 2
        assert summary["unconfigured_run_count"] == 1
        assert summary["preview_bound_run_count"] == 1
        assert summary["unbound_run_count"] == 2
        assert summary["zero_delete_run_count"] == 3
        assert summary["candidate_count"] == 0
        assert summary["deleted_count"] == 0
        assert summary["first_started_at"] is not None
        assert summary["last_completed_at"] is not None
    finally:
        db.close()
        engine.dispose()


def test_summary_filters_by_configured_and_preview_bound():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        policy = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
        assert policy.configured is True
        token = service.preview_policy().preview_token
        assert token
        service.apply_policy(preview_token=token)
        service.apply_policy()
        db.commit()

        repo = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db)
        bound = repo.summary(preview_bound=True)
        assert bound["run_count"] == 1
        assert bound["preview_bound_run_count"] == 1
        configured = repo.summary(configured=True)
        assert configured["run_count"] == 2
        assert configured["unconfigured_run_count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_summary_respects_time_range():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        first = service.apply_policy()
        db.commit()
        lower = first.older_than - timedelta(seconds=1)
        upper = datetime.now(UTC).replace(tzinfo=None) + timedelta(seconds=1)

        summary = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).summary(
            start_at=lower,
            end_at=upper,
        )
        assert summary["run_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_summary_api_is_read_only_and_returns_aggregate_shape():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        db.commit()
        before = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).summary()["run_count"]

        response = client.get("/api/memory/maintenance/alert-snapshots/retention/runs/summary")
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == before
        assert payload["configured_run_count"] == 0
        assert payload["unconfigured_run_count"] == 1
        assert payload["preview_bound_run_count"] == 0
        assert payload["read_only"] is True
        after = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).summary()["run_count"]
        assert after == before
    finally:
        db.close()
        engine.dispose()


def test_summary_api_supports_filters():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
        service.apply_policy()
        MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
        token = service.preview_policy().preview_token
        assert token
        service.apply_policy(preview_token=token)
        db.commit()

        response = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs/summary",
            params={"preview_bound": "true", "configured": "true"},
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 1
        assert payload["preview_bound_run_count"] == 1
        assert payload["configured_run_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_summary_api_rejects_invalid_time_range():
    client, db, engine = _client()
    try:
        response = client.get(
            "/api/memory/maintenance/alert-snapshots/retention/runs/summary",
            params={
                "start_at": "2026-09-20T00:00:00Z",
                "end_at": "2026-09-19T00:00:00Z",
            },
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
