from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicy
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_policy_returns_safe_defaults_without_persisting():
    db, engine = _db()
    try:
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db).get()
        assert policy.retention_days == 365
        assert policy.max_delete == 500
        assert policy.configured is False
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicy).count() == 0
    finally:
        db.close()
        engine.dispose()


def test_policy_set_persists_configuration():
    db, engine = _db()
    try:
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db).set(
            retention_days=90,
            max_delete=25,
        )
        assert policy.configured is True
        assert policy.retention_days == 90
        assert policy.max_delete == 25
        db.commit()

        reloaded = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db).get()
        assert reloaded == policy
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicy).count() == 1
    finally:
        db.close()
        engine.dispose()


def test_policy_update_is_singleton_and_overwrites_values():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        service.set(retention_days=30, max_delete=10)
        service.set(retention_days=120, max_delete=5)
        db.commit()
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicy).count() == 1
        policy = service.get()
        assert policy.retention_days == 120
        assert policy.max_delete == 5
    finally:
        db.close()
        engine.dispose()


def test_policy_rejects_invalid_values():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        for kwargs in (
            {"retention_days": 0, "max_delete": 500},
            {"retention_days": 36501, "max_delete": 500},
            {"retention_days": 365, "max_delete": 0},
            {"retention_days": 365, "max_delete": 501},
            {"retention_days": True, "max_delete": 500},
        ):
            try:
                service.set(**kwargs)
            except ValueError:
                pass
            else:
                raise AssertionError("expected ValueError")
    finally:
        db.close()
        engine.dispose()


def test_policy_reset_is_idempotent_and_does_not_execute_cleanup():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        service.set(retention_days=30, max_delete=10)
        db.commit()
        assert service.reset() is True
        db.commit()
        assert service.reset() is False
        assert service.get().configured is False
        assert db.query(MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicy).count() == 0
    finally:
        db.close()
        engine.dispose()


def test_injected_session_leaves_commit_to_caller():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        service.set(retention_days=60, max_delete=20)
        db.rollback()
        assert service.get().configured is False
    finally:
        db.close()
        engine.dispose()
