from __future__ import annotations

from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot
from backend_v2.memory.retention_maintenance_alert_persistence import (
    MemoryRetentionMaintenanceAlertSnapshotService,
)


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db):
    service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True, use_policy=False)
    service.capture(now=datetime(2026, 9, 19, 10, 0, tzinfo=UTC))
    service = MemoryRetentionMaintenanceAlertSnapshotService(
        db,
        assume_enabled=False,
        use_policy=False,
    )
    service.capture(now=datetime(2026, 9, 19, 11, 0, tzinfo=UTC))
    service = MemoryRetentionMaintenanceAlertSnapshotService(
        db,
        assume_enabled=True,
        stale_after_seconds=60,
        use_policy=True,
    )
    service.capture(now=datetime(2026, 9, 19, 12, 0, tzinfo=UTC))
    db.commit()


def test_snapshot_capture_preserves_injected_transaction_across_multiple_captures():
    client, db, engine = _client()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True)
        first = service.capture(now=datetime(2026, 9, 19, 10, 0, tzinfo=UTC))
        second = service.capture(now=datetime(2026, 9, 19, 11, 0, tzinfo=UTC))
        assert first.snapshot_id != second.snapshot_id
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 2
        db.rollback()
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 0
    finally:
        db.close()
        engine.dispose()


def test_snapshot_history_is_read_only_and_content_free():
    client, db, engine = _client()
    try:
        _seed(db)
        before = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot))
        response = client.get("/api/memory/maintenance/alert-snapshots")
        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 3
        assert payload["read_only"] is True
        item = payload["items"][0]
        assert item["snapshot_id"]
        assert "message" not in item
        assert "user_id" not in item
        assert "value" not in item
        assert "memory_key" not in item
        after = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot))
        assert after == before
    finally:
        db.close()
        engine.dispose()


def test_snapshot_history_cursor_paginates_without_gaps():
    client, db, engine = _client()
    try:
        _seed(db)
        seen = []
        counts = []
        cursor = None
        while True:
            params = {"limit": 2}
            if cursor:
                params["cursor"] = cursor
            response = client.get("/api/memory/maintenance/alert-snapshots", params=params)
            assert response.status_code == 200
            payload = response.json()
            counts.append(payload["count"])
            seen.extend(item["snapshot_id"] for item in payload["items"])
            cursor = payload["next_cursor"]
            if not cursor:
                break
        assert counts == [2, 1]
        assert len(seen) == 3
        assert len(set(seen)) == 3
    finally:
        db.close()
        engine.dispose()


def test_snapshot_history_filters_work():
    client, db, engine = _client()
    try:
        _seed(db)
        warning = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"severity": "warning"},
        )
        assert warning.status_code == 200
        assert warning.json()["count"] == 3

        enabled = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"assume_enabled": "true"},
        )
        assert enabled.status_code == 200
        assert enabled.json()["count"] == 2

        policy = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"use_policy": "true"},
        )
        assert policy.status_code == 200
        assert policy.json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_snapshot_history_rejects_invalid_cursor_filters_and_range():
    client, db, engine = _client()
    try:
        bad_cursor = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert bad_cursor.status_code == 422

        bad_health = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"health": "broken"},
        )
        assert bad_health.status_code == 422

        bad_severity = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"severity": "urgent"},
        )
        assert bad_severity.status_code == 422

        bad_range = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={
                "start_at": "2026-09-20T00:00:00Z",
                "end_at": "2026-09-19T00:00:00Z",
            },
        )
        assert bad_range.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_snapshot_history_time_boundaries_are_supported():
    client, db, engine = _client()
    try:
        _seed(db)
        response = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={
                "start_at": "2026-09-19T11:00:00Z",
                "end_at": "2026-09-19T12:00:00Z",
            },
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 1
        assert payload["items"][0]["captured_at"].startswith("2026-09-19T11:00:00")
    finally:
        db.close()
        engine.dispose()
