from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionRun, MemoryRetentionRunResult
from backend_v2.memory.retention_run_history import MemoryRetentionRunHistoryService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_run(db, run_id: str, completed_at: datetime, user_id: str) -> None:
    db.add(
        MemoryRetentionRun(
            run_id=run_id,
            status="completed",
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            dry_run=False,
            user_count=1,
            planned_count=0,
            executed_count=1,
            skipped_count=0,
            failed_count=0,
            candidate_count=1,
            would_delete_count=1,
            deleted_count=1,
        )
    )
    db.add(
        MemoryRetentionRunResult(
            run_id=run_id,
            user_id=user_id,
            status="executed",
            candidate_count=1,
            deleted_count=1,
            would_delete_count=1,
            dry_run=False,
            retention_days=30,
            executed_at=completed_at,
        )
    )
    db.commit()


def test_preview_is_read_only_and_respects_limit():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "old-a", cutoff - timedelta(days=2), "a")
        _seed_run(db, "old-b", cutoff - timedelta(days=1), "b")
        _seed_run(db, "new-c", cutoff + timedelta(days=1), "c")
        service = MemoryRetentionRunHistoryService(db)
        preview = service.preview(older_than=cutoff, max_delete=1)
        assert preview.candidate_count == 2
        assert preview.would_delete_count == 1
        assert db.get(MemoryRetentionRun, "old-a") is not None
        assert db.get(MemoryRetentionRun, "old-b") is not None
        assert db.get(MemoryRetentionRun, "new-c") is not None
    finally:
        db.close()
        engine.dispose()


def test_apply_deletes_parent_and_child_rows_atomically():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "delete-a", cutoff - timedelta(days=2), "a")
        result = MemoryRetentionRunHistoryService(db).apply(older_than=cutoff, max_delete=10)
        assert result.candidate_count == 1
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionRun, "delete-a") is None
        assert db.scalar(select(MemoryRetentionRunResult).where(MemoryRetentionRunResult.run_id == "delete-a")) is None
    finally:
        db.close()
        engine.dispose()


def test_apply_keeps_newer_runs():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "new-a", cutoff + timedelta(days=1), "a")
        result = MemoryRetentionRunHistoryService(db).apply(older_than=cutoff, max_delete=10)
        assert result.deleted_count == 0
        assert db.get(MemoryRetentionRun, "new-a") is not None
    finally:
        db.close()
        engine.dispose()


def test_future_cutoff_and_invalid_limit_are_rejected():
    db, engine = _db()
    try:
        service = MemoryRetentionRunHistoryService(db)
        for kwargs in (
            {"older_than": datetime.now(UTC) + timedelta(days=1)},
            {"older_than": datetime.now(UTC), "max_delete": 0},
            {"older_than": datetime.now(UTC), "max_delete": 501},
        ):
            try:
                service.preview(**kwargs)
            except ValueError:
                pass
            else:
                raise AssertionError("expected ValueError")
    finally:
        db.close()
        engine.dispose()


def test_injected_session_leaves_commit_to_caller():
    db, engine = _db()
    try:
        cutoff = datetime(2026, 9, 10)
        _seed_run(db, "tx-a", cutoff - timedelta(days=2), "a")
        MemoryRetentionRunHistoryService(db).apply(older_than=cutoff, max_delete=10)
        assert db.get(MemoryRetentionRun, "tx-a") is None
        db.rollback()
        assert db.get(MemoryRetentionRun, "tx-a") is not None
    finally:
        db.close()
        engine.dispose()
