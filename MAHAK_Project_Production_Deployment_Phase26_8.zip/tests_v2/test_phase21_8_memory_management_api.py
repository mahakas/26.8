from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(memory: MemoryService, user_id: str = "student-api-21-8") -> list[str]:
    ids = []
    for index in range(3):
        row = memory.remember(
            user_id=user_id,
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key=f"turn:{index}",
            value={"index": index},
            conversation_id="conv-a" if index < 2 else "conv-b",
        )
        ids.append(row.id)
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.PREVIOUS_QUESTION,
        memory_key="q:1",
        value={"question": "2+2?"},
        conversation_id="conv-a",
    )
    return ids


def test_delete_memory_endpoint_is_owner_scoped():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        owner_id = memory.remember(
            user_id="owner-21-8",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "2+2?"},
        ).id
        other_id = memory.remember(
            user_id="other-21-8",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "3+3?"},
        ).id
        db.commit()

        forbidden_delete = client.delete(f"/api/memory/other-21-8/records/{owner_id}")
        assert forbidden_delete.status_code == 404
        assert client.delete(f"/api/memory/owner-21-8/records/{owner_id}").json() == {
            "user_id": "owner-21-8",
            "action": "delete",
            "deleted_count": 1,
        }
        assert client.get("/api/memory/other-21-8/records").json()["count"] == 1
        assert other_id != owner_id
    finally:
        db.close()
        engine.dispose()


def test_clear_endpoint_supports_type_and_conversation_filters():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        _seed(memory)
        db.commit()

        response = client.delete(
            "/api/memory/student-api-21-8/records",
            params={"memory_type": "learning_history", "conversation_id": "conv-a"},
        )
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 2
        remaining = client.get("/api/memory/student-api-21-8/records").json()
        assert remaining["count"] == 2
        assert {item["memory_key"] for item in remaining["items"]} == {"turn:2", "q:1"}
    finally:
        db.close()
        engine.dispose()


def test_prune_endpoint_keeps_newest_records_and_supports_type_filter():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        _seed(memory)
        db.commit()

        response = client.post(
            "/api/memory/student-api-21-8/prune",
            params={"max_records": 1, "memory_type": "learning_history"},
        )
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 2
        remaining = client.get(
            "/api/memory/student-api-21-8/records",
            params={"memory_type": "learning_history"},
        ).json()
        assert remaining["count"] == 1
        assert remaining["items"][0]["value"]["index"] == 2
    finally:
        db.close()
        engine.dispose()


def test_management_api_validates_prune_limit_and_unknown_delete():
    client, db, engine = _client()
    try:
        assert client.post(
            "/api/memory/student-api-21-8/prune",
            params={"max_records": 0},
        ).status_code == 422
        assert client.delete(
            "/api/memory/student-api-21-8/records/does-not-exist",
        ).status_code == 404
    finally:
        db.close()
        engine.dispose()


def test_management_api_does_not_cross_user_boundaries_on_clear_or_prune():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="user-a",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="a:1",
            value={"topic": "algebra"},
        )
        memory.remember(
            user_id="user-b",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="b:1",
            value={"topic": "geometry"},
        )
        db.commit()

        response = client.delete("/api/memory/user-a/records")
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 1
        assert client.get("/api/memory/user-b/records").json()["count"] == 1

        response = client.post("/api/memory/user-a/prune", params={"max_records": 1})
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 0
        assert client.get("/api/memory/user-b/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_management_mutations_persist_across_http_requests():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    seed_db = Session()
    try:
        memory = MemoryService(seed_db)
        memory.remember(
            user_id="persisted-management",
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra"},
        )
        seed_db.commit()

        response = client.delete("/api/memory/persisted-management/records")
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 1
        assert client.get("/api/memory/persisted-management/records").json()["count"] == 0
    finally:
        seed_db.close()
        engine.dispose()
