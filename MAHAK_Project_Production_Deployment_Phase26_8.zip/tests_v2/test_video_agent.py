from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.agents.video import VideoAgent
from backend_v2.schemas.video_answer import VideoAnswerResponse
from backend_v2.vectorstores.base import VectorHit


def _hit() -> VectorHit:
    return VectorHit(
        "video-1",
        0.88,
        "قانون دوم نیوتن در این بخش توضیح داده می‌شود.",
        {
            "source_id": "video-source-1",
            "title": "قانون دوم نیوتن",
            "source_type": "video",
            "kind": "transcript",
            "start_time_seconds": 28.22,
            "end_time_seconds": 34.0,
            "frame_path": "frames/frame-28.jpg",
            "frame_timestamp_seconds": 30.0,
        },
    )


def test_video_agent_returns_video_evidence_and_citations():
    agent = VideoAgent()
    result = agent.execute("explain this video", hits=[_hit()])

    assert agent.agent_type == AgentType.VIDEO
    assert result.confidence == 0.88
    assert result.evidence[0]["type"] == "video"
    assert result.evidence[0]["timestamp"]["start"] == 28.22
    assert result.evidence[0]["timestamp"]["end"] == 34.0
    assert result.evidence[0]["frame_path"] == "frames/frame-28.jpg"
    assert result.citations[0]["source_id"] == "video-source-1"
    assert result.citations[0]["frame_path"] == "frames/frame-28.jpg"


def test_video_agent_converts_agent_result_to_phase19_schema():
    agent = VideoAgent()
    result = agent.execute("explain this video", hits=[_hit()])
    response = agent.to_response(result, provider="test-provider", model="test-model")

    assert isinstance(response, VideoAnswerResponse)
    assert response.found is True
    assert response.evidence[0].timestamp.start == 28.22
    assert response.evidence[0].timestamp.end == 34.0
    assert response.evidence[0].frame_path == "frames/frame-28.jpg"
    assert response.citations[0].start_time_seconds == 28.22
    assert response.citations[0].frame_path == "frames/frame-28.jpg"
    assert response.provider == "test-provider"
    assert response.model == "test-model"


def test_router_executes_registered_video_agent():
    registry = AgentRegistry()
    registry.register(VideoAgent())
    router = AgentRouter(registry)

    result = router.execute("find this video explanation", hits=[_hit()])

    assert result.confidence == 0.88
    assert result.evidence[0]["type"] == "video"
    assert result.citations[0]["frame_path"] == "frames/frame-28.jpg"
