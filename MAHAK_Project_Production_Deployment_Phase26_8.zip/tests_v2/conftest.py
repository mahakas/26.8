from __future__ import annotations

import os

# Unit/integration tests use deterministic mock providers. Live provider smoke
# tests opt in explicitly inside their own process.
os.environ["MAHAK_PROVIDER_MODE"] = "mock"
