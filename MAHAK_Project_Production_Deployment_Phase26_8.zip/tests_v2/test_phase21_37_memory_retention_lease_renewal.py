from __future__ import annotations

from datetime import datetime, timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceLease
from backend_v2.memory.retention_maintenance_lease import (
    MemoryRetentionMaintenanceLeaseLostError,
    MemoryRetentionMaintenanceLeaseService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_renew_extends_expiration_without_changing_owner():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        acquired_at = datetime(2026, 9, 19, 12, 0, 0)
        renewed_at = acquired_at + timedelta(seconds=30)
        handle = service.acquire(ttl_seconds=60, now=acquired_at)
        renewed = service.renew(handle, ttl_seconds=120, now=renewed_at)
        assert renewed.owner_token == handle.owner_token
        assert renewed.acquired_at == handle.acquired_at
        assert renewed.expires_at == renewed_at + timedelta(seconds=120)
        assert service.release(renewed) is True
    finally:
        db.close()
        engine.dispose()


def test_renew_rejects_expired_lease():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        acquired_at = datetime(2026, 9, 19, 12, 0, 0)
        handle = service.acquire(ttl_seconds=30, now=acquired_at)
        with pytest.raises(MemoryRetentionMaintenanceLeaseLostError):
            service.renew(
                handle,
                ttl_seconds=60,
                now=acquired_at + timedelta(seconds=31),
            )
    finally:
        db.close()
        engine.dispose()


def test_renew_rejects_stale_owner_after_reclaim():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        base_time = datetime(2026, 9, 19, 12, 0, 0)
        stale = service.acquire(ttl_seconds=10, now=base_time)
        replacement = service.acquire(ttl_seconds=60, now=base_time + timedelta(seconds=11))
        with pytest.raises(MemoryRetentionMaintenanceLeaseLostError):
            service.renew(stale, ttl_seconds=60, now=base_time + timedelta(seconds=12))
        assert service.release(replacement) is True
    finally:
        db.close()
        engine.dispose()


def test_renew_rejects_invalid_ttl_without_mutation():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        handle = service.acquire(ttl_seconds=30)
        old = db.query(MemoryRetentionMaintenanceLease).one().expires_at
        with pytest.raises(ValueError):
            service.renew(handle, ttl_seconds=0)
        assert db.query(MemoryRetentionMaintenanceLease).one().expires_at == old
        assert service.release(handle) is True
    finally:
        db.close()
        engine.dispose()


def test_existing_persistent_guard_contract_remains_usable_after_renewal():
    db, engine = _db()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        handle = service.acquire(ttl_seconds=30)
        renewed = service.renew(handle, ttl_seconds=30)
        assert renewed.owner_token == handle.owner_token
        assert service.release(renewed) is True
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
    finally:
        db.close()
        engine.dispose()
