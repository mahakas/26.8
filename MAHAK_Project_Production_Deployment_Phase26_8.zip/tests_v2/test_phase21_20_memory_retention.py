from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, user_id: str) -> None:
    base = datetime(2026, 1, 1, tzinfo=UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="q-old-1",
                value_json={"q": "old-1"},
                created_at=base,
                updated_at=base,
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.WEAK_AREA.value,
                memory_key="weak-old",
                value_json={"topic": "algebra"},
                created_at=base + timedelta(hours=1),
                updated_at=base + timedelta(hours=1),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="q-new",
                value_json={"q": "new"},
                created_at=base + timedelta(days=10),
                updated_at=base + timedelta(days=10),
            ),
            LearningMemory(
                user_id="other-user",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="other-old",
                value_json={"q": "other"},
                created_at=base,
                updated_at=base,
            ),
        ]
    )
    db.commit()


def test_retention_preview_is_read_only_and_user_scoped():
    client, db, engine = _client()
    try:
        _seed(db, "retention-user")
        before = len(db.scalars(select(LearningMemory).where(LearningMemory.user_id == "retention-user")).all())
        response = client.post(
            "/api/memory/retention-user/retention/preview",
            params={
                "older_than": "2026-01-05T00:00:00Z",
                "max_delete": 1,
            },
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["candidate_count"] == 2
        assert payload["would_delete_count"] == 1
        assert payload["read_only"] is True
        after = len(db.scalars(select(LearningMemory).where(LearningMemory.user_id == "retention-user")).all())
        audit_count = len(db.scalars(select(MemoryAuditEvent).where(MemoryAuditEvent.user_id == "retention-user")).all())
        assert before == after == 3
        assert audit_count == 0
    finally:
        db.close()
        engine.dispose()


def test_retention_preview_supports_memory_type_and_rejects_future_cutoff():
    client, db, engine = _client()
    try:
        _seed(db, "filter-user")
        response = client.post(
            "/api/memory/filter-user/retention/preview",
            params={
                "older_than": "2026-01-05T00:00:00Z",
                "memory_type": "weak_area",
                "max_delete": 500,
            },
        )
        assert response.status_code == 200
        assert response.json()["candidate_count"] == 1
        bad = client.post(
            "/api/memory/filter-user/retention/preview",
            params={"older_than": "2999-01-01T00:00:00Z"},
        )
        assert bad.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_retention_apply_deletes_oldest_up_to_safety_cap_and_audits():
    client, db, engine = _client()
    try:
        _seed(db, "apply-user")
        response = client.post(
            "/api/memory/apply-user/retention/apply",
            params={
                "older_than": "2026-01-05T00:00:00Z",
                "max_delete": 1,
            },
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload == {"user_id": "apply-user", "action": "retention", "deleted_count": 1}

        remaining = list(db.scalars(select(LearningMemory).where(LearningMemory.user_id == "apply-user")).all())
        assert len(remaining) == 2
        assert {row.memory_key for row in remaining} == {"weak-old", "q-new"}

        audit = list(db.scalars(select(MemoryAuditEvent).where(MemoryAuditEvent.user_id == "apply-user")).all())
        assert len(audit) == 1
        assert audit[0].action == "retention"
        assert audit[0].affected_count == 1

        # Commit persistence across the next HTTP request.
        second = client.get("/api/memory/apply-user/records")
        assert second.status_code == 200
        assert second.json()["count"] == 2
    finally:
        db.close()
        engine.dispose()


def test_retention_apply_zero_candidates_does_not_emit_audit_event():
    client, db, engine = _client()
    try:
        _seed(db, "none-user")
        response = client.post(
            "/api/memory/none-user/retention/apply",
            params={"older_than": "2025-01-01T00:00:00Z"},
        )
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 0
        assert len(db.scalars(select(MemoryAuditEvent).where(MemoryAuditEvent.user_id == "none-user")).all()) == 0
    finally:
        db.close()
        engine.dispose()


def test_retention_service_rejects_empty_user_and_invalid_limit():
    service = MemoryService()
    cutoff = datetime(2026, 1, 1)
    try:
        service.preview_retention("   ", older_than=cutoff)
        raise AssertionError("empty user_id should fail")
    except ValueError:
        pass
    try:
        service.preview_retention("user", older_than=cutoff, max_delete=0)
        raise AssertionError("invalid max_delete should fail")
    except ValueError:
        pass
