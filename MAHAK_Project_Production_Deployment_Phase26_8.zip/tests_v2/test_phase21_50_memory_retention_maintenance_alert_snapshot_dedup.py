from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot, MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_alert_persistence import (
    MemoryRetentionMaintenanceAlertSnapshotService,
)


def _db():
    engine = create_engine(
        "sqlite:///:memory:", future=True,
        connect_args={"check_same_thread": False}, poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    return engine, sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()


def _seed(db):
    db.add(MemoryRetentionMaintenanceRun(
        run_id="phase21-50-run",
        status="completed",
        started_at=datetime(2026, 9, 19, 11, 58, 30),
        completed_at=datetime(2026, 9, 19, 11, 59, 30),
        dry_run=False,
        cleanup_history=True,
        memory_status="completed",
        memory_user_count=1,
        memory_planned_count=1,
        memory_executed_count=1,
        memory_skipped_count=0,
        memory_failed_count=0,
        memory_candidate_count=0,
        memory_would_delete_count=0,
        memory_deleted_count=0,
        history_status="completed",
        history_configured=True,
        history_retention_days=365,
        history_max_delete=500,
        history_candidate_count=0,
        history_would_delete_count=0,
        history_deleted_count=0,
    ))
    db.commit()


def test_capture_if_changed_deduplicates_identical_latest_state():
    engine, db = _db()
    try:
        _seed(db)
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True, stale_after_seconds=60)
        first = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 0))
        second = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 10))
        db.commit()
        assert first.created is True and first.deduplicated is False
        assert second.created is False and second.deduplicated is True
        assert second.snapshot.snapshot_id == first.snapshot.snapshot_id
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
    finally:
        db.close(); engine.dispose()


def test_capture_if_changed_creates_when_alert_state_changes():
    engine, db = _db()
    try:
        _seed(db)
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True, stale_after_seconds=60)
        first = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 0))
        second = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 2, 0))
        db.commit()
        assert first.created is True
        assert second.created is True
        assert second.deduplicated is False
        assert second.snapshot.snapshot_id != first.snapshot.snapshot_id
        assert second.snapshot.severity == "warning"
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 2
    finally:
        db.close(); engine.dispose()


def test_capture_remains_legacy_non_deduplicating():
    engine, db = _db()
    try:
        _seed(db)
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True, stale_after_seconds=60)
        first = service.capture(now=datetime(2026, 9, 19, 12, 0, 0))
        second = service.capture(now=datetime(2026, 9, 19, 12, 0, 10))
        db.commit()
        assert first.snapshot_id != second.snapshot_id
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 2
    finally:
        db.close(); engine.dispose()


def test_capture_if_changed_honors_injected_transaction_rollback():
    engine, db = _db()
    try:
        _seed(db)
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True)
        outcome = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 0))
        assert outcome.created is True
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
        db.rollback()
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 0
    finally:
        db.close(); engine.dispose()
