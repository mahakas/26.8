from pathlib import Path

from backend_v2.core.enums import Capability, SourceType
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import (
    FFmpegFrameSampler, SidecarTranscript, TranscriptSegment, VideoProcessor,
)
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def _vision_orchestrator() -> ProviderOrchestrator:
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            'vision-test', {Capability.VISION}, default_model='vision-v1',
            handler=lambda payload: 'فریم آموزشی: نمودار قانون دوم نیوتن، F = ma.',
        ),
        priority=1,
    )
    return ProviderOrchestrator(registry, ProviderHealthManager(), max_attempts=1)


class FakeTranscriber:
    def transcribe(self, path: Path):
        return [
            TranscriptSegment(12.0, 18.5, 'قانون دوم نیوتن می‌گوید F = ma.'),
            TranscriptSegment(30.0, 36.0, 'هرچه جرم بیشتر باشد، برای نیروی یکسان شتاب کمتر است.'),
        ]


class FakeSampler:
    def sample(self, path: Path, output_dir: Path, duration=None):
        return []


def test_video_loader_declares_capabilities(tmp_path):
    p = tmp_path / 'lesson.mp4'
    p.write_bytes(b'video-placeholder')
    result = IngestionPipeline().process(p)
    assert result.analysis.source_type is SourceType.VIDEO
    assert Capability.TRANSCRIPTION in result.required_capabilities
    assert Capability.VISION in result.required_capabilities
    assert result.document.metadata['video_id'] == 'lesson'


def test_sidecar_srt_parses_timestamps(tmp_path):
    video = tmp_path / 'lesson.mp4'
    video.write_bytes(b'x')
    srt = tmp_path / 'lesson.srt'
    srt.write_text('1\n00:00:12,000 --> 00:00:18,500\nقانون دوم نیوتن\n\n2\n00:00:30,000 --> 00:00:36,000\nشتاب با جرم مرتبط است.\n', encoding='utf-8')
    result = SidecarTranscript().transcribe(video)
    assert len(result) == 2
    assert result[0].start == 12.0
    assert result[0].end == 18.5


def test_video_processor_builds_timestamp_aware_chunks(tmp_path):
    p = tmp_path / 'lesson.mp4'
    p.write_bytes(b'x')
    processor = VideoProcessor(_vision_orchestrator(), transcriber=FakeTranscriber(), frame_sampler=FakeSampler())
    pipeline = IngestionPipeline(video_processor=processor, chunk_size=400, overlap=40)
    result = pipeline.process(p)
    assert result.chunks
    assert result.required_capabilities == frozenset()
    assert all('start_time_seconds' in c.metadata for c in result.chunks)
    assert result.document.metadata['transcript_present'] is True


def test_video_processor_warns_when_no_transcript_and_no_frames(tmp_path):
    p = tmp_path / 'lesson.mp4'
    p.write_bytes(b'x')
    processor = VideoProcessor(None, transcriber=None, frame_sampler=FakeSampler(), vision_enabled=False)
    pipeline = IngestionPipeline(video_processor=processor)
    result = pipeline.process(p)
    assert 'no transcript available' in '\n'.join(result.warnings)
    assert result.chunks == ()


def test_video_segments_preserve_kind_and_timestamps(tmp_path):
    p = tmp_path / 'lesson.mp4'
    p.write_bytes(b'x')
    processor = VideoProcessor(None, transcriber=FakeTranscriber(), frame_sampler=FakeSampler(), vision_enabled=False)
    result = IngestionPipeline(video_processor=processor).process(p)
    kinds = {chunk.metadata.get('kind') for chunk in result.chunks}
    assert 'transcript' in kinds
    assert sorted(c.metadata['start_time_seconds'] for c in result.chunks) == [12.0, 30.0]


def test_frame_sampler_requires_ffmpeg_when_missing(monkeypatch, tmp_path):
    video = tmp_path / 'lesson.mp4'
    video.write_bytes(b'x')
    monkeypatch.setattr('shutil.which', lambda name: None)
    try:
        FFmpegFrameSampler().sample(video, tmp_path / 'frames', duration=10)
    except RuntimeError as exc:
        assert 'ffmpeg is required' in str(exc)
    else:
        raise AssertionError('Expected missing ffmpeg error')
