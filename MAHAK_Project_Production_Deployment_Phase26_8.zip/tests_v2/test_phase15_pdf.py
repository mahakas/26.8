from __future__ import annotations

from pathlib import Path

import pytest

from backend_v2.ingestion.loaders.pdf import PdfLoader
from backend_v2.ingestion.analyzer import FileAnalyzer
from backend_v2.ingestion.processors.chunk import TextChunker
from backend_v2.ingestion.pipeline import IngestionPipeline


def _make_text_pdf(path: Path) -> None:
    import fitz
    doc = fitz.open()
    page1 = doc.new_page()
    page1.insert_text((72, 72), "فیزیک دهم\nقانون دوم نیوتن: F = m a")
    page2 = doc.new_page()
    page2.insert_text((72, 72), "صفحه دوم\nاگر نیروی خالص صفر باشد، شتاب صفر است.")
    doc.save(path)
    doc.close()


def test_pdf_loader_preserves_page_text_and_locations(tmp_path):
    pdf = tmp_path / "physics.pdf"
    _make_text_pdf(pdf)
    analysis = FileAnalyzer().analyze(pdf)
    document = PdfLoader().load(analysis)
    assert document.metadata["pdf_kind"] == "text"
    assert document.metadata["pages"] == 2
    assert document.page_texts[0][0] == 1
    assert document.page_texts[1][0] == 2
    chunks = TextChunker(chunk_size=500, overlap=40).chunk(document)
    assert len(chunks) == 2
    assert chunks[0].location is not None and chunks[0].location.page == 1
    assert chunks[1].location is not None and chunks[1].location.page == 2


def test_pdf_pipeline_marks_unresolved_scanned_pages(tmp_path):
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (600, 300), "white")
    draw = ImageDraw.Draw(img)
    draw.text((30, 120), "Newton Law", fill="black")
    pdf = tmp_path / "scanned.pdf"
    img.save(pdf, "PDF")
    result = IngestionPipeline().process(pdf)
    assert result.document.metadata["pdf_kind"] in {"scanned", "hybrid"}
    assert result.document.metadata["unresolved_scanned_pages"]
    assert result.needs_provider_processing


def test_pdf_loader_ocr_hook_can_resolve_scanned_page(tmp_path, monkeypatch):
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (400, 200), "white")
    draw = ImageDraw.Draw(img)
    draw.text((20, 80), "scan", fill="black")
    pdf = tmp_path / "scanned.pdf"
    img.save(pdf, "PDF")
    monkeypatch.setattr("backend_v2.ingestion.loaders.pdf.settings", type("S", (), {
        "pdf_render_dpi": 180,
        "pdf_ocr_lang": "eng",
        "pdf_ocr_enabled": True,
        "pdf_min_text_chars_per_page": 20,
    })())
    monkeypatch.setattr("backend_v2.ingestion.loaders.pdf._ocr_page", lambda _p, _n: "OCR extracted Newton text")
    document = PdfLoader().load(FileAnalyzer().analyze(pdf))
    assert document.metadata["ocr_pages"] == [1]
    assert document.metadata["unresolved_scanned_pages"] == []
    assert document.page_texts[0][0] == 1
    assert "OCR extracted" in document.text
    assert not document.requires


def test_vector_metadata_omits_empty_pdf_lists(tmp_path):
    from backend_v2.ingestion.document import ContentChunk, SourceLocation
    from backend_v2.vectorstores.knowledge import KnowledgeIndexService
    from backend_v2.vectorstores.memory import InMemoryVectorStore
    from backend_v2.vectorstores.embedding import EmbeddingResult
    from backend_v2.vectorstores.indexing import IndexSpec

    class FakeEmbedding:
        def embed(self, texts):
            return EmbeddingResult(
                vectors=[[0.1, 0.2]],
                provider="test",
                model="test",
                dimension=2,
            )

    store = InMemoryVectorStore()
    service = KnowledgeIndexService(store, FakeEmbedding())
    chunk = ContentChunk(
        chunk_id="pdf-1",
        text="قانون دوم نیوتن",
        index=0,
        metadata={"ocr_pages": [], "unresolved_scanned_pages": []},
        location=SourceLocation(page=1),
    )
    result = service.index_chunks(
        [chunk],
        index_spec=IndexSpec("phase15-test", "test", "v1", 2),
        source_id="s1",
        title="PDF Test",
    )
    assert result.indexed == 1
    hit = store.search([0.1, 0.2], collection=result.collection, top_k=1)[0]
    assert "ocr_pages" not in hit.metadata
    assert "unresolved_scanned_pages" not in hit.metadata
