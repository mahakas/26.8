from __future__ import annotations

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import (
    EducationalRetrievalEvaluationRequest,
    EducationalRetrievalEvaluationService,
)


def test_retrieval_metrics_reward_relevant_first_hit():
    result = EducationalRetrievalEvaluationService().evaluate(
        EducationalRetrievalEvaluationRequest(
            expected_source_ids=("a", "b"),
            retrieved_source_ids=("a", "x", "b", "y"),
            cutoffs=(1, 3),
        )
    )
    assert result.reciprocal_rank == 1.0
    assert result.average_precision == 0.833333
    assert result.precision_at_k["1"] == 1.0
    assert result.recall_at_k["3"] == 1.0
    assert result.ndcg_at_k["1"] == 1.0
    assert result.hit_rate_at_k["1"] == 1.0


def test_retrieval_metrics_penalize_relevant_late():
    result = EducationalRetrievalEvaluationService().evaluate(
        EducationalRetrievalEvaluationRequest(
            expected_source_ids=("a", "b"),
            retrieved_source_ids=("x", "y", "a", "b"),
            cutoffs=(1, 3, 4),
        )
    )
    assert result.reciprocal_rank == 0.333333
    assert result.recall_at_k["1"] == 0.0
    assert result.recall_at_k["3"] == 0.5
    assert result.recall_at_k["4"] == 1.0
    assert result.ndcg_at_k["4"] == 0.570642


def test_retrieval_deduplicates_ids_case_insensitively():
    result = EducationalRetrievalEvaluationService().evaluate(
        EducationalRetrievalEvaluationRequest(
            expected_source_ids=("Lesson.PDF", "lesson.pdf", "notes.pdf"),
            retrieved_source_ids=("LESSON.PDF", "lesson.pdf", "notes.pdf"),
            cutoffs=(1, 3),
        )
    )
    assert result.relevant_count == 2
    assert result.retrieved_count == 2
    assert result.recall_at_k["3"] == 1.0


def test_empty_retrieval_is_zero_and_evaluable():
    result = EducationalRetrievalEvaluationService().evaluate(
        EducationalRetrievalEvaluationRequest(expected_source_ids=("a",), retrieved_source_ids=(), cutoffs=(1, 5))
    )
    assert result.reciprocal_rank == 0.0
    assert result.average_precision == 0.0
    assert result.precision_at_k["1"] == 0.0
    assert result.recall_at_k["5"] == 0.0
    assert result.hit_rate_at_k["5"] == 0.0


def test_invalid_reference_set_is_rejected():
    try:
        EducationalRetrievalEvaluationService().evaluate(
            EducationalRetrievalEvaluationRequest(expected_source_ids=(), retrieved_source_ids=("a",))
        )
    except ValueError as exc:
        assert "expected_source_ids" in str(exc)
    else:
        raise AssertionError("empty expected_source_ids should fail")


def test_batch_aggregates_rank_metrics():
    result = EducationalRetrievalEvaluationService.evaluate_batch(
        (
            EducationalRetrievalEvaluationRequest(expected_source_ids=("a",), retrieved_source_ids=("a",), cutoffs=(1, 3)),
            EducationalRetrievalEvaluationRequest(expected_source_ids=("b",), retrieved_source_ids=("x", "b"), cutoffs=(1, 3)),
        )
    )
    assert result.total_cases == 2
    assert result.evaluated_cases == 2
    assert result.failed_cases == 0
    assert result.mean_reciprocal_rank == 0.75
    assert result.mean_recall_at_k["3"] == 1.0


def test_batch_fail_fast_reports_error():
    result = EducationalRetrievalEvaluationService.evaluate_batch(
        (
            EducationalRetrievalEvaluationRequest(expected_source_ids=(), retrieved_source_ids=("a",)),
            EducationalRetrievalEvaluationRequest(expected_source_ids=("b",), retrieved_source_ids=("b",)),
        ),
        fail_fast=True,
    )
    assert result.total_cases == 2
    assert result.evaluated_cases == 0
    assert result.failed_cases == 1
    assert result.errors[0]["case_index"] == "1"


def test_retrieval_api_returns_rank_metrics():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/retrieval",
        json={
            "expected_source_ids": ["physics.pdf", "chapter.pdf"],
            "retrieved_source_ids": ["physics.pdf", "other.pdf", "chapter.pdf"],
            "cutoffs": [1, 3],
        },
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["reciprocal_rank"] == 1.0
    assert payload["recall_at_k"]["3"] == 1.0
    assert payload["ndcg_at_k"]["1"] == 1.0


def test_retrieval_batch_api_returns_aggregate():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/retrieval/batch",
        json={
            "cases": [
                {"expected_source_ids": ["a"], "retrieved_source_ids": ["a"], "cutoffs": [1, 3]},
                {"expected_source_ids": ["b"], "retrieved_source_ids": ["x", "b"], "cutoffs": [1, 3]},
            ]
        },
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["total_cases"] == 2
    assert payload["evaluated_cases"] == 2
    assert payload["mean_reciprocal_rank"] == 0.75
