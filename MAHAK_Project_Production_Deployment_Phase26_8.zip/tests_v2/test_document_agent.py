from backend_v2.agents.document import DocumentAgent
from backend_v2.agents.types import AgentType


def test_document_agent_returns_evidence_and_citations():
    agent = DocumentAgent()

    result = agent.execute(
        "explain page",
        hits=[
            {
                "text": "Newton law",
                "metadata": {
                    "source_id": "book1",
                    "title": "Physics",
                    "page": 12,
                },
            }
        ],
    )

    assert agent.agent_type == AgentType.DOCUMENT
    assert result.confidence == 0.8
    assert len(result.evidence) == 1
    assert result.evidence[0]["page"] == 12
    assert result.citations[0]["source_id"] == "book1"
