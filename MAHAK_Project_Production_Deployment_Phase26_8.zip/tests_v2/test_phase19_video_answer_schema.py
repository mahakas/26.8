from backend_v2.schemas.video_answer import VideoAnswerResponse
from backend_v2.schemas.video_evidence import VideoEvidence, VideoTimestamp


def test_phase19_video_answer_schema():
    response = VideoAnswerResponse(
        answer="video explanation",
        evidence=[
            VideoEvidence(
                timestamp=VideoTimestamp(start=10.5, end=15.2),
                frame_path="frames/frame_001.jpg",
                transcript="example transcript",
                confidence=0.9,
            )
        ],
        confidence=0.9,
    )

    assert response.evidence[0].timestamp.start == 10.5
    assert response.evidence[0].frame_path == "frames/frame_001.jpg"
