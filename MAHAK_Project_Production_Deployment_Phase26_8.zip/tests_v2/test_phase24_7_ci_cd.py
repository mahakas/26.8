from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _text(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_ci_workflow_has_quality_and_docker_gates() -> None:
    text = _text(".github/workflows/ci.yml")
    assert "pull_request:" in text
    assert "push:" in text
    assert "permissions:" in text
    assert "contents: read" in text
    assert "ci_quality_gate_phase24_7.py --require-docker" in text
    assert "docker build --pull" in text
    assert "docker compose config --quiet" in text


def test_ci_workflow_has_concurrency_protection() -> None:
    text = _text(".github/workflows/ci.yml")
    assert "concurrency:" in text
    assert "cancel-in-progress: true" in text


def test_release_workflow_publishes_versioned_image() -> None:
    text = _text(".github/workflows/release.yml")
    assert "tags:" in text
    assert "v*.*.*" in text
    assert "packages: write" in text
    assert "docker/login-action@v3" in text
    assert "docker/build-push-action@v6" in text
    assert "push: true" in text
    assert "type=ref,event=tag" in text
    assert "type=sha" in text


def test_local_quality_gate_script_runs_required_stages() -> None:
    text = _text("scripts/ci_quality_gate_phase24_7.py")
    for expected in (
        '"pytest regression"',
        '"compileall"',
        '"security hardening smoke"',
        '"observability smoke"',
        '"docker packaging smoke"',
        "--require-docker",
    ):
        assert expected in text


def test_ci_smoke_exists_and_uses_quality_gate() -> None:
    text = _text("scripts/smoke_ci_quality_gate_phase24_7.py")
    assert "ci_quality_gate_phase24_7.py" in text
    assert "--skip-tests" in text


def test_docker_smoke_supports_required_and_optional_modes() -> None:
    text = _text("scripts/smoke_docker_deployment_phase24_6.py")
    assert "--require-docker" in text
    assert "--optional-docker" in text
    assert "docker_path" in text


def test_gitignore_blocks_secrets_state_and_media() -> None:
    text = _text(".gitignore")
    for expected in (".env", ".env.*", "!.env.example", "!.env.production.example", "*.db", "storage_v2/", "*.mp4"):
        assert expected in text


def test_phase24_7_documentation_exists() -> None:
    assert (ROOT / "README_PHASE24_7.md").exists()
    assert (ROOT / "ROADMAP_STATUS_PHASE24_7.md").exists()
    readme = _text("README_PHASE24_7.md")
    assert "CI/CD Pipeline & Automated Quality Gates" in readme
    assert "GHCR" in readme


def test_ci_does_not_grant_write_access_to_repository() -> None:
    text = _text(".github/workflows/ci.yml")
    assert "contents: write" not in text
