from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.agents.teacher_report import TeacherReportService
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService


def _memory():
    engine = create_engine("sqlite:///:memory:", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def test_teacher_report_contains_dashboard_interactions_feedback_and_csv():
    memory, db, engine = _memory()
    try:
        interaction = TeacherInteractionService(memory).record(
            user_id="u25-11", conversation_id="c25-11", question="سؤال گزارش", agent_types=("DOCUMENT_AGENT",),
            modalities=("document",), strategy_mode="explain", strategy_difficulty="standard", learning_outcome="stable",
            recommended_mode="explain", recommended_difficulty="standard", next_action="continue", confidence=0.88,
            evidence_count=2, citation_count=2, found=True, learning_plan_id="plan-1",
        )
        TeacherFeedbackService(memory).record(
            user_id="u25-11", conversation_id="c25-11", feedback_id="fb-1", interaction_id=interaction.interaction_id,
            rating=4, understood=True, strategy_effective=True,
        )
        report = TeacherReportService(memory).build("u25-11", conversation_id="c25-11", learning_plan_id="plan-1")
        assert report.generated_for == "u25-11"
        assert len(report.interactions) == 1
        assert len(report.feedback) == 1
        csv_text = TeacherReportService.to_csv(report)
        assert "interaction_id" in csv_text
        assert "feedback" in csv_text
    finally:
        db.close(); engine.dispose()


def test_plan_scoped_report_excludes_unrelated_feedback():
    memory, db, engine = _memory()
    try:
        TeacherFeedbackService(memory).record(user_id="u25-11-b", conversation_id="c25-11-b", feedback_id="free", rating=5, understood=True)
        report = TeacherReportService(memory).build("u25-11-b", conversation_id="c25-11-b", learning_plan_id="plan-x")
        assert report.feedback == ()
    finally:
        db.close(); engine.dispose()


def test_teacher_report_api_json_and_csv(monkeypatch):
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    from backend_v2.api.dependencies import get_current_user, get_db
    from backend_v2.api import teacher as teacher_api
    from backend_v2.database.models.auth import User

    memory, db, engine = _memory()
    try:
        service = TeacherReportService(memory)
        TeacherInteractionService(memory).record(
            user_id="api-25-11", conversation_id="api-report-conv", question="سؤال API", agent_types=("GENERAL_AGENT",),
            modalities=("general",), strategy_mode="explain", strategy_difficulty="standard", learning_outcome="stable",
            recommended_mode="explain", recommended_difficulty="standard", next_action="continue", confidence=0.6,
            evidence_count=0, citation_count=0, found=False,
        )
        user = User(id="api-25-11", email="api25-11@example.com", password_hash="x", display_name="Phase25.11", role="student")
        app = create_app()
        app.dependency_overrides[get_current_user] = lambda: user
        app.dependency_overrides[get_db] = lambda: db
        monkeypatch.setattr(teacher_api, "TeacherReportService", lambda: service)
        client = TestClient(app)
        report = client.get("/api/teacher/report", params={"conversation_id":"api-report-conv"})
        assert report.status_code == 200, report.text
        assert report.json()["generated_for"] == "api-25-11"
        csv = client.get("/api/teacher/report.csv", params={"conversation_id":"api-report-conv"})
        assert csv.status_code == 200, csv.text
        assert "section,interaction_id" in csv.text
    finally:
        db.close(); engine.dispose()
