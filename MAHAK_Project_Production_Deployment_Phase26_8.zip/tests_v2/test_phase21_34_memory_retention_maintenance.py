from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import (
    LearningMemory,
    MemoryAuditEvent,
    MemoryRetentionRun,
    MemoryRetentionRunResult,
)
from backend_v2.memory.retention_maintenance import (
    MemoryRetentionMaintenanceBusyError,
    MemoryRetentionMaintenanceService,
)
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_run_history import MemoryRetentionRunHistoryService
from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def _seed_memory(db, user_id: str, *, old_days: int = 60, recent_days: int = 2) -> None:
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=old_days),
                updated_at=now - timedelta(days=old_days),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=recent_days),
                updated_at=now - timedelta(days=recent_days),
            ),
        ]
    )


def _seed_run(db, run_id: str, *, old_days: int = 60) -> None:
    now = datetime.now(UTC).replace(tzinfo=None)
    completed_at = now - timedelta(days=old_days)
    db.add(
        MemoryRetentionRun(
            run_id=run_id,
            status="completed",
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            dry_run=False,
            user_count=1,
            planned_count=0,
            executed_count=1,
            skipped_count=0,
            failed_count=0,
            candidate_count=1,
            would_delete_count=1,
            deleted_count=1,
        )
    )
    db.add(
        MemoryRetentionRunResult(
            run_id=run_id,
            user_id="maintenance-user",
            status="executed",
            candidate_count=1,
            deleted_count=1,
            would_delete_count=1,
            dry_run=False,
            retention_days=7,
            executed_at=completed_at,
        )
    )


def _configure(db, user_id: str = "maintenance-user") -> None:
    MemoryRetentionPolicyService(db).set(
        user_id,
        retention_days=7,
        max_delete=10,
        memory_type=MemoryType.PREVIOUS_QUESTION,
    )
    MemoryRetentionRunHistoryPolicyService(db).set(retention_days=7, max_delete=10)
    db.commit()


def test_disabled_maintenance_is_strictly_non_mutating():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-disabled")
        _configure(db)
        before_memory = db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count()
        before_runs = db.query(MemoryRetentionRun).count()

        report = MemoryRetentionMaintenanceService(db, enabled=False).run_with_report(user_ids=["maintenance-user"])

        assert report.status == "disabled"
        assert report.history is None
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count() == before_memory
        assert db.query(MemoryRetentionRun).count() == before_runs
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.action == "retention").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_dry_run_plans_memory_and_history_without_deleting():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-dry")
        _configure(db)
        before_memory = db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count()

        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
            dry_run=True,
        )

        assert report.status == "completed"
        assert report.memory_report.dry_run is True
        assert report.memory_report.deleted_count == 0
        assert report.history is not None
        assert report.history.status == "planned"
        assert report.history.deleted_count == 0
        assert report.history.would_delete_count >= 1
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count() == before_memory
        assert db.get(MemoryRetentionRun, "maintenance-dry") is not None
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "maintenance-user").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_execute_cleans_memory_and_run_history():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-execute")
        _configure(db)

        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
        )

        assert report.status == "completed"
        assert report.memory_report.deleted_count == 1
        assert report.history is not None
        assert report.history.status == "executed"
        assert report.history.deleted_count == 1
        assert db.get(MemoryRetentionRun, "maintenance-execute") is None
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count() == 1
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "maintenance-user").count() == 1
    finally:
        db.close()
        engine.dispose()


def test_history_failure_does_not_rollback_memory_retention(monkeypatch):
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-failure")
        _configure(db)

        def _fail(self, *args, **kwargs):
            raise RuntimeError("history cleanup failed")

        monkeypatch.setattr(MemoryRetentionRunHistoryService, "apply_policy", _fail)

        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
        )

        assert report.status == "completed_with_errors"
        assert report.memory_report.deleted_count == 1
        assert report.history is not None
        assert report.history.status == "failed"
        assert "history cleanup failed" in (report.history.error or "")
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count() == 1
        assert db.get(MemoryRetentionRun, "maintenance-failure") is not None
    finally:
        db.close()
        engine.dispose()


def test_history_cleanup_can_be_disabled_per_run():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-no-history")
        _configure(db)

        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
            cleanup_history=False,
        )

        assert report.status == "completed"
        assert report.memory_report.deleted_count == 1
        assert report.history is None
        assert db.get(MemoryRetentionRun, "maintenance-no-history") is not None
    finally:
        db.close()
        engine.dispose()


def test_maintenance_concurrency_guard_rejects_overlap_without_mutation():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-concurrency")
        _configure(db)
        before_memory = db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count()
        before_runs = db.query(MemoryRetentionRun).count()

        assert MemoryRetentionMaintenanceService._run_lock.acquire(blocking=False)
        service = MemoryRetentionMaintenanceService(db, enabled=True)
        try:
                service.run_with_report(user_ids=["maintenance-user"])
        except MemoryRetentionMaintenanceBusyError as exc:
            assert "already running" in str(exc)
        else:
            raise AssertionError("Expected concurrency guard to reject overlapping maintenance")
        finally:
            MemoryRetentionMaintenanceService._run_lock.release()

        assert db.query(LearningMemory).filter(LearningMemory.user_id == "maintenance-user").count() == before_memory
        assert db.query(MemoryRetentionRun).count() == before_runs
    finally:
        db.close()
        engine.dispose()


def test_maintenance_concurrency_lock_releases_after_completed_run():
    db, engine = _db()
    try:
        _seed_memory(db, "maintenance-user")
        _seed_run(db, "maintenance-lock-release")
        _configure(db)

        first = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
            dry_run=True,
        )
        assert first.status == "completed"

        second = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
            dry_run=True,
        )
        assert second.status == "completed"
    finally:
        db.close()
        engine.dispose()


def test_maintenance_concurrency_lock_releases_after_failure(monkeypatch):
    db, engine = _db()
    try:
        _configure(db)

        def _fail(*args, **kwargs):
            raise RuntimeError("maintenance failed")

        monkeypatch.setattr(
            "backend_v2.memory.retention_maintenance.MemoryRetentionSchedulerService.run_with_report",
            _fail,
        )
        service = MemoryRetentionMaintenanceService(db, enabled=True)
        try:
            service.run_with_report(user_ids=["maintenance-user"])
        except RuntimeError as exc:
            assert str(exc) == "maintenance failed"
        else:
            raise AssertionError("Expected maintenance run to fail")

        monkeypatch.undo()
        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
            user_ids=["maintenance-user"],
            dry_run=True,
        )
        assert report.status == "completed"
    finally:
        db.close()
        engine.dispose()
