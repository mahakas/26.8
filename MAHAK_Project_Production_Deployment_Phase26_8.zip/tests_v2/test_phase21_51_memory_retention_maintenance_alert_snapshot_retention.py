from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot
from backend_v2.memory import (
    MemoryRetentionMaintenanceAlertSnapshotPolicyService,
    MemoryRetentionMaintenanceAlertSnapshotRetentionService,
)


def _db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, sessionmaker(bind=engine)()


def _seed_snapshot(db, *, snapshot_id: str, captured_at: datetime):
    row = MemoryRetentionMaintenanceAlertSnapshot(
        snapshot_id=snapshot_id,
        captured_at=captured_at,
        health="healthy",
        ready=True,
        severity="none",
        stale_after_seconds=86400,
        alert_count=0,
        alert_codes="",
        assume_enabled=False,
        use_policy=False,
    )
    db.add(row)
    db.flush()


def test_policy_defaults_and_persistence():
    engine, db = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db)
        value = service.get()
        assert value.retention_days == 30
        assert value.max_delete == 500
        assert value.configured is False

        stored = service.set(retention_days=12, max_delete=7)
        assert stored.retention_days == 12
        assert stored.max_delete == 7
        assert stored.configured is True
        assert service.get().retention_days == 12
        assert service.get().max_delete == 7
    finally:
        db.close()
        engine.dispose()


def test_policy_validation():
    engine, db = _db()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db)
        with pytest.raises(ValueError):
            service.set(retention_days=0, max_delete=10)
        with pytest.raises(ValueError):
            service.set(retention_days=10, max_delete=0)
        with pytest.raises(ValueError):
            service.set(retention_days=10, max_delete=501)
    finally:
        db.close()
        engine.dispose()


def test_preview_policy_is_read_only_and_respects_max_delete():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_snapshot(db, snapshot_id="old-1", captured_at=now - timedelta(days=40))
        _seed_snapshot(db, snapshot_id="old-2", captured_at=now - timedelta(days=35))
        _seed_snapshot(db, snapshot_id="new-1", captured_at=now - timedelta(days=2))
        db.commit()

        MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
        preview = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).preview_policy()

        assert preview.candidate_count == 2
        assert preview.would_delete_count == 1
        assert preview.read_only is True
        assert db.scalar(select(MemoryRetentionMaintenanceAlertSnapshot).where(MemoryRetentionMaintenanceAlertSnapshot.snapshot_id == "old-1")) is not None
    finally:
        db.close()
        engine.dispose()


def test_apply_policy_deletes_only_expired_and_respects_limit():
    engine, db = _db()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        _seed_snapshot(db, snapshot_id="old-1", captured_at=now - timedelta(days=60))
        _seed_snapshot(db, snapshot_id="old-2", captured_at=now - timedelta(days=50))
        _seed_snapshot(db, snapshot_id="new-1", captured_at=now - timedelta(days=5))
        db.commit()

        MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
        result = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).apply_policy()

        assert result.candidate_count == 2
        assert result.deleted_count == 1
        rows = list(db.scalars(select(MemoryRetentionMaintenanceAlertSnapshot).order_by(MemoryRetentionMaintenanceAlertSnapshot.snapshot_id)).all())
        assert [row.snapshot_id for row in rows] == ["new-1", "old-2"]
    finally:
        db.close()
        engine.dispose()


def test_reset_returns_to_defaults_without_deleting_snapshots():
    engine, db = _db()
    try:
        policy = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db)
        policy.set(retention_days=5, max_delete=2)
        assert policy.reset() is True
        restored = policy.get()
        assert restored.configured is False
        assert restored.retention_days == 30
        assert restored.max_delete == 500
    finally:
        db.close()
        engine.dispose()
