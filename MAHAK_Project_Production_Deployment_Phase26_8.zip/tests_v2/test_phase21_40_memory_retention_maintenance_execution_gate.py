from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceLease
from backend_v2.memory.retention_maintenance_gate import (
    MemoryRetentionMaintenanceExecutionGate,
    MemoryRetentionMaintenanceNotReadyError,
)
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return db, engine


def test_disabled_gate_preserves_existing_disabled_contract():
    db, engine = _db()
    try:
        gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=False)
        decision = gate.authorize(now=datetime(2026, 9, 19, 12, 0, tzinfo=UTC))
        assert decision.allowed is False
        assert decision.reasons == ("maintenance_disabled",)
        report = gate.run_when_ready(dry_run=True, cleanup_history=False)
        assert report.status == "disabled"
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
    finally:
        db.close(); engine.dispose()


def test_gate_allows_ready_maintenance_and_reuses_persistent_guard():
    db, engine = _db()
    try:
        gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=True)
        now = datetime(2026, 9, 19, 12, 0, tzinfo=UTC)
        decision = gate.authorize(now=now)
        assert decision.allowed is True
        assert decision.reasons == ()
        report = gate.run_when_ready(now=now, dry_run=True, cleanup_history=False, lease_ttl_seconds=60)
        assert report.status == "completed"
        assert report.dry_run is True
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
    finally:
        db.close(); engine.dispose()


def test_gate_blocks_when_persistent_lease_is_held_without_mutation():
    db, engine = _db()
    try:
        now = datetime(2026, 9, 19, 12, 0, tzinfo=UTC)
        lease_service = MemoryRetentionMaintenanceLeaseService(db)
        handle = lease_service.acquire(ttl_seconds=60, now=now)
        try:
            gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=True)
            decision = gate.authorize(now=now + timedelta(seconds=10))
            assert decision.allowed is False
            assert decision.reasons == ("maintenance_lease_held",)
            with pytest.raises(MemoryRetentionMaintenanceNotReadyError) as exc_info:
                gate.run_when_ready(
                    now=now + timedelta(seconds=10),
                    dry_run=True,
                    cleanup_history=False,
                )
            assert exc_info.value.decision.reasons == ("maintenance_lease_held",)
            status = lease_service.status(now=now + timedelta(seconds=10))
            assert status.state == "held"
        finally:
            lease_service.release(handle)
    finally:
        db.close(); engine.dispose()


def test_gate_allows_reclaimable_expired_lease():
    db, engine = _db()
    try:
        now = datetime(2026, 9, 19, 12, 0, tzinfo=UTC)
        lease_service = MemoryRetentionMaintenanceLeaseService(db)
        stale = lease_service.acquire(ttl_seconds=5, now=now)
        later = now + timedelta(seconds=6)
        gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=True)
        decision = gate.authorize(now=later)
        assert decision.allowed is True
        assert decision.readiness.lease.state == "expired"
        report = gate.run_when_ready(now=later, dry_run=True, cleanup_history=False, lease_ttl_seconds=30)
        assert report.status == "completed"
        assert lease_service.status(now=later).state == "available"
        assert stale.owner_token
    finally:
        db.close(); engine.dispose()


def test_gate_reports_busy_race_as_not_ready(monkeypatch):
    db, engine = _db()
    try:
        gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=True)

        def _race(*args, **kwargs):
            from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceDistributedBusyError
            raise MemoryRetentionMaintenanceDistributedBusyError("already held")

        monkeypatch.setattr(gate._maintenance, "run_with_persistent_guard", _race)
        with pytest.raises(MemoryRetentionMaintenanceNotReadyError) as exc_info:
            gate.run_when_ready(dry_run=True, cleanup_history=False)
        assert exc_info.value.decision.reasons == (
            "maintenance_lease_acquired_between_readiness_and_execution",
        )
    finally:
        db.close(); engine.dispose()
