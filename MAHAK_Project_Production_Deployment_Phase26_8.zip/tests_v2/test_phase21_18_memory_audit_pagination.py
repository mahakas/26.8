from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed_events(client: TestClient, db, user_id: str, count: int) -> None:
    memory = MemoryService(db)
    rows = []
    for index in range(count):
        rows.append(
            memory.remember(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION,
                memory_key=f"q:{index}",
                value={"question": f"question-{index}"},
            )
        )
    db.commit()
    for row in rows:
        response = client.delete(f"/api/memory/{user_id}/records/{row.id}")
        assert response.status_code == 200


def test_audit_cursor_paginates_without_duplicates_or_gaps():
    client, db, engine = _client()
    try:
        _seed_events(client, db, "audit-page", 5)

        page_ids: list[str] = []
        cursor = None
        page_sizes = []
        for _ in range(4):
            params = {"limit": 2}
            if cursor:
                params["cursor"] = cursor
            response = client.get("/api/memory/audit-page/audit", params=params)
            assert response.status_code == 200
            payload = response.json()
            page_sizes.append(payload["count"])
            page_ids.extend(item["id"] for item in payload["items"])
            cursor = payload["next_cursor"]
            if not cursor:
                break

        assert page_sizes == [2, 2, 1]
        assert len(page_ids) == 5
        assert len(set(page_ids)) == 5
    finally:
        db.close()
        engine.dispose()


def test_audit_cursor_respects_action_filter():
    client, db, engine = _client()
    try:
        memory = MemoryService(db)
        row = memory.remember(
            user_id="audit-filter",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "1"},
        )
        db.commit()
        assert client.delete(f"/api/memory/audit-filter/records/{row.id}").status_code == 200
        assert client.delete("/api/memory/audit-filter/records").status_code == 200

        first = client.get(
            "/api/memory/audit-filter/audit",
            params={"action": "delete", "limit": 1},
        )
        assert first.status_code == 200
        assert first.json()["count"] == 1
        assert first.json()["next_cursor"] is None
    finally:
        db.close()
        engine.dispose()


def test_invalid_audit_cursor_is_rejected():
    client, db, engine = _client()
    try:
        response = client.get(
            "/api/memory/audit-invalid/audit",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_audit_cursor_is_user_scoped():
    client, db, engine = _client()
    try:
        _seed_events(client, db, "audit-owner", 3)
        first = client.get(
            "/api/memory/audit-owner/audit", params={"limit": 1}
        ).json()
        cursor = first["next_cursor"]
        assert cursor

        cross = client.get(
            "/api/memory/other-user/audit", params={"limit": 1, "cursor": cursor}
        )
        assert cross.status_code == 200
        assert cross.json()["count"] == 0
        assert cross.json()["items"] == []
    finally:
        db.close()
        engine.dispose()
