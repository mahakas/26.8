from pathlib import Path

from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import SidecarTranscript, VideoProcessor
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.core.enums import Capability


class NoFrameSampler:
    def sample(self, path: Path, output_dir: Path, duration=None):
        return []


def test_sidecar_transcript_only_requires_no_ffmpeg(tmp_path):
    video = tmp_path / "lesson.mp4"
    srt = tmp_path / "lesson.srt"
    video.write_bytes(b"not-a-real-video")
    srt.write_text(
        "1\n00:00:00,380 --> 00:00:05,800\nسلام امروز می‌خواهیم درس را یاد بگیریم.\n\n"
        "2\n00:00:06,260 --> 00:00:07,340\nما سه مرغ داریم.\n",
        encoding="utf-8",
    )
    processor = VideoProcessor(
        vision_orchestrator=None,
        transcriber=SidecarTranscript(),
        frame_sampler=NoFrameSampler(),
        vision_enabled=False,
    )
    result = IngestionPipeline(video_processor=processor).process(video)
    assert result.document.metadata["transcript_present"] is True
    assert result.document.metadata["transcript_segment_count"] == 2
    assert result.chunks
    assert [c.metadata["start_time_seconds"] for c in result.chunks] == [0.38, 6.26]
    assert [c.metadata["end_time_seconds"] for c in result.chunks] == [5.8, 7.34]


def test_transcript_only_processor_clears_video_capabilities(tmp_path):
    video = tmp_path / "lesson.mp4"
    srt = tmp_path / "lesson.srt"
    video.write_bytes(b"x")
    srt.write_text("1\n00:00:01,000 --> 00:00:02,000\nF = ma\n", encoding="utf-8")
    processor = VideoProcessor(
        vision_orchestrator=None,
        transcriber=SidecarTranscript(),
        frame_sampler=NoFrameSampler(),
        vision_enabled=False,
    )
    result = IngestionPipeline(video_processor=processor).process(video)
    assert result.required_capabilities == frozenset()


def test_transcript_chunk_metadata_is_citation_ready(tmp_path):
    video = tmp_path / "lesson.mp4"
    srt = tmp_path / "lesson.srt"
    video.write_bytes(b"x")
    srt.write_text("1\n00:00:12,500 --> 00:00:18,750\nقانون دوم نیوتن یعنی F = ma.\n", encoding="utf-8")
    processor = VideoProcessor(None, transcriber=SidecarTranscript(), frame_sampler=NoFrameSampler(), vision_enabled=False)
    result = IngestionPipeline(video_processor=processor).process(video)
    chunk = result.chunks[0]
    assert chunk.metadata["kind"] == "transcript"
    assert chunk.metadata["start_time_seconds"] == 12.5
    assert chunk.metadata["end_time_seconds"] == 18.75
    assert "قانون دوم نیوتن" in chunk.text
