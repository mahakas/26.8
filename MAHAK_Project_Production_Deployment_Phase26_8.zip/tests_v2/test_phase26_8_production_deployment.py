from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def test_not_ready_returns_http_503(monkeypatch):
    import backend_v2.api.observability as observability
    from backend_v2.operations.readiness import OperationalReadiness

    monkeypatch.setattr(
        observability,
        "check_operational_readiness",
        lambda: OperationalReadiness(status="not_ready", checks={"database": "error"}),
    )
    response = TestClient(create_app()).get("/api/health/ready")
    assert response.status_code == 503
    assert response.json()["status"] == "not_ready"


def test_production_deployment_assets_exist_and_are_phase26_8():
    root = Path(__file__).resolve().parents[1]
    compose = (root / "compose.yaml").read_text(encoding="utf-8")
    env = (root / ".env.production.example").read_text(encoding="utf-8")
    assert "mahak-ai:${IMAGE_TAG:-26.8}" in compose
    assert "MAHAK_PROVIDER_MODE=live" in env
    assert "EMBED_MODEL=BAAI/bge-m3" in env
    assert (root / "README_PRODUCTION_DEPLOYMENT_PHASE26_8.md").exists()
    assert (root / "scripts/smoke_production_deployment_phase26_8.py").exists()
