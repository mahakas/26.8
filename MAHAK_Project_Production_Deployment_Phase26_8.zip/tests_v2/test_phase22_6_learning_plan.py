from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _grade(client, *, attempt_id: str, answer: str, topic: str = "قانون دوم نیوتن"):
    response = client.post(
        "/api/education/attempts/grade",
        json={
            "user_id": "student-22-6",
            "attempt_id": attempt_id,
            "task_type": "quiz",
            "topic": topic,
            "items": [
                {
                    "item_id": "q1",
                    "question_type": "multiple_choice",
                    "question": "نیرو برابر چیست؟",
                    "topic": topic,
                    "answer": answer,
                    "correct_answer": "F=ma",
                    "options": ["F=ma", "F=m/a"],
                    "difficulty": "medium",
                }
            ],
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def test_start_learning_plan_creates_first_active_milestone():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        response = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-6",
                "plan_id": "plan-001",
                "total_sessions": 2,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "target_topics": ["انرژی جنبشی"],
                "mastery_target": 0.75,
            },
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["status"] == "active"
        assert body["current_milestone"] == 1
        assert body["completed_milestones"] == 0
        assert body["active_session_id"]
        assert body["milestones"][0]["status"] == "active"
        assert body["milestones"][1]["status"] == "pending"
        assert body["next_topic"] == "قانون دوم نیوتن"
    finally:
        db.close()
        engine.dispose()


def test_completed_milestone_starts_next_milestone_session():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-6",
                "plan_id": "plan-002",
                "total_sessions": 2,
                "session_steps": 1,
                "target_topics": ["قانون دوم نیوتن", "انرژی جنبشی"],
                "mastery_target": 0.75,
            },
        )
        assert start.status_code == 200, start.text
        session_id = start.json()["active_session_id"]
        assert session_id

        _grade(client, attempt_id="attempt-002", answer="F=ma")
        advanced = client.post(
            "/api/education/learning-plans/plan-002/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-002"},
        )
        assert advanced.status_code == 200, advanced.text
        body = advanced.json()
        assert body["status"] == "active"
        assert body["completed_sessions"] == 1
        assert body["completed_milestones"] == 1
        assert body["current_milestone"] == 2
        assert body["next_topic"] == "انرژی جنبشی"
        assert body["milestones"][0]["status"] == "completed"
        assert body["milestones"][1]["status"] == "active"
        assert body["active_session_id"] != session_id
    finally:
        db.close()
        engine.dispose()


def test_low_mastery_starts_targeted_remediation_and_then_blocks_after_cap():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-6",
                "plan_id": "plan-003",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
                "max_remediation_sessions": 1,
            },
        )
        assert start.status_code == 200, start.text

        _grade(client, attempt_id="attempt-003a", answer="F=m/a")
        remediation = client.post(
            "/api/education/learning-plans/plan-003/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-003a"},
        )
        assert remediation.status_code == 200, remediation.text
        remediation_body = remediation.json()
        assert remediation_body["status"] == "active"
        assert remediation_body["milestones"][0]["status"] == "active"
        assert remediation_body["milestones"][0]["remediation_sessions"] == 1
        assert remediation_body["reasons"][-1] == "remediation_session_started"

        _grade(client, attempt_id="attempt-003b", answer="F=m/a")
        blocked = client.post(
            "/api/education/learning-plans/plan-003/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-003b"},
        )
        assert blocked.status_code == 200, blocked.text
        blocked_body = blocked.json()
        assert blocked_body["status"] == "blocked"
        assert "max_remediation_sessions_reached" in blocked_body["reasons"]
    finally:
        db.close()
        engine.dispose()


def test_completed_plan_when_all_milestones_reach_mastery_target():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-6",
                "plan_id": "plan-004",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
            },
        )
        assert start.status_code == 200, start.text
        _grade(client, attempt_id="attempt-004", answer="F=ma")
        completed = client.post(
            "/api/education/learning-plans/plan-004/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-004"},
        )
        assert completed.status_code == 200, completed.text
        body = completed.json()
        assert body["status"] == "completed"
        assert body["completed_milestones"] == 1
        assert body["active_session_id"] is None
        assert body["recommendation"] is None
    finally:
        db.close()
        engine.dispose()


def test_learning_plan_get_and_advance_are_idempotent():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-6",
                "plan_id": "plan-005",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200
        _grade(client, attempt_id="attempt-005", answer="F=ma")
        first = client.post(
            "/api/education/learning-plans/plan-005/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-005"},
        )
        replay = client.post(
            "/api/education/learning-plans/plan-005/advance",
            json={"user_id": "student-22-6", "attempt_id": "attempt-005"},
        )
        fetched = client.get(
            "/api/education/learning-plans/plan-005",
            params={"user_id": "student-22-6"},
        )
        assert first.status_code == 200
        assert replay.status_code == 200
        assert fetched.status_code == 200
        assert replay.json()["idempotent_replay"] is True
        assert replay.json()["completed_milestones"] == 1
        assert fetched.json()["status"] == "completed"
    finally:
        db.close()
        engine.dispose()
