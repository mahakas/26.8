from __future__ import annotations

from types import SimpleNamespace

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_session import TeacherSessionService
from backend_v2.api import teacher_v1
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from backend_v2.memory.service import MemoryService


class _FakeFeedback:
    @staticmethod
    def summary(user_id: str, *, conversation_id: str):
        return SimpleNamespace(
            as_dict=lambda: {
                "total": 0,
                "needs_support": 0,
                "progressing": 0,
                "neutral": 0,
                "latest_signal": None,
                "latest": None,
            }
        )


class _FakeTeacher:
    feedback = _FakeFeedback()

    def execute(self, query, **kwargs):
        route = SimpleNamespace(agent_type=SimpleNamespace(value="VIDEO_AGENT"), reason="explicit video route")
        result = SimpleNamespace(
            answer="grounded answer",
            confidence=0.91,
            evidence=[{"type": "video", "timestamp": 12.5, "frame": "frame-12.jpg", "transcript": "hello"}],
            citations=[{"source_id": "lesson.mp4", "start_time_seconds": 12.5, "end_time_seconds": 14.0, "frame_path": "frame-12.jpg"}],
        )
        fusion = SimpleNamespace(as_dict=lambda: {
            "modalities": ["video"],
            "evidence_count": 1,
            "citation_count": 1,
            "cross_modal_links": [],
            "corroboration_score": 1.0,
            "coverage_score": 1.0,
            "fused_confidence": 0.91,
        })
        strategy = SimpleNamespace(as_dict=lambda: {
            "mode": "explain",
            "difficulty": "standard",
            "explanation_depth": "standard",
            "interaction_style": "direct_instruction",
            "scaffolding": "medium",
            "focus": [],
            "rationale": [],
            "next_step": "continue",
        })
        loop = SimpleNamespace(as_dict=lambda: {
            "user_id": kwargs.get("context").user_id,
            "conversation_id": kwargs.get("context").conversation_id,
            "learning_plan_id": kwargs.get("learning_plan_id"),
            "learning_outcome": "progressing",
            "feedback_signal": "neutral",
            "average_confidence": 0.91,
            "latest_score": None,
            "recent_average_score": 0.0,
            "score_trend": 0.0,
            "attempt_count": 0,
            "active_weak_areas": [],
            "current_strategy_mode": "explain",
            "recommended_mode": "explain",
            "recommended_difficulty": "standard",
            "next_action": "continue",
            "reasons": [],
            "source": "test",
        })
        interaction = SimpleNamespace(interaction_id="interaction-phase26", teacher_session_id=kwargs.get("teacher_session_id"))
        return SimpleNamespace(
            routes=(route,),
            result=result,
            fusion=fusion,
            teaching_strategy=strategy,
            learning_loop=loop,
            interaction=interaction,
        )


def _client(monkeypatch):
    engine = create_engine("sqlite://", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    user = User(id="phase26-user", email="phase26@example.com", password_hash="x", display_name="Phase 26", role="student")
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: user
    app.dependency_overrides[get_db] = lambda: db
    monkeypatch.setattr(teacher_v1, "build_teacher_service", lambda: _FakeTeacher())
    monkeypatch.setattr(teacher_v1, "TeacherSessionService", lambda: TeacherSessionService(MemoryService(db)))
    return TestClient(app), db, engine


def test_contract_endpoint_and_headers(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        response = client.get("/api/teacher/v1/contract", headers={"X-Request-ID": "phase26-contract-001"})
        assert response.status_code == 200, response.text
        payload = response.json()
        assert payload["contract"]["contract_version"] == "1.0"
        assert payload["contract"]["phase"] == "26.8"
        assert payload["meta"]["request_id"] == "phase26-contract-001"
        assert response.headers["X-Request-ID"] == "phase26-contract-001"
        assert response.headers["X-Mahak-API-Version"] == "v1"
        assert response.headers["X-Mahak-Contract-Version"] == "1.0"
    finally:
        client.close(); db.close(); engine.dispose()


def test_ask_envelope_preserves_evidence_citations_confidence_and_correlation(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        response = client.post(
            "/api/teacher/v1/ask",
            headers={"X-Request-ID": "phase26-ask-001"},
            json={"conversation_id": "conv-26", "query": "What happens at 12 seconds?", "modalities": ["video"]},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["answer"] == "grounded answer"
        assert body["evidence"][0]["type"] == "video"
        assert body["evidence"][0]["timestamp"] == 12.5
        assert body["citations"][0]["frame_path"] == "frame-12.jpg"
        assert body["confidence"] == 0.91
        assert body["meta"]["request_id"] == "phase26-ask-001"
    finally:
        client.close(); db.close(); engine.dispose()


def test_validation_error_is_structured_for_v1(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        response = client.post("/api/teacher/v1/ask", json={"query": "missing conversation id"})
        assert response.status_code == 422
        body = response.json()
        assert body["error"]["code"] == "VALIDATION_ERROR"
        assert body["error"]["details"]
        assert body["request_id"]
    finally:
        client.close(); db.close(); engine.dispose()


def test_business_error_is_structured_for_missing_session(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        response = client.post(
            "/api/teacher/v1/ask",
            json={"conversation_id": "conv-26", "query": "hello", "teacher_session_id": "missing"},
        )
        assert response.status_code == 422
        body = response.json()
        assert body["error"]["code"] == "INVALID_TEACHER_REQUEST"
        assert body["error"]["message"] == "teacher_session_id does not exist"
        assert body["request_id"]
    finally:
        client.close(); db.close(); engine.dispose()


def test_session_lifecycle_adapter(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        started = client.post(
            "/api/teacher/v1/sessions/start",
            json={"session_id": "phase26-session", "conversation_id": "conv-26"},
        )
        assert started.status_code == 200, started.text
        assert started.json()["status"] == "active"
        assert started.json()["meta"]["teacher_session_id"] == "phase26-session"

        listed = client.get("/api/teacher/v1/sessions", params={"status": "active"})
        assert listed.status_code == 200
        assert listed.json()["items"][0]["session_id"] == "phase26-session"

        closed = client.post("/api/teacher/v1/sessions/phase26-session/close")
        assert closed.status_code == 200
        assert closed.json()["status"] == "closed"
    finally:
        client.close(); db.close(); engine.dispose()


def test_feedback_envelope(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        response = client.post(
            "/api/teacher/v1/feedback",
            json={"conversation_id": "conv-26", "feedback_id": "fb-26", "rating": 5, "understood": True},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["feedback_id"] == "fb-26"
        assert body["meta"]["user_id"] == "phase26-user"
    finally:
        client.close(); db.close(); engine.dispose()


def test_capabilities_and_readiness(monkeypatch):
    client, db, engine = _client(monkeypatch)
    try:
        capabilities = client.get("/api/teacher/v1/capabilities")
        readiness = client.get("/api/teacher/v1/readiness")
        assert capabilities.status_code == 200, capabilities.text
        assert readiness.status_code == 200, readiness.text
        assert capabilities.json()["contract_version"] == "1.0"
        assert "unified_teacher_api_v1" in capabilities.json()["features"]
        assert readiness.json()["phase"] == "26.8"
        assert readiness.json()["status"] == "ready"
    finally:
        client.close(); db.close(); engine.dispose()


def test_v1_requires_existing_authentication_contract():
    app = create_app()
    client = TestClient(app)
    try:
        response = client.get("/api/teacher/v1/contract")
        assert response.status_code == 401
        body = response.json()
        assert body["error"]["code"] == "AUTHENTICATION_REQUIRED"
        assert body["request_id"]
    finally:
        client.close()


def test_legacy_health_contract_remains_compatible():
    app = create_app()
    client = TestClient(app)
    try:
        response = client.get("/api/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok", "version": "0.7.0"}
    finally:
        client.close()
