from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_readiness import TeacherProductReadinessService
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService


def _memory():
    engine = create_engine("sqlite:///:memory:", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def test_capabilities_and_readiness_are_ready_and_non_mutating():
    memory, db, engine = _memory()
    try:
        service = TeacherProductReadinessService(memory)
        capabilities = service.capabilities().as_dict()
        readiness = service.check("u25-12").as_dict()
        assert capabilities["current_phase"] == "25.12"
        assert "GET /api/teacher/dashboard" in capabilities["read_only_surfaces"]
        assert "POST /api/teacher/sessions/start" in capabilities["action_surfaces"]
        assert readiness["status"] == "ready"
        assert all(value == "ok" for value in readiness["checks"].values())
        assert memory.list("u25-12", limit=10, memory_type=None) == []
    finally:
        db.close(); engine.dispose()


def test_teacher_capabilities_and_readiness_api():
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    from backend_v2.api.dependencies import get_current_user
    from backend_v2.database.models.auth import User

    user = User(id="api-25-12", email="api25-12@example.com", password_hash="x", display_name="Phase25.12", role="student")
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: user
    client = TestClient(app)
    capabilities = client.get("/api/teacher/capabilities")
    readiness = client.get("/api/teacher/readiness")
    assert capabilities.status_code == 200, capabilities.text
    assert readiness.status_code == 200, readiness.text
    assert capabilities.json()["current_phase"] == "25.12"
    assert readiness.json()["status"] == "ready"
