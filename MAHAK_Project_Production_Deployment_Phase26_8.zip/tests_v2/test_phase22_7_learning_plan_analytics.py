from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _grade(client, attempt_id: str, answer: str):
    response = client.post(
        "/api/education/attempts/grade",
        json={
            "user_id": "student-22-7",
            "attempt_id": attempt_id,
            "task_type": "quiz",
            "topic": "قانون دوم نیوتن",
            "items": [
                {
                    "item_id": "q1",
                    "question_type": "multiple_choice",
                    "question": "نیرو برابر چیست؟",
                    "topic": "قانون دوم نیوتن",
                    "answer": answer,
                    "correct_answer": "F=ma",
                    "options": ["F=ma", "F=m/a"],
                    "difficulty": "medium",
                }
            ],
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def test_empty_plan_has_zero_attempts_and_on_track_outcome():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-7",
                "plan_id": "analytics-001",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text
        analytics = client.get(
            "/api/education/learning-plans/analytics-001/analytics",
            params={"user_id": "student-22-7"},
        )
        assert analytics.status_code == 200, analytics.text
        body = analytics.json()
        assert body["total_attempts"] == 0
        assert body["completion_percent"] == 0.0
        assert body["outcome"] == "on_track"
    finally:
        db.close()
        engine.dispose()


def test_analytics_tracks_completed_attempt_and_scores():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-7",
                "plan_id": "analytics-002",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
            },
        )
        assert start.status_code == 200, start.text
        _grade(client, "analytics-attempt-002", "F=ma")
        advanced = client.post(
            "/api/education/learning-plans/analytics-002/advance",
            json={"user_id": "student-22-7", "attempt_id": "analytics-attempt-002"},
        )
        assert advanced.status_code == 200, advanced.text

        analytics = client.get(
            "/api/education/learning-plans/analytics-002/analytics",
            params={"user_id": "student-22-7"},
        )
        assert analytics.status_code == 200, analytics.text
        body = analytics.json()
        assert body["status"] == "completed"
        assert body["outcome"] == "completed"
        assert body["completed_milestones"] == 1
        assert body["completion_percent"] == 100.0
        assert body["total_attempts"] == 1
        assert body["average_score"] == 1.0
        assert body["best_score"] == 1.0
        assert body["latest_score"] == 1.0
        assert body["current_mastery_average"] == 1.0
        assert body["mastery_gap"] == 0.0
        assert body["topics"][0]["topic"] == "قانون دوم نیوتن"
    finally:
        db.close()
        engine.dispose()


def test_analytics_marks_low_mastery_plan_at_risk_and_tracks_remediation():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-7",
                "plan_id": "analytics-003",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
                "max_remediation_sessions": 2,
            },
        )
        assert start.status_code == 200, start.text
        _grade(client, "analytics-attempt-003", "F=m/a")
        advanced = client.post(
            "/api/education/learning-plans/analytics-003/advance",
            json={"user_id": "student-22-7", "attempt_id": "analytics-attempt-003"},
        )
        assert advanced.status_code == 200, advanced.text

        analytics = client.get(
            "/api/education/learning-plans/analytics-003/analytics",
            params={"user_id": "student-22-7"},
        )
        assert analytics.status_code == 200, analytics.text
        body = analytics.json()
        assert body["outcome"] == "at_risk"
        assert body["remediation_sessions"] == 1
        assert body["remediation_share"] > 0.0
        assert body["mastery_gap"] > 0.0
        assert body["total_attempts"] == 1
    finally:
        db.close()
        engine.dispose()


def test_analytics_exposes_item_counts_and_topic_breakdown():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-7",
                "plan_id": "analytics-004",
                "total_sessions": 1,
                "session_steps": 2,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text
        _grade(client, "analytics-attempt-004a", "F=ma")
        step1 = client.post(
            "/api/education/sessions/{}/advance".format(start.json()["active_session_id"]),
            json={"user_id": "student-22-7", "attempt_id": "analytics-attempt-004a"},
        )
        assert step1.status_code == 200, step1.text
        _grade(client, "analytics-attempt-004b", "F=ma")
        plan_advance = client.post(
            "/api/education/learning-plans/analytics-004/advance",
            json={"user_id": "student-22-7", "attempt_id": "analytics-attempt-004b"},
        )
        assert plan_advance.status_code == 200, plan_advance.text

        analytics = client.get(
            "/api/education/learning-plans/analytics-004/analytics",
            params={"user_id": "student-22-7"},
        )
        assert analytics.status_code == 200, analytics.text
        body = analytics.json()
        assert body["total_attempts"] == 2
        assert body["total_items"] == 2
        assert body["correct_items"] == 2
        assert body["incorrect_items"] == 0
        assert body["topics"][0]["attempt_count"] == 2
        assert body["topics"][0]["average_score"] == 1.0
    finally:
        db.close()
        engine.dispose()


def test_analytics_get_is_read_only_and_repeated_requests_are_stable():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-7",
                "plan_id": "analytics-005",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
            },
        )
        assert start.status_code == 200, start.text
        first = client.get(
            "/api/education/learning-plans/analytics-005/analytics",
            params={"user_id": "student-22-7"},
        )
        second = client.get(
            "/api/education/learning-plans/analytics-005/analytics",
            params={"user_id": "student-22-7"},
        )
        assert first.status_code == 200
        assert second.status_code == 200
        assert first.json() == second.json()
        assert first.json()["total_attempts"] == 0
    finally:
        db.close()
        engine.dispose()
