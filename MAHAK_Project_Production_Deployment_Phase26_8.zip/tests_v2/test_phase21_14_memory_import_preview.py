from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _record(user_id: str, value: str, key: str = "profile"):
    return {
        "id": f"snapshot-{value}-{key}",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": key,
        "value": {"grade": value},
        "confidence": 1.0,
        "source": "snapshot",
    }


def test_preview_is_read_only_and_predicts_imports():
    client, db, engine = _client()
    try:
        user_id = "student-preview-read-only"
        payload = {"user_id": user_id, "records": [_record(user_id, "10")]}
        response = client.post(f"/api/memory/{user_id}/import/preview", json=payload)
        assert response.status_code == 200
        body = response.json()
        assert body["would_import_count"] == 1
        assert body["would_skip_count"] == 0
        assert body["conflict_count"] == 0
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 0
    finally:
        db.close()
        engine.dispose()


def test_preview_append_reports_duplicate_and_conflict_without_mutation():
    client, db, engine = _client()
    try:
        user_id = "student-preview-append"
        assert client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record(user_id, "10")]},
        ).status_code == 201
        payload = {
            "user_id": user_id,
            "records": [
                _record(user_id, "10"),
                _record(user_id, "11"),
                _record(user_id, "12", "new-profile"),
            ],
        }
        response = client.post(f"/api/memory/{user_id}/import/preview", json=payload)
        assert response.status_code == 200
        body = response.json()
        assert body["would_import_count"] == 2
        assert body["would_skip_count"] == 1
        assert body["conflict_count"] == 1
        assert body["exact_duplicate_count"] == 1
        assert body["would_reject"] is False
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_preview_skip_and_reject_have_distinct_predictions():
    client, db, engine = _client()
    try:
        user_id = "student-preview-policies"
        assert client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record(user_id, "10")]},
        ).status_code == 201

        skip = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={
                "user_id": user_id,
                "conflict_policy": "skip",
                "records": [_record(user_id, "11")],
            },
        )
        assert skip.status_code == 200
        assert skip.json()["would_import_count"] == 0
        assert skip.json()["would_skip_count"] == 1
        assert skip.json()["conflict_count"] == 1
        assert skip.json()["would_reject"] is False

        reject = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={
                "user_id": user_id,
                "conflict_policy": "reject",
                "records": [_record(user_id, "11")],
            },
        )
        assert reject.status_code == 200
        assert reject.json()["would_import_count"] == 0
        assert reject.json()["would_skip_count"] == 0
        assert reject.json()["conflict_count"] == 1
        assert reject.json()["would_reject"] is True
    finally:
        db.close()
        engine.dispose()


def test_preview_verifies_checksum_when_present():
    client, db, engine = _client()
    try:
        user_id = "student-preview-checksum"
        export = client.post(
            f"/api/memory/{user_id}/import",
            json={"user_id": user_id, "records": [_record(user_id, "10")]},
        )
        assert export.status_code == 201
        snapshot = client.get(f"/api/memory/{user_id}/export").json()

        preview = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={
                "user_id": user_id,
                "checksum": snapshot["checksum"],
                "records": snapshot["records"],
            },
        )
        assert preview.status_code == 200
        assert preview.json()["checksum"] == snapshot["checksum"]
        assert preview.json()["exact_duplicate_count"] == 1

        tampered = dict(snapshot["records"][0])
        tampered["value"] = {"grade": "11"}
        bad = client.post(
            f"/api/memory/{user_id}/import/preview",
            json={
                "user_id": user_id,
                "checksum": snapshot["checksum"],
                "records": [tampered],
            },
        )
        assert bad.status_code == 422
    finally:
        db.close()
        engine.dispose()


def test_preview_rejects_user_scope_mismatch():
    client, db, engine = _client()
    try:
        response = client.post(
            "/api/memory/student-preview-scope/import/preview",
            json={
                "user_id": "other-user",
                "records": [_record("other-user", "10")],
            },
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
