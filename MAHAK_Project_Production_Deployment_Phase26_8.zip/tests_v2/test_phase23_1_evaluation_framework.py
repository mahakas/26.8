from __future__ import annotations

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import EducationalAnswerEvaluationRequest, EducationalEvaluationService


def test_perfect_reference_evaluation_scores_full_quality():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="قانون دوم نیوتن چیست؟",
            answer="قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            expected_answer="قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            expected_source_ids=("physics.pdf",),
            retrieved_source_ids=("physics.pdf",),
            cited_source_ids=("physics.pdf",),
            evidence_texts=("قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",),
        )
    )
    assert result.answer_quality_score == 1.0
    assert result.retrieval_f1 == 1.0
    assert result.citation_f1 == 1.0
    assert result.evidence_coverage == 1.0
    assert result.heuristic_hallucination_risk == 0.0
    assert result.overall_score == 1.0
    assert result.quality_band == "excellent"


def test_answer_quality_penalizes_missing_reference_content():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="تعریف انرژی جنبشی چیست؟",
            answer="انرژی جنبشی به حرکت جسم مربوط است.",
            expected_answer="انرژی جنبشی انرژی ناشی از حرکت جسم است.",
        )
    )
    assert 0.0 < result.answer_quality_score < 1.0
    assert result.retrieval_f1 is None
    assert result.citation_f1 is None


def test_retrieval_metrics_distinguish_precision_and_recall():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="سؤال",
            answer="پاسخ",
            expected_source_ids=("a", "b"),
            retrieved_source_ids=("a", "c"),
        )
    )
    assert result.retrieval_precision == 0.5
    assert result.retrieval_recall == 0.5
    assert result.retrieval_f1 == 0.5


def test_citation_metrics_measure_correctness_and_completeness():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="سؤال",
            answer="پاسخ",
            expected_source_ids=("a", "b"),
            cited_source_ids=("a", "c"),
        )
    )
    assert result.citation_correctness == 0.5
    assert result.citation_completeness == 0.5
    assert result.citation_f1 == 0.5


def test_evidence_coverage_exposes_heuristic_hallucination_risk():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="سؤال",
            answer="نیرو برابر جرم ضربدر شتاب است. ماه در اقیانوس‌ها می‌درخشد.",
            evidence_texts=("نیرو برابر جرم ضربدر شتاب است.",),
        )
    )
    assert 0.0 < result.evidence_coverage < 1.0
    assert 0.0 < result.heuristic_hallucination_risk < 1.0
    assert any("heuristic_hallucination_risk" in note for note in result.notes)


def test_without_reference_sources_metrics_remain_not_evaluable():
    result = EducationalEvaluationService().evaluate(
        EducationalAnswerEvaluationRequest(
            question="سؤال",
            answer="پاسخ",
            evidence_texts=("پاسخ",),
        )
    )
    assert result.retrieval_precision is None
    assert result.retrieval_recall is None
    assert result.retrieval_f1 is None
    assert result.citation_correctness is None
    assert result.citation_completeness is None
    assert result.citation_f1 is None
    assert result.evidence_coverage == 1.0
    assert result.overall_score == 1.0


def test_evaluation_endpoint_returns_structured_metrics():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/answer",
        json={
            "question": "قانون دوم نیوتن چیست؟",
            "answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            "expected_answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            "expected_source_ids": ["physics.pdf"],
            "retrieved_source_ids": ["physics.pdf"],
            "cited_source_ids": ["physics.pdf"],
            "evidence_texts": ["قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است."],
        },
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["overall_score"] == 1.0
    assert payload["citation_correctness"] == 1.0
    assert payload["quality_band"] == "excellent"


def test_evaluation_endpoint_rejects_empty_answer():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/answer",
        json={"question": "سؤال", "answer": ""},
    )
    assert response.status_code == 422
