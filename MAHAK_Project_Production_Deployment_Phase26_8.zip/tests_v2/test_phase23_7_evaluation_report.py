from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import EducationalEvaluationReportService


def _answer_batch(score: float = 0.9):
    return {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_overall_score": score,
        "average_answer_quality_score": score,
        "average_retrieval_f1": score,
        "average_citation_f1": score,
        "average_evidence_coverage": score,
        "quality_band_counts": {"excellent": 2},
        "cases": [],
        "errors": [],
    }


def _retrieval_batch():
    return {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "mean_reciprocal_rank": 0.8,
        "mean_average_precision": 0.8,
        "mean_precision_at_k": {"1": 1.0, "3": 0.8},
        "mean_recall_at_k": {"1": 0.7, "3": 0.9},
        "mean_ndcg_at_k": {"1": 0.9, "3": 0.85},
        "mean_hit_rate_at_k": {"1": 1.0, "3": 1.0},
        "cases": [],
        "errors": [],
    }


def _citation_batch():
    return {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_citation_correctness": 0.9,
        "average_citation_completeness": 0.85,
        "average_citation_f1": 0.875,
        "average_locator_accuracy": 1.0,
        "average_evidence_coverage": 0.9,
        "cases": [],
        "errors": [],
    }


def _groundedness_batch():
    return {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_groundedness_score": 0.9,
        "average_unsupported_claim_rate": 0.1,
        "average_hallucination_risk": 0.1,
        "groundedness_band_counts": {"well_grounded": 2},
        "cases": [],
        "errors": [],
    }


def _agents_batch(score: float = 0.9):
    return {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_overall_score": score,
        "average_modality_evidence_coverage": score,
        "average_locator_completeness": score,
        "agent_type_counts": {"teacher": 2},
        "quality_band_counts": {"excellent": 2},
        "cases": [],
        "errors": [],
    }


def test_empty_report_rejected():
    service = EducationalEvaluationReportService()
    try:
        service.build()
    except ValueError as exc:
        assert str(exc) == "at least one evaluation section is required"
    else:
        raise AssertionError("expected ValueError")


def test_single_section_report_is_replayable():
    service = EducationalEvaluationReportService()
    first = service.build(report_id="r1", answer_batch=_answer_batch(0.8)).as_dict()
    second = service.build(report_id="r1", answer_batch=_answer_batch(0.8)).as_dict()
    assert first == second
    assert first["overall_score"] == 0.8
    assert first["quality_band"] == "good"


def test_all_sections_are_aggregated():
    result = EducationalEvaluationReportService().build(
        report_id="all",
        answer_batch=_answer_batch(),
        retrieval_batch=_retrieval_batch(),
        citation_batch=_citation_batch(),
        groundedness_batch=_groundedness_batch(),
        agents_batch=_agents_batch(),
    )
    assert result.section_count == 5
    assert result.available_sections == ("answer", "retrieval", "citation", "groundedness", "agents")
    assert result.total_evaluations == 10
    assert result.total_failures == 0
    assert result.overall_score is not None
    assert result.overall_score >= 0.8


def test_risk_flags_are_derived_from_thresholds():
    weak_groundedness = _groundedness_batch()
    weak_groundedness["average_groundedness_score"] = 0.4
    weak_groundedness["average_hallucination_risk"] = 0.6
    weak_retrieval = _retrieval_batch()
    weak_retrieval["mean_reciprocal_rank"] = 0.3
    weak_retrieval["mean_average_precision"] = 0.3
    weak_retrieval["mean_precision_at_k"] = {"1": 0.3, "3": 0.3}
    weak_retrieval["mean_recall_at_k"] = {"1": 0.3, "3": 0.3}
    weak_retrieval["mean_ndcg_at_k"] = {"1": 0.3, "3": 0.3}
    weak_retrieval["mean_hit_rate_at_k"] = {"1": 0.3, "3": 0.3}
    result = EducationalEvaluationReportService().build(
        groundedness_batch=weak_groundedness,
        retrieval_batch=weak_retrieval,
    )
    assert "elevated hallucination risk detected" in result.risk_flags
    assert "retrieval quality is below the evaluation pass threshold" in result.risk_flags
    assert result.recommendations


def test_failed_cases_are_retained_in_report():
    payload = _answer_batch()
    payload["failed_cases"] = 1
    result = EducationalEvaluationReportService().build(answer_batch=payload)
    assert result.total_failures == 1
    assert result.sections[0].notes == ("section contains failed evaluation cases",)


def test_markdown_report_contains_sections_and_risks():
    result = EducationalEvaluationReportService().build(report_id="md", answer_batch=_answer_batch())
    text = result.to_markdown()
    assert "# MAHAK Evaluation Report" in text
    assert "| answer | 2 | 0 |" in text
    assert "## Recommendations" in text


def test_api_report_endpoint():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/report",
        json={"report_id": "api", "answer_batch": _answer_batch(0.9)},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["report_id"] == "api"
    assert payload["available_sections"] == ["answer"]
    assert payload["overall_score"] == 0.9


def test_api_markdown_endpoint():
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/report/markdown",
        json={"report_id": "api-md", "agents_batch": _agents_batch(0.9)},
    )
    assert response.status_code == 200, response.text
    assert "MAHAK Evaluation Report" in response.text
    assert "| agents | 2 | 0 |" in response.text
