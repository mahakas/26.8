from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.database.connection import Base
from backend_v2.api import teacher as teacher_api
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.database.models.auth import User
from fastapi.testclient import TestClient
from backend_v2.memory.service import MemoryService


def _memory():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def test_teacher_interaction_round_trip_and_conversation_filter():
    memory, db, engine = _memory()
    try:
        service = TeacherInteractionService(memory)
        first = service.record(
            user_id="u25-7",
            conversation_id="c25-7-a",
            question="اولین سؤال",
            agent_types=("DOCUMENT_AGENT", "IMAGE_AGENT", "DOCUMENT_AGENT"),
            modalities=("document", "image", "document"),
            strategy_mode="explain",
            strategy_difficulty="standard",
            learning_outcome="stable",
            recommended_mode="explain",
            recommended_difficulty="standard",
            next_action="check_understanding",
            confidence=0.82,
            evidence_count=2,
            citation_count=1,
            found=True,
        )
        second = service.record(
            user_id="u25-7",
            conversation_id="c25-7-b",
            question="دومین سؤال",
            agent_types=("VIDEO_AGENT",),
            modalities=("video",),
            strategy_mode="practice",
            strategy_difficulty="advanced",
            learning_outcome="ready_to_advance",
            recommended_mode="practice",
            recommended_difficulty="advanced",
            next_action="advance_to_independent_practice",
            confidence=0.91,
            evidence_count=3,
            citation_count=3,
            found=True,
        )
        assert first.agent_types == ("DOCUMENT_AGENT", "IMAGE_AGENT")
        assert first.modalities == ("document", "image")
        assert service.get("u25-7", first.interaction_id) == first
        assert service.list("u25-7", conversation_id="c25-7-a", limit=10) == (first,)
        assert service.list("u25-7", limit=10)[0] in (first, second)
    finally:
        db.close()
        engine.dispose()


def test_feedback_can_be_bound_to_a_teacher_interaction():
    memory, db, engine = _memory()
    try:
        interaction = TeacherInteractionService(memory).record(
            user_id="u-bind-25-7",
            conversation_id="c-bind-25-7",
            question="قانون دوم نیوتن چیست؟",
            agent_types=("DOCUMENT_AGENT",),
            modalities=("document",),
            strategy_mode="explain",
            strategy_difficulty="standard",
            learning_outcome="stable",
            recommended_mode="explain",
            recommended_difficulty="standard",
            next_action="check_understanding",
            confidence=0.9,
            evidence_count=2,
            citation_count=2,
            found=True,
        )
        feedback = TeacherFeedbackService(memory).record(
            user_id="u-bind-25-7",
            conversation_id="c-bind-25-7",
            feedback_id="f-bind-25-7",
            interaction_id=interaction.interaction_id,
            rating=2,
            understood=False,
        )
        assert feedback.interaction_id == interaction.interaction_id
        summary = TeacherFeedbackService(memory).summary("u-bind-25-7", conversation_id="c-bind-25-7")
        assert summary.latest is not None
        assert summary.latest.interaction_id == interaction.interaction_id
    finally:
        db.close()
        engine.dispose()


def test_feedback_rejects_interaction_from_another_conversation():
    memory, db, engine = _memory()
    try:
        interaction = TeacherInteractionService(memory).record(
            user_id="u-bind-negative-25-7",
            conversation_id="c-one-25-7",
            question="سؤال",
            agent_types=("GENERAL_AGENT",),
            modalities=("general",),
            strategy_mode="explain",
            strategy_difficulty="standard",
            learning_outcome="stable",
            recommended_mode="explain",
            recommended_difficulty="standard",
            next_action="continue",
            confidence=0.5,
            evidence_count=0,
            citation_count=0,
            found=False,
        )
        service = TeacherFeedbackService(memory)
        try:
            service.record(
                user_id="u-bind-negative-25-7",
                conversation_id="c-two-25-7",
                feedback_id="f-bind-negative-25-7",
                interaction_id=interaction.interaction_id,
                rating=1,
            )
        except ValueError as exc:
            assert "another conversation" in str(exc)
        else:
            raise AssertionError("cross-conversation interaction binding must fail")
    finally:
        db.close()
        engine.dispose()


def test_teacher_interaction_requires_existing_user_and_question():
    memory, db, engine = _memory()
    try:
        service = TeacherInteractionService(memory)
        try:
            service.record(
                user_id="",
                conversation_id="c25-7",
                question="سؤال",
                agent_types=(),
                modalities=(),
                strategy_mode="explain",
                strategy_difficulty="standard",
                learning_outcome="stable",
                recommended_mode="explain",
                recommended_difficulty="standard",
                next_action="continue",
                confidence=0.0,
                evidence_count=0,
                citation_count=0,
                found=False,
            )
        except ValueError as exc:
            assert "user_id" in str(exc)
        else:
            raise AssertionError("empty user_id must fail")
    finally:
        db.close()
        engine.dispose()


def test_teacher_interactions_api_returns_trace_for_authenticated_user(monkeypatch):
    memory, db, engine = _memory()
    try:
        service = TeacherInteractionService(memory)
        service.record(
            user_id="api-user-25-7",
            conversation_id="api-conv-25-7",
            question="این را توضیح بده",
            agent_types=("VIDEO_AGENT",),
            modalities=("video",),
            strategy_mode="practice",
            strategy_difficulty="advanced",
            learning_outcome="ready_to_advance",
            recommended_mode="practice",
            recommended_difficulty="advanced",
            next_action="advance_to_independent_practice",
            confidence=0.94,
            evidence_count=4,
            citation_count=3,
            found=True,
        )
        user = User(id="api-user-25-7", email="phase25-7@example.com", password_hash="x", display_name="Phase 25.7", role="student")
        app = create_app()
        app.dependency_overrides[get_current_user] = lambda: user
        app.dependency_overrides[get_db] = lambda: db
        monkeypatch.setattr(teacher_api, "TeacherInteractionService", lambda: service)
        response = TestClient(app).get("/api/teacher/interactions", params={"conversation_id": "api-conv-25-7"})
        assert response.status_code == 200, response.text
        payload = response.json()
        assert len(payload["items"]) == 1
        assert payload["items"][0]["modalities"] == ["video"]
        assert payload["items"][0]["next_action"] == "advance_to_independent_practice"
    finally:
        db.close()
        engine.dispose()
