from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.agents.vision import VisionAgent


def test_vision_agent_returns_image_evidence_and_citations():
    agent = VisionAgent()

    result = agent.execute(
        "analyze this image",
        hits=[
            {
                "text": "A force diagram showing F = ma.",
                "metadata": {
                    "source_id": "image-source-1",
                    "title": "Newton diagram",
                    "image_id": "lesson-01",
                    "image_path": "images/lesson-01.png",
                },
            }
        ],
    )

    assert agent.agent_type == AgentType.IMAGE
    assert result.confidence == 0.8
    assert len(result.evidence) == 1
    assert result.evidence[0]["type"] == "image"
    assert result.evidence[0]["image_id"] == "lesson-01"
    assert result.citations[0]["source_id"] == "image-source-1"
    assert result.citations[0]["image_id"] == "lesson-01"


def test_router_executes_registered_vision_agent():
    registry = AgentRegistry()
    registry.register(VisionAgent())
    router = AgentRouter(registry)

    result = router.execute(
        "explain this image",
        hits=[
            {
                "text": "A labeled diagram",
                "metadata": {
                    "image_id": "diagram-1",
                    "title": "Lesson diagram",
                    "path": "images/diagram-1.png",
                },
            }
        ],
    )

    assert result.confidence == 0.8
    assert result.evidence[0]["image_id"] == "diagram-1"
    assert result.citations[0]["image_path"] == "images/diagram-1.png"
