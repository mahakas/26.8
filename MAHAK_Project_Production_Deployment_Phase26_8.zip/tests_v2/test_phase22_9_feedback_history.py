from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _app(db):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    return app


def _start(client, plan_id: str):
    response = client.post(
        "/api/education/learning-plans/start",
        json={
            "user_id": "student-22-9",
            "plan_id": plan_id,
            "total_sessions": 1,
            "session_steps": 1,
            "topic": "قانون دوم نیوتن",
            "mastery_target": 0.75,
            "max_remediation_sessions": 1,
        },
    )
    assert response.status_code == 200, response.text


def _record(client, plan_id: str, feedback_id: str):
    return client.post(
        "/api/education/recommendations/feedback/history",
        json={
            "user_id": "student-22-9",
            "learning_plan_id": plan_id,
            "feedback_id": feedback_id,
            "task_type": "quiz",
            "question_count": 4,
        },
    )


def test_feedback_history_record_is_persisted_and_idempotent():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "history-001")
        first = _record(client, "history-001", "feedback-001")
        second = _record(client, "history-001", "feedback-001")
        assert first.status_code == 200, first.text
        assert second.status_code == 200, second.text
        assert first.json()["recorded"] is True
        assert first.json()["replayed"] is False
        assert second.json()["recorded"] is False
        assert second.json()["replayed"] is True
        assert first.json()["entry"] == second.json()["entry"]
    finally:
        db.close()
        engine.dispose()


def test_feedback_history_lists_plan_scoped_summary():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "history-002")
        assert _record(client, "history-002", "feedback-002").status_code == 200
        assert _record(client, "history-002", "feedback-003").status_code == 200
        response = client.get(
            "/api/education/recommendations/feedback/history",
            params={"user_id": "student-22-9", "learning_plan_id": "history-002"},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total_feedback"] == 2
        assert body["continue_count"] == 2
        assert body["latest_action"] == "continue"
        assert [item["feedback_id"] for item in body["entries"]] == ["feedback-003", "feedback-002"]
    finally:
        db.close()
        engine.dispose()


def test_feedback_history_can_list_across_plans():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "history-003-a")
        _start(client, "history-003-b")
        assert _record(client, "history-003-a", "feedback-004").status_code == 200
        assert _record(client, "history-003-b", "feedback-005").status_code == 200
        response = client.get(
            "/api/education/recommendations/feedback/history",
            params={"user_id": "student-22-9", "limit": 10},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total_feedback"] == 2
        assert body["learning_plan_id"] is None
        assert {item["learning_plan_id"] for item in body["entries"]} == {"history-003-a", "history-003-b"}
    finally:
        db.close()
        engine.dispose()


def test_feedback_id_cannot_cross_learning_plans():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        _start(client, "history-004-a")
        _start(client, "history-004-b")
        assert _record(client, "history-004-a", "feedback-006").status_code == 200
        response = _record(client, "history-004-b", "feedback-006")
        assert response.status_code == 422
        assert "another learning plan" in response.json()["detail"]
    finally:
        db.close()
        engine.dispose()


def test_feedback_history_limit_validation():
    db, engine = _db()
    try:
        client = TestClient(_app(db))
        response = client.get(
            "/api/education/recommendations/feedback/history",
            params={"user_id": "student-22-9", "limit": 0},
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
