from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.agents.teacher_session import TeacherSessionService
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService


def _memory():
    engine = create_engine("sqlite:///:memory:", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def test_teacher_session_start_resume_touch_and_close():
    memory, db, engine = _memory()
    try:
        service = TeacherSessionService(memory)
        first = service.start(user_id="u25-10", session_id="s25-10", conversation_id="c25-10")
        resumed = service.start(user_id="u25-10", session_id="s25-10", conversation_id="c25-10")
        assert resumed == first
        interaction = TeacherInteractionService(memory).record(
            user_id="u25-10", conversation_id="c25-10", question="سؤال", agent_types=("GENERAL_AGENT",),
            modalities=("general",), strategy_mode="explain", strategy_difficulty="standard",
            learning_outcome="stable", recommended_mode="explain", recommended_difficulty="standard",
            next_action="continue", confidence=0.7, evidence_count=0, citation_count=0, found=False,
            teacher_session_id="s25-10",
        )
        current = service.get("u25-10", "s25-10")
        assert current is not None
        assert current.interaction_count == 1
        assert current.last_interaction_id == interaction.interaction_id
        closed = service.close("u25-10", "s25-10")
        assert closed.status == "closed"
        assert service.close("u25-10", "s25-10") == closed
    finally:
        db.close(); engine.dispose()


def test_teacher_session_rejects_cross_conversation_and_closed_use():
    memory, db, engine = _memory()
    try:
        service = TeacherSessionService(memory)
        service.start(user_id="u25-10-b", session_id="s25-10-b", conversation_id="a")
        try:
            service.start(user_id="u25-10-b", session_id="s25-10-b", conversation_id="b")
        except ValueError as exc:
            assert "another conversation" in str(exc)
        else:
            raise AssertionError("cross conversation resume must fail")
        service.close("u25-10-b", "s25-10-b")
        try:
            service.start(user_id="u25-10-b", session_id="s25-10-b")
        except ValueError as exc:
            assert "closed" in str(exc)
        else:
            raise AssertionError("closed session restart must fail")
    finally:
        db.close(); engine.dispose()


def test_teacher_session_api_lifecycle(monkeypatch):
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    from backend_v2.api.dependencies import get_current_user, get_db
    from backend_v2.api import teacher as teacher_api
    from backend_v2.database.models.auth import User

    memory, db, engine = _memory()
    service = TeacherSessionService(memory)
    user = User(id="api-25-10", email="api25-10@example.com", password_hash="x", display_name="Phase25.10", role="student")
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: user
    app.dependency_overrides[get_db] = lambda: db
    monkeypatch.setattr(teacher_api, "TeacherSessionService", lambda: service)
    try:
        client = TestClient(app)
        started = client.post("/api/teacher/sessions/start", json={"session_id":"api-session-25-10","conversation_id":"api-conv-25-10"})
        assert started.status_code == 200, started.text
        listed = client.get("/api/teacher/sessions", params={"status":"active"})
        assert listed.status_code == 200, listed.text
        assert len(listed.json()["items"]) == 1
        fetched = client.get("/api/teacher/sessions/api-session-25-10")
        assert fetched.status_code == 200
        closed = client.post("/api/teacher/sessions/api-session-25-10/close")
        assert closed.status_code == 200
        assert closed.json()["status"] == "closed"
    finally:
        db.close(); engine.dispose()
