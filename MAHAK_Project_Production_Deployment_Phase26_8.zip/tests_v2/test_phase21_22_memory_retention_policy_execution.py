from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.types import MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, user_id: str) -> None:
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-question",
                value_json={"q": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.WEAK_AREA.value,
                memory_key="old-weak",
                value_json={"topic": "algebra"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent-question",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=10),
                updated_at=now - timedelta(days=10),
            ),
        ]
    )
    db.commit()


def test_policy_preview_uses_effective_configuration_and_is_read_only():
    client, db, engine = _client()
    try:
        _seed(db, "policy-exec-user")
        configured = client.put(
            "/api/memory/policy-exec-user/retention/policy",
            json={"retention_days": 30, "max_delete": 1, "memory_type": "previous_question"},
        )
        assert configured.status_code == 200

        before = db.query(LearningMemory).filter(LearningMemory.user_id == "policy-exec-user").count()
        response = client.post("/api/memory/policy-exec-user/retention/policy/preview")
        assert response.status_code == 200
        payload = response.json()
        assert payload["retention_days"] == 30
        assert payload["max_delete"] == 1
        assert payload["memory_type"] == "previous_question"
        assert payload["candidate_count"] == 1
        assert payload["would_delete_count"] == 1
        assert payload["configured"] is True
        assert payload["read_only"] is True
        after = db.query(LearningMemory).filter(LearningMemory.user_id == "policy-exec-user").count()
        assert before == after == 3
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_respects_policy_and_audits_only_deleted_records():
    client, db, engine = _client()
    try:
        _seed(db, "apply-policy-user")
        client.put(
            "/api/memory/apply-policy-user/retention/policy",
            json={"retention_days": 30, "max_delete": 1, "memory_type": "previous_question"},
        )
        response = client.post("/api/memory/apply-policy-user/retention/policy/apply")
        assert response.status_code == 200
        assert response.json() == {
            "user_id": "apply-policy-user",
            "action": "retention",
            "deleted_count": 1,
        }
        remaining = list(
            db.scalars(select(LearningMemory).where(LearningMemory.user_id == "apply-policy-user"))
        )
        assert {row.memory_key for row in remaining} == {"old-weak", "recent-question"}
        audits = list(
            db.scalars(select(MemoryAuditEvent).where(MemoryAuditEvent.user_id == "apply-policy-user"))
        )
        retention_events = [event for event in audits if event.action == "retention"]
        assert len(retention_events) == 1
        assert retention_events[0].affected_count == 1
        assert retention_events[0].memory_type == "previous_question"
    finally:
        db.close()
        engine.dispose()


def test_policy_apply_with_no_candidates_is_idempotent_and_creates_no_audit():
    client, db, engine = _client()
    try:
        _seed(db, "no-op-policy-user")
        client.put(
            "/api/memory/no-op-policy-user/retention/policy",
            json={"retention_days": 90, "max_delete": 10, "memory_type": "weak_area"},
        )
        response = client.post("/api/memory/no-op-policy-user/retention/policy/apply")
        assert response.status_code == 200
        assert response.json()["deleted_count"] == 0
        audit_count = db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "no-op-policy-user").count()
        assert audit_count == 0
    finally:
        db.close()
        engine.dispose()


def test_unconfigured_policy_preview_uses_safe_defaults():
    client, db, engine = _client()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="default-policy-user",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="very-old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=400),
                updated_at=now - timedelta(days=400),
            )
        )
        db.commit()
        response = client.post("/api/memory/default-policy-user/retention/policy/preview")
        assert response.status_code == 200
        payload = response.json()
        assert payload["retention_days"] == 365
        assert payload["max_delete"] == 500
        assert payload["configured"] is False
        assert payload["candidate_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_policy_execution_does_not_run_automatically_on_records_read():
    client, db, engine = _client()
    try:
        _seed(db, "no-auto-user")
        client.put(
            "/api/memory/no-auto-user/retention/policy",
            json={"retention_days": 1, "max_delete": 500},
        )
        response = client.get("/api/memory/no-auto-user/records")
        assert response.status_code == 200
        assert response.json()["count"] == 3
    finally:
        db.close()
        engine.dispose()
