from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult
from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def _orchestrator() -> ProviderOrchestrator:
    registry = ProviderRegistry()
    provider = MockProviderAdapter(
        "phase20-8-teacher",
        {Capability.CHAT},
        lambda payload: {"answer": "توضیح آموزشی: ابتدا دو طرف معادله را در نظر می‌گیریم و سپس x را جدا می‌کنیم."},
        default_model="teacher-test-v1",
    )
    registry.register(provider, priority=1)
    return ProviderOrchestrator(registry, ProviderHealthManager())


def test_teacher_agent_uses_existing_provider_orchestration_and_preserves_evidence():
    source = AgentResult(
        answer="x = 3",
        evidence=[{"type": "video", "timestamp": {"start": 28.22, "end": 34.0}}],
        citations=[{"title": "lecture", "start_time_seconds": 28.22, "end_time_seconds": 34.0}],
        confidence=0.7,
    )

    result = TeacherAgent(_orchestrator()).execute(
        "این جواب را آموزشی توضیح بده",
        source_result=source,
    )

    assert result.answer.startswith("توضیح آموزشی:")
    assert result.evidence == source.evidence
    assert result.citations == source.citations
    assert result.confidence == 0.7
