from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class MemoryAwareStubAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def __init__(self) -> None:
        self.memory_context = None
        self.conversation_context = None

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.memory_context = kwargs.get("memory_context")
        self.conversation_context = kwargs.get("conversation_context")
        return AgentResult(
            answer="memory-aware answer",
            evidence=[{"type": "memory", "query": query}],
            citations=[{"title": "memory source"}],
            confidence=0.9,
        )


def _memory_service():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _pipeline(agent: MemoryAwareStubAgent, memory_service: MemoryService):
    registry = AgentRegistry()
    registry.register(agent)
    return UnifiedAgentPipeline(
        AgentRouter(registry),
        TeacherAgent(),
        memory=MemoryIntegrationService(memory_service),
    )


def test_memory_is_loaded_into_agent_and_turn_is_persisted():
    db, engine = _memory_service()
    try:
        memory_service = MemoryService(db)
        context = ConversationContext(
            conversation_id="conv-21-2",
            user_id="student-21-2",
            mode=ChatMode.GENERAL,
            grade_id="10",
            subject_id="physics",
        )
        memory_service.remember(
            user_id="student-21-2",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.3},
            confidence=0.8,
            conversation_id=context.conversation_id,
        )

        agent = MemoryAwareStubAgent()
        pipeline = _pipeline(agent, memory_service)
        result = pipeline.execute(
            "سلام، در جبر کمکم کن",
            conversation_context=context,
        )

        assert result.answer == "memory-aware answer"
        assert agent.conversation_context is context
        assert agent.memory_context is not None
        prompt_data = agent.memory_context.as_prompt_data()
        assert any(item["memory_type"] == MemoryType.WEAK_AREA.value for item in prompt_data)

        previous = memory_service.latest(
            context.user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key=f"conversation:{context.conversation_id}:latest_question",
        )
        learning = memory_service.latest(
            context.user_id,
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key=f"conversation:{context.conversation_id}:latest_turn",
        )
        assert previous is not None
        assert previous.value["question"] == "سلام، در جبر کمکم کن"
        assert learning is not None
        assert learning.value["agent_type"] == AgentType.GENERAL.value
    finally:
        db.close()
        engine.dispose()


def test_pipeline_without_conversation_remains_backward_compatible():
    db, engine = _memory_service()
    try:
        agent = MemoryAwareStubAgent()
        pipeline = _pipeline(agent, MemoryService(db))
        result = pipeline.execute("سلام")
        assert result.answer == "memory-aware answer"
        assert agent.memory_context is not None
        assert agent.memory_context.records == ()
    finally:
        db.close()
        engine.dispose()
