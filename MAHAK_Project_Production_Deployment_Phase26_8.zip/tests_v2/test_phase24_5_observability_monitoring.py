from __future__ import annotations

import json
import logging

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.observability.logging import StructuredJsonFormatter
from backend_v2.observability.metrics import MetricsRegistry


def _client():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), engine


def test_request_id_is_generated_and_returned():
    client, engine = _client()
    response = client.get("/api/health/live")
    assert response.status_code == 200
    assert len(response.headers["X-Request-ID"]) == 32
    engine.dispose()


def test_valid_incoming_request_id_is_preserved():
    client, engine = _client()
    request_id = "phase24-5-request-001"
    response = client.get("/api/health/live", headers={"X-Request-ID": request_id})
    assert response.headers["X-Request-ID"] == request_id
    engine.dispose()


def test_invalid_incoming_request_id_is_replaced():
    client, engine = _client()
    response = client.get("/api/health/live", headers={"X-Request-ID": "bad request id"})
    assert response.headers["X-Request-ID"] != "bad request id"
    engine.dispose()


def test_liveness_and_readiness_contracts():
    client, engine = _client()
    live = client.get("/api/health/live")
    ready = client.get("/api/health/ready")
    assert live.status_code == 200
    assert live.json()["status"] == "ok"
    assert ready.status_code == 200
    assert ready.json()["status"] == "ready"
    assert ready.json()["checks"]["database"] == "ok"
    engine.dispose()


def test_metrics_endpoint_uses_prometheus_text():
    client, engine = _client()
    client.get("/api/health/live")
    response = client.get("/api/metrics")
    assert response.status_code == 200
    assert "mahak_requests_total" in response.text
    assert "mahak_route_requests_total" in response.text
    assert response.headers["content-type"].startswith("text/plain")
    engine.dispose()


def test_metrics_registry_is_thread_safe_and_deterministic():
    registry = MetricsRegistry(max_route_labels=2)
    registry.request_started()
    registry.request_finished(method="GET", route="/a", status_code=200, duration_ms=3.5)
    registry.request_started()
    registry.request_finished(method="POST", route="/b", status_code=500, duration_ms=4.0)
    snapshot = registry.snapshot()
    assert snapshot["requests_total"] == 2
    assert snapshot["errors_total"] == 1
    assert snapshot["in_flight"] == 0
    text = registry.render_prometheus()
    assert "mahak_requests_total 2" in text
    assert 'status_class="5xx"' in text


def test_structured_formatter_emits_json_and_request_id(monkeypatch):
    from backend_v2.observability.context import set_request_id, reset_request_id

    formatter = StructuredJsonFormatter()
    logger = logging.getLogger("mahak.test")
    record = logger.makeRecord(
        logger.name,
        logging.INFO,
        __file__,
        1,
        "request completed",
        (),
        None,
        extra={"mahak_event": {"event": "request", "password": "SECRET", "status_code": 200}},
    )
    token = set_request_id("phase24-5-log-test")
    try:
        payload = json.loads(formatter.format(record))
    finally:
        reset_request_id(token)
    assert payload["request_id"] == "phase24-5-log-test"
    assert payload["event"] == "request"
    assert "password" not in payload
    assert "SECRET" not in formatter.format(record)


def test_observability_does_not_log_request_body_or_authorization():
    from backend_v2.observability.logging import _safe_event

    safe = _safe_event(
        {
            "method": "POST",
            "route": "/api/auth/login",
            "authorization": "Bearer super-secret",
            "password": "StrongPass123!",
            "event": "request",
        }
    )
    assert "authorization" not in safe
    assert "password" not in safe
    assert all(secret not in json.dumps(safe) for secret in ("super-secret", "StrongPass123!"))


def test_existing_health_endpoint_remains_backward_compatible():
    client, engine = _client()
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["version"] == "0.7.0"
    engine.dispose()
