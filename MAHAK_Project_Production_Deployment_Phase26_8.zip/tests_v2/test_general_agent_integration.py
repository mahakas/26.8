from backend_v2.agents.general import GeneralAgent
from backend_v2.chat.context import ConversationContext
from backend_v2.chat.general import GeneralChatService
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def _service() -> GeneralChatService:
    registry = ProviderRegistry()
    provider = MockProviderAdapter(
        "phase20-7-general",
        {Capability.CHAT},
        lambda payload: "پاسخ عمومی واقعی از مسیر GeneralChatService",
        default_model="general-test-v1",
    )
    registry.register(provider, priority=1)
    orchestrator = ProviderOrchestrator(registry, ProviderHealthManager())
    return GeneralChatService(orchestrator)


def test_general_agent_executes_existing_general_chat_service():
    service = _service()
    agent = GeneralAgent(service)
    context = ConversationContext(
        conversation_id="phase20-7-integration",
        user_id=None,
        mode=ChatMode.GENERAL,
    )

    result = agent.execute("سلام", context=context)

    assert result.answer == "پاسخ عمومی واقعی از مسیر GeneralChatService"
    assert result.confidence == 0.8
    assert result.evidence == []
    assert result.citations == []
    assert context.messages[-1]["role"] == "assistant"
