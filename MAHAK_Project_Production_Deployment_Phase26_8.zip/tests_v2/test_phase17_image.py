from pathlib import Path

from PIL import Image

from backend_v2.core.enums import Capability, SourceType
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.image import VisionImageProcessor
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def _vision_orchestrator() -> ProviderOrchestrator:
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            'vision-test', {Capability.VISION}, default_model='vision-test-v1',
            handler=lambda payload: 'متن استخراج‌شده از تصویر: قانون دوم نیوتن، F = ma.',
        ),
        priority=1,
    )
    return ProviderOrchestrator(registry, ProviderHealthManager(), max_attempts=1)


def _make_png(path: Path) -> None:
    Image.new('RGB', (20, 20), 'white').save(path)


def test_image_loader_metadata(tmp_path):
    p = tmp_path / 'lesson.png'
    _make_png(p)
    result = IngestionPipeline().process(p)
    assert result.analysis.source_type is SourceType.IMAGE
    assert result.document.metadata['image_id'] == 'lesson'
    assert Capability.VISION in result.required_capabilities
    assert not result.chunks


def test_vision_processor_turns_image_into_text(tmp_path):
    p = tmp_path / 'lesson.png'
    _make_png(p)
    pipeline = IngestionPipeline(vision_processor=VisionImageProcessor(_vision_orchestrator(), ocr_enabled=False))
    result = pipeline.process(p)
    assert result.chunks
    assert 'قانون دوم نیوتن' in result.chunks[0].text
    assert result.document.metadata['vision_provider'] == 'vision-test'
    assert result.document.metadata['vision_processed'] is True
    assert result.required_capabilities == frozenset()


def test_image_processing_does_not_claim_ocr_when_unavailable(monkeypatch, tmp_path):
    p = tmp_path / 'lesson.png'
    _make_png(p)
    class FakeOCR:
        def extract(self, path, *, language):
            return '', 'OCR unavailable: missing binary'
    pipeline = IngestionPipeline(
        vision_processor=VisionImageProcessor(_vision_orchestrator(), ocr=FakeOCR(), ocr_enabled=True)
    )
    result = pipeline.process(p)
    assert result.chunks
    assert result.document.metadata['ocr_text_present'] is False
    assert 'OCR unavailable' in '\n'.join(result.warnings)


def test_vision_provider_can_failover_to_second_provider(tmp_path):
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter('bad-vision', {Capability.VISION}, default_model='bad', handler=lambda payload: (_ for _ in ()).throw(ConnectionError('down'))),
        priority=1,
    )
    registry.register(
        MockProviderAdapter('good-vision', {Capability.VISION}, default_model='good', handler=lambda payload: 'fallback vision result'),
        priority=2,
    )
    orch = ProviderOrchestrator(registry, ProviderHealthManager(), max_attempts=2, sleeper=lambda _: None)
    p = tmp_path / 'x.png'
    _make_png(p)
    result = VisionImageProcessor(orch, ocr_enabled=False).process(
        IngestionPipeline().loaders.load(IngestionPipeline().analyze(p)), p
    )
    assert result.provider == 'good-vision'
    assert 'fallback vision result' in result.vision_text
