from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.learning_loop import TeacherLearningLoopService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.agents.teaching_strategy import AdaptiveTeachingStrategyPlanner, TeachingMode
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.agents.base import BaseAgent
from backend_v2.agents.multimodal import MultimodalTeacherService
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType
from backend_v2.providers.orchestrator import ProviderOrchestrator


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session(), engine


def _attempt(memory: MemoryService, user_id: str, attempt_id: str, score: float, task_type: str = "quiz"):
    memory.remember(
        user_id=user_id,
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key=f"attempt:{attempt_id}",
        value={
            "attempt_id": attempt_id,
            "user_id": user_id,
            "task_type": task_type,
            "total_score": score,
            "correct_count": 1 if score >= 0.5 else 0,
            "partial_count": 0,
            "incorrect_count": 0 if score >= 0.5 else 1,
            "mastery_by_topic": {"فیزیک": score},
        },
        confidence=1.0,
        source="test",
    )


def test_learning_loop_requests_remediation_from_negative_feedback_and_low_score():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        _attempt(memory, "student-25-6", "a1", 0.4)
        memory.remember(
            user_id="student-25-6",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:فیزیک",
            value={"topic": "فیزیک", "status": "active", "mastery_score": 0.4, "weakness_score": 0.6, "needs_retry": True},
            confidence=1.0,
            source="test",
        )
        feedback = TeacherFeedbackService(memory)
        feedback.record(
            user_id="student-25-6",
            conversation_id="conv-25-6",
            feedback_id="f1",
            rating=1,
            understood=False,
            strategy_effective=False,
        )
        state = TeacherLearningLoopService(memory).evaluate(
            "student-25-6",
            conversation_id="conv-25-6",
            student_progress=MemoryProgressService(memory).build("student-25-6"),
            feedback_summary=feedback.summary("student-25-6", conversation_id="conv-25-6"),
        )
        assert state.learning_outcome == "needs_support"
        assert state.recommended_mode == "remediation"
        assert state.recommended_difficulty == "foundational"
        assert state.next_action == "remediation_retry"
        assert state.active_weak_areas == ("فیزیک",)
    finally:
        db.close()
        engine.dispose()


def test_learning_loop_detects_positive_momentum_and_advancement_readiness():
    db, engine = _db()
    try:
        memory = MemoryService(db)
        _attempt(memory, "student-25-6-up", "a1", 0.65, "practice")
        _attempt(memory, "student-25-6-up", "a2", 0.85, "quiz")
        _attempt(memory, "student-25-6-up", "a3", 0.95, "practice")
        feedback = TeacherFeedbackService(memory)
        feedback.record(
            user_id="student-25-6-up",
            conversation_id="conv-up",
            feedback_id="f-up",
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        state = TeacherLearningLoopService(memory).evaluate(
            "student-25-6-up",
            conversation_id="conv-up",
            student_progress=MemoryProgressService(memory).build("student-25-6-up"),
            feedback_summary=feedback.summary("student-25-6-up", conversation_id="conv-up"),
        )
        assert state.learning_outcome == "ready_to_advance"
        assert state.recommended_mode == "practice"
        assert state.recommended_difficulty == "advanced"
        assert state.next_action == "advance_to_independent_practice"
        assert state.score_trend > 0
    finally:
        db.close()
        engine.dispose()


def test_learning_loop_uses_learning_plan_outcome_when_plan_is_supplied():
    class AnalyticsStub:
        def analyze(self, user_id: str, plan_id: str):
            return type(
                "Analytics",
                (),
                {
                    "outcome": "completed",
                    "latest_score": 0.95,
                    "average_score": 0.92,
                },
            )()

    db, engine = _db()
    try:
        memory = MemoryService(db)
        state = TeacherLearningLoopService(memory, analytics=AnalyticsStub()).evaluate(
            "student-25-6-plan",
            learning_plan_id="plan-25-6",
            student_progress=MemoryProgressService(memory).build("student-25-6-plan"),
        )
        assert state.learning_outcome == "ready_to_advance"
        assert state.learning_plan_id == "plan-25-6"
        assert state.source == "learning_plan_analytics"
        assert state.latest_score == 0.95
    finally:
        db.close()
        engine.dispose()


def test_learning_loop_updates_auto_strategy_but_respects_explicit_mode():
    class Loop:
        learning_outcome = "ready_to_advance"
        recommended_mode = "practice"
        recommended_difficulty = "advanced"

    planner = AdaptiveTeachingStrategyPlanner()
    auto = planner.plan(requested_mode=TeachingMode.AUTO, query="توضیح بده", learning_loop=Loop())
    explicit = planner.plan(requested_mode=TeachingMode.SOCRATIC, query="توضیح بده", learning_loop=Loop())
    assert auto.mode is TeachingMode.PRACTICE
    assert auto.difficulty == "advanced"
    assert explicit.mode is TeachingMode.SOCRATIC


def test_multimodal_teacher_execution_exposes_learning_loop():
    class StubAgent(BaseAgent):
        agent_type = AgentType.GENERAL

        def execute(self, query: str, **kwargs):
            return AgentResult("پاسخ خام", [{"type": "text", "text": "محتوا"}], [], 0.8)

    db, engine = _db()
    try:
        memory = MemoryIntegrationService(MemoryService(db))
        registry = __import__("backend_v2.agents.registry", fromlist=["AgentRegistry"]).AgentRegistry()
        registry.register(StubAgent())
        service = MultimodalTeacherService(registry, __import__("backend_v2.agents.teacher", fromlist=["TeacherAgent"]).TeacherAgent(), memory=memory)
        context = ConversationContext(
            conversation_id="conv-multi-25-6",
            user_id="student-multi-25-6",
            mode=ChatMode.GENERAL,
        )
        result = service.execute("یک توضیح بده", context=context, modalities=("general",))
        assert result.learning_loop.learning_outcome == "stable"
        assert result.teaching_strategy.mode is TeachingMode.EXPLAIN
        assert result.result.evidence == [{"type": "text", "text": "محتوا"}]
    finally:
        db.close()
        engine.dispose()


def test_multimodal_teacher_persists_interaction_trace_for_authenticated_context():
    class StubAgent(BaseAgent):
        agent_type = AgentType.GENERAL

        def execute(self, query: str, **kwargs):
            return AgentResult("پاسخ", [{"type": "text", "text": "محتوا"}], [], 0.8)

    db, engine = _db()
    try:
        memory = MemoryIntegrationService(MemoryService(db))
        registry = __import__("backend_v2.agents.registry", fromlist=["AgentRegistry"]).AgentRegistry()
        registry.register(StubAgent())
        service = MultimodalTeacherService(
            registry,
            __import__("backend_v2.agents.teacher", fromlist=["TeacherAgent"]).TeacherAgent(),
            memory=memory,
        )
        context = ConversationContext("conv-trace-25-7", "student-trace-25-7", ChatMode.GENERAL)
        execution = service.execute("یک توضیح بده", context=context, modalities=("general",))
        assert execution.interaction is not None
        stored = TeacherInteractionService(memory.memory).get("student-trace-25-7", execution.interaction.interaction_id)
        assert stored is not None
        assert stored.conversation_id == "conv-trace-25-7"
        assert stored.evidence_count == 1
        assert stored.citation_count == 0
        assert stored.next_action == execution.learning_loop.next_action
    finally:
        db.close()
        engine.dispose()
