from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _service():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    return Session()


def test_memory_service_persists_all_required_memory_types():
    db = _service()
    try:
        service = MemoryService(db)
        user_id = "student-1"
        for memory_type, key, value in (
            (MemoryType.LEARNING_HISTORY, "lesson-1", {"score": 0.8}),
            (MemoryType.WEAK_AREA, "algebra", {"mastery": 0.3}),
            (MemoryType.PREVIOUS_QUESTION, "q-1", {"text": "x+4=16"}),
            (MemoryType.STUDENT_PROFILE, "language", {"value": "fa"}),
        ):
            service.remember(
                user_id=user_id,
                memory_type=memory_type,
                memory_key=key,
                value=value,
                confidence=0.9,
            )
        db.commit()

        records = service.list(user_id)
        assert {record.memory_type for record in records} == set(MemoryType)
        assert len(records) == 4
    finally:
        db.close()


def test_memory_service_latest_returns_newest_value():
    db = _service()
    try:
        service = MemoryService(db)
        service.remember(
            user_id="student-2",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="grade",
            value={"value": "10"},
        )
        service.remember(
            user_id="student-2",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="grade",
            value={"value": "11"},
        )
        db.commit()

        latest = service.latest(
            "student-2",
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="grade",
        )
        assert latest is not None
        assert latest.value == {"value": "11"}
    finally:
        db.close()


def test_memory_service_rejects_invalid_confidence():
    db = _service()
    try:
        service = MemoryService(db)
        try:
            service.remember(
                user_id="student-3",
                memory_type=MemoryType.WEAK_AREA,
                memory_key="fractions",
                value={"mastery": 0.2},
                confidence=1.5,
            )
        except ValueError as exc:
            assert "confidence" in str(exc)
        else:
            raise AssertionError("Expected ValueError")
    finally:
        db.close()
