from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient
from pytest import approx

from backend_v2.agents.teacher_analytics import TeacherOutcomeAnalyticsService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.api import teacher as teacher_api
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from backend_v2.memory.service import MemoryService


def _memory():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def _record_interaction(memory: MemoryService, *, user: str, conversation: str, question: str, plan: str | None, confidence: float, found: bool, mode: str, modalities: tuple[str, ...], outcome: str):
    return TeacherInteractionService(memory).record(
        user_id=user,
        conversation_id=conversation,
        question=question,
        agent_types=("DOCUMENT_AGENT",),
        modalities=modalities,
        strategy_mode=mode,
        strategy_difficulty="standard",
        learning_outcome=outcome,
        recommended_mode=mode,
        recommended_difficulty="standard",
        next_action="check_understanding",
        confidence=confidence,
        evidence_count=2,
        citation_count=1,
        found=found,
        learning_plan_id=plan,
    )


def test_teacher_outcome_analytics_aggregates_interactions_and_feedback():
    memory, db, engine = _memory()
    try:
        user = "u25-8"
        first = _record_interaction(
            memory,
            user=user,
            conversation="c25-8-a",
            question="اول",
            plan="plan-a",
            confidence=0.70,
            found=True,
            mode="explain",
            modalities=("document", "image"),
            outcome="stable",
        )
        second = _record_interaction(
            memory,
            user=user,
            conversation="c25-8-a",
            question="دوم",
            plan="plan-a",
            confidence=0.90,
            found=False,
            mode="practice",
            modalities=("video",),
            outcome="needs_support",
        )
        _record_interaction(
            memory,
            user=user,
            conversation="other",
            question="سوم",
            plan="plan-b",
            confidence=0.80,
            found=True,
            mode="review",
            modalities=("audio",),
            outcome="ready_to_advance",
        )

        feedback = TeacherFeedbackService(memory)
        feedback.record(
            user_id=user,
            conversation_id="c25-8-a",
            feedback_id="fb-1",
            interaction_id=first.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        feedback.record(
            user_id=user,
            conversation_id="c25-8-a",
            feedback_id="fb-2",
            interaction_id=second.interaction_id,
            rating=2,
            understood=False,
            strategy_effective=False,
        )
        feedback.record(
            user_id=user,
            conversation_id="c25-8-a",
            feedback_id="fb-3",
            rating=4,
            understood=True,
        )

        result = TeacherOutcomeAnalyticsService(memory).analyze(
            user,
            conversation_id="c25-8-a",
            limit=20,
            window_size=2,
            recent_interactions=5,
        )
        assert result.total_interactions == 2
        assert result.average_confidence == 0.8
        assert result.found_rate == 0.5
        assert result.total_feedback == 3
        assert result.bound_feedback == 2
        assert result.unbound_feedback == 1
        assert result.feedback_coverage_rate == 1.0
        assert result.average_rating == approx(11 / 3, rel=1e-6)
        assert result.understood_rate == approx(2 / 3, rel=1e-6)
        assert result.strategy_effective_rate == 0.5
        assert result.feedback_signal_counts["progressing"] == 2
        assert result.feedback_signal_counts["needs_support"] == 1
        assert result.modality_counts == {"video": 1, "document": 1, "image": 1}
        assert result.strategy_mode_counts == {"practice": 1, "explain": 1}
    finally:
        db.close()
        engine.dispose()


def test_teacher_outcome_analytics_filters_learning_plan_and_excludes_unbound_feedback():
    memory, db, engine = _memory()
    try:
        user = "u25-8-plan"
        item = _record_interaction(
            memory,
            user=user,
            conversation="c-plan",
            question="سؤال برنامه",
            plan="plan-target",
            confidence=0.95,
            found=True,
            mode="explain",
            modalities=("document",),
            outcome="stable",
        )
        _record_interaction(
            memory,
            user=user,
            conversation="c-plan",
            question="سؤال برنامه دیگر",
            plan="plan-other",
            confidence=0.30,
            found=False,
            mode="practice",
            modalities=("video",),
            outcome="needs_support",
        )
        feedback = TeacherFeedbackService(memory)
        feedback.record(
            user_id=user,
            conversation_id="c-plan",
            feedback_id="fb-plan-bound",
            interaction_id=item.interaction_id,
            rating=5,
            understood=True,
        )
        feedback.record(
            user_id=user,
            conversation_id="c-plan",
            feedback_id="fb-plan-unbound",
            rating=1,
            understood=False,
        )

        result = TeacherOutcomeAnalyticsService(memory).analyze(
            user,
            conversation_id="c-plan",
            learning_plan_id="plan-target",
        )
        assert result.total_interactions == 1
        assert result.total_feedback == 1
        assert result.bound_feedback == 1
        assert result.unbound_feedback == 0
        assert result.average_rating == 5.0
        assert result.recent_interactions[0].interaction_id == item.interaction_id
    finally:
        db.close()
        engine.dispose()


def test_teacher_outcome_analytics_api_for_authenticated_user(monkeypatch):
    memory, db, engine = _memory()
    try:
        user_id = "api-user-25-8"
        item = _record_interaction(
            memory,
            user=user_id,
            conversation="api-conv-25-8",
            question="تحلیل کن",
            plan="api-plan",
            confidence=0.91,
            found=True,
            mode="practice",
            modalities=("audio", "video"),
            outcome="ready_to_advance",
        )
        TeacherFeedbackService(memory).record(
            user_id=user_id,
            conversation_id="api-conv-25-8",
            feedback_id="api-feedback-25-8",
            interaction_id=item.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        user = User(id=user_id, email="phase25-8@example.com", password_hash="x", display_name="Phase 25.8", role="student")
        app = create_app()
        app.dependency_overrides[get_current_user] = lambda: user
        app.dependency_overrides[get_db] = lambda: db
        monkeypatch.setattr(teacher_api, "TeacherOutcomeAnalyticsService", lambda: TeacherOutcomeAnalyticsService(memory))

        response = TestClient(app).get(
            "/api/teacher/analytics",
            params={"conversation_id": "api-conv-25-8", "learning_plan_id": "api-plan"},
        )
        assert response.status_code == 200, response.text
        payload = response.json()
        assert payload["total_interactions"] == 1
        assert payload["total_feedback"] == 1
        assert payload["feedback_signal_counts"]["progressing"] == 1
        assert payload["recent_interactions"][0]["interaction_id"] == item.interaction_id
    finally:
        db.close()
        engine.dispose()
