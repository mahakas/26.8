from __future__ import annotations

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.database.connection import Base, engine


def reset_db(tmp_path, monkeypatch):
    db_path = tmp_path / "phase2.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_path}")


def test_schema_tables_exist():
    names = set(Base.metadata.tables)
    assert {"grades", "subjects", "courses", "chapters", "lessons", "sources"}.issubset(names)


def test_catalog_api_smoke():
    client = TestClient(create_app())
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_seed_catalog_is_defined():
    from scripts.seed_v2 import DEFAULT_CATALOG
    assert list(DEFAULT_CATALOG) == ["هفتم", "هشتم", "نهم", "دهم", "یازدهم", "دوازدهم"]
    assert all(subjects for subjects in DEFAULT_CATALOG.values())


def test_catalog_repository_roundtrip():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from backend_v2.database.connection import Base
    from backend_v2.database.repositories import CatalogRepository

    test_engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(test_engine)
    Session = sessionmaker(bind=test_engine, autoflush=False, expire_on_commit=False)
    with Session() as db:
        repo = CatalogRepository(db)
        grade = repo.create_grade("آزمایشی", 99)
        subject = repo.create_subject(grade.id, "فیزیک", 1)
        course = repo.create_course(subject.id, "دوره آزمایشی")
        chapter = repo.create_chapter(course.id, "فصل اول", 1)
        lesson = repo.create_lesson(chapter.id, "درس اول", 1)
        db.commit()
        assert repo.get_grade(grade.id).name == "آزمایشی"
        assert repo.list_subjects(grade.id)[0].name == "فیزیک"
        assert repo.list_courses(subject.id)[0].name == "دوره آزمایشی"
        assert repo.list_chapters(course.id)[0].name == "فصل اول"
        assert repo.list_lessons(chapter.id)[0].name == "درس اول"
