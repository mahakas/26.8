from backend_v2.retrieval.citation_builder import citation_from_hit
from backend_v2.retrieval.hybrid import HybridReranker
from backend_v2.retrieval.quality import assess_document_quality
from backend_v2.retrieval.threshold import RetrievalThreshold
from backend_v2.vectorstores.base import VectorHit


def test_garbled_document_is_penalized_and_marked():
    q = assess_document_quality("Ù¾Ø§Ø³Ø® نامفهوم")
    assert q.garbled
    hit = VectorHit("bad", 0.95, "Ù¾Ø§Ø³Ø® نامفهوم", {})
    ranked = HybridReranker().rerank("پاسخ", [hit])
    assert ranked[0].metadata["quality_garbled"] is True
    assert ranked[0].score < 0.7


def test_near_duplicate_documents_are_suppressed():
    hits = [
        VectorHit("a", 0.9, "قانون دوم نیوتن F = ma", {}),
        VectorHit("b", 0.89, "قانون دوم نیوتن F = ma", {}),
        VectorHit("c", 0.8, "شتاب جسم به نیروی خالص وابسته است", {}),
    ]
    ranked = HybridReranker().rerank("قانون دوم نیوتن", hits, top_k=3)
    assert [h.id for h in ranked] == ["a", "c"]


def test_low_quality_hit_is_rejected_by_threshold():
    hit = VectorHit("bad", 0.9, "Ù¾Ø§Ø³Ø® نامفهوم", {"quality_score": 0.2, "quality_garbled": True})
    decision = RetrievalThreshold(0.2).apply([hit])
    assert not decision.accepted
    assert decision.rejected == [hit]


def test_citation_contains_relevance_and_confidence():
    hit = VectorHit("good", 0.88, "محتوای مرتبط", {"source_id": "s1", "title": "فیزیک دهم", "page": 42})
    c = citation_from_hit(hit)
    assert c.page == 42
    assert c.relevance_score == 0.88
    assert c.confidence == "high"
