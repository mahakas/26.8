from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent, MemoryRetentionPolicy
from backend_v2.database.repositories import MemoryRetentionPolicyRepository
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def _db():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return session, engine


def _seed(db, user_id: str, *, old_days: int = 60, recent_days: int = 5):
    now = datetime.now(UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=old_days),
                updated_at=now - timedelta(days=old_days),
            ),
            LearningMemory(
                user_id=user_id,
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=recent_days),
                updated_at=now - timedelta(days=recent_days),
            ),
        ]
    )
    db.commit()


def test_disabled_scheduler_is_strictly_non_mutating():
    db, engine = _db()
    try:
        _seed(db, "disabled")
        MemoryRetentionPolicyService(db).set(
            "disabled",
            retention_days=30,
            max_delete=10,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        before = db.scalar(select(LearningMemory.id).where(LearningMemory.user_id == "disabled").order_by(LearningMemory.id))
        result = MemoryRetentionSchedulerService(db, enabled=False).run_once(user_ids=["disabled"])
        assert result[0].status == "disabled"
        assert db.scalar(select(LearningMemory.id).where(LearningMemory.user_id == "disabled").order_by(LearningMemory.id)) == before
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "disabled").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_enabled_scheduler_executes_only_configured_policy_and_audits():
    db, engine = _db()
    try:
        _seed(db, "enabled")
        MemoryRetentionPolicyService(db).set(
            "enabled",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        results = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            user_ids=["enabled"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        assert results[0].status == "executed"
        assert results[0].candidate_count == 1
        assert results[0].deleted_count == 1
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "enabled").count() == 1
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "enabled").count() == 1
    finally:
        db.close()
        engine.dispose()


def test_scheduler_skips_unconfigured_target_user():
    db, engine = _db()
    try:
        result = MemoryRetentionSchedulerService(db, enabled=True).run_once(user_ids=["unconfigured"])
        assert result[0].status == "skipped"
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "unconfigured").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_scheduler_processes_all_configured_users_once():
    db, engine = _db()
    try:
        for user_id in ("multi-a", "multi-b"):
            _seed(db, user_id)
            MemoryRetentionPolicyService(db).set(
                user_id,
                retention_days=30,
                max_delete=10,
                memory_type=MemoryType.PREVIOUS_QUESTION,
            )
        results = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        assert {row.user_id for row in results} == {"multi-a", "multi-b"}
        assert all(row.status == "executed" for row in results)
        assert all(row.deleted_count == 1 for row in results)
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.action == "retention").count() == 2
    finally:
        db.close()
        engine.dispose()


def test_policy_repository_lists_configured_users():
    db, engine = _db()
    try:
        MemoryRetentionPolicyService(db).set(
            "listed-a",
            retention_days=30,
            max_delete=10,
            memory_type=None,
        )
        MemoryRetentionPolicyService(db).set(
            "listed-b",
            retention_days=60,
            max_delete=10,
            memory_type=None,
        )
        users = MemoryRetentionPolicyRepository(db).list_user_ids(limit=10)
        assert set(users) == {"listed-a", "listed-b"}
    finally:
        db.close()
        engine.dispose()


def test_scheduler_isolates_one_bad_policy_from_other_users():
    db, engine = _db()
    try:
        _seed(db, "good-user")
        MemoryRetentionPolicyService(db).set(
            "good-user",
            retention_days=30,
            max_delete=10,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        db.add(
            MemoryRetentionPolicy(
                user_id="bad-user",
                retention_days=30,
                max_delete=10,
                memory_type="not-a-memory-type",
            )
        )
        db.commit()

        results = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            user_ids=["bad-user", "good-user"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
        )
        by_user = {row.user_id: row for row in results}
        assert by_user["bad-user"].status == "failed"
        assert by_user["good-user"].status == "executed"
        assert by_user["good-user"].deleted_count == 1
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "good-user").count() == 1
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "good-user").count() == 1
    finally:
        db.close()
        engine.dispose()



def test_scheduler_dry_run_plans_without_mutation_or_audit():
    db, engine = _db()
    try:
        _seed(db, "dry-run")
        MemoryRetentionPolicyService(db).set(
            "dry-run",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        before = db.query(LearningMemory).filter(LearningMemory.user_id == "dry-run").count()
        result = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            user_ids=["dry-run"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        assert result[0].status == "planned"
        assert result[0].dry_run is True
        assert result[0].candidate_count == 1
        assert result[0].would_delete_count == 1
        assert result[0].deleted_count == 0
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "dry-run").count() == before
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "dry-run").count() == 0
    finally:
        db.close()
        engine.dispose()


def test_scheduler_dry_run_honors_disabled_guard():
    db, engine = _db()
    try:
        _seed(db, "dry-disabled")
        result = MemoryRetentionSchedulerService(db, enabled=False).run_once(
            user_ids=["dry-disabled"],
            dry_run=True,
        )
        assert result[0].status == "disabled"
        assert result[0].dry_run is False
    finally:
        db.close()
        engine.dispose()
