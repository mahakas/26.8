from __future__ import annotations

from types import SimpleNamespace

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.factory import build_external_registry_from_env
from backend_v2.providers.adapters.local_embedding import LocalBGEEmbeddingAdapter
from backend_v2.providers.contracts import ProviderRequest


class FakeModel:
    def encode(self, texts, *, batch_size, normalize_embeddings, convert_to_numpy):
        assert batch_size == 4
        assert normalize_embeddings is True
        assert convert_to_numpy is True
        return SimpleNamespace(tolist=lambda: [[0.1] * 1024 for _ in texts])


def test_local_bge_adapter_produces_expected_dimension_without_network():
    adapter = LocalBGEEmbeddingAdapter(
        "BAAI/bge-m3",
        device="cpu",
        batch_size=4,
        model_loader=lambda name, **kwargs: FakeModel(),
    )
    result = adapter.execute(
        ProviderRequest(
            capability=Capability.EMBEDDING,
            model="BAAI/bge-m3",
            payload={"texts": ["سلام", "قانون دوم نیوتن"]},
        )
    )
    assert result.provider == "local-bge"
    assert result.model == "BAAI/bge-m3"
    assert len(result.output) == 2
    assert len(result.output[0]) == 1024
    assert result.metadata["backend"] == "local"


def test_factory_registers_local_bge_when_requested(monkeypatch):
    monkeypatch.setenv("EMBED_BACKEND", "local")
    monkeypatch.setenv("EMBED_MODEL", "BAAI/bge-m3")
    monkeypatch.delenv("CUSTOM_LLM_API_KEY", raising=False)
    registry = build_external_registry_from_env()
    provider = registry.get("local-bge")
    assert provider is not None
    assert provider.candidate_models(Capability.EMBEDDING)[0].model == "BAAI/bge-m3"
    assert registry.get_candidates(Capability.EMBEDDING)[0].adapter.provider_name == "local-bge"


def test_local_bge_adapter_declares_only_embedding_capability():
    adapter = LocalBGEEmbeddingAdapter(model_loader=lambda name, **kwargs: FakeModel())
    assert adapter.supports(Capability.EMBEDDING)
    assert not adapter.supports(Capability.CHAT)
    assert not adapter.supports(Capability.VISION)
