from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.agents.teacher_dashboard import TeacherDashboardService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.api import teacher as teacher_api
from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def _memory():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    return MemoryService(db), db, engine


def _interaction(memory: MemoryService, *, user: str, conversation: str, plan: str, question: str, confidence: float):
    return TeacherInteractionService(memory).record(
        user_id=user,
        conversation_id=conversation,
        question=question,
        agent_types=("DOCUMENT_AGENT",),
        modalities=("document",),
        strategy_mode="explain",
        strategy_difficulty="standard",
        learning_outcome="progressing",
        recommended_mode="practice",
        recommended_difficulty="standard",
        next_action="guided_practice",
        confidence=confidence,
        evidence_count=2,
        citation_count=1,
        found=True,
        learning_plan_id=plan,
    )


def _plan(memory: MemoryService, user: str, plan_id: str) -> None:
    memory.remember(
        user_id=user,
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key=f"learning_plan:{plan_id}",
        value={
            "plan_id": plan_id,
            "user_id": user,
            "status": "active",
            "total_sessions": 4,
            "completed_sessions": 1,
            "completed_milestones": 1,
            "current_milestone": 2,
            "mastery_target": 0.75,
            "active_session_id": f"{plan_id}:session-2",
            "next_topic": "algebra",
            "milestones": [{"index": 1, "topic": "fractions", "status": "completed", "mastery_score": 0.9}],
            "state_revision": 1,
            "recommendation": None,
            "last_attempt_id": "attempt-1",
        },
        confidence=1.0,
        source="test",
    )


def test_teacher_dashboard_composes_profile_learning_loop_analytics_and_plans():
    memory, db, engine = _memory()
    try:
        user = "u25-9"
        first = _interaction(memory, user=user, conversation="c25-9", plan="plan-25-9", question="اول", confidence=0.7)
        _interaction(memory, user=user, conversation="c25-9", plan="plan-25-9", question="دوم", confidence=0.9)
        TeacherFeedbackService(memory).record(
            user_id=user,
            conversation_id="c25-9",
            feedback_id="fb-25-9",
            interaction_id=first.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        _plan(memory, user, "plan-25-9")

        result = TeacherDashboardService(memory).build(user, conversation_id="c25-9", plan_limit=5)
        assert result.user_id == user
        assert result.profile.average_confidence == 0.9
        assert result.outcome_analytics["total_interactions"] == 2
        assert result.feedback_summary["total"] == 1
        assert result.learning_loop["feedback_signal"] == "progressing"
        assert len(result.learning_plans) == 1
        assert result.learning_plans[0].plan_id == "plan-25-9"
        assert result.learning_plans[0].completion_percent == 25.0
    finally:
        db.close()
        engine.dispose()


def test_teacher_dashboard_plan_scope_rejects_unknown_plan():
    memory, db, engine = _memory()
    try:
        try:
            TeacherDashboardService(memory).build("u25-9-missing", learning_plan_id="missing")
        except ValueError as exc:
            assert "not found" in str(exc).lower()
        else:
            raise AssertionError("unknown learning plan must fail")
    finally:
        db.close()
        engine.dispose()


def test_teacher_dashboard_api_is_authenticated_and_returns_composed_payload(monkeypatch):
    memory, db, engine = _memory()
    try:
        user_id = "api-user-25-9"
        interaction = _interaction(
            memory,
            user=user_id,
            conversation="api-conv-25-9",
            plan="api-plan-25-9",
            question="داشبورد",
            confidence=0.95,
        )
        TeacherFeedbackService(memory).record(
            user_id=user_id,
            conversation_id="api-conv-25-9",
            feedback_id="api-feedback-25-9",
            interaction_id=interaction.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        _plan(memory, user_id, "api-plan-25-9")

        user = User(id=user_id, email="phase25-9@example.com", password_hash="x", display_name="Phase 25.9", role="student")
        app = create_app()
        app.dependency_overrides[get_current_user] = lambda: user
        app.dependency_overrides[get_db] = lambda: db
        monkeypatch.setattr(teacher_api, "TeacherDashboardService", lambda: TeacherDashboardService(memory))

        response = TestClient(app).get(
            "/api/teacher/dashboard",
            params={"conversation_id": "api-conv-25-9", "learning_plan_id": "api-plan-25-9"},
        )
        assert response.status_code == 200, response.text
        payload = response.json()
        assert payload["user_id"] == user_id
        assert payload["outcome_analytics"]["total_interactions"] == 1
        assert payload["learning_loop"]["feedback_signal"] == "progressing"
        assert payload["learning_plans"][0]["plan_id"] == "api-plan-25-9"
    finally:
        db.close()
        engine.dispose()
