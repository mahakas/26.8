from __future__ import annotations

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.evaluation import (
    EducationalAgentEvaluationRequest,
    EducationalAgentEvaluationService,
)


def _document_request(**overrides):
    payload = dict(
        agent_type="DOCUMENT_AGENT",
        query="قانون دوم نیوتن چیست؟",
        answer="قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.",
        evidence=[{"type": "document", "text": "...", "source_id": "physics.pdf", "page": 4}],
        citations=[{"source_id": "physics.pdf", "page": 4}],
        confidence=0.9,
        expected_agent_type="DOCUMENT_AGENT",
    )
    payload.update(overrides)
    return EducationalAgentEvaluationRequest(**payload)


def test_document_agent_contract_can_score_excellent():
    result = EducationalAgentEvaluationService().evaluate(_document_request())
    assert result.agent_selection_accuracy == 1.0
    assert result.modality_evidence_coverage == 1.0
    assert result.citation_evidence_alignment == 1.0
    assert result.locator_completeness == 1.0
    assert result.contract_compliance == 1.0
    assert result.overall_score == 1.0
    assert result.quality_band == "excellent"


def test_wrong_modality_is_penalized():
    result = EducationalAgentEvaluationService().evaluate(
        _document_request(evidence=[{"type": "image", "image_id": "img-1"}])
    )
    assert result.modality_evidence_coverage == 0.0
    assert result.overall_score < 0.85


def test_video_agent_validates_timestamp_locator():
    result = EducationalAgentEvaluationService().evaluate(
        EducationalAgentEvaluationRequest(
            agent_type="VIDEO_AGENT",
            query="در این ویدیو چه زمانی قانون دوم نیوتن گفته شد؟",
            answer="در بخش مربوط به قانون دوم نیوتن توضیح داده می‌شود.",
            evidence=[{"type": "video", "transcript": "قانون دوم نیوتن", "timestamp": {"start": 54.5, "end": 57.3}}],
            citations=[{"source_id": "lesson.mp4", "start_time_seconds": 54.5, "end_time_seconds": 57.3, "frame_path": "frame_0054.jpg"}],
            confidence=0.8,
            expected_agent_type="VIDEO_AGENT",
        )
    )
    assert result.modality_evidence_coverage == 1.0
    assert result.locator_completeness == 1.0


def test_video_agent_missing_locator_is_penalized():
    result = EducationalAgentEvaluationService().evaluate(
        EducationalAgentEvaluationRequest(
            agent_type="VIDEO_AGENT",
            query="چه زمانی؟",
            answer="در ویدیو توضیح داده می‌شود.",
            evidence=[{"type": "video", "transcript": "قانون دوم نیوتن"}],
            citations=[{"source_id": "lesson.mp4"}],
            confidence=0.8,
        )
    )
    assert result.modality_evidence_coverage == 1.0
    assert result.locator_completeness == 0.0


def test_vision_agent_accepts_image_locator():
    result = EducationalAgentEvaluationService().evaluate(
        EducationalAgentEvaluationRequest(
            agent_type="IMAGE_AGENT",
            query="این تصویر چیست؟",
            answer="این تصویر یک نمودار است.",
            evidence=[{"type": "image", "image_id": "img-42", "image_path": "lesson.png"}],
            citations=[{"source_id": "lesson.png", "image_id": "img-42", "image_path": "lesson.png"}],
            confidence=0.8,
            expected_agent_type="IMAGE_AGENT",
        )
    )
    assert result.modality_evidence_coverage == 1.0
    assert result.locator_completeness == 1.0


def test_teacher_agent_accepts_mixed_modalities():
    result = EducationalAgentEvaluationService().evaluate(
        EducationalAgentEvaluationRequest(
            agent_type="TEACHER_AGENT",
            query="توضیح بده",
            answer="این مطالب را به‌صورت آموزشی توضیح می‌دهم.",
            evidence=[
                {"type": "document", "source_id": "book.pdf", "page": 3},
                {"type": "image", "image_id": "img-1"},
                {"type": "video", "timestamp": {"start": 2.0, "end": 5.0}},
            ],
            citations=[{"source_id": "book.pdf", "page": 3}, {"source_id": "img-1", "image_id": "img-1"}],
            confidence=0.9,
            expected_agent_type="TEACHER_AGENT",
        )
    )
    assert result.modality_evidence_coverage == 1.0
    assert result.notes[-1].startswith("teacher agent accepts mixed")


def test_agent_selection_mismatch_is_reported():
    result = EducationalAgentEvaluationService().evaluate(
        _document_request(expected_agent_type="VIDEO_AGENT")
    )
    assert result.agent_selection_accuracy == 0.0
    assert any("actual agent type differs" in note for note in result.notes)


def test_general_agent_uses_url_or_source_locator():
    result = EducationalAgentEvaluationService().evaluate(
        EducationalAgentEvaluationRequest(
            agent_type="GENERAL_AGENT",
            query="یک منبع عمومی چیست؟",
            answer="این یک پاسخ عمومی است.",
            evidence=[{"type": "general", "text": "snippet", "source_id": "web-1"}],
            citations=[{"source_id": "web-1", "url": "https://example.com"}],
            confidence=0.7,
        )
    )
    assert result.modality_evidence_coverage == 1.0
    assert result.locator_completeness == 1.0


def test_batch_is_deterministic_and_counts_agents():
    requests = (
        _document_request(),
        _document_request(expected_agent_type="VIDEO_AGENT"),
    )
    first = EducationalAgentEvaluationService.evaluate_batch(requests)
    second = EducationalAgentEvaluationService.evaluate_batch(requests)
    assert first.as_dict() == second.as_dict()
    assert first.total_cases == 2
    assert first.evaluated_cases == 2
    assert first.agent_type_counts == {"DOCUMENT_AGENT": 2}


def test_agent_evaluation_api_and_batch_endpoints():
    client = TestClient(create_app())
    payload = {
        "agent_type": "VIDEO_AGENT",
        "query": "چه زمانی؟",
        "answer": "در این بخش.",
        "evidence": [{"type": "video", "timestamp": {"start": 10.0, "end": 12.0}}],
        "citations": [{"source_id": "lesson.mp4", "start_time_seconds": 10.0, "end_time_seconds": 12.0}],
        "confidence": 0.8,
        "expected_agent_type": "VIDEO_AGENT",
    }
    response = client.post("/api/evaluation/agents", json=payload)
    assert response.status_code == 200, response.text
    assert response.json()["modality_evidence_coverage"] == 1.0

    batch = client.post(
        "/api/evaluation/agents/batch",
        json={"cases": [{"case_id": "video", "request": payload}, {"case_id": "video2", "request": payload}]},
    )
    assert batch.status_code == 200, batch.text
    assert batch.json()["evaluated_cases"] == 2
    assert batch.json()["agent_type_counts"] == {"VIDEO_AGENT": 2}
