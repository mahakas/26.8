from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _seed(db, *, status="completed", completed_at=datetime(2026, 9, 19, 10, 1)):
    db.add(
        MemoryRetentionMaintenanceRun(
            run_id=f"alert-{status}-{completed_at.isoformat()}",
            status=status,
            started_at=completed_at - timedelta(minutes=1),
            completed_at=completed_at,
            dry_run=False,
            cleanup_history=True,
            memory_status="completed",
            memory_user_count=1,
            memory_planned_count=1,
            memory_executed_count=1,
            memory_skipped_count=0,
            memory_failed_count=0,
            memory_candidate_count=2,
            memory_would_delete_count=2,
            memory_deleted_count=2,
            history_status="completed",
            history_configured=True,
            history_retention_days=365,
            history_max_delete=500,
            history_candidate_count=1,
            history_would_delete_count=1,
            history_deleted_count=1,
            history_error="history failure" if status == "completed_with_errors" else None,
        )
    )
    db.commit()


def test_alerts_disabled_state_is_warning_and_read_only():
    client, db, engine = _client()
    try:
        before = db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun))
        response = client.get("/api/memory/maintenance/alerts")
        assert response.status_code == 200
        payload = response.json()
        assert payload["severity"] == "warning"
        assert payload["health"] == "disabled"
        assert payload["alerts"][0]["code"] == "maintenance_disabled"
        assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceRun)) == before
    finally:
        db.close()
        engine.dispose()


def test_alerts_healthy_has_no_active_alerts():
    client, db, engine = _client()
    try:
        completed_at = datetime.now(UTC).replace(tzinfo=None) - timedelta(seconds=30)
        _seed(db, completed_at=completed_at)
        response = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true", "stale_after_seconds": 60},
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["severity"] == "none"
        assert payload["alerts"] == []
    finally:
        db.close()
        engine.dispose()


def test_alerts_blocked_lease_is_critical():
    client, db, engine = _client()
    lease = None
    try:
        _seed(db)
        lease_now = datetime.now(UTC)
        lease = MemoryRetentionMaintenanceLeaseService(db).acquire(
            ttl_seconds=60,
            now=lease_now,
        )
        payload = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true"},
        ).json()
        assert payload["severity"] == "critical"
        assert any(a["code"] == "maintenance_lease_held" for a in payload["alerts"])
    finally:
        if lease is not None:
            MemoryRetentionMaintenanceLeaseService(db).release(lease)
        db.close()
        engine.dispose()


def test_alerts_degraded_and_latest_errors_are_reported():
    client, db, engine = _client()
    try:
        _seed(db, status="completed_with_errors")
        payload = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true", "stale_after_seconds": 86_400},
        ).json()
        assert payload["severity"] == "warning"
        codes = {a["code"] for a in payload["alerts"]}
        assert "recent_execution_errors" in codes
        assert "latest_run_completed_with_errors" in codes
    finally:
        db.close()
        engine.dispose()


def test_alerts_stale_latest_run_is_warning():
    client, db, engine = _client()
    try:
        _seed(db, completed_at=datetime(2026, 9, 18, 0, 0))
        payload = client.get(
            "/api/memory/maintenance/alerts",
            params={
                "assume_enabled": "true",
                "stale_after_seconds": 3_600,
            },
        ).json()
        assert payload["severity"] == "warning"
        assert any(a["code"] == "stale_last_run" for a in payload["alerts"])
    finally:
        db.close()
        engine.dispose()


def test_alerts_invalid_stale_threshold_is_rejected():
    client, db, engine = _client()
    try:
        response = client.get(
            "/api/memory/maintenance/alerts",
            params={"stale_after_seconds": 30},
        )
        assert response.status_code == 422
    finally:
        db.close()
        engine.dispose()
