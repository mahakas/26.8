import pytest

from backend_v2.database.connection import create_all
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.agents.teaching_strategy import AdaptiveTeachingStrategyPlanner, TeachingMode
from backend_v2.memory.service import MemoryService


def test_negative_feedback_is_persisted_and_requests_support():
    service = TeacherFeedbackService(MemoryService())
    item = service.record(
        user_id="u25-5",
        conversation_id="c25-5",
        feedback_id="f1",
        rating=2,
        understood=False,
        strategy_effective=False,
    )
    assert item.signal == "needs_support"
    summary = service.summary("u25-5", conversation_id="c25-5")
    assert summary.latest_signal == "needs_support"
    assert summary.needs_support == 1


def test_feedback_is_idempotent_for_same_id():
    service = TeacherFeedbackService(MemoryService())
    first = service.record(user_id="u-idempotent-25-5", conversation_id="c-idempotent-25-5", feedback_id="f-idempotent-25-5", rating=1)
    second = service.record(user_id="u-idempotent-25-5", conversation_id="c-idempotent-25-5", feedback_id="f-idempotent-25-5", rating=5)
    assert second == first


def test_positive_feedback_can_advance_auto_strategy():
    service = TeacherFeedbackService(MemoryService())
    service.record(user_id="u-progressing-25-5", conversation_id="c-progressing-25-5", feedback_id="f-progressing-25-5", rating=5, understood=True, strategy_effective=True)
    summary = service.summary("u-progressing-25-5", conversation_id="c-progressing-25-5")
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.AUTO,
        query="این مفهوم را توضیح بده",
        student_progress=type("P", (), {"as_prompt_data": lambda self: {"average_confidence": 0.9}})(),
        feedback_summary=summary,
    )
    assert strategy.mode is TeachingMode.PRACTICE


def test_negative_feedback_overrides_auto_to_remediation():
    service = TeacherFeedbackService(MemoryService())
    service.record(user_id="u-negative-25-5", conversation_id="c-negative-25-5", feedback_id="f-negative-25-5", rating=1, understood=False)
    summary = service.summary("u-negative-25-5", conversation_id="c-negative-25-5")
    strategy = AdaptiveTeachingStrategyPlanner().plan(
        requested_mode=TeachingMode.AUTO,
        query="توضیح بده",
        feedback_summary=summary,
    )
    assert strategy.mode is TeachingMode.REMEDIATION
    assert strategy.scaffolding == "high"


@pytest.fixture(scope="module", autouse=True)
def _phase25_5_database_schema():
    """Ensure the default MemoryService database schema exists for standalone tests."""
    create_all()

