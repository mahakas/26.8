from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import memory_snapshot_checksum
from backend_v2.memory.types import MemoryRecord, MemoryType


def _client():
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app), db, engine


def _record(record_id: str = "r1", value: object | None = None) -> MemoryRecord:
    return MemoryRecord(
        id=record_id,
        user_id="student-checksum",
        memory_type=MemoryType.PREVIOUS_QUESTION,
        memory_key="q1",
        value=value if value is not None else {"question": "What is x?"},
        confidence=0.9,
        source="test",
    )


def test_snapshot_checksum_is_stable_and_order_independent():
    first = _record("r1")
    second = _record("r2", {"question": "What is y?"})

    checksum_a = memory_snapshot_checksum("student-checksum", [first, second])
    checksum_b = memory_snapshot_checksum("student-checksum", [second, first])

    assert checksum_a == checksum_b
    assert len(checksum_a) == 64


def test_snapshot_checksum_changes_when_record_content_changes():
    original = memory_snapshot_checksum("student-checksum", [_record()])
    changed = memory_snapshot_checksum(
        "student-checksum",
        [_record(value={"question": "What is y?"})],
    )

    assert original != changed


def test_export_contains_checksum_and_import_accepts_verified_snapshot():
    client, db, engine = _client()
    try:
        user_id = "student-checksum-roundtrip"
        seed = {
            "format_version": "1.0",
            "user_id": user_id,
            "records": [
                {
                    "id": "legacy-1",
                    "user_id": user_id,
                    "memory_type": "student_profile",
                    "memory_key": "profile",
                    "value": {"grade": "10"},
                    "confidence": 1.0,
                    "source": "test",
                }
            ],
        }
        assert client.post(f"/api/memory/{user_id}/import", json=seed).status_code == 201
        exported = client.get(f"/api/memory/{user_id}/export")
        assert exported.status_code == 200
        snapshot = exported.json()
        assert len(snapshot["checksum"]) == 64

        client.delete(f"/api/memory/{user_id}/records")
        restored = client.post(f"/api/memory/{user_id}/import", json=snapshot)
        assert restored.status_code == 201
        assert restored.json()["checksum"] == snapshot["checksum"]
        assert restored.json()["imported_count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_tampered_snapshot_is_rejected_without_importing():
    client, db, engine = _client()
    try:
        user_id = "student-checksum-tamper"
        payload = {
            "format_version": "1.0",
            "user_id": user_id,
            "records": [
                {
                    "id": "legacy-1",
                    "user_id": user_id,
                    "memory_type": "previous_question",
                    "memory_key": "q-1",
                    "value": {"question": "x"},
                    "confidence": 0.9,
                    "source": "test",
                }
            ],
        }
        imported = client.post(f"/api/memory/{user_id}/import", json=payload)
        assert imported.status_code == 201
        snapshot = client.get(f"/api/memory/{user_id}/export").json()
        snapshot["records"][0]["value"] = {"question": "tampered"}

        response = client.post(f"/api/memory/{user_id}/import", json=snapshot)
        assert response.status_code == 422
        assert response.json()["detail"] == "Invalid memory snapshot checksum"
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
    finally:
        db.close()
        engine.dispose()


def test_legacy_snapshot_without_checksum_remains_supported():
    client, db, engine = _client()
    try:
        user_id = "student-checksum-legacy"
        payload = {
            "format_version": "1.0",
            "user_id": user_id,
            "records": [
                {
                    "id": "legacy-1",
                    "user_id": user_id,
                    "memory_type": "previous_question",
                    "memory_key": "q-1",
                    "value": {"question": "legacy"},
                    "confidence": 0.8,
                    "source": "legacy",
                }
            ],
        }
        response = client.post(f"/api/memory/{user_id}/import", json=payload)
        assert response.status_code == 201
        assert "checksum" not in response.json()
        assert response.json()["imported_count"] == 1
    finally:
        db.close()
        engine.dispose()
