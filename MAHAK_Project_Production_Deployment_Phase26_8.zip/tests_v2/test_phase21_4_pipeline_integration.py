from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class StubAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def execute(self, query: str, **kwargs) -> AgentResult:
        return AgentResult(
            answer="answer",
            evidence=[{"type": "general", "text": query}],
            citations=[{"title": "source"}],
            confidence=0.8,
        )


def test_pipeline_updates_weak_area_without_changing_agent_result():
    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        registry = AgentRegistry()
        registry.register(StubAgent())
        pipeline = UnifiedAgentPipeline(
            AgentRouter(registry),
            TeacherAgent(),
            memory=MemoryIntegrationService(memory),
        )
        context = ConversationContext(
            conversation_id="conv-21-4-pipeline",
            user_id="student-21-4-pipeline",
            mode=ChatMode.GENERAL,
            subject_id="math",
        )

        result = pipeline.execute(
            "سلام",
            conversation_context=context,
            evaluation_signals={
                "topic": "algebra",
                "mastery_score": 0.25,
                "correctness_score": 0.4,
                "needs_retry": True,
                "attempts": 2,
                "evaluator_confidence": 0.95,
            },
        )

        assert result.answer == "answer"
        assert result.evidence == [{"type": "general", "text": "سلام"}]
        assert result.citations == [{"title": "source"}]
        assert result.confidence == 0.8

        weak = memory.latest(
            context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
        )
        assert weak is not None
        assert weak.value["status"] == "active"
    finally:
        db.close()
        engine.dispose()
