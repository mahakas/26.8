# Phase 21.46 — Maintenance Alert Evaluation

Phase 21.46 adds a read-only alert evaluator over the existing maintenance health and operational status signals.

## Endpoint

`GET /api/memory/maintenance/alerts`

Query parameters:

- `assume_enabled`: evaluate readiness as explicitly enabled without enabling or executing maintenance.
- `stale_after_seconds`: threshold for an old latest persisted run. Range `60..31536000`, default `86400`.

## Alert codes

- `maintenance_disabled` — warning when maintenance is actually disabled.
- `maintenance_lease_held` — critical when the maintenance lease is held by another owner.
- `recent_execution_errors` — warning when health reports degraded execution history.
- `latest_run_completed_with_errors` — warning when the latest persisted run has errors.
- `no_persisted_run` — warning when maintenance is evaluated as enabled but no run exists yet.
- `stale_last_run` — warning when the latest persisted run exceeds the configured stale threshold.

## Contract

The endpoint is strictly read-only. It does not acquire, renew, or release a lease, and it does not mutate Memory, Policy, Audit, or Maintenance Run History.

No notifier, email, webhook, or background scheduler is introduced in this phase.
