# Phase 21.4 — Automatic Weak-area Detection

## Purpose

Convert evaluation signals into conservative `weak_area` memory updates without changing the `AgentResult` contract.

## Evaluation Signals

- `topic`
- `mastery_score`
- `correctness_score`
- `needs_retry`
- `attempts`
- `evaluator_confidence`

## Controlled Update Rules

1. Empty/invalid topics are rejected.
2. Weak-area writes require a conservative confidence threshold.
3. Equal repeated signals are deduplicated.
4. Strong mastery/correctness can mark an existing weak area as `resolved`.
5. Memory updates never modify evidence, citations, or confidence inside `AgentResult`.

## Pipeline

`AgentResult` remains the canonical answer object. Evaluation signals are optional pipeline input:

`Query -> Agent -> TeacherAgent -> AgentResult -> Evaluation -> WeakAreaMemoryUpdater`

## Smoke Test

```powershell
$env:PYTHONPATH="."
$env:PHASE21_4_LIVE="1"
python scripts/smoke_memory_phase21_4.py
```
