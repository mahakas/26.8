# MAHAK — Phase 21.45

## Unified Maintenance Health Assessment

Adds a read-only health assessment composed from existing Maintenance readiness, lease, policy, summary, and latest-run signals.

### Endpoint

`GET /api/memory/maintenance/health`

Optional query:

- `assume_enabled=true|false` — evaluates health as if explicit maintenance execution were enabled. It does not enable execution and performs no mutation.

### Health states

- `disabled` — maintenance execution is not enabled.
- `healthy` — explicit execution is enabled for evaluation, the lease is available/reclaimable, and no recorded execution errors were detected.
- `degraded` — recent maintenance history contains execution errors.
- `blocked` — the persistent maintenance lease is currently held by another owner.

### Response highlights

- `health`
- `enabled`
- `ready`
- named health checks with `ok`, `degraded`, `blocked`, `disabled`, or `unknown` status
- read-only reasons

The response does not expose user IDs, Memory values, memory keys, questions, profiles, or other user content.

### Compatibility

This phase is additive and read-only. Existing Retention, Scheduler, Lease, Maintenance, Persistence, History API, Summary API, Operational Status, Readiness, Execution Gate, and Unified Maintenance contracts remain unchanged.
