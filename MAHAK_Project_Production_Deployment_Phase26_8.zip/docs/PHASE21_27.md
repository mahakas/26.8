# Phase 21.27 — Retention Scheduler Run Report

Adds a backward-compatible aggregate report through `MemoryRetentionSchedulerService.run_with_report()`.

The existing `run_once()` contract is unchanged.

## Report fields

- `run_id`
- `status`: `disabled`, `completed`, or `completed_with_errors`
- `started_at`, `completed_at`
- `dry_run`
- user counts by result status
- aggregate candidate / would-delete / deleted counts
- original per-user `RetentionSchedulerResult` rows

This phase does not persist scheduler runs to the database and does not start background execution. It is designed as an orchestration-friendly foundation for later scheduling/monitoring work.
