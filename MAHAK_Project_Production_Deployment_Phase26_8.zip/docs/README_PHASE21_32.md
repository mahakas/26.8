# Phase 21.32 — Retention Run History Policy

## Goal
Add a persistent, configuration-only policy for scheduler run-history retention without changing or executing the existing cleanup service.

## Service
`backend_v2.memory.retention_run_history_policy.MemoryRetentionRunHistoryPolicyService`

Methods:
- `get()` — returns configured policy or safe defaults.
- `set(retention_days, max_delete)` — persists the singleton policy.
- `reset()` — removes the explicit policy and restores effective defaults.

## Defaults and bounds
- `retention_days = 365`
- `max_delete = 500`
- `retention_days` accepted range: `1..36500`
- `max_delete` accepted range: `1..500`

## Safety
- The policy is global for scheduler run history, not user-scoped.
- This phase does **not** execute cleanup.
- `MemoryRetentionRunHistoryService` behavior from Phase 21.31 is unchanged.
- No public mutation endpoint is added; authentication/permissions remain a later production concern (Phase 24).
- An injected SQLAlchemy Session retains caller-owned commit/rollback semantics.

## Persistence
Table: `memory_retention_run_history_policies`

The table is a singleton configuration row identified by `policy_id='default'`.

## Validation
- Dedicated tests: `tests_v2/test_phase21_32_memory_retention_run_history_policy.py`
- Smoke: `scripts/smoke_memory_retention_run_history_policy_phase21_32.py`
