# Phase 21.40 — Memory Retention Maintenance Execution Gate

## Purpose

Phase 21.40 adds a readiness gate in front of the already-existing persistent maintenance execution path.

## New components

- `MemoryRetentionMaintenanceExecutionGate`
- `MemoryRetentionMaintenanceGateDecision`
- `MemoryRetentionMaintenanceNotReadyError`

## Behavior

1. The gate performs a read-only readiness snapshot.
2. Disabled maintenance keeps the existing disabled contract.
3. A held persistent lease blocks execution before any mutation.
4. An expired lease remains reclaimable and is allowed to proceed through the existing persistent guard.
5. Once readiness passes, execution delegates to `MemoryRetentionMaintenanceService.run_with_persistent_guard()`.
6. A readiness/execution race that loses the persistent lease is reported as a readiness failure; no second mutation path is introduced.

## Compatibility

Existing maintenance methods, lease APIs, readiness APIs, retention policies, run-history retention, and prior tests are unchanged.
