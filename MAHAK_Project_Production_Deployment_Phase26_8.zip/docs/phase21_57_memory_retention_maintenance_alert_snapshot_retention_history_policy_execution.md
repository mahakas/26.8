# Phase 21.57 — Snapshot Retention Execution History Policy Execution

## Goal
Execute the persisted Phase 21.56 retention policy against the content-free snapshot-retention execution-history rows managed by Phase 21.55.

## Service
`backend_v2.memory.retention_maintenance_alert_snapshot_retention_history.MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService`

New methods:
- `preview_policy()` — read-only execution preview using the effective persisted policy or safe defaults.
- `apply_policy()` — executes the effective policy and deletes only eligible execution-history rows.

New result models:
- `MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyPreview`
- `MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyApplyResult`

## Behavior
- Effective defaults are `retention_days=365`, `max_delete=500` when no policy is configured.
- A configured Phase 21.56 policy is used without mutation.
- Cutoff is `now - retention_days`.
- Candidates are ordered oldest-first by `completed_at`, then `run_id`.
- Deletion is bounded by the policy's `max_delete`.
- Only `memory_retention_maintenance_alert_snapshot_retention_runs` is affected.
- No alert snapshots, policy rows, or unrelated maintenance history are deleted.
- `preview_policy()` never mutates data.
- With an injected SQLAlchemy Session, the caller owns commit/rollback semantics.
- Standalone service sessions commit successful deletes.

## Scope
No scheduler, automatic execution, or public mutation endpoint is introduced. Production authentication/permissions remain part of Phase 24.

## Validation
- Dedicated tests: `tests_v2/test_phase21_57_memory_retention_maintenance_alert_snapshot_retention_history_policy_execution.py`
- Smoke: `scripts/smoke_memory_retention_maintenance_alert_snapshot_retention_history_policy_execution_phase21_57.py`
- Baseline: Phase 21.56

### Test stability

Phase 21.57 also removes time-of-day flakiness from legacy maintenance status/health/alert lease tests by deriving their held-lease timestamps from the test's current UTC time. Production maintenance logic is unchanged.
