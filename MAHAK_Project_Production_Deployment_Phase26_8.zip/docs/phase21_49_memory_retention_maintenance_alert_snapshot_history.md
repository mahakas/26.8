# Phase 21.49 — Maintenance Alert Snapshot History API

Phase 21.49 adds a read-only cursor-paginated API for persisted, content-free maintenance alert snapshots.

## Endpoint

`GET /api/memory/maintenance/alert-snapshots`

Supported filters:

- `limit=1..500`
- `cursor`
- `health=healthy|degraded|blocked`
- `severity=none|warning|critical`
- `ready=true|false`
- `assume_enabled=true|false`
- `use_policy=true|false`
- `start_at` inclusive
- `end_at` exclusive

The response exposes only snapshot metadata and alert codes. It does not return alert messages, user IDs, memory keys, memory values, questions, or profiles.

The endpoint is strictly read-only and never creates or mutates alert snapshots.

## Transaction compatibility fix

Phase 21.49 also hardens the existing injected-session contract for alert snapshot capture: lease status reads reuse the caller's injected SQLAlchemy session instead of opening and closing a second session on the same bind. This prevents an unintended rollback of the caller's transaction when multiple snapshots are captured in one transaction.
