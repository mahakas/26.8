# Phase 21.3 — Memory-aware Agent and Teacher Personalization

## Goal

Use the loaded Phase 21 memory context to derive safe educational personalization hints while preserving the existing `AgentResult` contract.

## Behavior

`UnifiedAgentPipeline` derives a `PersonalizationContext` from loaded memories and passes it to both the specialist agent and `TeacherAgent`.

The personalization layer can derive:

- weak areas
- preferred explanation style
- learning level
- recent learning topics

Memory remains contextual guidance only. It is not treated as evidence or a source of truth.

## Compatibility

- `AgentResult` is unchanged.
- Existing evidence, citations, and confidence are preserved.
- Calls without a conversation or memory context continue to work.
- Specialist retrieval is not rewritten by this phase.

## Validation

- focused personalization tests
- smoke test
- full `tests_v2` suite
- compile check
