# Phase 21.53 — Maintenance Alert Snapshot Retention Execution History

Adds content-free persistence and a read-only history API for explicit maintenance alert snapshot retention executions.

## Execution record

Each successful `apply()` or `apply_policy()` execution creates one history row containing:

- `run_id`
- `started_at` / `completed_at`
- exact `older_than` cutoff
- `candidate_count`
- `deleted_count`
- effective `retention_days` and `max_delete`
- whether the policy was configured
- whether a Phase 21.52 preview token bound the execution

The preview token itself and snapshot content are never persisted.

## API

`GET /api/memory/maintenance/alert-snapshots/retention/runs`

Supported query parameters:

- `limit` (1..500)
- `cursor`
- `configured`
- `preview_bound`
- `start_at`
- `end_at`

The endpoint is read-only, cursor-paginated, and content-free.

No automatic cleanup, scheduler, alert notification, or authentication policy is introduced.
