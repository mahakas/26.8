# MAHAK — Phase 21.44

## Unified Maintenance Operational Status API

Adds a read-only operational snapshot composed from existing Maintenance contracts.

### Endpoint

`GET /api/memory/maintenance/status`

Optional query:

- `assume_enabled=true|false` — evaluates readiness as if explicit maintenance execution were enabled. It does not enable execution and performs no mutation.

### Response highlights

- readiness state and reasons
- persistent lease status
- configured per-user memory policy count
- effective run-history policy
- persisted unified maintenance summary
- latest persisted unified maintenance run metadata

No user IDs, Memory values, memory keys, questions, profiles, or other user content are returned.

### Compatibility

This phase is additive and read-only. Existing Retention, Scheduler, Lease, Maintenance, Persistence, History List, and History Summary contracts remain unchanged.
