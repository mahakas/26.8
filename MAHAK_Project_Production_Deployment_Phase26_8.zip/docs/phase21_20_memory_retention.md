# Phase 21.20 — Memory Retention Policy & Cleanup

## هدف

مدیریت صریح چرخهٔ نگهداری Memory بدون اجرای خودکار در مسیر Chat/Agent.

## API

### Preview

`POST /api/memory/{user_id}/retention/preview`

پارامترها:

- `older_than`: مرز زمانی به‌صورت ISO-8601؛ رکوردهای قدیمی‌تر از این زمان کاندید هستند.
- `memory_type`: اختیاری.
- `max_delete`: سقف عملیات، بین 1 و 500.

این endpoint کاملاً read-only است و هیچ Memory یا Audit Event ایجاد نمی‌کند.

### Apply

`POST /api/memory/{user_id}/retention/apply`

همان پارامترهای Preview را می‌پذیرد و حداکثر `max_delete` رکورد قدیمی‌تر را حذف می‌کند. رکوردها از قدیمی‌ترین به جدیدترین انتخاب می‌شوند.

پس از حذف موفق، یک Audit Event با action=`retention` ثبت می‌شود. اگر هیچ رکوردی حذف نشود، Audit Event ساخته نمی‌شود.

## قواعد ایمنی

- `older_than` نمی‌تواند در آینده باشد.
- `max_delete` فقط 1 تا 500 است.
- Scope همیشه محدود به `user_id` درخواست است.
- `memory_type` در صورت وجود، فیلتر دقیقی است.
- Preview هیچ mutation ندارد.
- Retention به‌صورت خودکار داخل Chat یا Agent Pipeline اجرا نمی‌شود.
- حذف و Audit در همان transaction انجام می‌شوند و commit فقط پس از موفقیت کامل رخ می‌دهد.

## Audit

`MemoryAuditRepository.VALID_ACTIONS` اکنون شامل `retention` است؛ بنابراین endpointهای audit و summary می‌توانند عملیات retention را نیز گزارش کنند، بدون اینکه محتوای Memory را ذخیره کنند.

## تست و Smoke

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_20_memory_retention.py -q

$env:PHASE21_20_LIVE="1"
python scripts/smoke_memory_retention_phase21_20.py

pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
