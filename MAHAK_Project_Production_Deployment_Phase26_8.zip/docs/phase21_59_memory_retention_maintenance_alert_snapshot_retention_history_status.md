# Phase 21.59 — Snapshot Retention Execution History Operational Status

## Goal

Add a read-only operational status surface for the content-free execution-history retention branch introduced in Phases 21.53–21.58.

## Status endpoint

```text
GET /api/memory/maintenance/alert-snapshots/retention/status
```

The endpoint reports:

- effective `retention_days`
- effective `max_delete`
- whether the policy is explicitly configured
- the current retention cutoff (`older_than`)
- current execution-history candidate count
- current `would_delete_count` after the policy delete cap
- whether automatic execution is enabled
- execution mode
- latest execution timestamp and aggregate result counts
- whether the latest execution used preview binding
- `read_only=true`

## Safety

The status operation:

- does not create a preview token;
- does not delete execution-history rows;
- does not mutate the retention policy;
- does not expose run IDs or candidate IDs;
- does not enable scheduling or automatic cleanup.

Automatic execution remains disabled and the branch remains `explicit_only`.

## Validation

Focused tests:

```text
pytest tests_v2/test_phase21_59_memory_retention_maintenance_alert_snapshot_retention_history_status.py -q
```

Smoke:

```powershell
$env:PYTHONPATH="."
$env:PHASE21_59_LIVE="1"
python scripts/smoke_memory_retention_maintenance_alert_snapshot_retention_history_status_phase21_59.py
```

Full regression:

```text
pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
