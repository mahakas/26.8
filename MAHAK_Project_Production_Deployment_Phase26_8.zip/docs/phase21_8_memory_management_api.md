# Phase 21.8 — Memory Management API

## Purpose

Expose explicit, user-scoped memory lifecycle controls through FastAPI while reusing the existing `MemoryService` lifecycle methods from Phase 21.6.

## Endpoints

- `DELETE /api/memory/{user_id}/records/{memory_id}`
  - Deletes exactly one memory record when it belongs to the requested user.
  - Returns `404` for both missing and cross-user records so ownership is not disclosed.
- `DELETE /api/memory/{user_id}/records`
  - Clears user-owned records.
  - Optional `memory_type` and `conversation_id` filters.
- `POST /api/memory/{user_id}/prune`
  - Keeps the newest `max_records` for the user.
  - Optional `memory_type` filter.
  - `max_records` is bounded to 1–500.

## Contract rules

- Management actions are explicit; nothing is automatically deleted during chat execution.
- All mutation calls are scoped by `user_id` through the existing service methods.
- Cross-user single-record deletion returns `404` instead of exposing ownership information.
- Existing read API, progress aggregation, personalization, weak-area detection, and unified agent execution remain unchanged.
- Authentication/authorization identity binding is still a later production concern; current endpoints use explicit `user_id` scope.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_8_memory_management_api.py -q

$env:PHASE21_8_LIVE="1"
python scripts/smoke_memory_management_phase21_8.py

pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
