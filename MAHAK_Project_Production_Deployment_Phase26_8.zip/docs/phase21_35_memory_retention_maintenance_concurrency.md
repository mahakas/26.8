# Phase 21.35 — Memory Retention Maintenance Concurrency Guard

## Scope

Phase 21.35 adds an explicit in-process concurrency guard to
`MemoryRetentionMaintenanceService`.

## Behavior

- Existing single-run behavior is unchanged.
- `enabled=False` remains non-mutating and does not participate in locking.
- If a second maintenance run is requested while another run is executing in
  the same Python process, `MemoryRetentionMaintenanceBusyError` is raised.
- The rejected run performs no database mutation.
- The guard is released in `finally`, including failure paths.
- This is an in-process guard only; distributed locking is intentionally left
  for a deployment-specific production phase.

## Compatibility

Existing retention, scheduler, run-history, and maintenance contracts remain
unchanged for non-overlapping execution.
