# Phase 21.48 — Maintenance Alert Snapshot Persistence

Phase 21.48 adds explicit persistence for one content-free maintenance alert evaluation.

## Scope

`MemoryRetentionMaintenanceAlertSnapshotService.capture()` evaluates the existing alert service and stores only operational metadata:

- capture time
- health / readiness / severity
- effective stale threshold
- alert count and alert codes
- assume-enabled / policy usage flags

No user ID, memory key, memory value, question, profile, or alert message is persisted.

The existing `/api/memory/maintenance/alerts` endpoint remains read-only and unchanged. Phase 21.48 does not add notification, acknowledgement, or alert-history APIs.

## Transaction behavior

With an injected SQLAlchemy session, `capture()` flushes but does not commit; transaction ownership remains with the caller. With an internally-created session, the service commits its own snapshot.
