# Phase 21.11 — Idempotent Memory Import

Phase 21.11 makes the Phase 21.10 memory restore endpoint idempotent for exact content duplicates.

## Behavior

- `POST /api/memory/{user_id}/import` still accepts the Phase 21 snapshot format (`format_version: "1.0"`).
- A stable content fingerprint is computed from user scope, memory type/key, value, confidence, source, and learning context fields.
- Historical database IDs are excluded from the fingerprint.
- Exact duplicates already stored for the user are skipped instead of creating another row.
- Duplicate records inside the same import batch are also skipped after the first copy is accepted.
- A changed value or other fingerprinted field is treated as a new memory.
- Import remains append-only: no existing memory is overwritten or deleted.
- The response now reports both `imported_count` and `skipped_count`.

## Response example

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "imported_count": 0,
  "skipped_count": 2
}
```

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_11_memory_idempotent_import.py tests_v2/test_phase21_10_memory_import.py -q

$env:PHASE21_11_LIVE="1"
python scripts/smoke_memory_idempotent_import_phase21_11.py

pytest tests_v2 -q

python -m compileall -q backend_v2 scripts
```
