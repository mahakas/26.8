# Phase 21.51 — Maintenance Alert Snapshot Retention

Adds a system-level retention policy and explicit preview/apply service for content-free maintenance alert snapshots.

- Defaults: 30 days, max 500 deletes.
- Policy is persistent and singleton-scoped.
- `preview_policy()` is read-only.
- `apply_policy()` deletes only expired snapshot rows and never touches alert evaluation, policies, leases, maintenance runs, or Memory content.
- Existing `capture()` and `capture_if_changed()` contracts are unchanged.
- No automatic scheduler or background cleanup is introduced.
