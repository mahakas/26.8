# Phase 21.42 — Unified Maintenance Run History Read API

Adds a read-only API for persisted unified maintenance runs created by Phase 21.41.

Endpoint:
- `GET /api/memory/maintenance/runs`

Filters:
- `limit=1..500`
- `cursor=<opaque cursor>`
- `status=completed|completed_with_errors`
- `dry_run=true|false`
- `cleanup_history=true|false`
- `start_at` inclusive
- `end_at` exclusive

The response exposes only maintenance metadata. It does not expose user IDs, Memory values, memory keys, questions, profile data, or other content.

This phase is read-only and does not change any Retention, Lease, Maintenance, or Scheduler contract. Authentication/authorization remains a later production concern in Phase 24.
