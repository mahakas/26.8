# Phase 21.21 — Memory Retention Policy Management

Phase 21.21 adds persistent, user-scoped retention policy configuration without enabling automatic cleanup.

## API

- `GET /api/memory/{user_id}/retention/policy`
- `PUT /api/memory/{user_id}/retention/policy`
- `DELETE /api/memory/{user_id}/retention/policy`

## Policy fields

- `retention_days`: 1–36500
- `max_delete`: 1–500
- `memory_type`: optional memory type filter

The GET endpoint returns safe defaults (`365` days, `500` max-delete, no memory-type filter) when no policy is configured and reports `configured=false`.

The DELETE endpoint resets the user to those effective defaults. It is idempotent.

## Safety and compatibility

- Policy is configuration only; no automatic retention job is started.
- Existing Phase 21.20 preview/apply endpoints keep their explicit `older_than` and `max_delete` behavior.
- Policies are isolated by `user_id`.
- No Memory content is exposed by the policy endpoints.
- Existing Memory Agent/Pipeline, retrieval, citation, and `AgentResult` contracts are unchanged.
