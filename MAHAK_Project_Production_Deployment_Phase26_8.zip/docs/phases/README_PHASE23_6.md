# MAHAK Phase 23.6 — Agent & Multimodal Evaluation

Phase 23.6 adds deterministic evaluation for the existing AgentResult contract and multimodal agent outputs.

## Scope

Evaluates:

- Agent selection accuracy when an expected agent type is supplied.
- Non-empty answer and confidence validity.
- Evidence and citation presence.
- Modality evidence coverage for Document, Vision, Video, General, and mixed Teacher agents.
- Citation-to-evidence source alignment.
- Modality-specific locator completeness:
  - Document: source or page.
  - Image: image id/path/reference.
  - Video: timestamp/frame locator.
  - General: URL or source.
  - Teacher: mixed evidence is accepted.
- Structural contract compliance.

This evaluator is deterministic and contract-based. It does not judge semantic answer correctness; semantic answer quality remains covered by the previous evaluation phases.

## API

- `POST /api/evaluation/agents`
- `POST /api/evaluation/agents/batch`

## Validation

- Baseline before Phase 23.6: `511 passed, 3 skipped`
- Dedicated tests: `10 passed`
- Final regression: `521 passed, 3 skipped`
- Smoke: `scripts/smoke_education_evaluation_agents_phase23_6.py`
- Compile: `python -m compileall -q backend_v2 scripts`
