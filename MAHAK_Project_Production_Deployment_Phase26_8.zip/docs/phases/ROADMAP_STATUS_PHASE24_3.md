# Roadmap Status — Phase 24.3

## Completed

- Authorization/RBAC foundation.
- Role and permission registry.
- Route-level FastAPI authorization dependencies.
- Admin user listing and role management.
- Persistent User role with additive compatibility migration.
- Operator CLI for role assignment.
- Regression tests and smoke coverage.

## Next

Phase 24.4 — Security Hardening.
