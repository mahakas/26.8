# Phase 18 — Video Intelligence

Video ingestion now produces timestamp-aware retrieval artifacts from:

- transcript sidecars (`.srt`, `.vtt`, `.txt`) or optional `faster-whisper`
- sampled video frames through `ffmpeg`
- Vision Provider analysis of sampled frames
- BGE-M3 embeddings and Chroma indexing through the existing architecture

Metadata retains `video_id`, `start_time_seconds`, `end_time_seconds`, `kind`, and vision model/provider fields for source-aware citations.

For local transcription without a sidecar, install `faster-whisper` separately and configure the processor with `FasterWhisperTranscriber`. The core requirements do not force-download a Whisper model.

Live smoke test:

```powershell
$env:PHASE18_LIVE="1"
python scripts/live_video_smoke_phase18.py
```

The smoke test generates a short local MP4, attaches an SRT transcript, samples frames with ffmpeg, analyzes frames through a live Vision provider, indexes with BGE-M3 + Chroma, and retrieves timestamped video chunks.

## Phase 18A — Real MP4 + sidecar transcript, no ffmpeg

Use a real MP4 and an `.srt`, `.vtt`, or `.txt` transcript with matching stem. No frame extraction or ffmpeg is required.

```powershell
$env:PHASE18A_LIVE="1"
python scripts/live_video_smoke_phase18a.py --video "D:\path\lesson.mp4" --transcript "D:\path\transcription.srt"
```

This indexes transcript-only chunks with `start_time_seconds` / `end_time_seconds` and retrieves timestamp-aware results through BGE-M3 + Chroma.
