# MAHAK Phase 23.4 — Citation & Evidence Evaluation

Phase 23.4 adds deterministic citation-reference validation and lexical evidence-support evaluation on top of the existing Phase 23.1–23.3 evaluation stack.

## New API

- `POST /api/evaluation/citations`
- `POST /api/evaluation/citations/batch`

## Citation metrics

- citation correctness: matched actual references / actual references
- citation completeness: matched expected references / expected references
- citation F1
- source precision / recall
- locator accuracy for expected page, video timestamps and frame references

Video timestamps use a configurable tolerance in seconds (default `0.5`).

## Evidence metrics

`evidence_coverage` measures lexical coverage of answer sentences by the supplied evidence items. A sentence is counted as supported when the best evidence item covers at least the configured token threshold (default `0.5`). This is a deterministic heuristic and is not semantic fact-checking.

## Determinism and compatibility

The phase adds independent evaluation endpoints and does not change the behavior of the Phase 23.1–23.3 APIs. The citation evaluator also supports empty actual-citation sets as a valid, explicitly measurable outcome.

## Final validation

- Full regression: `501 passed, 3 skipped`
- Phase-specific tests: `10 passed`
- Smoke: `scripts/smoke_education_evaluation_citations_phase23_4.py` — OK
- Compile: `python -m compileall -q backend_v2 scripts` — OK
