# Phase 21.16 — Atomic Memory Restore

Phase 21.16 makes memory restore atomic at the service boundary.

## Behavior
- Imported batches run inside a SQLAlchemy savepoint.
- A persistence failure after one or more successful inserts rolls back the entire batch.
- The caller still owns the outer transaction when a database session is injected.
- Existing conflict policies from Phase 21.13 remain unchanged.
- Preview, checksum, and preview-token behavior remain unchanged.

## Validation
- Focused tests cover mid-batch failure rollback, successful restore, and reject policy atomicity.
- Smoke test simulates a persistence failure on the second record and verifies zero records remain.
