# MAHAK Phase 24.1 — Production Configuration & Secrets

Phase 24.1 hardens the runtime configuration layer without changing the existing development/test defaults.

## Scope

- Typed environment parsing for booleans, integers, floats, and CSV lists.
- Explicit `APP_ENV` values: `development`, `staging`, `production`.
- Production startup validation for debug mode, secret key strength, and allowed hosts.
- Diagnostics-safe configuration export via `AppSettings.safe_dict()` with no secret value exposure.
- New operational settings: `MAHAK_SECRET_KEY`, `LOG_LEVEL`, `ALLOWED_HOSTS`, `CORS_ORIGINS`, `TRUST_PROXY_HEADERS`.
- No database migration and no API behavior changes.

## Production variables

```env
APP_ENV=production
APP_DEBUG=false
MAHAK_SECRET_KEY=<at-least-32-character-secret>
LOG_LEVEL=INFO
ALLOWED_HOSTS=api.example.com
CORS_ORIGINS=https://app.example.com
TRUST_PROXY_HEADERS=false
```

`MAHAK_SECRET_KEY` is never included in `repr()` or `safe_dict()`.

## Validation

- Baseline before Phase 24.1: `529 passed, 3 skipped`
- Dedicated tests: `6 passed`
- Final regression: `535 passed, 3 skipped`
- Smoke: `scripts/smoke_production_configuration_phase24_1.py`
- Compile: `python -m compileall -q backend_v2 scripts`
