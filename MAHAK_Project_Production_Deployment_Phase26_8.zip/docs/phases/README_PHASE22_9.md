# MAHAK Phase 22.9 — Recommendation Feedback History & Persistent Loop

Phase 22.9 makes the Phase 22.8 recommendation feedback loop persistent and idempotent without introducing a new database migration.

## Delivered

- `EducationalRecommendationFeedbackHistoryService`
- persistent feedback events stored in existing `MemoryType.LEARNING_HISTORY`
- deterministic `feedback_id` idempotency
- cross-learning-plan collision protection for reused `feedback_id`
- plan-scoped and user-wide feedback history summaries
- `POST /api/education/recommendations/feedback/history`
- `GET /api/education/recommendations/feedback/history`
- unit/integration tests
- dedicated Smoke test

## API

Record feedback:

`POST /api/education/recommendations/feedback/history`

Required fields:

- `user_id`
- `learning_plan_id`
- `feedback_id`
- `task_type`
- `question_count`

Read history:

`GET /api/education/recommendations/feedback/history?user_id=...`

Optional filters:

- `learning_plan_id`
- `limit` (1..200)

Repeated POSTs with the same `feedback_id` for the same learning plan return the persisted event with `replayed=true` and do not create another record.

## Tests

Specific test file:

`tests_v2/test_phase22_9_feedback_history.py`

Smoke script:

`scripts/smoke_education_recommendation_feedback_history_phase22_9.py`

Smoke command:

```powershell
$env:PHASE22_9_LIVE="1"
python scripts/smoke_education_recommendation_feedback_history_phase22_9.py
```

Compile command:

```powershell
python -m compileall -q backend_v2 scripts
```

## Validation

- Full regression: `460 passed, 3 skipped`
- Phase-specific tests: `5 passed`
- Smoke: `learning recommendation feedback history: OK`
- Compile: `python -m compileall -q backend_v2 scripts` completed successfully.
