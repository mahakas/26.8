# MAHAK Phase 22.5 — Learning Path & Multi-Step Adaptive Session

## هدف
Phase 22.5 قابلیت‌های Phase 22.1 تا 22.4 را به یک learning session چندمرحله‌ای متصل می‌کند.

چرخه:

`Start Session → Generate/Deliver Task → Grade Attempt → Adapt Next Step → Repeat`

Session خودش نمره‌دهی یا mastery را دوباره محاسبه نمی‌کند؛ نتیجه معتبر Attempt از Phase 22.3 خوانده می‌شود و سپس Recommendation Phase 22.4 دوباره ارزیابی می‌شود.

## API

- `POST /api/education/sessions/start`
- `POST /api/education/sessions/{session_id}/advance`
- `GET /api/education/sessions/{session_id}?user_id=...`

## Persistence

وضعیت session در `MemoryType.LEARNING_HISTORY` با کلید `adaptive_session:{session_id}` ثبت می‌شود تا MemoryType جدید و migration دیتابیس لازم نباشد.

## Idempotency

ارسال دوباره همان `attempt_id` برای یک session، step جدید ایجاد نمی‌کند و `idempotent_replay=true` برمی‌گرداند.

## تست

```powershell
python -m pytest -q tests_v2
python -m pytest -q tests_v2/test_phase22_5_learning_path_session.py
$env:PHASE22_5_LIVE="1"
python scripts/smoke_education_learning_path_phase22_5.py
python -m compileall -q backend_v2 scripts
```

برای تست API واقعی:

```powershell
uvicorn backend_v2.api.app:app --reload
```

Swagger:

`http://127.0.0.1:8000/docs`
