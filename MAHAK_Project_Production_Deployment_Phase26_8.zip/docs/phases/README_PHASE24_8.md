# MAHAK Phase 24.8 — Production Readiness, Backup/Recovery & Operational Hardening

## Goal

Complete the Phase 24 Production Engineering line with repeatable backup/recovery operations, stronger readiness checks, safe restore behavior, graceful application lifecycle handling, and an operator runbook that does not assume a particular cloud provider.

## Backup architecture

`backend_v2.operations.backup.BackupService` creates a compressed `tar.gz` archive containing:

- a transaction-consistent SQLite database snapshot produced with SQLite's backup API;
- a snapshot of `storage_v2` including the persistent Chroma directory when Chroma is configured;
- a JSON manifest with format version, file count/size, and SHA-256 checksums.

Backups are written to `BACKUP_DIR` and automatically pruned to `BACKUP_RETENTION_COUNT` newest archives. The service rejects unsafe path layouts where the backup directory is the same as, or nested inside, runtime storage or the live SQLite database directory.

The SQLite database snapshot is transaction-consistent. The filesystem storage snapshot is a best-effort point-in-time copy; for strict multimodal storage consistency, schedule backups during a quiet window or use filesystem/volume snapshots supplied by the deployment platform.

## Verify and restore

PowerShell:

```powershell
python scripts/backup_restore_phase24_8.py backup --label nightly
python scripts/backup_restore_phase24_8.py list
python scripts/backup_restore_phase24_8.py verify .\backups_v2\mahak-backup-....tar.gz
```

Production restore must be performed with the API stopped:

```powershell
python scripts/backup_restore_phase24_8.py restore .\backups_v2\mahak-backup-....tar.gz --force
```

Restore creates a `pre-restore` safety backup by default. Use `--skip-pre-restore-backup` only when an operator has already secured an equivalent recovery point.

Archive extraction rejects path traversal and symbolic-link members. Checksum verification happens before data replacement.

## Operational readiness

`GET /api/health/ready` now checks:

- configuration;
- database connectivity;
- writable runtime storage;
- vector-store heartbeat when `VECTOR_STORE_BACKEND=chroma`.

A CLI gate can additionally enforce backup freshness:

```powershell
python scripts/ops_readiness_phase24_8.py --require-backup --max-backup-age-hours 24
```

A fresh installation can intentionally start without a backup; use `--require-backup` once the scheduled backup process is expected to be active.

## Graceful lifecycle

The FastAPI app now uses a lifespan hook to log startup/shutdown and dispose the SQLAlchemy engine cleanly during shutdown. Docker Compose maps `GRACEFUL_SHUTDOWN_SECONDS` to `stop_grace_period`.

## Docker persistence

The single `mahak_data` volume contains:

```text
/app/data/mahak_v2.db
/app/data/storage_v2
/app/data/backups_v2
```

Backups should still be copied off-host/off-volume on a schedule. A backup on the same volume is recovery material, not disaster recovery by itself.

## CI / automated gates

Phase 24.7's local/CI quality gate now also runs `scripts/smoke_production_readiness_phase24_8.py`. The full regression suite therefore covers the Phase 24.8 backup/restore tests automatically.

## Recovery runbook

1. Stop the MAHAK application and prevent new writes.
2. Identify the newest verified backup archive.
3. Run `verify` on the archive.
4. Run `restore --force`; keep the default pre-restore safety backup enabled.
5. Start MAHAK.
6. Check `/api/health/live` and `/api/health/ready`.
7. Check `/api/metrics` and application logs for errors.
8. Run the dedicated Phase 24.8 Smoke Test and a small application-level read/write verification.

Cloud-specific replication, off-site object storage, scheduled secrets rotation, and multi-region disaster recovery remain deployment-environment concerns and are deliberately not hard-coded into this phase.

## Validation

Final Phase 24.8 validation: `596 passed, 3 skipped`; Phase 24.8 dedicated tests: `8 passed`; compileall, CI quality-gate smoke, production-readiness smoke, backup verification, and restore rehearsal all passed. Docker image build could not be executed in the development environment because the Docker CLI is not installed; the Docker build remains a required GitHub Actions gate.
