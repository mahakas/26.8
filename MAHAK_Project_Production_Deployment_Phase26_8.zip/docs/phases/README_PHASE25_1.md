# MAHAK Phase 25.1 — Multimodal Teacher Orchestration & Unified Answer

Phase 25.1 شروع Phase 25 «Complete Multimodal AI Teacher» است.

## Delivered

- Multi-route agent classification for document, image and video questions.
- Explicit modality selection API support.
- Modality-aware retrieval filters using `source_type`.
- Unified specialist evidence/citation aggregation.
- Final educational pass through the existing `TeacherAgent`.
- New authenticated endpoint: `POST /api/teacher/ask`.
- Conversation ownership check for authenticated users.
- Reuse of existing memory integration and production RBAC (`chat:use`).

## API

`POST /api/teacher/ask`

The response contains the final answer, evidence, citations, confidence, selected agents, modalities and route trace.

## Safety / grounding

The TeacherAgent preserves specialist evidence and citations. Memory and student progress are used for educational personalization only and are not promoted to source-of-truth evidence.

## Validation

Dedicated tests: `tests_v2/test_phase25_1_multimodal_teacher.py`
Smoke: `scripts/smoke_multimodal_teacher_phase25_1.py`
