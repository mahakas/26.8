# Phase 21.41 — Unified Maintenance Run Persistence

Phase 21.41 persists the unified `MemoryRetentionMaintenanceService` report without storing memory content.

## Scope
- Adds `memory_retention_maintenance_runs`.
- Reuses the scheduler `run_id` as the unified maintenance identifier.
- Stores status, timing, dry-run flag, memory retention aggregates, and run-history cleanup aggregates.
- Disabled maintenance runs are not persisted.
- Injected SQLAlchemy sessions are not committed by the persistence layer.
- No `Memory.value`, `memory_key`, question text, profile data, or evidence is stored.

## Backward compatibility
Existing maintenance, scheduler, run-history, lease, readiness, and execution-gate contracts remain unchanged.
