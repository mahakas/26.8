# Phase 21.39 — Memory Retention Maintenance Readiness

Adds a read-only readiness snapshot for the explicit retention maintenance flow.

## Service

`MemoryRetentionMaintenanceReadinessService.snapshot()` reports:

- whether explicit maintenance can currently start;
- process execution mode (`explicit_only`);
- whether automatic execution is enabled (always false in this phase);
- current persistent lease state and remaining seconds;
- count of configured per-user memory retention policies;
- effective run-history retention policy;
- non-mutating readiness reasons.

## Safety

The readiness service never acquires, renews, releases, or reclaims a lease and never changes retention configuration or memory records.

A held lease makes readiness false. An expired lease is reported as reclaimable, so readiness remains true while the actual acquisition path remains responsible for reclaiming it.

No background scheduler or mutation endpoint is introduced.
