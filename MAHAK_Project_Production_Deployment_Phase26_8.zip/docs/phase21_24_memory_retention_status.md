# Phase 21.24 — Memory Retention Status / Health API

## Goal

Provide one read-only endpoint for operational visibility into Memory Retention
without introducing automatic cleanup.

## Endpoint

`GET /api/memory/{user_id}/retention/status`

## Response semantics

- `retention_days`, `max_delete`, `memory_type`, and `configured` come from the
  effective per-user policy.
- `older_than` is calculated from the current UTC time and the effective
  `retention_days`.
- `candidate_count` is the total number of user-owned memories eligible under
  the current cutoff/type filter.
- `would_delete_count` applies the configured safety cap.
- `last_execution_at`, `last_deleted_count`, and
  `last_execution_memory_type` come from the newest successful `retention`
  audit event for the same user.
- `automatic_execution_enabled` is always `false` in this phase.
- `execution_mode` is `explicit_only`.

The endpoint never mutates memory or audit state and does not expose Memory
`value` content.
