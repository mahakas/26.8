# Phase 19 - Video Answer Schema

## Purpose

Standard response contract for video based answers.

## Response fields

- answer
- evidence
- citations
- confidence
- provider
- model

## Evidence

Video evidence preserves:

- timestamp range
- transcript
- frame reference
- confidence

Example:

```json
{
  "type": "video",
  "timestamp": {
    "start": 54.5,
    "end": 57.3
  },
  "frame_path": "frames/frame_003.jpg"
}
```
