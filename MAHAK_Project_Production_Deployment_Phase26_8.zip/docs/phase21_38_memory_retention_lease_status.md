# Phase 21.38 — Persistent Maintenance Lease Status

Adds a read-only `status()` observer to `MemoryRetentionMaintenanceLeaseService`.

The status reports only:
- `available`, `held`, or `expired`
- `acquired_at`
- `expires_at`
- `remaining_seconds`

The owner token is never returned.

The observer does not acquire, renew, release, reclaim, or mutate the lease.
Existing acquire/renew/release/run contracts remain unchanged.
