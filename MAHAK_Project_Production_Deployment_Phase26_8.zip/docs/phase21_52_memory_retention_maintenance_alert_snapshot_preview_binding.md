# Phase 21.52 — Maintenance Alert Snapshot Retention Preview Binding

Phase 21.52 adds an explicit consistency token between maintenance alert snapshot retention preview and apply.

## API

- `GET /api/memory/maintenance/alert-snapshots/retention/policy`
- `PUT /api/memory/maintenance/alert-snapshots/retention/policy`
- `DELETE /api/memory/maintenance/alert-snapshots/retention/policy`
- `POST /api/memory/maintenance/alert-snapshots/retention/policy/preview`
- `POST /api/memory/maintenance/alert-snapshots/retention/policy/apply?preview_token=...`

## Preview binding

The preview token binds:

- effective `retention_days`
- effective `max_delete`
- whether the policy was explicitly configured
- exact preview cutoff
- full candidate count
- ordered candidate snapshot IDs within the configured delete cap

When `preview_token` is supplied to apply:

- malformed or unsupported tokens return `422` at the HTTP layer;
- changed policy or changed candidate state returns `409`;
- the exact preview cutoff is reused;
- no snapshot is deleted on binding failure.

Applying without a token remains backward compatible with Phase 21.51 and still uses the current effective policy.

The token is a consistency guard, not an authentication credential.

No scheduler or automatic cleanup was added.
