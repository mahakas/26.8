# Phase 20.6 — VideoAgent

## Purpose

Connect the Agent Router/Execution pipeline to the existing video retrieval stack and the Phase 19 `VideoAnswerResponse` schema.

## Architecture

```text
Question
   |
   v
AgentRouter
   |
   v
VideoAgent
   |
   v
RetrievalService
   |
   v
VectorHit + video metadata
   |
   +--> CitationRef
   +--> VideoEvidence
   |
   v
VideoAnswerResponse
```

## Design Rules

- `VideoAgent` does orchestration only.
- Existing `RetrievalService` remains responsible for embedding, vector search, reranking and thresholds.
- Existing `citation_from_hit()` remains the source-aware citation builder.
- Existing `VideoAnswerResponse` remains the canonical Phase 19 response schema.
- The Agent layer does not add a provider-specific dependency.
- The sample video is supplied externally to smoke tests and is not bundled with the project archive.

## Usage

```python
agent = VideoAgent(
    retrieval_service,
    collection="physics10_video_19",
    scope=RetrievalScope(grade_id="10", subject_id="physics"),
)
result = agent.execute("قانون دوم نیوتن در ویدیو چه زمانی توضیح داده شده؟")
response = agent.to_response(result)
```

For routing:

```python
registry.register(agent)
result = router.execute("در ویدیو قانون دوم نیوتن چه زمانی توضیح داده شده؟")
```

## Evidence

Each video evidence item preserves:

- `type="video"`
- `timestamp.start`
- `timestamp.end`
- `frame_path` when available
- frame timestamp when available
- retrieved video text
- confidence derived from the retrieval hit score

## Validation

Focused tests:

```bash
pytest tests_v2/test_video_agent.py tests_v2/test_video_agent_retrieval.py -q
```

Full tests:

```bash
pytest tests_v2 -q
```

Compile check:

```bash
python -m compileall -q backend_v2 scripts
```

Live smoke test:

```bash
set PHASE20_6_LIVE=1
python scripts/live_video_agent_smoke_phase20_6.py --video <video> --transcript <transcript>
```
