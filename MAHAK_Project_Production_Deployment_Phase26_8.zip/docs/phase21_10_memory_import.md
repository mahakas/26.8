# Phase 21.10 — Memory Import & Restore

Phase 21.10 complements the Phase 21.9 export snapshot with a controlled restore API.

## Endpoint

`POST /api/memory/{user_id}/import`

The request uses the Phase 21 memory snapshot format (`format_version: "1.0"`) and accepts up to 500 records.

## Safety and behavior

- The request `user_id` must match the path `user_id`.
- Every imported record must belong to the same user.
- Only format version `1.0` is accepted.
- Exported record IDs are treated as historical metadata and are **not** reused as database primary keys.
- Restore is append-only; existing memories are not overwritten or deleted.
- Progress is not imported as persisted memory because it is derived from the records.
- The import operation is committed as one API transaction after validation.

## Response

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "imported_count": 2
}
```

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_10_memory_import.py -q

$env:PHASE21_10_LIVE="1"
python scripts/smoke_memory_import_phase21_10.py

pytest tests_v2 -q

python -m compileall -q backend_v2 scripts
```
