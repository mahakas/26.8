# Phase 21.5 — Student Profile & Learning Progress Aggregation

## Purpose

Aggregate persisted Phase 21 memories into a compact, read-only student progress snapshot.

## Output

`StudentProgressProfile` contains:

- latest student profile fields
- active and resolved weak areas
- learning-history count
- previous-question count
- average learning-history confidence
- total citation count from recorded turns
- agent usage counts
- recent topics
- latest recorded question
- latest mastery estimates from weak-area records

## Pipeline integration

`UnifiedAgentPipeline` loads the aggregated profile when a `ConversationContext` has a `user_id` and exposes it to specialist agents and `TeacherAgent` through `student_progress`.

`AgentResult` is unchanged.

## Safety

The progress snapshot is derived memory, not source evidence. It is used for personalization and must not override retrieved evidence or citations.

## Smoke test

```powershell
$env:PYTHONPATH="."
$env:PHASE21_5_LIVE="1"
python scripts/smoke_memory_phase21_5.py
```

## Validation

Focused tests:

```powershell
pytest tests_v2/test_phase21_5_progress_aggregation.py tests_v2/test_phase21_5_pipeline_progress.py -q
```

Full suite:

```powershell
pytest tests_v2 -q
```

Compile:

```powershell
python -m compileall -q backend_v2 scripts
```
