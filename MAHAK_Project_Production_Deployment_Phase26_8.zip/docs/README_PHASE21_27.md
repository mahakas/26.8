# Phase 21.27 — Retention Scheduler Run Report

Adds `MemoryRetentionSchedulerService.run_with_report()` without changing `run_once()` compatibility.

The aggregate report includes a unique run id, lifecycle timestamps, status, dry-run flag, per-status user counts, candidate/delete totals, and the original per-user results.

Statuses:
- `disabled` when the scheduler guard is off.
- `completed` when all targeted users finish without failure.
- `completed_with_errors` when one or more targeted users fail while other users may still succeed.

The report is in-memory only; no database table or background scheduler is introduced in this phase.
