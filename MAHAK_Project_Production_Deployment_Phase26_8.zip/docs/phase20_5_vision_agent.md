# Phase 20.5 - VisionAgent

## Goal

Add the first real vision/image agent to the Phase 20 execution pipeline while
preserving the common `AgentResult` contract and the existing provider and
retrieval architecture.

## Behavior

`VisionAgent`:

- implements `BaseAgent`
- uses `AgentType.IMAGE`
- consumes existing retrieval hits through `hits`, `images`, or `documents`
- preserves `image_id` and image path metadata when available
- returns image evidence and image-aware citations through `AgentResult`
- does not call a vision provider directly; provider execution remains in the
  existing ingestion/provider layers

## Execution

```text
User query
   |
   v
AgentRouter
   |
   v
AgentRegistry
   |
   v
VisionAgent
   |
   v
AgentResult
```

## Compatibility

No existing API, retrieval, vector-store, or Phase 19 video response schema is
changed by this phase.
