# Phase 20.9 — Unified Agent Pipeline

## Purpose

Phase 20.9 provides one execution boundary for the completed Agent layer:

```text
Question
  -> AgentRouter
  -> Specialist Agent
  -> TeacherAgent
  -> AgentResult
```

## Design

`UnifiedAgentPipeline` owns orchestration only. It does not instantiate retrieval stores or providers and does not replace the existing specialist agents.

The specialist agent remains responsible for its domain evidence/citations. `TeacherAgent` receives that `AgentResult` and preserves evidence, citations, and confidence while optionally performing educational post-processing through the existing provider orchestrator.

## Trace

`execute_with_trace()` returns:

- selected `agent_type`
- original specialist `AgentResult`
- final `AgentResult`

The normal `execute()` method returns only the final `AgentResult` so it remains compatible with the existing execution contract.

## Smoke Test

```powershell
$env:PYTHONPATH="."
$env:PHASE20_9_LIVE="1"
python scripts/smoke_unified_agent_pipeline_phase20_9.py
```

No media files are required for this smoke test.
