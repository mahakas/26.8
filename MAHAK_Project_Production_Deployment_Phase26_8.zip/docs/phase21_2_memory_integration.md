# Phase 21.2 — Memory Integration

## Goal

Connect the Phase 21 memory foundation to the conversation-aware unified agent pipeline without changing `AgentResult`.

## Flow

```text
ConversationContext
       |
       v
MemoryIntegrationService
       |
       +--> load existing memories
       |
       v
UnifiedAgentPipeline
       |
       v
AgentRouter -> Specialist Agent -> TeacherAgent
       |
       v
AgentResult
       |
       +--> persist previous question
       +--> persist learning history
```

## Compatibility

- `AgentResult` is unchanged.
- Calling `UnifiedAgentPipeline.execute(query)` without a conversation context remains supported.
- Memory is optional and skipped when no user is attached to the conversation.
- Existing retrieval and provider boundaries remain unchanged.

## Persisted turn memories

Each conversation-aware pipeline turn records:

- `previous_question`: the latest question for the conversation.
- `learning_history`: the latest answer, selected agent, confidence, and citation count.

Existing `weak_area` and `student_profile` records are loaded into the memory snapshot but are not inferred or overwritten automatically in this phase.
