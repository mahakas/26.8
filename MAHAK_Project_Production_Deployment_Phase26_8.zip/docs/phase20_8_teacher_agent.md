# Phase 20.8 — TeacherAgent

## Purpose

Add the educational post-processing layer on top of the existing specialist agents.
`TeacherAgent` does not perform retrieval. It consumes an existing `AgentResult`,
preserves its evidence/citations/confidence, and optionally uses the existing
`ProviderOrchestrator` to rewrite the answer into a clearer educational explanation.

## Flow

```text
Specialist Agent
      |
      v
  AgentResult
      |
      v
 TeacherAgent
      |
      +--> optional ProviderOrchestrator
      |
      v
  Educational AgentResult
```

## Safety / grounding behavior

The TeacherAgent prompt instructs the provider to use only the supplied answer,
evidence, and citations. If no provider is configured, the agent uses a safe pass-through
fallback rather than inventing content. Evidence and citations are never regenerated or
silently discarded by the TeacherAgent.

## Tests

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_teacher_agent.py tests_v2/test_teacher_agent_integration.py -q
```

Smoke test:

```powershell
$env:PHASE20_8_LIVE="1"
python scripts/smoke_teacher_agent_phase20_8.py
```
