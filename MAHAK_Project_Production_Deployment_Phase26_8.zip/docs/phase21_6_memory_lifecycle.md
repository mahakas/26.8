# Phase 21.6 — Memory Lifecycle & User Control

## Purpose

Add explicit lifecycle controls to the Phase 21 memory subsystem without changing the
`AgentResult`, retrieval, router, TeacherAgent, or unified pipeline contracts.

## Capabilities

`MemoryService` now provides:

- `delete(user_id, memory_id)` — deletes one memory only when it belongs to the requested user.
- `clear(user_id, memory_type=..., conversation_id=...)` — removes matching user-owned memories and returns the number removed.
- `prune(user_id, max_records=..., memory_type=...)` — keeps the newest records and removes older records for the selected scope.

The repository enforces the same user ownership boundary.

## Safety / behavior

- Lifecycle operations are explicit; the chat pipeline does not prune or delete memory automatically.
- A user cannot delete another user's memory through `MemoryService.delete`.
- Existing memory types and `MemoryRecord` remain unchanged.
- No evidence, citation, confidence, or retrieval data is altered by lifecycle operations.

## Tests

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_6_memory_lifecycle.py -q
```

## Smoke test

```powershell
$env:PYTHONPATH="."
$env:PHASE21_6_LIVE="1"
python scripts/smoke_memory_phase21_6.py
```

## Full validation

```powershell
pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
