# Phase 21.1 — Memory Foundation

## Purpose

Introduce a persistent memory foundation for the future learning-memory system without changing current agent or chat behavior.

## Supported memory types

- `learning_history`
- `weak_area`
- `previous_question`
- `student_profile`

## Architecture

`MemoryService` -> `MemoryRepository` -> `LearningMemory` SQLAlchemy model.

The foundation keeps value data in JSON so later phases can evolve the shape of each memory type without changing the storage boundary.

## Scope

Phase 21.1 does not yet attach memory to the Agent Router, TeacherAgent, or chat pipeline. That integration belongs to later Phase 21 steps.

## Test

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_memory_foundation.py -q
$env:PHASE21_1_LIVE="1"
python scripts/smoke_memory_phase21_1.py
python -m compileall -q backend_v2 scripts
```
