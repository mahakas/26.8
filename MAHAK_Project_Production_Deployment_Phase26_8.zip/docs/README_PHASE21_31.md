# Phase 21.31 — Retention Run History Cleanup

## Goal
Provide an explicit, bounded cleanup service for old scheduler run history without changing LearningMemory retention behavior.

## Service
`backend_v2.memory.retention_run_history.MemoryRetentionRunHistoryService`

Methods:
- `preview(older_than, max_delete=500)` — read-only plan.
- `apply(older_than, max_delete=500)` — deletes old scheduler runs and their per-user result rows.

## Safety
- Applies to `memory_retention_runs` / `memory_retention_run_results` only.
- Does not touch `LearningMemory`.
- `older_than` may not be in the future.
- `max_delete` is bounded to 1..500.
- Oldest completed runs are removed first.
- Parent and child history rows are removed together.
- When a Session is injected, the caller owns commit/rollback.
- Standalone service sessions commit successful deletes.

## Scope
No public mutation endpoint is added in this phase because API authentication/permissions are scheduled for Phase 24. The service is intended for explicit internal/admin orchestration later.

## Validation
- Dedicated tests: `tests_v2/test_phase21_31_memory_retention_run_history.py`
- Smoke: `scripts/smoke_memory_retention_run_history_phase21_31.py`
