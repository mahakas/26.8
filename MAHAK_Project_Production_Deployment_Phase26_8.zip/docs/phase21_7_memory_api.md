# Phase 21.7 — Memory Read API

## Purpose

Expose the persisted Phase 21 memory state through controlled, read-only FastAPI endpoints while reusing the existing `MemoryService` and `MemoryProgressService`.

## Endpoints

- `GET /api/memory/{user_id}/records`
  - Returns user-scoped memory records.
  - Optional `memory_type` filter.
  - `limit` is bounded to 1–500.
- `GET /api/memory/{user_id}/progress`
  - Returns the existing `StudentProgressProfile` aggregation.
  - `limit` is bounded to 1–500.

## Contract rules

- No memory mutation is performed by these endpoints.
- Memory aggregation logic remains in `MemoryProgressService`.
- `AgentResult`, retrieval, citations, confidence, and the unified agent pipeline are unchanged.
- The current project does not yet have authentication/authorization; `user_id` is therefore an explicit API scope parameter. Production identity binding belongs to the later production/auth phase.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_7_memory_api.py -q

$env:PHASE21_7_LIVE="1"
python scripts/smoke_memory_api_phase21_7.py

pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
