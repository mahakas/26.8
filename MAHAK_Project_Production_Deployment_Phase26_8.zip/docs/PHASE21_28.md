# Phase 21.28 — Persistent Retention Scheduler Run History

Adds persistent, non-content history for explicit retention scheduler runs.

## Stored data

Run-level metadata:

- `run_id`
- status and timestamps
- dry-run flag
- user/result aggregates
- candidate / would-delete / deleted counts

Per-user result metadata:

- user id
- result status
- candidate / would-delete / deleted counts
- retention settings used
- memory type
- execution timestamp
- error text when applicable

Memory values, questions, profile content, and other memory payloads are never stored in this history.

## Transaction behavior

When a caller provides an existing SQLAlchemy session, run history is flushed into that same caller transaction.
For standalone scheduler execution, the retention transaction is committed first by the existing scheduler flow, then the run report is persisted in a separate session so a history persistence failure cannot roll back an already-completed retention run.

Disabled scheduler invocations are not persisted as run history because no scheduler run occurred.

This phase does not add a read API or a background scheduler. Those remain separate concerns for later phases.
