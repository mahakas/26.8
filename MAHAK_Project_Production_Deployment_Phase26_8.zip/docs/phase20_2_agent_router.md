# Phase 20.2 - Agent Router

Implemented:

- AgentRouter core
- Query classification
- Registry based agent selection
- Router tests

Current routing is deterministic and prepared for future ML based routing in later phases.
