# Phase 20.7 — GeneralAgent

## Purpose

Provide a real `GENERAL_AGENT` implementation using the existing `GeneralChatService`.
The agent does not replace provider orchestration, prompt construction, web search, or
session-file handling. It adapts the existing general chat response into the shared
`AgentResult` contract.

## Flow

```text
User query
  -> AgentRouter
  -> AgentRegistry
  -> GeneralAgent
  -> GeneralChatService
  -> ProviderOrchestrator
  -> AgentResult
```

## Contract

`GeneralAgent` requires a `GeneralChatService` and a `ConversationContext`.
Its `AgentResult` contains the existing general answer, evidence derived from general
citations, and normalized citation payloads.

## Tests

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_general_agent.py tests_v2/test_general_agent_integration.py -q
```

For the end-to-end local smoke test:

```powershell
$env:PHASE20_7_LIVE="1"
python scripts/smoke_general_agent_phase20_7.py
```
