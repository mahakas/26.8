# Phase 21.58 — Snapshot Retention Execution History Preview Binding

## Goal

Add an explicit consistency token between the Phase 21.57 execution-history retention-policy preview and its apply operation.

## Service

`backend_v2.memory.retention_maintenance_alert_snapshot_retention_history.MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService`

Changes:
- `preview_policy()` now returns a `preview_token`.
- `apply_policy(preview_token=...)` validates the preview before deletion.

## Preview binding

The token binds:

- effective `retention_days`
- effective `max_delete`
- whether the policy is explicitly configured
- exact preview cutoff (`older_than`)
- full candidate count
- ordered candidate execution `run_id`s within the configured delete cap

When a token is supplied to apply:

- malformed or tampered tokens are rejected;
- changed policy state is rejected;
- changed candidate state is rejected;
- the exact preview cutoff is reused;
- no history rows are deleted when validation fails.

Applying without a token remains backward compatible with Phase 21.57.

The token is a consistency guard, not an authentication credential, and it is never persisted.

## Scope

Only `memory_retention_maintenance_alert_snapshot_retention_runs` can be deleted by this cleanup. Snapshot rows and policy rows are not touched by the operation.

No scheduler, automatic cleanup, or public mutation endpoint is introduced.

## Validation

Dedicated tests:

```text
pytest tests_v2/test_phase21_58_memory_retention_maintenance_alert_snapshot_retention_history_preview_binding.py -q
```

Smoke:

```powershell
$env:PYTHONPATH="."
$env:PHASE21_58_LIVE="1"
python scripts/smoke_memory_retention_maintenance_alert_snapshot_retention_history_preview_binding_phase21_58.py
```

Full regression:

```text
pytest tests_v2 -q
python -m compileall -q backend_v2 scripts
```
