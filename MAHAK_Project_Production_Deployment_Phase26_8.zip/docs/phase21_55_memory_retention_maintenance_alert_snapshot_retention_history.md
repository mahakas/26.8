# Phase 21.55 — Maintenance Alert Snapshot Retention Execution History Cleanup

## Goal
Provide an explicit, bounded cleanup service for old content-free execution-history rows created by Phase 21.53.

## Service
`backend_v2.memory.retention_maintenance_alert_snapshot_retention_history.MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService`

Methods:
- `preview(older_than, max_delete=500)` — read-only cleanup plan.
- `apply(older_than, max_delete=500)` — deletes old execution-history rows.

## Safety
- Applies only to `memory_retention_maintenance_alert_snapshot_retention_runs`.
- Never deletes alert snapshots, retention policies, or other maintenance history.
- `older_than` may not be in the future.
- `max_delete` is bounded to `1..500`.
- Oldest completed executions are removed first.
- With an injected SQLAlchemy `Session`, the caller owns commit/rollback semantics.
- Standalone service sessions commit successful deletes.

## Scope
No public mutation endpoint is added. API authentication/permissions remain a later production concern.

## Validation
- Dedicated tests: `tests_v2/test_phase21_55_memory_retention_maintenance_alert_snapshot_retention_history.py`
- Smoke: `scripts/smoke_memory_retention_maintenance_alert_snapshot_retention_history_phase21_55.py`
