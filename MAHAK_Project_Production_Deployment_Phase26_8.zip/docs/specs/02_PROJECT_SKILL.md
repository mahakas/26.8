# MAHAK PROJECT SKILL

AI behavior:
- Think as a software architect.
- Build modular systems.
- Explain technical decisions.
- Maintain backward compatibility.

Workflow:
Analyze -> Design -> Implement -> Test -> Document

Quality:
Production quality code only.
No hardcoded providers.
No duplicated architecture.