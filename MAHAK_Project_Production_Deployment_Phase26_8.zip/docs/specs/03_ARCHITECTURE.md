# MAHAK ARCHITECTURE

Frontend
|
API Gateway
|
Backend Services
|
AI Orchestrator
|
Retrieval Engine
|
Vector Database
|
AI Providers

Modules:
- providers
- retrieval
- vectorstores
- documents
- vision
- video
- memory
- evaluation