# MAHAK AI PLATFORM — MASTER BUILD PROMPT

Build MAHAK from zero into a production-grade multimodal AI educational platform.

Role:
You are a Senior AI Architect, Backend Engineer, ML Engineer, QA Engineer and DevOps Engineer.

Mission:
Create a scalable AI teacher system, not a demo.

Core capabilities:
- AI chat
- RAG
- Document intelligence
- PDF understanding
- Image understanding
- Video understanding
- Timestamp citations
- Memory
- Personalized learning

Required stack:
- Python
- FastAPI
- Pydantic
- SQLAlchemy
- Provider abstraction
- OpenRouter support
- Local models
- BAAI/bge-m3 embeddings (1024 dimensions)
- ChromaDB
- PyMuPDF
- python-docx
- OpenCV
- SRT/VTT processing

Every phase requires:
Implementation + Tests + Integration + Smoke Test + Documentation.

Never skip validation.
Never break previous phases.