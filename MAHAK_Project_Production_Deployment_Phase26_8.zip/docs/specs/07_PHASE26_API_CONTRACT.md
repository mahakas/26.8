# Phase 26 API Contract Specification

## Versioning

- API version: `v1`
- Contract version: `1.0`
- Phase: `26.8`

## Authentication

The v1 Teacher API uses the existing Bearer authentication and `CHAT_USE` permission dependency. No parallel identity or authorization mechanism is introduced.

## Correlation

Clients may send `X-Request-ID`. The existing observability middleware validates or generates the request ID. The value is returned through `X-Request-ID` and surfaced in v1 structured errors.

## Response headers

- `X-Request-ID`
- `X-Mahak-API-Version`
- `X-Mahak-Contract-Version`

## Core Teacher answer

`POST /api/teacher/v1/ask` preserves the canonical Phase 25 Teacher response and adds a `meta` object. Evidence and citations remain authoritative and are not transformed into a simplified text-only representation.

## Session contract

Session operations reuse `TeacherSessionService`. The `teacher_session_id` supplied to `/ask` must belong to the authenticated user and must satisfy existing active/conversation/learning-plan binding rules.

## Error contract

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "request failed",
    "details": []
  },
  "request_id": "..."
}
```

Request-body validation is distinguished from application-level 422 errors:

- `VALIDATION_ERROR`: FastAPI/Pydantic request validation;
- `INVALID_TEACHER_REQUEST`: business-level 422 error;
- `AUTHENTICATION_REQUIRED`: 401;
- `FORBIDDEN`: 403;
- `NOT_FOUND`: 404;
- `CONFLICT`: 409;
- `RATE_LIMIT_EXCEEDED`: 429;
- `INTERNAL_ERROR`: unexpected v1 server error.

## Compatibility rule

The legacy `/api/teacher/*` contract remains available. Phase 26 error normalization is path-scoped to `/api/teacher/v1` so existing clients are not forced to migrate immediately.
