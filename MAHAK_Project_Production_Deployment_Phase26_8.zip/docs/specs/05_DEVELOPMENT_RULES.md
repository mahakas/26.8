# DEVELOPMENT RULES

- Test every feature.
- Preserve existing APIs.
- Use configuration.
- Keep modules independent.
- Document major changes.
- Validate before next phase.