# Phase 21.47 — Persistent Maintenance Alert Policy

Phase 21.47 adds a persistent system-level alert policy for Unified Maintenance.

## Scope

The policy stores only one operational threshold:

- `stale_after_seconds`: 60 to 31,536,000 seconds; default 86,400.

The policy is configuration only. It does not send notifications and does not execute maintenance.

## Service

`MemoryRetentionMaintenanceAlertPolicyService` provides:

- `get()` — effective policy and configured state
- `set(stale_after_seconds=...)` — persist policy
- `reset()` — remove configured policy and restore defaults

## API

`GET /api/memory/maintenance/alerts/policy` is a read-only status endpoint.

The existing `GET /api/memory/maintenance/alerts` endpoint is unchanged by default.
When `use_policy=true`, the stored policy supplies the stale threshold only when the caller does not provide `stale_after_seconds`.

Explicit `stale_after_seconds` always overrides the persisted policy.

No authentication/authorization mutation endpoint is added in this phase; permissioned configuration remains aligned with the production security roadmap.
