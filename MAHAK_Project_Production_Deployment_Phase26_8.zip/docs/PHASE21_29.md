# Phase 21.29 — Retention Scheduler Run History API

Adds a read-only, user-scoped API over the persistent scheduler run history introduced in Phase 21.28.

## Endpoint

`GET /api/memory/{user_id}/retention/runs`

Supported query parameters:

- `limit=1..500`
- `cursor=<opaque cursor>`
- `run_status=completed|completed_with_errors`
- `result_status=planned|executed|skipped|failed`
- `dry_run=true|false`

## Security and scope

The endpoint joins run-level and per-user result history but returns only the requested user's result row. Global run aggregates such as total user count are intentionally not exposed through this user-scoped endpoint.

The response never contains memory `value`, `memory_key`, question text, profile content, or other memory payloads.

## Pagination

Pagination is cursor-based and ordered by:

`started_at DESC, run_id DESC, result_id DESC`

Malformed cursors return HTTP 422. The cursor is opaque and contains only ordering keys.

## Read-only behavior

The endpoint performs no mutation, creates no audit events, and does not alter scheduler history.
