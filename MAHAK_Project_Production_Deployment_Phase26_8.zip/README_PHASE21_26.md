# Phase 21.26 — Memory Retention Scheduler Dry Run

Adds a safe dry-run mode to `MemoryRetentionSchedulerService`. The scheduler can now build a retention plan without deleting memories or creating audit events.

## Capabilities

- `run_once(..., dry_run=True)` returns `status="planned"`.
- Reports `candidate_count` and `would_delete_count`.
- Does not mutate learning memories.
- Does not create retention audit events.
- Continues to honor `retention_days`, `max_delete`, and `memory_type`.
- Disabled scheduler mode remains strictly non-mutating, even when `dry_run=True`.
- Existing `dry_run=False` execution behavior is unchanged and backward compatible.

## Design boundary

No background scheduler, cron process, Celery worker, or automatic execution is introduced. The dry-run mode is an engine-level planning primitive for future job orchestration and operational validation.

Smoke:
`PHASE21_26_LIVE=1 python scripts/smoke_memory_retention_scheduler_phase21_26.py`
