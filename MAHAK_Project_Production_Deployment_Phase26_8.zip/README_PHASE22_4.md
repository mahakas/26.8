# MAHAK Phase 22.4 — Adaptive Recommendations & Targeted Remediation

Phase 22.4 adds a deterministic recommendation layer on top of Phase 22.3 learning progress.

## Scope
- Read active weak-area state, mastery, retry signals, and recent learning context.
- Select the next educational topic.
- Choose remediation/reinforcement/advancement mode.
- Select a difficulty without using an LLM.
- Emit a generation-ready request compatible with `POST /api/education/tasks/generate`.
- Keep recommendations explainable through explicit reasons.
- Return no recommendation when there is neither a topic nor enough learning history.

## API
`POST /api/education/recommendations/next`

Example:
```json
{
  "user_id": "student-22-4",
  "task_type": "quiz",
  "question_count": 5
}
```

When an active weak area exists, the response identifies a targeted topic, remediation difficulty, rationale, and `generation_request` suitable for Phase 22.2 content generation.

## Validation
- Full `tests_v2` regression.
- Dedicated Phase 22.4 unit/integration tests.
- Smoke test: `scripts/smoke_education_adaptive_recommendation_phase22_4.py`.
- Compile check: `python -m compileall -q backend_v2 scripts`.
