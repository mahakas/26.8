# MAHAK Phase 21.15 — Memory Import Preview Binding

Phase 21.15 adds an optional execution guard that binds a memory import request
to the exact preview state from which it was generated.

## API

`POST /api/memory/{user_id}/import/preview` now returns:

```json
{
  "preview_token": "<sha256>"
}
```

The token is optional on import:

```json
{
  "user_id": "student-1",
  "preview_token": "<sha256>",
  "records": []
}
```

## Guarantees

- A preview token binds the payload checksum, conflict policy, user, and the
  current fingerprints of the logical memory keys present in the snapshot.
- If a relevant memory changes after preview, import returns HTTP `409` and
  performs no write for that request.
- Changing the import payload or conflict policy also invalidates the token.
- Imports without `preview_token` keep the Phase 21.10/21.13 legacy behavior.
- The token is a consistency guard, not an authentication credential.
- Preview remains fully read-only.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_15_memory_preview_binding.py -q

$env:PHASE21_15_LIVE="1"
python scripts/smoke_memory_preview_binding_phase21_15.py

pytest tests_v2 -q

python -m compileall -q backend_v2 scripts
```
