# MAHAK — Phase 21.43

## Unified Maintenance Run History Summary API

Phase 21.43 adds a read-only aggregate API over the persisted unified maintenance run history introduced in Phase 21.41 and exposed as a list API in Phase 21.42.

### Endpoint

`GET /api/memory/maintenance/runs/summary`

Supported filters:

- `status=completed|completed_with_errors`
- `dry_run=true|false`
- `cleanup_history=true|false`
- `start_at` inclusive
- `end_at` exclusive

### Response highlights

The response contains run-level aggregates only: run counts, dry-run counts, cleanup-history counts, memory candidate/deletion counts, history candidate/deletion counts, error count, and first/last timestamps.

No user content, memory values, questions, keys, or profile data are returned.

### Compatibility

This phase is additive. The Phase 21.42 history list endpoint, all retention execution contracts, lease contracts, maintenance execution gate, persistence model, and prior tests remain unchanged.
