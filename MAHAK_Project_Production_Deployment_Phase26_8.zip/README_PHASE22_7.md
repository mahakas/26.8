# MAHAK Phase 22.7 — Learning Plan Analytics & Outcome Tracking

Phase 22.7 adds live analytics for an existing educational learning plan.

## API

`GET /api/education/learning-plans/{plan_id}/analytics?user_id=...`

The endpoint derives analytics from the persisted learning-plan, adaptive-session, and attempt state. It does not create a second source of truth.

## Metrics

- plan/session completion percentages
- milestone completion percentage
- attempt and item counts
- average/best/latest score
- correct/partial/incorrect counts
- current mastery average and mastery gap
- remediation sessions and remediation share
- topic-level score/mastery breakdown
- outcome: `on_track`, `at_risk`, `completed`, or `blocked`

## Validation

```text
Full regression at Phase 22.7 delivery: 448 passed, 3 skipped
Phase 22.7: 5 tests
Smoke: live analytics endpoint
Compile: backend_v2 + scripts
```

## Smoke

```powershell
$env:PHASE22_7_LIVE="1"
python scripts/smoke_education_learning_plan_analytics_phase22_7.py
```
