# MAHAK Phase 22.1 — Educational Task Planning & Adaptive Difficulty Foundation

Phase 22.1 starts the Educational Intelligence roadmap after the Phase 21 memory/retention branch.

## What changed

- Added `EducationalTaskPlanner` for deterministic educational task planning.
- Added task types: `quiz`, `homework`, `exam`, `review`.
- Added difficulty modes: `easy`, `medium`, `hard`, `adaptive`.
- Adaptive planning can consume the existing `StudentProgressProfile` and weak-area/mastery signals.
- Added `POST /api/education/tasks/plan`.
- Added focused tests and a smoke test.

## Design boundary

Phase 22.1 plans the educational task; it does not generate question content yet.
Question/content generation is intentionally deferred to Phase 22.2 so the planner can be validated independently and remain provider-agnostic.

## Validation

- Existing Phase 21.59 baseline: 412 passed, 3 skipped.
- Phase 22.1 adds deterministic planner and API coverage.
- No database schema migration is required in this phase.
