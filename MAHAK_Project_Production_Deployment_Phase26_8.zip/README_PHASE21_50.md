# Phase 21.50 — Maintenance Alert Snapshot Deduplication

Phase 21.50 adds an opt-in deduplicated snapshot capture path.

## New API

`MemoryRetentionMaintenanceAlertSnapshotService.capture_if_changed()` evaluates the current alert state and only creates a new persisted snapshot when the evaluated state differs from the latest snapshot.

The existing `capture()` method remains unchanged and always creates a snapshot, preserving backward compatibility.

## Deduplication

The comparison uses the content-free operational state:

- health
- ready
- severity
- stale_after_seconds
- alert_count
- alert_codes
- assume_enabled
- use_policy

The capture timestamp is intentionally excluded, so identical evaluations are not persisted repeatedly just because time advanced slightly.

When the state changes (for example, a last-run becomes stale and severity changes), a new snapshot is persisted.

No schema migration is required for this phase.
