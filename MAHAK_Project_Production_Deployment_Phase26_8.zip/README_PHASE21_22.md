# Phase 21.22 — Retention Policy Execution

Adds explicit preview/apply endpoints that execute the effective per-user memory retention policy.

Endpoints:
- `POST /api/memory/{user_id}/retention/policy/preview`
- `POST /api/memory/{user_id}/retention/policy/apply`

The policy is never executed automatically. Preview is read-only. Apply derives the cutoff from `retention_days`, respects `max_delete` and `memory_type`, and emits the existing `retention` audit event only when records are deleted. Unconfigured users use the existing safe defaults (365 days, 500 records, all memory types).

Smoke test:
`PHASE21_22_LIVE=1 python scripts/smoke_memory_retention_policy_execution_phase21_22.py`
