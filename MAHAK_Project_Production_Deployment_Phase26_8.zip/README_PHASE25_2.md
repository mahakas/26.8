# MAHAK Phase 25.2 — Audio Ingestion & Speech Understanding

Phase 25.2 adds first-class audio ingestion and timestamp-aware speech understanding.

## Capabilities

- MP3, WAV, M4A, FLAC, OGG, OGA, OPUS, AAC and WMA analysis.
- Deterministic SRT/VTT/TXT sidecar transcription.
- Optional injected local `FasterWhisperTranscriber`.
- Timestamp-preserving transcript segments.
- Audio-aware chunks with `source_type=audio` and `modality=audio`.
- `AudioAgent` with transcript evidence and start/end citation locators.
- Multimodal Teacher routing for `audio` / `AUDIO_AGENT`.

## Optional local transcription

`FasterWhisperTranscriber` from `backend_v2.ingestion.processors.audio` can be injected into `AudioProcessor` when `faster-whisper` and the desired model are installed. The default pipeline remains deterministic and uses a same-stem sidecar when present; it does not download a model automatically.

## Validation

```powershell
python -m pytest -q tests_v2/test_phase25_2_audio_ingestion_speech.py
python scripts/smoke_audio_ingestion_speech_phase25_2.py
python -m compileall -q backend_v2 scripts
```
