# MAHAK Phase 24.2 — Authentication & Identity Layer

Phase 24.2 introduces the first production-oriented identity boundary without forcing authentication onto every legacy endpoint yet.

## Delivered

- Persistent `User` identity model with normalized unique email.
- PBKDF2-SHA256 password hashing using the Python standard library.
- Bearer access tokens signed with the Phase 24.1 secret configuration.
- Persistent refresh sessions with SHA-256 token hashes.
- Refresh-token rotation and server-side revocation.
- `GET /api/auth/me` dependency with active-user validation.
- Registration, login, refresh, and logout endpoints.
- Authentication-specific configuration for access-token and refresh-session lifetimes.
- No password or refresh-token plaintext is persisted in the database.
- Existing legacy routes remain behavior-compatible; endpoint-by-endpoint authorization is deferred to Phase 24.3.

## Endpoints

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/refresh`
- `POST /api/auth/logout`
- `GET /api/auth/me`

## Configuration

```dotenv
AUTH_ACCESS_TOKEN_TTL_MINUTES=30
AUTH_REFRESH_TOKEN_TTL_DAYS=14
```

`MAHAK_SECRET_KEY` from Phase 24.1 signs access tokens. Production still requires the Phase 24.1 secret and host configuration.

## Security boundary

Phase 24.2 establishes identity and authentication. Authorization/RBAC and route-level enforcement are introduced in Phase 24.3 without globally locking legacy business routes in one compatibility-breaking change.

## Validation

```powershell
python -m pytest -q tests_v2/test_phase24_2_authentication_identity.py
python scripts/smoke_authentication_identity_phase24_2.py
python -m compileall -q backend_v2 scripts
python -m pytest -q tests_v2
```
