# MAHAK Phase 23.1 — Evaluation Framework

Phase 23.1 introduces a deterministic, API-accessible evaluation layer for educational AI answers.

## Scope

The evaluator measures four evidence-based dimensions when their reference inputs are available:

- answer quality using token-level F1 against an expected answer;
- retrieval precision/recall/F1 against expected source IDs;
- citation correctness/completeness/F1 against expected source IDs;
- evidence coverage over supplied evidence text.

`heuristic_hallucination_risk = 1 - evidence_coverage` is intentionally a lexical heuristic. It is not a semantic fact-checker and must not be interpreted as proof of hallucination.

## API

`POST /api/evaluation/answer`

Swagger: `http://127.0.0.1:8000/docs`

## Exact tests

```powershell
python -m pytest -q tests_v2/test_phase23_1_evaluation_framework.py
$env:PHASE23_1_LIVE="1"
python scripts/smoke_education_evaluation_phase23_1.py
python -m compileall -q backend_v2 scripts
```

## Full regression baseline

Validation after Phase 23.1: `475 passed, 3 skipped`.
