# Phase 21.52 — Maintenance Alert Snapshot Retention Preview Binding

Adds an explicit preview/apply consistency guard for maintenance alert snapshot retention.

Preview returns an opaque token bound to the effective retention policy, exact cutoff, candidate count, and ordered candidate snapshot IDs within the configured deletion cap. Apply may use that token to prevent deletion when the retention state changed after preview.

New API:

- `GET /api/memory/maintenance/alert-snapshots/retention/policy`
- `PUT /api/memory/maintenance/alert-snapshots/retention/policy`
- `DELETE /api/memory/maintenance/alert-snapshots/retention/policy`
- `POST /api/memory/maintenance/alert-snapshots/retention/policy/preview`
- `POST /api/memory/maintenance/alert-snapshots/retention/policy/apply?preview_token=...`

Apply without a token remains supported for backward compatibility. The token is a consistency guard, not an authentication credential.

Smoke test:

`PHASE21_52_LIVE=1 python scripts/smoke_memory_retention_maintenance_alert_snapshot_preview_binding_phase21_52.py`
