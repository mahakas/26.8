# MAHAK Phase 22.3 — Quiz / Attempt / Grading / Learning Progress Update

Phase 22.3 چرخه ارزیابی آموزشی را به MAHAK اضافه می‌کند:

`Question -> Attempt -> Deterministic Grading -> Mastery Update -> Weak Area Update -> Persistent Learning History`

## قابلیت‌ها

- ثبت `attempt_id` برای هر تلاش آموزشی.
- نمره‌دهی deterministic برای multiple-choice و true/false با تطبیق دقیق.
- نمره‌دهی تقریبی برای پاسخ‌های متنی با token overlap و sequence similarity.
- ثبت نتیجه کامل attempt در `learning_history` برای حفظ سازگاری با Memory Foundation قبلی.
- به‌روزرسانی `mastery_score` برای هر topic به‌صورت میانگین تجمعی بین تلاش‌ها.
- استفاده از `WeakAreaMemoryUpdater` موجود در Phase 21 برای فعال/حل‌شدن weak areaها.
- idempotent replay: ارسال دوباره همان `attempt_id` نتیجه قبلی را بازمی‌گرداند و progress را دوباره تغییر نمی‌دهد.
- endpoint جدید:

`POST /api/education/attempts/grade`

## قرارداد پاسخ

پاسخ شامل این موارد است:

- `total_score`
- `correct_count`
- `partial_count`
- `incorrect_count`
- `items`
- `mastery_by_topic`
- `weak_area_status_by_topic`
- `confidence`
- `idempotent_replay`

## Smoke Test

PowerShell:

```powershell
$env:PHASE22_3_LIVE="1"
python scripts/smoke_education_attempt_grading_phase22_3.py
```

## Validation

```powershell
python -m pytest -q tests_v2
python -m pytest -q tests_v2/test_phase22_3_education_attempt_grading.py
python -m compileall -q backend_v2 scripts
```

این Phase از دیتابیس موجود Memory استفاده می‌کند و schema جدیدی به جدول‌های قبلی اضافه نمی‌کند.
