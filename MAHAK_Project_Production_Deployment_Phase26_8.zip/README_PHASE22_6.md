# MAHAK Phase 22.6 — Multi-Session Learning Plan & Milestones

Phase 22.6 builds a persistent multi-session learning plan on top of Phase 22.5 adaptive sessions.

## Capabilities
- Multi-session learning plan with configurable session count and steps.
- Ordered milestones with per-topic mastery targets.
- Automatic first-session creation.
- Automatic transition to the next milestone after a completed session reaches the mastery target.
- Targeted remediation session when a milestone finishes below the mastery target.
- Configurable remediation cap; a plan becomes `blocked` when the cap is exhausted without meeting the target.
- Persistent plan state in `LEARNING_HISTORY`; no new `MemoryType` or database migration is required.
- Revisioned plan state to avoid stale reads when multiple memory writes share the same timestamp.
- Idempotent plan advancement by `attempt_id`.

## API
- `POST /api/education/learning-plans/start`
- `POST /api/education/learning-plans/{plan_id}/advance`
- `GET /api/education/learning-plans/{plan_id}?user_id=...`

Session responses now optionally expose `learning_plan_id`, allowing direct linkage from a multi-session plan to its active Phase 22.5 session.

## Validation
- Full regression: 443 passed, 3 skipped.
- Phase 22.6 tests: 5 passed.
- Smoke: `scripts/smoke_education_learning_plan_phase22_6.py`.
- Compile: `python -m compileall -q backend_v2 scripts`.
