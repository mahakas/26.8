# MAHAK Phase 21.14 — Memory Import Preview / Dry Run

Phase 21.14 adds a read-only import preview endpoint for portable memory
snapshots.

## API

```text
POST /api/memory/{user_id}/import/preview
```

The request uses the same `MemoryImportIn` payload and therefore supports:

- `append`
- `skip`
- `reject`
- optional snapshot checksum verification

Example response:

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "conflict_policy": "skip",
  "record_count": 3,
  "would_import_count": 1,
  "would_skip_count": 2,
  "conflict_count": 1,
  "exact_duplicate_count": 1,
  "would_reject": false
}
```

## Guarantees

- The preview endpoint performs no create, delete, flush, or commit operation.
- Exact duplicates and logical-key conflicts are classified using the same
  semantics introduced in Phase 21.13, including conflicts inside one batch.
- `reject` preview reports `would_reject=true` when any logical-key conflict
  exists and predicts zero writes for that request.
- When a checksum is supplied, the snapshot is verified before previewing.
- User-scoped validation remains identical to the import endpoint.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_14_memory_import_preview.py -q

$env:PHASE21_14_LIVE="1"
python scripts/smoke_memory_import_preview_phase21_14.py

pytest tests_v2 -q

python -m compileall -q backend_v2 scripts
```
