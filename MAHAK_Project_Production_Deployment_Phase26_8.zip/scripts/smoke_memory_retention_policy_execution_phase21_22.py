from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory
from backend_v2.memory.types import MemoryType


def main() -> int:
    if __import__("os").environ.get("PHASE21_22_LIVE") != "1":
        print("Set PHASE21_22_LIVE=1 to run the Phase 21.22 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db: Session = SessionLocal()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        db.add_all(
            [
                LearningMemory(
                    user_id="phase21-22-smoke",
                    memory_type=MemoryType.PREVIOUS_QUESTION.value,
                    memory_key="old",
                    value_json={"q": "old"},
                    created_at=now - timedelta(days=60),
                    updated_at=now - timedelta(days=60),
                ),
                LearningMemory(
                    user_id="phase21-22-smoke",
                    memory_type=MemoryType.PREVIOUS_QUESTION.value,
                    memory_key="recent",
                    value_json={"q": "recent"},
                    created_at=now - timedelta(days=2),
                    updated_at=now - timedelta(days=2),
                ),
            ]
        )
        db.commit()
        policy = client.put(
            "/api/memory/phase21-22-smoke/retention/policy",
            json={"retention_days": 30, "max_delete": 1, "memory_type": "previous_question"},
        )
        assert policy.status_code == 200
        preview = client.post("/api/memory/phase21-22-smoke/retention/policy/preview")
        assert preview.status_code == 200
        assert preview.json()["candidate_count"] == 1
        print("runtime: OK")
        print("preview: OK")
        apply_response = client.post("/api/memory/phase21-22-smoke/retention/policy/apply")
        assert apply_response.status_code == 200
        assert apply_response.json()["deleted_count"] == 1
        print("apply: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
