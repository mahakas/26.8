from __future__ import annotations

import os

from backend_v2.agents.general import GeneralAgent
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.chat.general import GeneralChatService
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def _service() -> GeneralChatService:
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            "phase20-7-smoke",
            {Capability.CHAT},
            lambda payload: "GeneralAgent smoke response",
            default_model="general-smoke-v1",
        ),
        priority=1,
    )
    return GeneralChatService(
        ProviderOrchestrator(registry, ProviderHealthManager())
    )


def main() -> int:
    if os.getenv("PHASE20_7_LIVE", "0") != "1":
        print("Set PHASE20_7_LIVE=1 to run the Phase 20.7 smoke test.")
        return 0

    registry = AgentRegistry()
    registry.register(GeneralAgent(_service()))

    router = AgentRouter(registry)
    route = router.classify("سلام")

    context = ConversationContext(
        conversation_id="phase20-7-smoke",
        user_id=None,
        mode=ChatMode.GENERAL,
    )
    result = router.execute("سلام", context=context)

    print("runtime: OK")
    print(f"router: {route.agent_type.value}")
    print(f"agent: {result.answer}")
    print(f"confidence: {result.confidence}")

    return 0 if route.agent_type is AgentType.GENERAL and result.confidence == 0.8 else 1


if __name__ == "__main__":
    raise SystemExit(main())
