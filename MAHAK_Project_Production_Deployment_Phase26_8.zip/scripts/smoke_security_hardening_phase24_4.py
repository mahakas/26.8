from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from backend_v2.api.app import create_app


def main() -> int:
    client = TestClient(create_app())

    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.headers["X-Content-Type-Options"] == "nosniff"
    assert health.headers["X-Frame-Options"] == "DENY"
    assert health.headers["Referrer-Policy"] == "no-referrer"

    for _ in range(10):
        response = client.post(
            "/api/auth/login",
            json={"email": "rate-limit-smoke@example.com", "password": "wrong-password"},
        )
        assert response.status_code in {401, 429}
    limited = client.post(
        "/api/auth/login",
        json={"email": "rate-limit-smoke@example.com", "password": "wrong-password"},
    )
    assert limited.status_code == 429
    assert "Retry-After" in limited.headers

    print("security hardening: OK")
    print("security_headers: OK")
    print("auth_rate_limit: OK")
    print("retry_after: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
