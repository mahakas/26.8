from __future__ import annotations

from pathlib import Path
import argparse
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[1]


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Phase 24.6 Docker packaging smoke")
    parser.add_argument("--require-docker", action="store_true")
    parser.add_argument("--optional-docker", action="store_true")
    args = parser.parse_args()
    dockerfile = ROOT / "Dockerfile"
    compose = ROOT / "compose.yaml"
    env_example = ROOT / ".env.production.example"
    dockerignore = ROOT / ".dockerignore"

    checks = {
        "dockerfile": dockerfile.exists(),
        "compose": compose.exists(),
        "env_template": env_example.exists(),
        "dockerignore": dockerignore.exists(),
    }
    if all(checks.values()):
        dockerfile_text = _read(dockerfile)
        compose_text = _read(compose)
        env_text = _read(env_example)
        ignore_text = _read(dockerignore)
        checks.update(
            {
                "non_root": "USER 10001:10001" in dockerfile_text,
                "docker_healthcheck": "/api/health/ready" in dockerfile_text,
                "persistent_volume": "mahak_data:/app/data" in compose_text,
                "read_only_root": "read_only: true" in compose_text,
                "no_new_privileges": "no-new-privileges:true" in compose_text,
                "cap_drop_all": "- ALL" in compose_text,
                "production_env": "APP_ENV=production" in env_text,
                "secret_template": "MAHAK_SECRET_KEY=" in env_text,
                "media_exclusion": "*.mp4" in ignore_text,
            }
        )

    ok = all(checks.values())
    print("docker deployment packaging: " + ("OK" if ok else "FAILED"))
    for name, value in checks.items():
        print(f"{name}: {'OK' if value else 'FAILED'}")

    docker_path = shutil.which("docker")
    if args.require_docker and not docker_path:
        print("docker_cli: NOT_INSTALLED")
        print("runtime_build: REQUIRED")
        return 1
    if docker_path:
        version = subprocess.run([docker_path, "--version"], capture_output=True, text=True)
        compose = subprocess.run([docker_path, "compose", "version"], capture_output=True, text=True)
        print(f"docker_cli: {'OK' if version.returncode == 0 else 'FAILED'}")
        print(f"docker_compose: {'OK' if compose.returncode == 0 else 'FAILED'}")
        if version.returncode == 0 and compose.returncode == 0:
            config = subprocess.run(
                [docker_path, "compose", "config", "--quiet"],
                cwd=ROOT,
                capture_output=True,
                text=True,
            )
            print(f"compose_config: {'OK' if config.returncode == 0 else 'FAILED'}")
            ok = ok and config.returncode == 0
    else:
        print("docker_cli: NOT_INSTALLED")
        print("runtime_build: NOT_RUN")

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
