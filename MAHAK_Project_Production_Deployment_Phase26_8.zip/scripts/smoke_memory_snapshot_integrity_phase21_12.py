from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    if os.getenv("PHASE21_12_LIVE") != "1":
        print("Set PHASE21_12_LIVE=1 to run the Phase 21.12 memory snapshot integrity smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    user_id = "smoke-phase21-12"

    try:
        seed = {
            "format_version": "1.0",
            "user_id": user_id,
            "records": [
                {
                    "id": "legacy-checksum-id",
                    "user_id": user_id,
                    "memory_type": "previous_question",
                    "memory_key": "q-1",
                    "value": {"question": "معادله چیست؟"},
                    "confidence": 0.9,
                    "source": "smoke",
                }
            ],
        }
        created = client.post(f"/api/memory/{user_id}/import", json=seed)
        assert created.status_code == 201, created.text

        exported = client.get(f"/api/memory/{user_id}/export")
        assert exported.status_code == 200, exported.text
        snapshot = exported.json()
        checksum = snapshot["checksum"]
        assert len(checksum) == 64
        print("runtime: OK")
        print("checksum: OK")

        client.delete(f"/api/memory/{user_id}/records")
        restored = client.post(f"/api/memory/{user_id}/import", json=snapshot)
        assert restored.status_code == 201, restored.text
        assert restored.json()["checksum"] == checksum
        assert restored.json()["imported_count"] == 1
        print("verified_restore: OK")

        tampered = dict(snapshot)
        tampered["records"] = [dict(snapshot["records"][0])]
        tampered["records"][0]["value"] = {"question": "دستکاری شده"}
        rejected = client.post(f"/api/memory/{user_id}/import", json=tampered)
        assert rejected.status_code == 422
        assert rejected.json()["detail"] == "Invalid memory snapshot checksum"
        print("tamper_rejection: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
