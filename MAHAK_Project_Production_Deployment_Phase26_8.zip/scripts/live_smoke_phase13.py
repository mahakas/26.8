from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("PYTHONPATH", str(ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")

from backend_v2.core.enums import Capability


def main() -> int:
    if os.getenv("PHASE13_LIVE") != "1":
        print("Set PHASE13_LIVE=1 to run live provider smoke tests.")
        return 2
    # Live mode must be enabled before constructing the runtime. The global
    # runtime is created at module import time, so changing the environment
    # after importing it would leave the process on the mock registry.
    os.environ["MAHAK_PROVIDER_MODE"] = "live"
    from backend_v2.runtime import V2Runtime
    runtime = V2Runtime()
    configured = [
        p.adapter.provider_name
        for p in runtime.registry.providers()
        if p.adapter.provider_name not in {"default-chat", "default-embedding"}
    ]
    if not configured:
        print("No real provider is configured. Set at least one *_API_KEY in .env.")
        return 2
    print("Configured real providers:", ", ".join(configured))
    for capability, payload in [
        (Capability.CHAT, {"messages": [{"role": "user", "content": "فقط بنویس: تست اتصال موفق است."}]}),
        (Capability.EMBEDDING, {"texts": ["این یک تست embedding فارسی است."]}),
    ]:
        try:
            result = runtime.llm_orchestrator.execute(capability, payload, metadata={"smoke_test": True}) if capability is Capability.CHAT else runtime.embedding_orchestrator.execute(capability, payload, metadata={"smoke_test": True})
            print(f"{capability.value}: OK | provider={result.response.provider} | model={result.response.model}")
            if capability is Capability.CHAT:
                print("answer:", result.response.output)
            else:
                print("dimension:", len(result.response.output[0]))
        except Exception as exc:
            print(f"{capability.value}: FAILED | {type(exc).__name__}: {exc}")
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
