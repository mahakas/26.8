from __future__ import annotations

import os

from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult
from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


def main() -> None:
    if os.getenv("PHASE20_8_LIVE") != "1":
        print("Set PHASE20_8_LIVE=1 to run the Phase 20.8 smoke test.")
        return

    registry = ProviderRegistry()
    provider = MockProviderAdapter(
        "phase20-8-smoke",
        {Capability.CHAT},
        lambda payload: {"answer": "این پاسخ برای دانش‌آموز مرحله‌به‌مرحله توضیح داده شد."},
        default_model="teacher-smoke-v1",
    )
    registry.register(provider, priority=1)
    orchestrator = ProviderOrchestrator(registry, ProviderHealthManager())

    source = AgentResult(
        answer="x = 3",
        evidence=[{"type": "document", "text": "3x = 9", "page": 12}],
        citations=[{"title": "algebra", "page": 12}],
        confidence=0.82,
    )

    result = TeacherAgent(orchestrator).execute(
        "x را برای دانش‌آموز توضیح بده",
        source_result=source,
    )

    assert result.answer
    assert result.evidence == source.evidence
    assert result.citations == source.citations
    print("runtime: OK")
    print("agent: TeacherAgent")
    print("provider: OK")
    print("evidence: preserved")
    print("citations: preserved")
    print(f"confidence: {result.confidence}")


if __name__ == "__main__":
    main()
