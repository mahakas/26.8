from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    compose = (ROOT / "compose.yaml").read_text(encoding="utf-8")
    env = (ROOT / ".env.production.example").read_text(encoding="utf-8")
    runbook = ROOT / "README_PRODUCTION_DEPLOYMENT_PHASE26_8.md"

    checks = {
        "image_tag_26_8": "mahak-ai:${IMAGE_TAG:-26.8}" in compose,
        "non_root": "USER 10001:10001" in dockerfile,
        "read_only": "read_only: true" in compose,
        "cap_drop_all": "- ALL" in compose,
        "healthcheck_ready": "/api/health/ready" in dockerfile and "/api/health/ready" in compose,
        "production_env": "APP_ENV=production" in env and "APP_DEBUG=false" in env,
        "live_provider_mode": "MAHAK_PROVIDER_MODE=live" in env,
        "local_embedding": "EMBED_BACKEND=local" in env and "EMBED_MODEL=BAAI/bge-m3" in env,
        "secret_template": "MAHAK_SECRET_KEY=" in env,
        "runbook": runbook.exists(),
    }
    ok = all(checks.values())
    print("production deployment packaging: " + ("OK" if ok else "FAILED"))
    for name, value in checks.items():
        print(f"{name}: {'OK' if value else 'FAILED'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
