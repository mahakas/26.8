from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.agents.audio import AudioAgent
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.vectorstores.base import VectorHit


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="mahak_phase25_2_") as tmp:
        root = Path(tmp)
        audio = root / "lesson.mp3"
        srt = root / "lesson.srt"
        audio.write_bytes(b"not-real-audio")
        srt.write_text(
            "1\n00:00:02,000 --> 00:00:04,500\nسلام، موضوع امروز انرژی جنبشی است.\n",
            encoding="utf-8",
        )
        result = IngestionPipeline().process(audio)
        assert result.document.metadata["modality"] == "audio"
        assert result.document.metadata["transcript_segment_count"] == 1
        assert result.chunks[0].metadata["start_time_seconds"] == 2.0
        assert result.chunks[0].metadata["end_time_seconds"] == 4.5

    router = AgentRouter(__import__("backend_v2.agents.registry", fromlist=["AgentRegistry"]).AgentRegistry())
    # classify_many only constructs deterministic routes; registry registration is not needed here.
    route = router.classify_many("صدا و گفتار این درس")
    assert route[0].agent_type is AgentType.AUDIO

    hit = VectorHit(
        "audio-smoke",
        0.91,
        "انرژی جنبشی",
        {"source_id": "lesson.mp3", "title": "درس", "source_type": "audio", "start_time_seconds": 2.0, "end_time_seconds": 4.5},
    )
    agent = AudioAgent()
    response = agent.execute("انرژی چیست؟", hits=[hit])
    assert response.evidence[0]["timestamp"] == {"start": 2.0, "end": 4.5}
    print("audio ingestion & speech understanding: OK")
    print("transcript_segments: 1")
    print("timestamp_evidence: OK")
    print("audio_agent: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
