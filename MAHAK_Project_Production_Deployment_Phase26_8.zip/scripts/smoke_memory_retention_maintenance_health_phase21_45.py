from __future__ import annotations

import os
import tempfile
from datetime import datetime
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun


def main() -> int:
    if os.getenv("PHASE21_45_LIVE") != "1":
        print("Set PHASE21_45_LIVE=1 to run Phase 21.45 smoke tests.")
        return 0

    fd, path = tempfile.mkstemp(prefix="mahak_phase21_45_", suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{Path(path).as_posix()}", future=True)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        db.add(
            MemoryRetentionMaintenanceRun(
                run_id="smoke-45-a",
                status="completed",
                started_at=datetime(2026, 9, 19, 10, 0),
                completed_at=datetime(2026, 9, 19, 10, 1),
                dry_run=False,
                cleanup_history=True,
                memory_status="completed",
                memory_user_count=1,
                memory_planned_count=1,
                memory_executed_count=1,
                memory_skipped_count=0,
                memory_failed_count=0,
                memory_candidate_count=2,
                memory_would_delete_count=2,
                memory_deleted_count=2,
                history_status="completed",
                history_configured=True,
                history_retention_days=365,
                history_max_delete=500,
                history_candidate_count=1,
                history_would_delete_count=1,
                history_deleted_count=1,
                history_error=None,
            )
        )
        db.commit()

        app = create_app()

        def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db
        client = TestClient(app)

        response = client.get("/api/memory/maintenance/health", params={"assume_enabled": "true"})
        assert response.status_code == 200
        payload = response.json()
        assert payload["health"] == "healthy"
        assert payload["ready"] is True
        assert payload["read_only"] is True
        assert payload["checks"]
        assert "user_id" not in str(payload)
        assert "memory_key" not in str(payload)

        second = client.get("/api/memory/maintenance/health")
        assert second.status_code == 200
        assert second.json()["health"] == "disabled"

        print("runtime: OK")
        print("health_api: OK")
        print("healthy_assumed_enabled: OK")
        print("disabled_state: OK")
        print("read_only: OK")
        db.close()
        engine.dispose()
        return 0
    finally:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
