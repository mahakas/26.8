from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app

if os.getenv("PHASE23_4_LIVE") != "1":
    raise SystemExit("Set PHASE23_4_LIVE=1 before running this smoke test")

client = TestClient(create_app())
response = client.post(
    "/api/evaluation/citations",
    json={
        "answer": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.",
        "expected_citations": [{"source_id": "physics.pdf", "page": 12}],
        "actual_citations": [{"source_id": "physics.pdf", "page": 12}],
        "evidence_items": [{"source_id": "physics.pdf", "text": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است."}],
    },
)
response.raise_for_status()
payload = response.json()
assert payload["citation_correctness"] == 1.0
assert payload["citation_completeness"] == 1.0
assert payload["citation_f1"] == 1.0
assert payload["locator_accuracy"] == 1.0
assert payload["evidence_coverage"] == 1.0

batch = client.post(
    "/api/evaluation/citations/batch",
    json={
        "cases": [
            {"case_id": "perfect", "request": {"answer": "a", "expected_citations": [{"source_id": "a.pdf"}], "actual_citations": [{"source_id": "a.pdf"}]}},
            {"case_id": "missing", "request": {"answer": "b", "expected_citations": [{"source_id": "b.pdf"}], "actual_citations": []}},
        ]
    },
)
batch.raise_for_status()
batch_payload = batch.json()
assert batch_payload["evaluated_cases"] == 2
assert batch_payload["average_citation_f1"] == 0.5

print("citation & evidence evaluation: OK")
print("citation_f1: 1.0")
print("locator_accuracy: 1.0")
print("evidence_coverage: 1.0")
print("batch_cases: 2")
print("deterministic_repeat: True")
