from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_analytics import TeacherOutcomeAnalyticsService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        memory = MemoryService(db)
        interaction = TeacherInteractionService(memory).record(
            user_id="smoke-25-8",
            conversation_id="conv-smoke-25-8",
            question="تحلیل آموزشی چیست؟",
            agent_types=("DOCUMENT_AGENT",),
            modalities=("document", "image"),
            strategy_mode="explain",
            strategy_difficulty="standard",
            learning_outcome="stable",
            recommended_mode="explain",
            recommended_difficulty="standard",
            next_action="check_understanding",
            confidence=0.9,
            evidence_count=2,
            citation_count=2,
            found=True,
            learning_plan_id="plan-smoke-25-8",
        )
        TeacherFeedbackService(memory).record(
            user_id="smoke-25-8",
            conversation_id="conv-smoke-25-8",
            feedback_id="feedback-smoke-25-8",
            interaction_id=interaction.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        result = TeacherOutcomeAnalyticsService(memory).analyze(
            "smoke-25-8",
            conversation_id="conv-smoke-25-8",
            learning_plan_id="plan-smoke-25-8",
        )
        assert result.total_interactions == 1
        assert result.total_feedback == 1
        assert result.bound_feedback == 1
        assert result.average_rating == 5.0
        assert result.feedback_signal_counts["progressing"] == 1
        assert result.modality_counts["document"] == 1
        assert result.modality_counts["image"] == 1
        print("analytics: OK")
        print("feedback_binding: OK")
        print(f"interaction_id: {interaction.interaction_id}")
        print(f"trend: {result.feedback_trend}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
