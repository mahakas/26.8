from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.learning_loop import TeacherLearningLoopService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.database.connection import Base
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        memory = MemoryService(db)
        for index, score in enumerate((0.45, 0.40, 0.35), start=1):
            memory.remember(
                user_id="smoke-25-6",
                memory_type=MemoryType.LEARNING_HISTORY,
                memory_key=f"attempt:smoke-{index}",
                value={"attempt_id": f"smoke-{index}", "user_id": "smoke-25-6", "task_type": "quiz", "total_score": score},
                confidence=1.0,
                source="smoke",
            )
        memory.remember(
            user_id="smoke-25-6",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:ریاضی",
            value={"topic": "ریاضی", "status": "active", "mastery_score": 0.4, "weakness_score": 0.6, "needs_retry": True},
            confidence=1.0,
            source="smoke",
        )
        feedback = TeacherFeedbackService(memory)
        feedback.record(
            user_id="smoke-25-6",
            conversation_id="smoke-conversation-25-6",
            feedback_id="smoke-feedback",
            rating=1,
            understood=False,
            strategy_effective=False,
        )
        state = TeacherLearningLoopService(memory).evaluate(
            "smoke-25-6",
            conversation_id="smoke-conversation-25-6",
            student_progress=MemoryProgressService(memory).build("smoke-25-6"),
            feedback_summary=feedback.summary("smoke-25-6", conversation_id="smoke-conversation-25-6"),
        )
        assert state.learning_outcome == "needs_support"
        assert state.recommended_mode == "remediation"
        assert state.next_action == "remediation_retry"
        print("multimodal teacher learning loop: OK")
        print(f"outcome: {state.learning_outcome} | mode: {state.recommended_mode} | action: {state.next_action}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
