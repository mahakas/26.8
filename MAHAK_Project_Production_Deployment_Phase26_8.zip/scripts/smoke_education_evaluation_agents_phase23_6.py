from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app

if os.getenv("PHASE23_6_LIVE") != "1":
    raise SystemExit("Set PHASE23_6_LIVE=1 before running this smoke test")

client = TestClient(create_app())
payload = {
    "agent_type": "VIDEO_AGENT",
    "query": "چه زمانی قانون دوم نیوتن گفته شد؟",
    "answer": "در این بخش از ویدیو توضیح داده می‌شود.",
    "evidence": [
        {"type": "video", "transcript": "قانون دوم نیوتن", "timestamp": {"start": 54.5, "end": 57.3}}
    ],
    "citations": [
        {"source_id": "lesson.mp4", "start_time_seconds": 54.5, "end_time_seconds": 57.3, "frame_path": "frame_0054.jpg"}
    ],
    "confidence": 0.8,
    "expected_agent_type": "VIDEO_AGENT",
}
first = client.post("/api/evaluation/agents", json=payload)
second = client.post("/api/evaluation/agents", json=payload)
first.raise_for_status()
second.raise_for_status()
assert first.json() == second.json()
result = first.json()
assert result["agent_selection_accuracy"] == 1.0
assert result["modality_evidence_coverage"] == 1.0
assert result["locator_completeness"] == 1.0

batch = client.post(
    "/api/evaluation/agents/batch",
    json={
        "cases": [
            {"case_id": "video", "request": payload},
            {
                "case_id": "document",
                "request": {
                    "agent_type": "DOCUMENT_AGENT",
                    "query": "صفحه چیست؟",
                    "answer": "اطلاعات در صفحه 3 است.",
                    "evidence": [{"type": "document", "source_id": "book.pdf", "page": 3}],
                    "citations": [{"source_id": "book.pdf", "page": 3}],
                    "confidence": 0.9,
                    "expected_agent_type": "DOCUMENT_AGENT",
                },
            },
        ]
    },
)
batch.raise_for_status()
batch_payload = batch.json()
assert batch_payload["evaluated_cases"] == 2
assert batch_payload["agent_type_counts"] == {"DOCUMENT_AGENT": 1, "VIDEO_AGENT": 1}

print("agent & multimodal evaluation: OK")
print(f"agent_selection_accuracy: {result['agent_selection_accuracy']}")
print(f"modality_evidence_coverage: {result['modality_evidence_coverage']}")
print(f"locator_completeness: {result['locator_completeness']}")
print(f"overall_score: {result['overall_score']}")
print("deterministic_repeat: True")
