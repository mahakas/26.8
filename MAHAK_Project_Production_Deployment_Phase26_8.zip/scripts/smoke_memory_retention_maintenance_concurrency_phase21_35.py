from __future__ import annotations

import os


def main() -> int:
    if os.getenv("PHASE21_35_LIVE") != "1":
        print("Set PHASE21_35_LIVE=1 to run phase 21.35 smoke test.")
        return 0

    from backend_v2.memory.retention_maintenance import (
        MemoryRetentionMaintenanceBusyError,
        MemoryRetentionMaintenanceService,
    )

    assert MemoryRetentionMaintenanceService._run_lock.acquire(blocking=False)
    try:
        service = MemoryRetentionMaintenanceService(enabled=True)
        try:
            service.run_with_report(dry_run=True)
        except MemoryRetentionMaintenanceBusyError:
            print("runtime: OK")
            print("concurrency_guard: OK")
            return 0
        raise AssertionError("Expected overlapping maintenance run to be rejected")
    finally:
        MemoryRetentionMaintenanceService._run_lock.release()


if __name__ == "__main__":
    raise SystemExit(main())
