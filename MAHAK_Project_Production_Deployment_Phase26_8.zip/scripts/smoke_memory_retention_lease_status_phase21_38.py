from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0, tzinfo=UTC)
        initial = service.status(now=now)
        assert initial.state == "available"
        handle = service.acquire(ttl_seconds=60, now=now)
        held = service.status(now=now + timedelta(seconds=15))
        assert held.state == "held" and held.remaining_seconds == 45
        released = service.release(handle)
        assert released is True
        final = service.status(now=now + timedelta(seconds=15))
        assert final.state == "available"
        print("runtime: OK")
        print("initial_status: available")
        print("held_status: OK")
        print("remaining_seconds: 45")
        print("release: OK")
        print("final_status: available")
        return 0
    finally:
        db.close(); engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
