from __future__ import annotations

import os
from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance_alert_persistence import (
    MemoryRetentionMaintenanceAlertSnapshotService,
)


def main() -> int:
    if os.getenv("PHASE21_49_LIVE") != "1":
        print("Set PHASE21_49_LIVE=1 to run the Phase 21.49 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True)
        for hour in (10, 11, 12):
            service.capture(now=datetime(2026, 9, 19, hour, 0, tzinfo=UTC))
        db.commit()

        app = create_app()

        def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db
        client = TestClient(app)
        page1 = client.get("/api/memory/maintenance/alert-snapshots", params={"limit": 2})
        assert page1.status_code == 200
        payload = page1.json()
        assert payload["count"] == 2
        assert payload["next_cursor"]
        assert payload["read_only"] is True

        page2 = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"limit": 2, "cursor": payload["next_cursor"]},
        )
        assert page2.status_code == 200
        assert page2.json()["count"] == 1
        assert not page2.json()["next_cursor"]

        bad = client.get(
            "/api/memory/maintenance/alert-snapshots",
            params={"cursor": "not-a-valid-cursor"},
        )
        assert bad.status_code == 422

        content_free = page1.json()["items"][0]
        assert "message" not in content_free
        assert "user_id" not in content_free
        assert "value" not in content_free
        assert "memory_key" not in content_free

        print("runtime: OK")
        print("history_api: OK")
        print("page1_count: 2")
        print("page2_count: 1")
        print("cursor: OK")
        print("content_free: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
