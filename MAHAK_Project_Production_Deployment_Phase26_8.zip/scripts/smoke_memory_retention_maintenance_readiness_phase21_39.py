from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionPolicy
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService
from backend_v2.memory.retention_maintenance_readiness import MemoryRetentionMaintenanceReadinessService
from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        now = datetime(2026, 9, 19, 12, 0, 0, tzinfo=UTC)
        db.add(MemoryRetentionPolicy(user_id="student-1", retention_days=30, max_delete=10))
        MemoryRetentionRunHistoryPolicyService(db).set(retention_days=14, max_delete=7)
        db.commit()

        service = MemoryRetentionMaintenanceReadinessService(db, enabled=True)
        available = service.snapshot(now=now)
        assert available.ready is True
        assert available.lease.state == "available"
        assert available.configured_memory_policy_users == 1

        lease = MemoryRetentionMaintenanceLeaseService(db).acquire(ttl_seconds=60, now=now)
        held = service.snapshot(now=now + timedelta(seconds=10))
        assert held.ready is False
        assert held.lease.state == "held"
        assert held.reasons == ("maintenance_lease_held",)
        assert held.lease.remaining_seconds == 50
        MemoryRetentionMaintenanceLeaseService(db).release(lease)

        final = service.snapshot(now=now + timedelta(seconds=10))
        assert final.ready is True
        assert final.lease.state == "available"
        assert final.read_only is True

        print("runtime: OK")
        print("available_readiness: OK")
        print("held_guard: OK")
        print("policy_visibility: OK")
        print("read_only: OK")
        return 0
    finally:
        db.close(); engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
