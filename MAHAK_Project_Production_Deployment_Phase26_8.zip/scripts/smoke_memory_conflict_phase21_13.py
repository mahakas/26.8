from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    if os.getenv("PHASE21_13_LIVE") != "1":
        print("Set PHASE21_13_LIVE=1 to run the phase 21.13 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    user_id = "smoke-phase21-13"
    record = {
        "id": "smoke-id",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": "profile",
        "value": {"grade": "10"},
        "confidence": 1.0,
        "source": "smoke",
    }

    try:
        seed = client.post(f"/api/memory/{user_id}/import", json={"user_id": user_id, "records": [record]})
        assert seed.status_code == 201
        response = client.post(
            f"/api/memory/{user_id}/import",
            json={
                "user_id": user_id,
                "conflict_policy": "skip",
                "records": [{**record, "value": {"grade": "11"}}],
            },
        )
        assert response.status_code == 201
        payload = response.json()
        assert payload["imported_count"] == 0
        assert payload["skipped_count"] == 1
        assert payload["conflict_count"] == 1
        assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1
        print("runtime: OK")
        print("policy: skip")
        print("conflicts: 1")
        print("imported: 0")
        print("state_preserved: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())