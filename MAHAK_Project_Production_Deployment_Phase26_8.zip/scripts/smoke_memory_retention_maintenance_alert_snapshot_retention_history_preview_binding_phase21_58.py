from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from uuid import uuid4


def main() -> int:
    if os.getenv("PHASE21_58_LIVE") != "1":
        print("Set PHASE21_58_LIVE=1 to run Phase 21.58 smoke test.")
        return 0

    os.environ["DATABASE_URL"] = "sqlite:///:memory:"

    from backend_v2.database.connection import Base, SessionLocal, engine
    from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
    )
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
    )

    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        run_id = f"phase21-58-old-{uuid4().hex[:12]}"
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id=run_id,
                started_at=now - timedelta(days=400, minutes=1),
                completed_at=now - timedelta(days=400),
                older_than=now - timedelta(days=430),
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=False,
                candidate_count=1,
                deleted_count=1,
            )
        )
        db.commit()

        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=365, max_delete=10)
        db.commit()

        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview_policy()
        assert preview.preview_token
        assert preview.configured is True
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert preview.read_only is True
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, run_id) is not None
        print("runtime: OK")
        print(f"preview: OK | candidates={preview.candidate_count} | token=True")

        result = service.apply_policy(preview_token=preview.preview_token)
        assert result.preview_bound is True
        assert result.older_than == preview.older_than
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, run_id) is None
        print("apply: OK | preview_bound=True")
        print(f"deleted_count: {result.deleted_count}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
