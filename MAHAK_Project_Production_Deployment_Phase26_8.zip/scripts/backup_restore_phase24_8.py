from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.core.config import settings
from backend_v2.operations.backup import BackupError, BackupService


def build_service() -> BackupService:
    return BackupService(
        database_url=settings.database_url,
        storage_dir=settings.storage_dir,
        backup_dir=settings.backup_dir,
        retention_count=settings.backup_retention_count,
        include_storage=settings.backup_include_storage,
        verify_after_create=settings.backup_verify_after_create,
        min_free_space_mb=settings.backup_min_free_space_mb,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="MAHAK Phase 24.8 backup/restore operations")
    sub = parser.add_subparsers(dest="command", required=True)

    backup = sub.add_parser("backup")
    backup.add_argument("--label", default="manual")

    verify = sub.add_parser("verify")
    verify.add_argument("archive", type=Path)

    sub.add_parser("list")

    prune = sub.add_parser("prune")
    prune.add_argument("--retain", type=int, default=settings.backup_retention_count)

    restore = sub.add_parser("restore")
    restore.add_argument("archive", type=Path)
    restore.add_argument("--force", action="store_true")
    restore.add_argument("--skip-pre-restore-backup", action="store_true")

    args = parser.parse_args()
    service = build_service()
    try:
        if args.command == "backup":
            archive = service.create_backup(label=args.label)
            print(f"backup: OK")
            print(f"archive: {archive}")
            return 0
        if args.command == "verify":
            manifest = service.verify_backup(args.archive)
            print("backup verification: OK")
            print(f"backup_id: {manifest.backup_id}")
            print(f"storage_files: {manifest.storage_file_count}")
            return 0
        if args.command == "list":
            for archive in service.list_backups():
                print(archive)
            return 0
        if args.command == "prune":
            service.retention_count = max(1, args.retain)
            removed = service.prune()
            print(f"prune: OK | removed={len(removed)} | retained={len(service.list_backups())}")
            return 0
        if args.command == "restore":
            print("WARNING: stop the MAHAK application before restoring production data.")
            manifest = service.restore_backup(
                args.archive,
                overwrite=args.force,
                create_pre_restore_backup=not args.skip_pre_restore_backup,
            )
            print("restore: OK")
            print(f"backup_id: {manifest.backup_id}")
            return 0
    except BackupError as exc:
        print(f"operation failed: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
