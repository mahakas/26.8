from __future__ import annotations

import os
from datetime import UTC, datetime

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryRetentionRun, MemoryRetentionRunResult
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_28_LIVE") != "1":
        print("Set PHASE21_28_LIVE=1 to run the Phase 21.28 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="smoke-history",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now.replace(year=now.year - 1),
                updated_at=now.replace(year=now.year - 1),
            )
        )
        db.commit()
        MemoryRetentionPolicyService(db).set(
            "smoke-history",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["smoke-history"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        run = db.get(MemoryRetentionRun, report.run_id)
        result = db.scalar(
            select(MemoryRetentionRunResult).where(MemoryRetentionRunResult.run_id == report.run_id)
        )
        assert report.status == "completed"
        assert report.dry_run is True
        assert report.would_delete_count == 1
        assert report.deleted_count == 0
        assert run is not None
        assert result is not None
        assert result.user_id == "smoke-history"
        print("runtime: OK")
        print("history: OK")
        print("run_id: OK")
        print("per_user_result: OK")
        print("dry_run_metadata_only: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
