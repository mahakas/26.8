from __future__ import annotations
import os, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from dotenv import load_dotenv
load_dotenv(ROOT/'.env')
if os.getenv('PHASE14_LIVE','0')!='1':
    print('Set PHASE14_LIVE=1 to run live RAG smoke test.'); raise SystemExit(0)
os.environ['MAHAK_PROVIDER_MODE']='live'
os.environ['VECTOR_STORE_BACKEND']='chroma'
os.environ['EMBED_BACKEND']='local'
os.environ['EMBED_MODEL']='BAAI/bge-m3'
from backend_v2.chat.context import ConversationContext
from backend_v2.chat.educational import EducationalChatService
from backend_v2.core.enums import ChatMode
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.runtime import V2Runtime
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService
TEXT='''قانون دوم نیوتن بیان می‌کند که شتاب یک جسم با نیروی خالص واردشده بر جسم متناسب و با جرم جسم معکوساً متناسب است. در قالب رابطه، نیروی خالص برابر جرم ضربدر شتاب است: F = m a. اگر نیروی خالص صفر باشد، شتاب صفر است.'''

def main():
    with tempfile.TemporaryDirectory(prefix='mahak_phase14_') as td:
        p=Path(td)/'physics10.txt'; p.write_text(TEXT,encoding='utf-8')
        ing=IngestionPipeline(chunk_size=500,overlap=60).process(p)
        r=V2Runtime()
        if r.vector_store.name!='chroma': print('vector_store=',r.vector_store.name); return 3
        spec=IndexSpec('physics10','bge-m3-local','bge-m3-v1',1024)
        result=KnowledgeIndexService(r.vector_store,r.embedding).index_chunks(
            ing.chunks,index_spec=spec,source_id='phase14-physics10',title='فیزیک دهم — قانون دوم نیوتن',
            scope_metadata={'grade_id':'10','subject_id':'physics'})
        print(f'index: OK | collection={result.collection} | chunks={result.indexed} | embedding={result.provider}/{result.model}/{result.dimension}')
        retr=RetrievalService(r.vector_store,r.embedding).retrieve(RetrievalRequest(
            'قانون دوم نیوتن چیست؟',RetrievalScope(grade_id='10',subject_id='physics'),result.collection,top_k=3,candidate_k=6,min_score=.25))
        print(f'retrieval: {"OK" if retr.found else "FAILED"} | hits={len(retr.accepted)}')
        if not retr.found: return 4
        ctx=ConversationContext('phase14-live-rag',None,ChatMode.EDUCATIONAL,grade_id='10',subject_id='physics')
        ans=EducationalChatService(r.retrieval if hasattr(r,'retrieval') else RetrievalService(r.vector_store,r.embedding),r.llm_orchestrator,
            collection=result.collection,session_collection='mahak_sessions',top_k=3,min_score=.25).ask(ctx,'قانون دوم نیوتن را توضیح بده')
        print(f'chat: {"OK" if ans.found else "FAILED"} | provider={ans.provider} | model={ans.model}')
        print('answer:',ans.answer); print('citations:',len(ans.citations)); return 0 if ans.found else 5
if __name__=='__main__': raise SystemExit(main())
