from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from fastapi.testclient import TestClient


def main() -> None:
    if __import__("os").environ.get("PHASE22_5_LIVE") != "1":
        print("Set PHASE22_5_LIVE=1 to run Phase 22.5 smoke test.")
        return

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        app = create_app()
        app.dependency_overrides[get_db] = lambda: (yield db)
        client = TestClient(app)

        start = client.post(
            "/api/education/sessions/start",
            json={
                "user_id": "phase22-5-smoke-user",
                "session_id": "phase22-5-smoke-session",
                "total_steps": 2,
                "question_count": 2,
                "topic": "قانون دوم نیوتن",
            },
        )
        start.raise_for_status()
        start_body = start.json()

        grade = client.post(
            "/api/education/attempts/grade",
            json={
                "user_id": "phase22-5-smoke-user",
                "attempt_id": "phase22-5-smoke-attempt-1",
                "task_type": "quiz",
                "topic": "قانون دوم نیوتن",
                "items": [
                    {
                        "item_id": "q1",
                        "question_type": "multiple_choice",
                        "question": "F چند است؟",
                        "topic": "قانون دوم نیوتن",
                        "answer": "wrong",
                        "correct_answer": "F=ma",
                        "options": ["F=ma", "F=m/a"],
                    }
                ],
            },
        )
        grade.raise_for_status()

        advance = client.post(
            "/api/education/sessions/phase22-5-smoke-session/advance",
            json={
                "user_id": "phase22-5-smoke-user",
                "attempt_id": "phase22-5-smoke-attempt-1",
            },
        )
        advance.raise_for_status()
        body = advance.json()

        replay = client.post(
            "/api/education/sessions/phase22-5-smoke-session/advance",
            json={
                "user_id": "phase22-5-smoke-user",
                "attempt_id": "phase22-5-smoke-attempt-1",
            },
        )
        replay.raise_for_status()
        replay_body = replay.json()

        assert start_body["current_step"] == 1
        assert body["current_step"] == 2
        assert body["completed_steps"] == 1
        assert body["recommendation"]["recommendation_type"] == "targeted_remediation"
        assert body["recommendation"]["difficulty"] == "easy"
        assert replay_body["idempotent_replay"] is True
        assert len(replay_body["step_results"]) == 1

        print("learning path: OK")
        print(f"session_id: {body['session_id']}")
        print(f"step: {body['current_step']}/{body['total_steps']}")
        print(f"completed_steps: {body['completed_steps']}")
        print(f"next_type: {body['recommendation']['recommendation_type']}")
        print(f"next_difficulty: {body['recommendation']['difficulty']}")
        print(f"topic: {body['recommendation']['topic']}")
        print("idempotent_replay: True")
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    main()
