from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_current_user, get_db
from backend_v2.api import teacher_v1
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User
from backend_v2.agents.teacher_session import TeacherSessionService
from backend_v2.memory.service import MemoryService


def main() -> int:
    engine = create_engine("sqlite://", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    user = User(id="phase26-smoke", email="phase26-smoke@example.com", password_hash="x", display_name="Phase 26", role="student")
    app = create_app()
    app.dependency_overrides[get_current_user] = lambda: user
    app.dependency_overrides[get_db] = lambda: db
    session_service = TeacherSessionService(MemoryService(db))
    teacher_v1.TeacherSessionService = lambda: session_service

    client = TestClient(app)
    try:
        contract = client.get("/api/teacher/v1/contract", headers={"X-Request-ID": "phase26-smoke-001"})
        assert contract.status_code == 200, contract.text
        assert contract.json()["contract"]["contract_version"] == "1.0"
        assert contract.headers["X-Request-ID"] == "phase26-smoke-001"
        assert contract.headers["X-Mahak-API-Version"] == "v1"
        print("teacher_api_contract: OK")

        invalid = client.post("/api/teacher/v1/ask", json={"query": "x"})
        assert invalid.status_code == 422
        assert invalid.json()["error"]["code"] == "VALIDATION_ERROR"
        assert invalid.json()["request_id"]
        print("structured_errors: OK")

        auth = TestClient(create_app()).get("/api/teacher/v1/contract")
        assert auth.status_code == 401
        assert auth.json()["error"]["code"] == "AUTHENTICATION_REQUIRED"
        auth.close()
        print("authentication_contract: OK")

        started = client.post("/api/teacher/v1/sessions/start", json={"session_id": "phase26-session", "conversation_id": "phase26-conv"})
        assert started.status_code == 200, started.text
        assert started.json()["status"] == "active"
        print("session_binding: OK")

        caps = client.get("/api/teacher/v1/capabilities")
        ready = client.get("/api/teacher/v1/readiness")
        assert caps.status_code == 200 and caps.json()["contract_version"] == "1.0"
        assert ready.status_code == 200 and ready.json()["status"] == "ready"
        print("capabilities: OK")
        print("readiness: OK")
        print("backward_compatibility: OK")
        return 0
    finally:
        client.close()
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
