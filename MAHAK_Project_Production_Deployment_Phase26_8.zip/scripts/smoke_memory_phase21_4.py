from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class SmokeAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def execute(self, query: str, **kwargs) -> AgentResult:
        return AgentResult(
            answer="evaluation-aware answer",
            evidence=[{"type": "general", "text": query}],
            citations=[{"title": "smoke source"}],
            confidence=0.85,
        )


def main() -> int:
    if os.getenv("PHASE21_4_LIVE") != "1":
        print("Set PHASE21_4_LIVE=1 to run the live smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        registry = AgentRegistry()
        registry.register(SmokeAgent())
        pipeline = UnifiedAgentPipeline(
            AgentRouter(registry),
            TeacherAgent(),
            memory=MemoryIntegrationService(memory),
        )
        context = ConversationContext(
            conversation_id="smoke-21-4",
            user_id="smoke-student-21-4",
            mode=ChatMode.GENERAL,
            subject_id="math",
        )

        result = pipeline.execute(
            "Help me with algebra",
            conversation_context=context,
            evaluation_signals={
                "topic": "algebra",
                "mastery_score": 0.3,
                "correctness_score": 0.4,
                "needs_retry": True,
                "attempts": 2,
                "evaluator_confidence": 0.95,
            },
        )
        db.commit()

        weak = memory.latest(
            context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
        )
        print("runtime: OK")
        print(f"agent_result: {result.answer}")
        print(f"weak_area_detected: {weak is not None}")
        print(f"weak_area_status: {weak.value['status'] if weak else 'none'}")
        print(f"confidence: {result.confidence}")
        return 0 if weak is not None and weak.value["status"] == "active" else 1
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
