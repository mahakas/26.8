from __future__ import annotations

import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.database.repositories.memory_retention_run_history_policy import (
    MemoryRetentionRunHistoryPolicyRepository,
)


def main() -> int:
    if os.getenv("PHASE21_44_LIVE") != "1":
        print("Set PHASE21_44_LIVE=1 to run Phase 21.44 smoke tests.")
        return 0

    fd, path = tempfile.mkstemp(prefix="mahak_phase21_44_", suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{Path(path).as_posix()}", future=True)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        db.add(
            MemoryRetentionMaintenanceRun(
                run_id="smoke-44-a",
                status="completed",
                started_at=datetime(2026, 9, 19, 10, 0),
                completed_at=datetime(2026, 9, 19, 10, 1),
                dry_run=False,
                cleanup_history=True,
                memory_status="completed",
                memory_user_count=1,
                memory_planned_count=1,
                memory_executed_count=1,
                memory_skipped_count=0,
                memory_failed_count=0,
                memory_candidate_count=2,
                memory_would_delete_count=2,
                memory_deleted_count=2,
                history_status="completed",
                history_configured=True,
                history_retention_days=365,
                history_max_delete=500,
                history_candidate_count=1,
                history_would_delete_count=1,
                history_deleted_count=1,
                history_error=None,
            )
        )
        MemoryRetentionRunHistoryPolicyRepository(db).upsert(retention_days=180, max_delete=50)
        db.commit()
        before = db.query(MemoryRetentionMaintenanceRun).count()

        app = create_app()

        def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db
        client = TestClient(app)
        response = client.get("/api/memory/maintenance/status", params={"assume_enabled": "true"})
        assert response.status_code == 200
        payload = response.json()
        assert payload["ready"] is True
        assert payload["lease"]["state"] == "available"
        assert payload["run_history_policy"]["retention_days"] == 180
        assert payload["summary"]["run_count"] == 1
        assert payload["latest_run"]["run_id"] == "smoke-44-a"
        assert payload["read_only"] is True
        assert db.query(MemoryRetentionMaintenanceRun).count() == before

        lease_endpoint = client.get("/api/memory/maintenance/status")
        assert lease_endpoint.status_code == 200
        assert lease_endpoint.json()["enabled"] is False
        assert lease_endpoint.json()["ready"] is False

        print("runtime: OK")
        print("operational_status: OK")
        print("latest_run: OK")
        print("policy: OK")
        print("readiness: OK")
        print("read_only: OK")
        db.close()
        engine.dispose()
        return 0
    finally:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
