from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]


def _run(label: str, command: Sequence[str], *, timeout: int = 900) -> int:
    print(f"\n== {label} ==")
    print("$ " + " ".join(command))
    completed = subprocess.run(command, cwd=ROOT, timeout=timeout)
    print(f"{label}: {'OK' if completed.returncode == 0 else 'FAILED'}")
    return completed.returncode


def _python(script: str, *args: str) -> list[str]:
    return [sys.executable, str(ROOT / script), *args]


def main() -> int:
    parser = argparse.ArgumentParser(description="MAHAK Phase 24.7 CI quality gates")
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--require-docker", action="store_true")
    args = parser.parse_args()

    commands: list[tuple[str, Sequence[str]]] = []
    if not args.skip_tests:
        commands.append(("pytest regression", [sys.executable, "-m", "pytest", "-q", "tests_v2"]))
    commands.extend(
        [
            ("compileall", [sys.executable, "-m", "compileall", "-q", "backend_v2", "scripts"]),
            (
                "security hardening smoke",
                _python("scripts/smoke_security_hardening_phase24_4.py"),
            ),
            (
                "observability smoke",
                _python("scripts/smoke_observability_monitoring_phase24_5.py"),
            ),
            (
                "docker packaging smoke",
                _python(
                    "scripts/smoke_docker_deployment_phase24_6.py",
                    "--require-docker" if args.require_docker else "--optional-docker",
                ),
            ),
            (
                "production readiness smoke",
                _python("scripts/smoke_production_readiness_phase24_8.py"),
            ),
        ]
    )

    failures = 0
    for label, command in commands:
        try:
            failures += 0 if _run(label, command) == 0 else 1
        except subprocess.TimeoutExpired:
            print(f"{label}: TIMEOUT")
            failures += 1

    print("\nCI quality gate: " + ("OK" if failures == 0 else f"FAILED ({failures})"))
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
