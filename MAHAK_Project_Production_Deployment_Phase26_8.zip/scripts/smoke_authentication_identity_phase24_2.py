"""Phase 24.2 authentication/identity smoke test."""
from __future__ import annotations

import os
import sys

# Allow direct Windows execution: python scripts/<name>.py
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> None:
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    register = client.post(
        "/api/auth/register",
        json={"email": "smoke@example.com", "password": "StrongPass123!", "display_name": "Smoke User"},
    )
    assert register.status_code == 201, register.text

    login = client.post(
        "/api/auth/login",
        json={"email": "smoke@example.com", "password": "StrongPass123!"},
    )
    assert login.status_code == 200, login.text
    tokens = login.json()

    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {tokens['access_token']}"})
    assert me.status_code == 200, me.text
    assert me.json()["email"] == "smoke@example.com"

    refresh = client.post("/api/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert refresh.status_code == 200, refresh.text
    rotated = refresh.json()
    assert rotated["refresh_token"] != tokens["refresh_token"]

    logout = client.post("/api/auth/logout", json={"refresh_token": rotated["refresh_token"]})
    assert logout.status_code == 204, logout.text
    assert client.post("/api/auth/refresh", json={"refresh_token": rotated["refresh_token"]}).status_code == 401

    print("authentication & identity: OK")
    print(f"user: {me.json()['email']}")
    print(f"access_token: issued ({tokens['expires_in']}s)")
    print("refresh_rotation: OK")
    print("logout_revocation: OK")
    engine.dispose()


if __name__ == "__main__":
    main()
