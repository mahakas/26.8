from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta


def main() -> int:
    if os.getenv("PHASE21_34_LIVE") != "1":
        print("Set PHASE21_34_LIVE=1 to run phase 21.34 smoke test.")
        return 0

    os.environ["DATABASE_URL"] = "sqlite:///:memory:"

    from backend_v2.database.connection import Base, SessionLocal, engine
    from backend_v2.database.models import LearningMemory, MemoryRetentionRun, MemoryRetentionRunResult
    from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService
    from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
    from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService
    from backend_v2.memory.types import MemoryType

    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="phase21-34",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=21),
                updated_at=now - timedelta(days=21),
            )
        )
        db.add(
            LearningMemory(
                user_id="phase21-34",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="recent",
                value_json={"q": "recent"},
                created_at=now - timedelta(days=2),
                updated_at=now - timedelta(days=2),
            )
        )
        history_time = now - timedelta(days=21)
        db.add(
            MemoryRetentionRun(
                run_id="phase21-34-old",
                status="completed",
                started_at=history_time - timedelta(minutes=1),
                completed_at=history_time,
                dry_run=False,
                user_count=1,
                planned_count=0,
                executed_count=1,
                skipped_count=0,
                failed_count=0,
                candidate_count=1,
                would_delete_count=1,
                deleted_count=1,
            )
        )
        db.add(
            MemoryRetentionRunResult(
                run_id="phase21-34-old",
                user_id="phase21-34",
                status="executed",
                candidate_count=1,
                deleted_count=1,
                would_delete_count=1,
                dry_run=False,
                retention_days=7,
                executed_at=history_time,
            )
        )
        MemoryRetentionPolicyService(db).set(
            "phase21-34",
            retention_days=7,
            max_delete=10,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        MemoryRetentionRunHistoryPolicyService(db).set(retention_days=7, max_delete=10)
        db.commit()

        service = MemoryRetentionMaintenanceService(db, enabled=True)
        dry = service.run_with_report(user_ids=["phase21-34"], dry_run=True)
        assert dry.status == "completed"
        assert dry.memory_report.deleted_count == 0
        assert dry.history is not None and dry.history.deleted_count == 0
        assert dry.history.would_delete_count == 1
        print("runtime: OK")
        print("dry_run: OK")

        live = service.run_with_report(user_ids=["phase21-34"], dry_run=False)
        assert live.status == "completed"
        assert live.memory_report.deleted_count == 1
        assert live.history is not None and live.history.deleted_count == 1
        print("execute: OK")
        print(f"memory_deleted: {live.memory_report.deleted_count}")
        print(f"history_deleted: {live.history.deleted_count}")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
