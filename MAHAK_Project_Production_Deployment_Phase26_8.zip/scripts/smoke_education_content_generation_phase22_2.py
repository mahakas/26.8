from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.core.enums import Capability
from backend_v2.education import EducationalContentGenerator, EducationalTaskPlanner, EducationalTaskPlanningRequest
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.vectorstores.base import VectorHit


def main() -> int:
    if os.getenv("PHASE22_2_LIVE", "0") != "1":
        print("Set PHASE22_2_LIVE=1 to run the Phase 22.2 smoke test.")
        return 0

    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter(
            "phase22-2-smoke",
            {Capability.STRUCTURED_OUTPUT},
            default_model="smoke-model",
            handler=lambda payload: json.dumps(
                {
                    "items": [
                        {
                            "item_id": "q1",
                            "question_type": "multiple_choice",
                            "question": "کدام رابطه قانون دوم نیوتن است؟",
                            "options": ["F=ma", "F=m/a", "F=a/m"],
                            "correct_answer": "F=ma",
                            "explanation": "رابطه در منبع آموزشی داده‌شده آمده است.",
                            "difficulty": "medium",
                            "topic": "قانون دوم نیوتن",
                            "source_refs": [1],
                        },
                        {
                            "item_id": "q2",
                            "question_type": "short_answer",
                            "question": "شتاب با کدام کمیت نسبت مستقیم دارد؟",
                            "options": [],
                            "correct_answer": "نیرو، با جرم ثابت",
                            "explanation": "این رابطه در منبع آموزشی داده‌شده آمده است.",
                            "difficulty": "medium",
                            "topic": "قانون دوم نیوتن",
                            "source_refs": [1],
                        },
                    ]
                }, ensure_ascii=False
            ),
        ),
        priority=1,
    )
    orchestrator = ProviderOrchestrator(registry, ProviderHealthManager(), max_attempts=1)
    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            task_type="quiz",
            difficulty="adaptive",
            question_count=2,
            topic="قانون دوم نیوتن",
        )
    )
    hit = VectorHit(
        id="phase22-2-source-1",
        document="قانون دوم نیوتن: F=ma و در جرم ثابت، شتاب با نیرو نسبت مستقیم دارد.",
        score=0.91,
        metadata={"source_id": "physics-10", "title": "فیزیک دهم", "page": 12},
    )
    result = EducationalContentGenerator(orchestrator).generate(plan, [hit])
    assert result.generated
    assert len(result.items) == 2
    assert result.items[0].source_refs == (1,)
    assert result.citations[0].page == 12

    print("education content generation: OK")
    print(f"task_type: {result.plan.task_type.value}")
    print(f"difficulty: {result.plan.difficulty.value}")
    print(f"questions: {len(result.items)}")
    print(f"sources: {result.source_count}")
    print(f"citations: {len(result.citations)}")
    print(f"confidence: {result.confidence}")
    print(f"provider: {result.provider}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
