from backend_v2.agents.teacher_session import TeacherSessionService

def main():
    service = TeacherSessionService()
    # Runtime smoke is intentionally guarded: no user data is mutated without an explicit user id.
    try:
        service.list("__phase25_10_smoke_nonexistent__", limit=1)
        print("teacher_sessions: OK")
    except Exception as exc:
        print(f"teacher_sessions: FAIL | {exc}")
        raise

if __name__ == "__main__":
    main()
