from backend_v2.agents.teacher_readiness import TeacherProductReadinessService

def main():
    service = TeacherProductReadinessService()
    caps = service.capabilities()
    ready = service.check("__phase25_12_smoke_nonexistent__")
    assert caps.current_phase == "25.12"
    assert ready.status == "ready"
    print("teacher_product_readiness: OK")

if __name__ == "__main__":
    main()
