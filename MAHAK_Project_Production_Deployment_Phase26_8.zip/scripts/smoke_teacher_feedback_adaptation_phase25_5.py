from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teaching_strategy import AdaptiveTeachingStrategyPlanner, TeachingMode
from backend_v2.memory.service import MemoryService

service = TeacherFeedbackService(MemoryService())
service.record(
    user_id="smoke-user",
    conversation_id="smoke-conversation",
    feedback_id="smoke-feedback",
    rating=1,
    understood=False,
    strategy_effective=False,
)
summary = service.summary("smoke-user", conversation_id="smoke-conversation")
strategy = AdaptiveTeachingStrategyPlanner().plan(
    requested_mode=TeachingMode.AUTO,
    query="این موضوع را توضیح بده",
    feedback_summary=summary,
)
assert summary.latest_signal == "needs_support"
assert strategy.mode is TeachingMode.REMEDIATION
assert strategy.scaffolding == "high"
print("multimodal teacher feedback & continuous adaptation: OK")
print(f"feedback: {summary.latest_signal} | mode: {strategy.mode.value} | scaffolding: {strategy.scaffolding}")
