from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models.memory_audit import MemoryAuditEvent


def main() -> int:
    if os.getenv("PHASE21_19_LIVE") != "1":
        print("Set PHASE21_19_LIVE=1 to run the live smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    db.add_all(
        [
            MemoryAuditEvent(user_id="smoke-21-19", action="delete", affected_count=2),
            MemoryAuditEvent(user_id="smoke-21-19", action="import", affected_count=3, skipped_count=1, conflict_count=1),
            MemoryAuditEvent(user_id="smoke-21-19", action="prune", affected_count=4),
            MemoryAuditEvent(user_id="other-smoke", action="clear", affected_count=99),
        ]
    )
    db.commit()

    try:
        response = client.get("/api/memory/smoke-21-19/audit/summary")
        if response.status_code != 200:
            raise AssertionError(response.text)
        payload = response.json()
        assert payload["event_count"] == 3
        assert payload["affected_count"] == 9
        assert payload["skipped_count"] == 1
        assert payload["conflict_count"] == 1
        assert payload["action_counts"] == {"delete": 1, "import": 1, "prune": 1}
        print("runtime: OK")
        print("event_count:", payload["event_count"])
        print("affected_count:", payload["affected_count"])
        print("action_counts: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
