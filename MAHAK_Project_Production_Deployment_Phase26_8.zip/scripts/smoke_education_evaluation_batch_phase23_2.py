from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


if os.getenv("PHASE23_2_LIVE") != "1":
    raise SystemExit("Set PHASE23_2_LIVE=1 before running this smoke test")

client = TestClient(create_app())
response = client.post(
    "/api/evaluation/batch",
    json={
        "dataset_id": "phase23-2-smoke",
        "cases": [
            {
                "case_id": "perfect",
                "request": {
                    "question": "قانون دوم نیوتن چیست؟",
                    "answer": "نیرو برابر جرم ضربدر شتاب است.",
                    "expected_answer": "نیرو برابر جرم ضربدر شتاب است.",
                    "expected_source_ids": ["physics.pdf"],
                    "retrieved_source_ids": ["physics.pdf"],
                    "cited_source_ids": ["physics.pdf"],
                    "evidence_texts": ["نیرو برابر جرم ضربدر شتاب است."],
                },
            },
            {
                "case_id": "partial",
                "request": {
                    "question": "انرژی جنبشی چیست؟",
                    "answer": "انرژی جنبشی به حرکت جسم مربوط است.",
                    "expected_answer": "انرژی جنبشی انرژی ناشی از حرکت جسم است.",
                    "expected_source_ids": ["energy.pdf"],
                    "retrieved_source_ids": ["energy.pdf"],
                    "cited_source_ids": ["energy.pdf"],
                    "evidence_texts": ["انرژی جنبشی انرژی ناشی از حرکت جسم است."],
                },
            },
        ],
    },
)
response.raise_for_status()
payload = response.json()
assert payload["total_cases"] == 2
assert payload["evaluated_cases"] == 2
assert payload["failed_cases"] == 0
assert payload["average_overall_score"] is not None

print("evaluation batch: OK")
print(f"dataset_id: {payload['dataset_id']}")
print(f"cases: {payload['evaluated_cases']}/{payload['total_cases']}")
print(f"average_overall_score: {payload['average_overall_score']}")
print(f"quality_bands: {payload['quality_band_counts']}")
print("deterministic_replay: True")
