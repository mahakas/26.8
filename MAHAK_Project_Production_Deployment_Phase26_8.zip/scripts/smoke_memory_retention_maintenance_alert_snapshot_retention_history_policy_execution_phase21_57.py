from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from uuid import uuid4


def main() -> int:
    if os.getenv("PHASE21_57_LIVE") != "1":
        print("Set PHASE21_57_LIVE=1 to run Phase 21.57 smoke test.")
        return 0

    os.environ["DATABASE_URL"] = "sqlite:///:memory:"

    from backend_v2.database.connection import Base, SessionLocal, engine
    from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
    )
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
    )

    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        run_id = f"phase21-57-old-{uuid4().hex[:12]}"
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id=run_id,
                started_at=now - timedelta(days=20, minutes=1),
                completed_at=now - timedelta(days=20),
                older_than=now - timedelta(days=50),
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=False,
                candidate_count=1,
                deleted_count=1,
            )
        )
        db.commit()

        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=10)
        db.commit()

        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview_policy()
        assert preview.configured is True
        assert preview.retention_days == 7
        assert preview.max_delete == 10
        assert preview.candidate_count >= 1
        assert preview.read_only is True
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, run_id) is not None
        print("runtime: OK")
        print("policy_preview: OK")

        result = service.apply_policy()
        assert result.configured is True
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, run_id) is None
        print("policy_apply: OK")
        print(f"deleted_count: {result.deleted_count}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
