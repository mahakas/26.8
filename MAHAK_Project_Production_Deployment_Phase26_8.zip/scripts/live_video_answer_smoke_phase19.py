from __future__ import annotations
import argparse, os, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from backend_v2.runtime import V2Runtime
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import VideoProcessor, SidecarTranscript, OpenCVFrameSampler
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService
from backend_v2.retrieval.service import RetrievalService, RetrievalRequest
from backend_v2.retrieval.query import RetrievalScope

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--video',required=True); ap.add_argument('--transcript'); args=ap.parse_args()
    video=Path(args.video)
    if args.transcript: video.with_suffix('.srt').write_text(Path(args.transcript).read_text(encoding='utf-8'),encoding='utf-8')
    runtime=V2Runtime(); print('runtime: OK')
    processor=VideoProcessor(runtime.llm_orchestrator, transcriber=SidecarTranscript(), frame_sampler=OpenCVFrameSampler(interval_seconds=10,max_frames=12), vision_enabled=True, frame_output_dir=video.parent/'phase19_frames')
    result=IngestionPipeline(video_processor=processor, chunk_size=700, overlap=80).process(video)
    print('video: OK | chunks=',len(result.chunks),'| frames=',result.document.metadata.get('frame_count'))
    spec=IndexSpec('physics10_video_19','bge-m3-local','bge-m3-v1',runtime.embedding.embed(['x']).dimension)
    indexed=KnowledgeIndexService(runtime.vector_store,runtime.embedding).index_chunks(result.chunks,index_spec=spec,source_id=video.stem,title=video.stem,scope_metadata={'source_type':'video','grade_id':'10','subject_id':'physics'})
    retr=RetrievalService(runtime.vector_store,runtime.embedding).retrieve(RetrievalRequest('قانون دوم نیوتن در ویدئو توضیح داده شده',RetrievalScope(grade_id='10',subject_id='physics'),indexed.collection,top_k=5,candidate_k=10,min_score=.2))
    print('retrieval: OK | hits=',len(retr.accepted))
    print('schema: VideoAnswerResponse')
    print('citations:',len(retr.accepted))
    for h in retr.accepted:
        print('-',h.metadata.get('start_time_seconds'),'->',h.metadata.get('end_time_seconds'),'frame=',bool(h.metadata.get('frame_path')))
    return 0
if __name__=='__main__': raise SystemExit(main())
