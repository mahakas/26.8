from __future__ import annotations
import os, sys, tempfile, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
load_dotenv(ROOT / '.env')

if os.getenv('PHASE18_LIVE', '0') != '1':
    print('Set PHASE18_LIVE=1 to run the live video smoke test.')
    raise SystemExit(0)

os.environ['MAHAK_PROVIDER_MODE'] = 'live'
os.environ['VECTOR_STORE_BACKEND'] = 'chroma'
os.environ['EMBED_BACKEND'] = 'local'
os.environ['EMBED_MODEL'] = 'BAAI/bge-m3'

from backend_v2.runtime import V2Runtime
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import VideoProcessor, SidecarTranscript, FFmpegFrameSampler
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalService, RetrievalRequest
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def _make_demo_video(path: Path) -> None:
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError('ffmpeg is required for live video smoke test')
    # 8-second black video with a silent audio track; transcript is supplied via sidecar.
    import subprocess
    cmd = [ffmpeg, '-y', '-f', 'lavfi', '-i', 'color=c=white:s=640x360:r=24', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '8', '-shortest', '-c:v', 'libx264', '-c:a', 'aac', str(path)]
    completed = subprocess.run(cmd, capture_output=True, text=True)
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr[-1500:])


def main() -> int:
    try:
        with tempfile.TemporaryDirectory(prefix='mahak_phase18_') as td_raw:
            td = Path(td_raw)
            video = td / 'newton-lesson.mp4'
            _make_demo_video(video)
            (td / 'newton-lesson.srt').write_text(
                '1\n00:00:02,000 --> 00:00:04,500\nقانون دوم نیوتن می‌گوید F = ma.\n\n'
                '2\n00:00:05,000 --> 00:00:07,500\nهرچه جرم بیشتر باشد برای نیروی یکسان شتاب کمتر است.\n', encoding='utf-8'
            )
            runtime = V2Runtime()
            processor = VideoProcessor(
                runtime.llm_orchestrator,
                transcriber=SidecarTranscript(),
                frame_sampler=FFmpegFrameSampler(interval_seconds=4, max_frames=2),
                frame_output_dir=td / 'frames',
                vision_enabled=True,
            )
            pipeline = IngestionPipeline(chunk_size=700, overlap=80, video_processor=processor)
            result = pipeline.process(video)
            print(f'video: OK | transcript={result.document.metadata.get("transcript_present")} | transcript_segments={result.document.metadata.get("transcript_segment_count")} | frames={result.document.metadata.get("frame_count")} | chunks={len(result.chunks)}')
            for chunk in result.chunks[:6]:
                print(' -', chunk.metadata.get('kind'), chunk.metadata.get('start_time_seconds'), chunk.metadata.get('end_time_seconds'))

            spec = IndexSpec('physics10_videos', 'bge-m3-local', 'bge-m3-v1', 1024)
            indexed = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
                result.chunks, index_spec=spec, source_id='phase18-video', title='قانون دوم نیوتن - ویدئو',
                scope_metadata={'grade_id':'10','subject_id':'physics','source_type':'video','video_id':result.document.metadata.get('video_id')},
            )
            print(f'index: OK | collection={indexed.collection} | chunks={indexed.indexed}')
            retr = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
                RetrievalRequest('در ویدئو قانون دوم نیوتن و رابطه F = ma چه زمانی توضیح داده شده؟', RetrievalScope(grade_id='10', subject_id='physics'), spec.collection_name, top_k=4, candidate_k=8, min_score=.20)
            )
            print(f'retrieval: {"OK" if retr.found else "FAILED"} | hits={len(retr.accepted)}')
            for hit in retr.accepted:
                print(' -', hit.metadata.get('kind'), hit.metadata.get('start_time_seconds'), hit.metadata.get('end_time_seconds'), hit.metadata.get('video_id'))
            return 0 if indexed.indexed and retr.found else 3
    except Exception as exc:
        print(f'ERROR: {type(exc).__name__}: {exc}')
        return 10


if __name__ == '__main__':
    raise SystemExit(main())
