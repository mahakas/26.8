from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        memory = MemoryService(db)
        interactions = TeacherInteractionService(memory)
        item = interactions.record(
            user_id="smoke-25-7",
            conversation_id="conv-smoke-25-7",
            question="فاصله‌گذاری چیست؟",
            agent_types=("DOCUMENT_AGENT",),
            modalities=("document",),
            strategy_mode="explain",
            strategy_difficulty="standard",
            learning_outcome="stable",
            recommended_mode="explain",
            recommended_difficulty="standard",
            next_action="check_understanding",
            confidence=0.88,
            evidence_count=1,
            citation_count=1,
            found=True,
        )
        feedback = TeacherFeedbackService(memory).record(
            user_id="smoke-25-7",
            conversation_id="conv-smoke-25-7",
            feedback_id="feedback-smoke-25-7",
            interaction_id=item.interaction_id,
            rating=5,
            understood=True,
            strategy_effective=True,
        )
        fetched = interactions.get("smoke-25-7", item.interaction_id)
        assert fetched is not None
        assert feedback.interaction_id == item.interaction_id
        assert feedback.signal == "progressing"
        print("interaction: OK")
        print("feedback_binding: OK")
        print(f"interaction_id: {item.interaction_id}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
