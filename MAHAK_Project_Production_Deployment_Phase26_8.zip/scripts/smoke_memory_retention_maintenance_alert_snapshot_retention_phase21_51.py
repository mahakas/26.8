from __future__ import annotations

import os
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot
from backend_v2.memory import (
    MemoryRetentionMaintenanceAlertSnapshotPolicyService,
    MemoryRetentionMaintenanceAlertSnapshotRetentionService,
)


def main() -> int:
    if os.getenv("PHASE21_51_LIVE") != "1":
        print("Set PHASE21_51_LIVE=1 to run live smoke test.")
        return 0

    fd, path = tempfile.mkstemp(prefix="mahak_phase21_51_", suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{path}")
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)
        db = Session()
        try:
            now = datetime.now(UTC).replace(tzinfo=None)
            db.add_all([
                MemoryRetentionMaintenanceAlertSnapshot(
                    snapshot_id="old-a", captured_at=now - timedelta(days=40), health="healthy", ready=True,
                    severity="none", stale_after_seconds=86400, alert_count=0, alert_codes="",
                    assume_enabled=False, use_policy=False,
                ),
                MemoryRetentionMaintenanceAlertSnapshot(
                    snapshot_id="old-b", captured_at=now - timedelta(days=35), health="healthy", ready=True,
                    severity="none", stale_after_seconds=86400, alert_count=0, alert_codes="",
                    assume_enabled=False, use_policy=False,
                ),
            ])
            db.commit()

            policy = MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
            preview = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).preview_policy()
            assert preview.candidate_count == 2
            assert preview.would_delete_count == 1
            print("runtime: OK")
            print("preview: OK")

            result = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db).apply_policy()
            assert result.candidate_count == 2
            assert result.deleted_count == 1
            remaining = db.scalar(select(MemoryRetentionMaintenanceAlertSnapshot).where(MemoryRetentionMaintenanceAlertSnapshot.snapshot_id == "old-b"))
            assert remaining is not None
            print("apply: OK")
            print(f"deleted_count: {result.deleted_count}")
            return 0
        finally:
            db.close()
            engine.dispose()
    finally:
        Path(path).unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
