from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun


def main() -> int:
    if os.getenv("PHASE21_46_LIVE") != "1":
        print("Set PHASE21_46_LIVE=1 to run Phase 21.46 smoke test.")
        return 0

    with TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "phase21_46_smoke.db"
        engine = create_engine(
            f"sqlite:///{db_path}",
            future=True,
            connect_args={"check_same_thread": False},
        )
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        try:
            now = datetime(2026, 9, 19, 12, 0)
            db.add(
                MemoryRetentionMaintenanceRun(
                    run_id="phase21-46-smoke",
                    status="completed",
                    started_at=now - timedelta(seconds=30),
                    completed_at=now - timedelta(seconds=20),
                    dry_run=False,
                    cleanup_history=True,
                    memory_status="completed",
                    memory_user_count=1,
                    memory_planned_count=1,
                    memory_executed_count=1,
                    memory_skipped_count=0,
                    memory_failed_count=0,
                    memory_candidate_count=1,
                    memory_would_delete_count=1,
                    memory_deleted_count=1,
                    history_status="completed",
                    history_configured=True,
                    history_retention_days=365,
                    history_max_delete=500,
                    history_candidate_count=1,
                    history_would_delete_count=1,
                    history_deleted_count=1,
                )
            )
            db.commit()
            app = create_app()

            def override_get_db():
                yield db

            app.dependency_overrides[get_db] = override_get_db
            client = TestClient(app)
            response = client.get(
                "/api/memory/maintenance/alerts",
                params={"assume_enabled": "true", "stale_after_seconds": 60},
            )
            response.raise_for_status()
            payload = response.json()
            assert payload["severity"] == "none"
            assert payload["alerts"] == []
            assert payload["read_only"] is True

            disabled = client.get("/api/memory/maintenance/alerts")
            disabled.raise_for_status()
            assert disabled.json()["alerts"][0]["code"] == "maintenance_disabled"
            print("runtime: OK")
            print("alerts_api: OK")
            print("healthy: OK")
            print("disabled_guard: OK")
            print("read_only: OK")
        finally:
            db.close()
            engine.dispose()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
