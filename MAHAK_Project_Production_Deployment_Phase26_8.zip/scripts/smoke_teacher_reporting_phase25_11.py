from backend_v2.agents.teacher_report import TeacherReportService

def main():
    report = TeacherReportService().build("__phase25_11_smoke_nonexistent__", limit=1)
    csv_text = TeacherReportService.to_csv(report)
    assert "section,interaction_id" in csv_text
    print("teacher_reporting: OK")

if __name__ == "__main__":
    main()
