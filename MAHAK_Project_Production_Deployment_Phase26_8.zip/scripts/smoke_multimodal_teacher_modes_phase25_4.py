from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.agents.teaching_strategy import AdaptiveTeachingStrategyPlanner, TeachingMode
from backend_v2.memory.personalization import PersonalizationContext
from backend_v2.memory.progress import StudentProgressProfile


def main() -> int:
    planner = AdaptiveTeachingStrategyPlanner()
    remediation = planner.plan(
        requested_mode=TeachingMode.AUTO,
        query="قانون دوم نیرو را توضیح بده",
        personalization=PersonalizationContext(weak_areas=("قانون دوم نیرو",), learning_level="beginner"),
        student_progress=StudentProgressProfile(
            "smoke",
            {},
            active_weak_areas=("قانون دوم نیرو",),
            average_confidence=0.4,
        ),
        modalities=("document", "video"),
        source_confidence=0.82,
    )
    explicit = planner.plan(requested_mode=TeachingMode.SOCRATIC, query="خلاصه بده")

    assert remediation.mode is TeachingMode.REMEDIATION
    assert remediation.scaffolding == "high"
    assert "قانون دوم نیرو" in remediation.focus
    assert explicit.mode is TeachingMode.SOCRATIC
    assert explicit.interaction_style == "guided_questions"
    assert 0.0 <= 0.82 <= 1.0
    print("multimodal teacher modes & adaptive strategy: OK")
    print(f"auto_mode: {remediation.mode.value} | difficulty={remediation.difficulty} | scaffolding={remediation.scaffolding}")
    print(f"explicit_mode: {explicit.mode.value} | interaction={explicit.interaction_style}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
