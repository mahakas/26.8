from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_9_LIVE") != "1":
        print("Set PHASE21_9_LIVE=1 to run the Phase 21.9 memory export smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db

    try:
        user_id = "student-smoke-21-9"
        memory = MemoryService(db)
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"grade": "10"},
        )
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"topic": "algebra", "status": "active", "mastery_score": 0.3},
        )
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="lesson",
            value={"topic": "algebra", "citation_count": 1},
            confidence=0.8,
        )
        db.commit()

        client = TestClient(app)
        response = client.get(f"/api/memory/{user_id}/export")
        body = response.json()
        assert response.status_code == 200
        assert body["count"] == 3
        assert body["user_id"] == user_id
        assert body["progress"]["active_weak_areas"] == ["algebra"]
        assert body["progress"]["total_citations"] == 1

        print("runtime: OK")
        print(f"export_records: {body['count']}")
        print("export_endpoint: OK")
        print(f"active_weak_areas: {tuple(body['progress']['active_weak_areas'])}")
        print("read_only: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
