from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    if os.getenv("PHASE22_9_LIVE") != "1":
        print("PHASE22_9_LIVE=1 is required")
        return 2

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)

    try:
        with TestClient(app) as client:
            start = client.post(
                "/api/education/learning-plans/start",
                json={
                    "user_id": "phase22-9-smoke-user",
                    "plan_id": "phase22-9-smoke-plan",
                    "total_sessions": 1,
                    "session_steps": 1,
                    "topic": "قانون دوم نیوتن",
                    "mastery_target": 0.75,
                    "max_remediation_sessions": 1,
                },
            )
            assert start.status_code == 200, start.text

            first = client.post(
                "/api/education/recommendations/feedback/history",
                json={
                    "user_id": "phase22-9-smoke-user",
                    "learning_plan_id": "phase22-9-smoke-plan",
                    "feedback_id": "phase22-9-smoke-feedback",
                    "task_type": "quiz",
                    "question_count": 4,
                },
            )
            assert first.status_code == 200, first.text
            first_body = first.json()

            replay = client.post(
                "/api/education/recommendations/feedback/history",
                json={
                    "user_id": "phase22-9-smoke-user",
                    "learning_plan_id": "phase22-9-smoke-plan",
                    "feedback_id": "phase22-9-smoke-feedback",
                    "task_type": "quiz",
                    "question_count": 4,
                },
            )
            assert replay.status_code == 200, replay.text

            history = client.get(
                "/api/education/recommendations/feedback/history",
                params={
                    "user_id": "phase22-9-smoke-user",
                    "learning_plan_id": "phase22-9-smoke-plan",
                },
            )
            assert history.status_code == 200, history.text
            history_body = history.json()

            print("learning recommendation feedback history: OK")
            print(f"feedback_id: {first_body['entry']['feedback_id']}")
            print(f"action: {first_body['entry']['feedback_action']}")
            print(f"replayed: {replay.json()['replayed']}")
            print(f"history_count: {history_body['total_feedback']}")
            print(f"latest_action: {history_body['latest_action']}")
            return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
