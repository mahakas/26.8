from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_6_LIVE") != "1":
        print("Set PHASE21_6_LIVE=1 to run Phase 21.6 memory lifecycle smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        for index in range(3):
            memory.remember(
                user_id="phase21-6-user",
                memory_type=MemoryType.LEARNING_HISTORY,
                memory_key=f"turn:{index}",
                value={"index": index},
            )
        deletable = memory.remember(
            user_id="phase21-6-user",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:delete",
            value={"question": "What is algebra?"},
        )
        db.commit()

        deleted = memory.delete("phase21-6-user", deletable.id)
        pruned = memory.prune(
            "phase21-6-user",
            max_records=2,
            memory_type=MemoryType.LEARNING_HISTORY,
        )
        remaining = memory.list("phase21-6-user")

        print("runtime: OK")
        print(f"delete: {'OK' if deleted else 'FAILED'}")
        print(f"pruned_records: {pruned}")
        print(f"remaining_memories: {len(remaining)}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
