from __future__ import annotations

import argparse

from backend_v2.auth.rbac import Role
from backend_v2.auth.service import AuthService, AuthError
from backend_v2.database.connection import SessionLocal, create_all
from backend_v2.database.models.auth import User
from sqlalchemy import select


def main() -> int:
    parser = argparse.ArgumentParser(description="Assign a MAHAK user role.")
    parser.add_argument("--email", required=True)
    parser.add_argument("--role", choices=[role.value for role in Role], required=True)
    args = parser.parse_args()

    create_all()
    db = SessionLocal()
    try:
        user = db.scalar(select(User).where(User.email == args.email.strip().lower()))
        if user is None:
            raise SystemExit("user was not found")
        updated = AuthService(db).set_role(user.id, args.role)
        print(f"role updated: {updated.email} -> {updated.role}")
        return 0
    except AuthError as exc:
        print(f"role update failed: {exc}")
        return 1
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
