from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.education import EducationalDifficulty, EducationalTaskPlanner, EducationalTaskPlanningRequest, EducationalTaskType


def main() -> int:
    if os.getenv("PHASE22_1_LIVE", "0") != "1":
        print("Set PHASE22_1_LIVE=1 to run Phase 22.1 smoke test.")
        return 0

    plan = EducationalTaskPlanner().plan(
        EducationalTaskPlanningRequest(
            task_type=EducationalTaskType.QUIZ,
            difficulty=EducationalDifficulty.ADAPTIVE,
            question_count=5,
            topic="قانون دوم نیوتن",
            grade_id="10",
            subject_id="physics",
        )
    )

    print("education planner: OK")
    print("task_type:", plan.task_type.value)
    print("difficulty:", plan.difficulty.value)
    print("questions:", plan.question_count)
    print("topic:", plan.topic)
    print("focus_topics:", list(plan.focus_topics))
    print("memory_used:", plan.memory_used)
    print("content_generation:", "deferred_to_phase22_2")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
