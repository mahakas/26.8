from __future__ import annotations

from backend_v2.agents.teacher_dashboard import TeacherDashboardService
from backend_v2.agents.teacher_feedback import TeacherFeedbackService
from backend_v2.agents.teacher_interaction import TeacherInteractionService
from backend_v2.memory.service import MemoryService


def main() -> None:
    memory = MemoryService()
    user = "phase25-9-smoke"
    conversation = "phase25-9-conversation"
    interaction = TeacherInteractionService(memory).record(
        user_id=user,
        conversation_id=conversation,
        question="Phase 25.9 smoke",
        agent_types=("DOCUMENT_AGENT",),
        modalities=("document",),
        strategy_mode="explain",
        strategy_difficulty="standard",
        learning_outcome="progressing",
        recommended_mode="practice",
        recommended_difficulty="standard",
        next_action="guided_practice",
        confidence=0.9,
        evidence_count=1,
        citation_count=1,
        found=True,
        learning_plan_id=None,
    )
    TeacherFeedbackService(memory).record(
        user_id=user,
        conversation_id=conversation,
        feedback_id="phase25-9-feedback",
        interaction_id=interaction.interaction_id,
        rating=5,
        understood=True,
        strategy_effective=True,
    )
    result = TeacherDashboardService(memory).build(user, conversation_id=conversation)
    assert result.outcome_analytics["total_interactions"] == 1
    assert result.feedback_summary["total"] == 1
    assert result.learning_loop["feedback_signal"] == "progressing"
    print("phase25.9 dashboard: OK")


if __name__ == "__main__":
    main()
