from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> None:
    if os.getenv("PHASE21_8_LIVE") != "1":
        print("Set PHASE21_8_LIVE=1 to run the Phase 21.8 smoke test.")
        return

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()

    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    memory = MemoryService(db)
    owner_record = memory.remember(
        user_id="phase21-8",
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key="turn:0",
        value={"topic": "algebra"},
        conversation_id="conv-a",
    )
    memory.remember(
        user_id="phase21-8",
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key="turn:1",
        value={"topic": "geometry"},
        conversation_id="conv-b",
    )
    memory.remember(
        user_id="phase21-8-other",
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key="other:1",
        value={"topic": "physics"},
    )
    db.commit()

    denied = client.delete(f"/api/memory/phase21-8-other/records/{owner_record.id}")
    cleared = client.delete(
        "/api/memory/phase21-8/records",
        params={"conversation_id": "conv-a"},
    )
    prune = client.post(
        "/api/memory/phase21-8/prune",
        params={"max_records": 1, "memory_type": "learning_history"},
    )
    other_records = client.get("/api/memory/phase21-8-other/records")

    assert denied.status_code == 404
    assert cleared.status_code == 200 and cleared.json()["deleted_count"] == 1
    assert prune.status_code == 200 and prune.json()["deleted_count"] == 0
    assert other_records.status_code == 200 and other_records.json()["count"] == 1

    print("runtime: OK")
    print("delete_owner_scope: OK")
    print(f"clear_deleted: {cleared.json()['deleted_count']}")
    print(f"prune_deleted: {prune.json()['deleted_count']}")
    print("cross_user_isolation: OK")

    db.close()
    engine.dispose()


if __name__ == "__main__":
    main()
