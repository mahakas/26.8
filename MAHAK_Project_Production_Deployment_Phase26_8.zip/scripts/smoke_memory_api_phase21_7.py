from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> None:
    if os.getenv("PHASE21_7_LIVE") != "1":
        print("Set PHASE21_7_LIVE=1 to run the Phase 21.7 smoke test.")
        return

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()

    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    memory = MemoryService(db)
    memory.remember(
        user_id="phase21-7",
        memory_type=MemoryType.STUDENT_PROFILE,
        memory_key="profile",
        value={"learning_level": "grade10"},
    )
    memory.remember(
        user_id="phase21-7",
        memory_type=MemoryType.WEAK_AREA,
        memory_key="weak:algebra",
        value={"topic": "algebra", "status": "active", "mastery_score": 0.4},
    )
    memory.remember(
        user_id="phase21-7",
        memory_type=MemoryType.LEARNING_HISTORY,
        memory_key="turn:1",
        value={"topic": "algebra", "agent_type": "DOCUMENT_AGENT", "citation_count": 2},
        confidence=0.82,
    )
    memory.remember(
        user_id="phase21-7",
        memory_type=MemoryType.PREVIOUS_QUESTION,
        memory_key="q:1",
        value={"question": "معادله چیست؟"},
    )
    db.commit()

    records = client.get("/api/memory/phase21-7/records")
    progress = client.get("/api/memory/phase21-7/progress")

    assert records.status_code == 200
    assert progress.status_code == 200
    assert progress.json()["active_weak_areas"] == ["algebra"]
    assert progress.json()["latest_question"] == "معادله چیست؟"

    print("runtime: OK")
    print(f"records: {records.json()['count']}")
    print("records_endpoint: OK")
    print(f"active_weak_areas: {tuple(progress.json()['active_weak_areas'])}")
    print("progress_endpoint: OK")
    print(f"average_confidence: {progress.json()['average_confidence']}")

    db.close()
    engine.dispose()


if __name__ == "__main__":
    main()
