from __future__ import annotations

import argparse
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

if os.getenv("PHASE18A_LIVE", "0") != "1":
    print("Set PHASE18A_LIVE=1 to run the live transcript-only video smoke test.")
    raise SystemExit(0)

os.environ["MAHAK_PROVIDER_MODE"] = "live"
os.environ["VECTOR_STORE_BACKEND"] = "chroma"
os.environ["EMBED_BACKEND"] = "local"
os.environ["EMBED_MODEL"] = "BAAI/bge-m3"

from backend_v2.runtime import V2Runtime
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import SidecarTranscript, VideoProcessor
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


class NoFrameSampler:
    def sample(self, path: Path, output_dir: Path, duration: float | None = None):
        return []


def main() -> int:
    parser = argparse.ArgumentParser(description="Phase 18A: real MP4 + SRT transcript-only RAG smoke test (no ffmpeg).")
    parser.add_argument("--video", required=True, help="Path to the real MP4 file")
    parser.add_argument("--transcript", required=True, help="Path to a matching SRT/VTT/TXT transcript")
    parser.add_argument("--query", default="معادله x + 4 = 16 در کدام بخش ویدئو توضیح داده می‌شود؟")
    args = parser.parse_args()

    video = Path(args.video).expanduser().resolve()
    transcript = Path(args.transcript).expanduser().resolve()
    if not video.is_file():
        raise FileNotFoundError(f"Video not found: {video}")
    if not transcript.is_file():
        raise FileNotFoundError(f"Transcript not found: {transcript}")

    with tempfile.TemporaryDirectory(prefix="mahak_phase18a_") as td_raw:
        td = Path(td_raw)
        # SidecarTranscript intentionally requires same-stem files.
        staged_video = td / f"{video.stem}{video.suffix.lower()}"
        staged_transcript = td / f"{video.stem}{transcript.suffix.lower()}"
        shutil.copy2(video, staged_video)
        shutil.copy2(transcript, staged_transcript)

        runtime = V2Runtime()
        processor = VideoProcessor(
            vision_orchestrator=None,
            transcriber=SidecarTranscript(),
            frame_sampler=NoFrameSampler(),
            vision_enabled=False,
        )
        pipeline = IngestionPipeline(video_processor=processor)
        result = pipeline.process(staged_video)

        segments = result.document.metadata.get("video_segments", [])
        if not segments:
            print("ERROR: no transcript segments were produced")
            return 3

        first = segments[0]
        last = segments[-1]
        print(
            "video: OK | "
            f"file={video.name} | size_mb={video.stat().st_size / 1048576:.2f} | "
            f"duration_from_transcript={last['end_time_seconds']:.3f}s | "
            f"transcript_segments={len(segments)} | frames=0"
        )
        print(
            "timestamps: "
            f"first={first['start_time_seconds']:.3f}->{first['end_time_seconds']:.3f} | "
            f"last={last['start_time_seconds']:.3f}->{last['end_time_seconds']:.3f}"
        )
        for chunk in result.chunks[:6]:
            print(" -", chunk.metadata.get("kind"), chunk.metadata.get("start_time_seconds"), chunk.metadata.get("end_time_seconds"), chunk.text[:120])

        spec = IndexSpec("physics10_videos_18a", "bge-m3-local", "bge-m3-v1", 1024)
        indexed = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
            result.chunks,
            index_spec=spec,
            source_id="phase18a-real-video",
            title=video.stem,
            scope_metadata={
                "grade_id": "8",
                "subject_id": "mathematics",
                "source_type": "video",
                "video_id": video.stem,
            },
        )
        print(
            f"index: OK | collection={indexed.collection} | chunks={indexed.indexed} | "
            f"embedding={indexed.provider}/{indexed.model}/{indexed.dimension}"
        )

        retrieval = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
            RetrievalRequest(
                args.query,
                RetrievalScope(grade_id="8", subject_id="mathematics"),
                spec.collection_name,
                top_k=5,
                candidate_k=12,
                min_score=0.15,
            )
        )
        print(f"retrieval: {'OK' if retrieval.found else 'FAILED'} | hits={len(retrieval.accepted)}")
        for hit in retrieval.accepted:
            print(
                " -",
                hit.metadata.get("kind"),
                hit.metadata.get("start_time_seconds"),
                hit.metadata.get("end_time_seconds"),
                hit.metadata.get("video_id"),
                "score=", round(hit.score, 4),
            )
        return 0 if indexed.indexed and retrieval.found else 4


if __name__ == "__main__":
    raise SystemExit(main())
