from __future__ import annotations

import os
from pathlib import Path
import sqlite3
import tempfile


def main() -> int:
    if os.getenv("PHASE21_54_LIVE") != "1":
        print("Set PHASE21_54_LIVE=1 to run live retention summary smoke tests.")
        return 0

    fd, path = tempfile.mkstemp(prefix="mahak_phase21_54_", suffix=".db")
    os.close(fd)
    db_path = Path(path)
    conn = None
    try:
        import backend_v2.database.models  # noqa: F401
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from backend_v2.database.connection import Base
        from backend_v2.memory import MemoryRetentionMaintenanceAlertSnapshotRetentionService
        from backend_v2.memory.retention_maintenance_alert_snapshot_policy import MemoryRetentionMaintenanceAlertSnapshotPolicyService
        from backend_v2.database.repositories import MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository

        engine = create_engine(f"sqlite:///{db_path}", future=True)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        try:
            print("runtime: OK")
            service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
            result1 = service.apply_policy()
            db.commit()
            MemoryRetentionMaintenanceAlertSnapshotPolicyService(db).set(retention_days=30, max_delete=1)
            token = service.preview_policy().preview_token
            if not token:
                raise RuntimeError("preview token missing")
            result2 = service.apply_policy(preview_token=token)
            db.commit()
            summary = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).summary()
            if summary["run_count"] != 2 or summary["configured_run_count"] != 1 or summary["preview_bound_run_count"] != 1:
                raise RuntimeError(f"unexpected summary: {summary}")
            print(
                "summary: OK | "
                f"run_count={summary['run_count']} | "
                f"configured={summary['configured_run_count']} | "
                f"preview_bound={summary['preview_bound_run_count']}"
            )
            if result1.run_id == result2.run_id:
                raise RuntimeError("run IDs must be distinct")
            print("history: OK | distinct_run_ids=True")
        finally:
            db.close()
            engine.dispose()
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
        try:
            db_path.unlink(missing_ok=True)
        except PermissionError:
            pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
