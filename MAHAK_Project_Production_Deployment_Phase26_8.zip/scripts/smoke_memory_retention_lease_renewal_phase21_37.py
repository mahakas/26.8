from __future__ import annotations

import os
from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance_lease import (
    MemoryRetentionMaintenanceLeaseLostError,
    MemoryRetentionMaintenanceLeaseService,
)


def main() -> int:
    if os.getenv("PHASE21_37_LIVE") != "1":
        print("Set PHASE21_37_LIVE=1 to run Phase 21.37 smoke test.")
        return 0
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        service = MemoryRetentionMaintenanceLeaseService(db)
        now = datetime(2026, 9, 19, 12, 0, 0)
        handle = service.acquire(ttl_seconds=10, now=now)
        renewed = service.renew(handle, ttl_seconds=30, now=now + timedelta(seconds=5))
        assert renewed.owner_token == handle.owner_token
        assert renewed.expires_at == now + timedelta(seconds=35)
        print("runtime: OK")
        print("renewal: OK")
        try:
            service.renew(renewed, ttl_seconds=30, now=now + timedelta(seconds=36))
        except MemoryRetentionMaintenanceLeaseLostError:
            print("expired_guard: OK")
        else:
            print("expired_guard: FAIL")
            return 1
        assert service.release(renewed) is True
        print("release: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
