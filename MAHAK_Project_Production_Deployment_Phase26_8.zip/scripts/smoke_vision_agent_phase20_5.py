from __future__ import annotations

from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.types import AgentType
from backend_v2.agents.vision import VisionAgent


def main() -> int:
    registry = AgentRegistry()
    registry.register(VisionAgent())
    router = AgentRouter(registry)

    result = router.execute(
        "explain this image",
        hits=[
            {
                "text": "Diagram of Newton's second law: F = ma.",
                "metadata": {
                    "source_id": "smoke-image-1",
                    "title": "Newton diagram",
                    "image_id": "smoke-diagram-1",
                    "image_path": "images/smoke-diagram-1.png",
                },
            }
        ],
    )

    assert result.answer
    assert result.confidence == 0.8
    assert result.evidence
    assert result.evidence[0]["type"] == "image"
    assert result.evidence[0]["image_id"] == "smoke-diagram-1"
    assert result.citations
    assert result.citations[0]["image_id"] == "smoke-diagram-1"

    print("runtime: OK")
    print("router: IMAGE_AGENT")
    print("vision_agent: OK")
    print("evidence: OK")
    print("citations: OK")
    print("confidence:", result.confidence)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
