from __future__ import annotations

import os

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def main() -> int:
    if os.getenv("PHASE21_21_LIVE") != "1":
        print("Set PHASE21_21_LIVE=1 to run the Phase 21.21 smoke test.")
        return 0

    client = TestClient(create_app())
    user_id = "phase21-21-smoke"

    initial = client.get(f"/api/memory/{user_id}/retention/policy")
    assert initial.status_code == 200
    assert initial.json()["configured"] is False

    updated = client.put(
        f"/api/memory/{user_id}/retention/policy",
        json={"retention_days": 45, "max_delete": 20, "memory_type": "weak_area"},
    )
    assert updated.status_code == 200
    assert updated.json()["configured"] is True
    assert updated.json()["retention_days"] == 45

    fetched = client.get(f"/api/memory/{user_id}/retention/policy")
    assert fetched.status_code == 200
    assert fetched.json()["max_delete"] == 20

    reset = client.delete(f"/api/memory/{user_id}/retention/policy")
    assert reset.status_code == 200
    assert reset.json()["configured"] is False

    print("runtime: OK")
    print("policy: OK")
    print("reset: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
