from __future__ import annotations

from unittest.mock import patch

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.repositories.memory import MemoryRepository
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryRecord, MemoryType


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        print("runtime: OK")
        service = MemoryService(db)
        records = [
            MemoryRecord("a", "smoke-atomic", MemoryType.PREVIOUS_QUESTION, "q1", {"q": 1}, 1.0, "smoke"),
            MemoryRecord("b", "smoke-atomic", MemoryType.PREVIOUS_QUESTION, "q2", {"q": 2}, 1.0, "smoke"),
        ]

        real_create = MemoryRepository.create
        calls = {"count": 0}

        def failing_create(self, **kwargs):
            calls["count"] += 1
            if calls["count"] == 2:
                raise RuntimeError("smoke persistence failure")
            return real_create(self, **kwargs)

        with patch.object(MemoryRepository, "create", failing_create):
            try:
                service.import_records_with_conflicts("smoke-atomic", records)
            except RuntimeError as exc:
                assert str(exc) == "smoke persistence failure"
            else:
                raise AssertionError("expected simulated persistence failure")

        assert service.list("smoke-atomic") == []
        print("mid_batch_failure: OK")
        print("rollback: OK")
        print("remaining_records: 0")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
