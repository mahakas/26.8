from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionRun, MemoryRetentionRunResult
from backend_v2.memory.retention_run_history import MemoryRetentionRunHistoryService


def main() -> int:
    if os.getenv("PHASE21_31_LIVE") != "1":
        print("Set PHASE21_31_LIVE=1 to run the Phase 21.31 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        cutoff = datetime(2026, 9, 10)
        db.add(
            MemoryRetentionRun(
                run_id="smoke-old",
                status="completed",
                started_at=cutoff - timedelta(days=2, minutes=1),
                completed_at=cutoff - timedelta(days=2),
                dry_run=False,
                user_count=1,
                executed_count=1,
                candidate_count=1,
                would_delete_count=1,
                deleted_count=1,
            )
        )
        db.add(
            MemoryRetentionRunResult(
                run_id="smoke-old",
                user_id="smoke-user",
                status="executed",
                candidate_count=1,
                deleted_count=1,
                would_delete_count=1,
                dry_run=False,
                executed_at=cutoff - timedelta(days=2),
            )
        )
        db.commit()

        service = MemoryRetentionRunHistoryService(db)
        preview = service.preview(older_than=cutoff, max_delete=1)
        assert preview.candidate_count == 1
        assert preview.would_delete_count == 1
        assert db.get(MemoryRetentionRun, "smoke-old") is not None

        applied = service.apply(older_than=cutoff, max_delete=1)
        assert applied.deleted_count == 1
        assert db.get(MemoryRetentionRun, "smoke-old") is None
        assert db.scalar(select(MemoryRetentionRunResult).where(MemoryRetentionRunResult.run_id == "smoke-old")) is None

        print("runtime: OK")
        print("preview: OK")
        print("apply: OK")
        print("parent_child_cleanup: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
