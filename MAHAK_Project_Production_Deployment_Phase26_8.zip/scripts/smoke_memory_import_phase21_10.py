from __future__ import annotations

import os

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def main() -> int:
    if os.getenv("PHASE21_10_LIVE") != "1":
        print("Set PHASE21_10_LIVE=1 to run memory import smoke test.")
        return 0

    app = create_app()
    client = TestClient(app)
    user_id = "smoke-phase21-10"

    # Keep the smoke test idempotent when the default persistent DB is reused.
    cleanup = client.delete(f"/api/memory/{user_id}/records")
    assert cleanup.status_code == 200, cleanup.text

    payload = {
        "format_version": "1.0",
        "user_id": user_id,
        "records": [
            {
                "id": "legacy-id",
                "user_id": user_id,
                "memory_type": "previous_question",
                "memory_key": "q-1",
                "value": {"question": "معادله چیست؟"},
                "confidence": 0.9,
                "source": "smoke",
            }
        ],
    }
    response = client.post(f"/api/memory/{user_id}/import", json=payload)
    assert response.status_code == 201, response.text
    print("runtime: OK")
    print(f"imported_count: {response.json()['imported_count']}")

    records = client.get(f"/api/memory/{user_id}/records")
    assert records.status_code == 200
    assert records.json()["count"] == 1
    print("records_after_import: 1")

    mismatch = client.post(
        f"/api/memory/{user_id}/import",
        json={**payload, "user_id": "other-user"},
    )
    assert mismatch.status_code == 422
    print("user_scope_validation: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
