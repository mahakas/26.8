from __future__ import annotations

import os
import tempfile
from datetime import datetime

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot, MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_alert_persistence import MemoryRetentionMaintenanceAlertSnapshotService


def main() -> int:
    if os.getenv("PHASE21_48_LIVE") != "1":
        print("Set PHASE21_48_LIVE=1 to run the live alert snapshot smoke test.")
        return 0

    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{path}", future=True)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        try:
            run_time = datetime(2026, 9, 19, 11, 59, 30)
            db.add(
                MemoryRetentionMaintenanceRun(
                    run_id="phase21-48-smoke-run",
                    status="completed",
                    started_at=datetime(2026, 9, 19, 11, 58, 30),
                    completed_at=run_time,
                    dry_run=False,
                    cleanup_history=True,
                    memory_status="completed",
                    memory_user_count=1,
                    memory_planned_count=1,
                    memory_executed_count=1,
                    memory_skipped_count=0,
                    memory_failed_count=0,
                    memory_candidate_count=0,
                    memory_would_delete_count=0,
                    memory_deleted_count=0,
                    history_status="completed",
                    history_configured=True,
                    history_retention_days=365,
                    history_max_delete=500,
                    history_candidate_count=0,
                    history_would_delete_count=0,
                    history_deleted_count=0,
                )
            )
            db.commit()
            result = MemoryRetentionMaintenanceAlertSnapshotService(
                db,
                assume_enabled=True,
                stale_after_seconds=60,
            ).capture(now=datetime(2026, 9, 19, 12, 0, 0))
            db.commit()
            row = db.scalar(select(MemoryRetentionMaintenanceAlertSnapshot).where(
                MemoryRetentionMaintenanceAlertSnapshot.snapshot_id == result.snapshot_id
            ))
            assert row is not None
            assert row.alert_codes == ""
            assert row.alert_count == 0
            assert not hasattr(row, "message")
            print("runtime: OK")
            print("persistence: OK")
            print("content_free: OK")
            print(f"snapshot_id: {result.snapshot_id}")
            return 0
        finally:
            db.close()
            engine.dispose()
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
