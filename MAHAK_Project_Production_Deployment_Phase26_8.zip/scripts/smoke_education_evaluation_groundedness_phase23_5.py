from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app

if os.getenv("PHASE23_5_LIVE") != "1":
    raise SystemExit("Set PHASE23_5_LIVE=1 before running this smoke test")

client = TestClient(create_app())
payload = {
    "answer": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است. پایتخت ژاپن لندن است.",
    "evidence_items": [
        {"source_id": "physics.pdf", "text": "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است."}
    ],
}
first = client.post("/api/evaluation/groundedness", json=payload)
first.raise_for_status()
second = client.post("/api/evaluation/groundedness", json=payload)
second.raise_for_status()
result = first.json()
assert first.json() == second.json()
assert result["claim_count"] == 2
assert result["supported_claim_count"] == 1
assert result["unsupported_claim_count"] == 1
assert 0.0 < result["groundedness_score"] < 1.0
assert result["hallucination_risk"] == round(1.0 - result["groundedness_score"], 6)
assert result["semantic_verification_available"] is False

batch = client.post(
    "/api/evaluation/groundedness/batch",
    json={
        "cases": [
            {"case_id": "perfect", "request": {"answer": "alpha beta gamma", "evidence_items": [{"text": "alpha beta gamma"}]}},
            {"case_id": "unsupported", "request": {"answer": "xylophone zebra", "evidence_items": []}},
        ]
    },
)
batch.raise_for_status()
batch_payload = batch.json()
assert batch_payload["evaluated_cases"] == 2
assert batch_payload["average_groundedness_score"] == 0.5

print("hallucination & groundedness evaluation: OK")
print(f"groundedness_score: {result['groundedness_score']}")
print(f"unsupported_claim_rate: {result['unsupported_claim_rate']}")
print(f"hallucination_risk: {result['hallucination_risk']}")
print("semantic_verification: lexical_only")
print("deterministic_repeat: True")
