from __future__ import annotations

import os
import sys

if os.getenv("PHASE21_14_LIVE") != "1":
    print("Set PHASE21_14_LIVE=1 to run Phase 21.14 smoke.")
    raise SystemExit(0)

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    user_id = "phase21-14-smoke"
    record = {
        "id": "preview-record",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": "profile",
        "value": {"grade": "10"},
        "confidence": 1.0,
        "source": "smoke",
    }

    preview = client.post(
        f"/api/memory/{user_id}/import/preview",
        json={"user_id": user_id, "records": [record]},
    )
    assert preview.status_code == 200
    body = preview.json()
    assert body["would_import_count"] == 1
    assert body["would_skip_count"] == 0
    assert body["conflict_count"] == 0
    assert body["would_reject"] is False
    assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 0

    imported = client.post(
        f"/api/memory/{user_id}/import",
        json={"user_id": user_id, "records": [record]},
    )
    assert imported.status_code == 201

    conflict = {**record, "value": {"grade": "11"}, "id": "preview-conflict"}
    reject_preview = client.post(
        f"/api/memory/{user_id}/import/preview",
        json={
            "user_id": user_id,
            "conflict_policy": "reject",
            "records": [conflict],
        },
    )
    assert reject_preview.status_code == 200
    reject_body = reject_preview.json()
    assert reject_body["conflict_count"] == 1
    assert reject_body["would_reject"] is True
    assert client.get(f"/api/memory/{user_id}/records").json()["count"] == 1

    print("runtime: OK")
    print("preview: OK")
    print("read_only: OK")
    print("reject_prediction: OK")
    db.close()
    engine.dispose()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
