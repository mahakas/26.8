from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from uuid import uuid4


def main() -> int:
    if os.getenv("PHASE21_33_LIVE") != "1":
        print("Set PHASE21_33_LIVE=1 to run phase 21.33 smoke test.")
        return 0

    # Smoke tests must be isolated from a persistent project database so the
    # script can be rerun safely without colliding with old run-history rows.
    os.environ["DATABASE_URL"] = "sqlite:///:memory:"

    from backend_v2.database.connection import Base, SessionLocal, engine
    from backend_v2.database.models import MemoryRetentionRun, MemoryRetentionRunResult
    from backend_v2.memory.retention_run_history import MemoryRetentionRunHistoryService
    from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService

    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        run_id = f"phase21-33-old-{uuid4().hex[:12]}"
        db.add(
            MemoryRetentionRun(
                run_id=run_id,
                status="completed",
                started_at=now - timedelta(days=21, minutes=1),
                completed_at=now - timedelta(days=21),
                dry_run=False,
                user_count=1,
                planned_count=0,
                executed_count=1,
                skipped_count=0,
                failed_count=0,
                candidate_count=1,
                would_delete_count=1,
                deleted_count=1,
            )
        )
        db.add(
            MemoryRetentionRunResult(
                run_id=run_id,
                user_id="phase21-33",
                status="executed",
                candidate_count=1,
                deleted_count=1,
                would_delete_count=1,
                dry_run=False,
                retention_days=7,
                executed_at=now - timedelta(days=21),
            )
        )
        db.commit()

        policy = MemoryRetentionRunHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=10)
        db.commit()

        service = MemoryRetentionRunHistoryService(db)
        preview = service.preview_policy()
        assert preview.candidate_count >= 1
        assert preview.read_only is True
        assert db.get(MemoryRetentionRun, run_id) is not None
        print("runtime: OK")
        print("policy_preview: OK")

        result = service.apply_policy()
        assert result.deleted_count == 1
        assert db.get(MemoryRetentionRun, run_id) is None
        print("policy_apply: OK")
        print(f"deleted_count: {result.deleted_count}")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
