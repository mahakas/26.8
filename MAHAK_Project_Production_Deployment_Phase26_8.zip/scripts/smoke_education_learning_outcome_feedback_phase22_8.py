from __future__ import annotations

import os
import sys
from pathlib import Path

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    if os.getenv("PHASE22_8_LIVE") != "1":
        print("set PHASE22_8_LIVE=1 to run the Phase 22.8 smoke test")
        return 1

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    client = TestClient(app)

    try:
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "phase22-8-smoke-user",
                "plan_id": "phase22-8-smoke-plan",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
                "max_remediation_sessions": 2,
            },
        )
        assert start.status_code == 200, start.text

        grade = client.post(
            "/api/education/attempts/grade",
            json={
                "user_id": "phase22-8-smoke-user",
                "attempt_id": "phase22-8-smoke-attempt",
                "task_type": "quiz",
                "topic": "قانون دوم نیوتن",
                "items": [
                    {
                        "item_id": "q1",
                        "question_type": "multiple_choice",
                        "question": "F?",
                        "topic": "قانون دوم نیوتن",
                        "answer": "F=ma",
                        "correct_answer": "F=ma",
                        "options": ["F=ma", "F=m/a"],
                        "difficulty": "medium",
                    }
                ],
            },
        )
        assert grade.status_code == 200, grade.text

        advance = client.post(
            "/api/education/learning-plans/phase22-8-smoke-plan/advance",
            json={
                "user_id": "phase22-8-smoke-user",
                "attempt_id": "phase22-8-smoke-attempt",
            },
        )
        assert advance.status_code == 200, advance.text
        assert advance.json()["status"] == "completed"

        feedback = client.post(
            "/api/education/recommendations/feedback",
            json={
                "user_id": "phase22-8-smoke-user",
                "learning_plan_id": "phase22-8-smoke-plan",
                "task_type": "quiz",
                "question_count": 4,
            },
        )
        assert feedback.status_code == 200, feedback.text
        body = feedback.json()
        assert body["evaluated"] is True
        assert body["outcome"] == "completed"
        assert body["feedback_action"] == "advance"
        assert body["recommendation"]["recommendation_type"] == "advancement"
        assert body["recommendation"]["difficulty"] == "hard"
        assert body["recommendation"]["generation_request"]["feedback_action"] == "advance"
        assert body["recommendation"]["generation_request"]["learning_plan_outcome"] == "completed"
        assert body["completion_percent"] == 100.0

        replay = client.post(
            "/api/education/recommendations/feedback",
            json={
                "user_id": "phase22-8-smoke-user",
                "learning_plan_id": "phase22-8-smoke-plan",
                "task_type": "quiz",
                "question_count": 4,
            },
        )
        assert replay.status_code == 200
        assert replay.json() == body

        print("learning outcome feedback: OK")
        print(f"outcome: {body['outcome']}")
        print(f"feedback_action: {body['feedback_action']}")
        print(f"recommendation_type: {body['recommendation']['recommendation_type']}")
        print(f"difficulty: {body['recommendation']['difficulty']}")
        print(f"completion: {body['completion_percent']}%")
        print(f"mastery_gap: {body['mastery_gap']}")
        print("read_only_repeat: True")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
