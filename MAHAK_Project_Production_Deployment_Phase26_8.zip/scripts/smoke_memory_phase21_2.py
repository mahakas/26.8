from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class SmokeAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def execute(self, query: str, **kwargs) -> AgentResult:
        memories = kwargs.get("memory_context")
        return AgentResult(
            answer=f"Memory-aware response ({len(memories.records)} memories)",
            evidence=[],
            citations=[],
            confidence=0.9,
        )


def main() -> int:
    if os.getenv("PHASE21_2_LIVE") != "1":
        print("Set PHASE21_2_LIVE=1 to run the memory integration smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = session_factory()
    try:
        memory = MemoryService(db)
        context = ConversationContext(
            conversation_id="smoke-21-2",
            user_id="student-smoke",
            mode=ChatMode.GENERAL,
            subject_id="physics",
        )
        memory.remember(
            user_id=context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.3},
            confidence=0.8,
            conversation_id=context.conversation_id,
        )

        registry = AgentRegistry()
        registry.register(SmokeAgent())
        pipeline = UnifiedAgentPipeline(
            AgentRouter(registry),
            TeacherAgent(),
            memory=MemoryIntegrationService(memory),
        )
        result = pipeline.execute("کمکم کن", conversation_context=context)

        latest = memory.latest(
            context.user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key=f"conversation:{context.conversation_id}:latest_question",
        )
        print("runtime: OK")
        print("memory_lookup: OK")
        print(f"memory_records_used: 1")
        print(f"agent: {result.answer}")
        print(f"previous_question_persisted: {latest is not None}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
