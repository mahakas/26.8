from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.agents.document import DocumentAgent
from backend_v2.agents.multimodal import MultimodalTeacherService
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.video import VideoAgent
from backend_v2.agents.vision import VisionAgent
from backend_v2.agents.types import AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.memory.integration import MemoryIntegrationService
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.core.enums import Capability
from backend_v2.retrieval.service import RetrievalService
from backend_v2.vectorstores.embedding import EmbeddingResult
from backend_v2.vectorstores.memory import InMemoryVectorStore
from backend_v2.vectorstores.base import VectorRecord


@dataclass
class FixedEmbedding:
    def embed(self, texts):
        return EmbeddingResult([[1.0, 0.0] for _ in texts], "smoke", "fixed", 2)


def main() -> int:
    os.environ.setdefault("PHASE25_1_LIVE", "1")
    store = InMemoryVectorStore()
    store.upsert(
        [
            VectorRecord("image", [1.0, 0.0], "نمودار نیرو", {"source_type": "image", "source_id": "diagram.png", "image_id": "smoke-image"}),
            VectorRecord("video", [1.0, 0.0], "ویدیو قانون دوم نیوتن", {"source_type": "video", "source_id": "lesson.mp4", "start_time_seconds": 10.0, "end_time_seconds": 12.0, "frame_path": "frame-10.jpg"}),
        ],
        collection="mahak_knowledge",
    )
    providers = ProviderRegistry()
    providers.register(MockProviderAdapter("smoke-teacher", {Capability.CHAT}, handler=lambda payload: {"answer": "پاسخ یکپارچه چندرسانه‌ای"}, default_model="smoke-teacher-v1"))
    orchestrator = ProviderOrchestrator(providers, ProviderHealthManager())
    retrieval = RetrievalService(store, FixedEmbedding())
    registry = AgentRegistry()
    registry.register(DocumentAgent())
    registry.register(VisionAgent())
    registry.register(VideoAgent(retrieval, collection="mahak_knowledge", top_k=3, candidate_k=6, min_score=0.0))
    service = MultimodalTeacherService(registry, TeacherAgent(orchestrator), retrieval, memory=MemoryIntegrationService(), collection="mahak_knowledge")
    execution = service.execute(
        "این ویدیو و تصویر را توضیح بده",
        context=ConversationContext("phase25-1-smoke", None, ChatMode.EDUCATIONAL),
        top_k=3,
        min_score=0.0,
    )
    assert [route.agent_type for route in execution.routes] == [AgentType.VIDEO, AgentType.IMAGE]
    assert {item["type"] for item in execution.result.evidence} == {"video", "image"}
    assert execution.result.answer == "پاسخ یکپارچه چندرسانه‌ای"
    print("multimodal teacher: OK")
    print("agents:", [route.agent_type.value for route in execution.routes])
    print("evidence_types:", sorted({item["type"] for item in execution.result.evidence}))
    print("confidence:", execution.result.confidence)
    print("unified_answer: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
