from __future__ import annotations

import os
import sys
from datetime import UTC, datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    if os.environ.get("PHASE21_41_LIVE") != "1":
        print("Set PHASE21_41_LIVE=1 to run the live maintenance persistence smoke test.")
        return 0

    from backend_v2.database.connection import Base
    from backend_v2.database.models import MemoryRetentionMaintenanceRun
    from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService

    fd, db_path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        Base.metadata.create_all(engine)
        session_factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = session_factory()
        try:
            report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_report(
                user_ids=[],
                now=datetime(2026, 9, 1, tzinfo=UTC),
                dry_run=True,
                cleanup_history=True,
            )
            db.commit()
            row = db.get(MemoryRetentionMaintenanceRun, report.run_id)
            assert row is not None
            assert row.dry_run is True
            assert row.history_status == "planned"
            assert not hasattr(row, "value_json")
            print("runtime: OK")
            print("persistence: OK")
            print("history_status: planned")
            print("content_free: OK")
            return 0
        finally:
            db.close()
            engine.dispose()
    finally:
        try:
            Path(db_path).unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
