from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def main() -> None:
    if os.getenv("PHASE23_3_LIVE") != "1":
        print("phase23.3 smoke skipped: set PHASE23_3_LIVE=1")
        return

    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/retrieval",
        json={
            "expected_source_ids": ["physics.pdf", "chapter.pdf"],
            "retrieved_source_ids": ["physics.pdf", "unrelated.pdf", "chapter.pdf"],
            "cutoffs": [1, 3, 5],
        },
    )
    response.raise_for_status()
    payload = response.json()
    assert payload["reciprocal_rank"] == 1.0
    assert payload["recall_at_k"]["3"] == 1.0
    assert payload["ndcg_at_k"]["1"] == 1.0

    batch = client.post(
        "/api/evaluation/retrieval/batch",
        json={
            "cases": [
                {"expected_source_ids": ["a"], "retrieved_source_ids": ["a"], "cutoffs": [1, 3]},
                {"expected_source_ids": ["b"], "retrieved_source_ids": ["x", "b"], "cutoffs": [1, 3]},
            ]
        },
    )
    batch.raise_for_status()
    batch_payload = batch.json()
    assert batch_payload["evaluated_cases"] == 2
    assert batch_payload["mean_reciprocal_rank"] == 0.75

    print("retrieval evaluation: OK")
    print("mrr: 0.75")
    print("recall@3: 1.0")
    print("ndcg@1: 1.0")
    print("batch_cases: 2")
    print("deterministic_repeat: True")


if __name__ == "__main__":
    main()
