from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_5_LIVE") != "1":
        print("Set PHASE21_5_LIVE=1 to run the Phase 21.5 smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        user_id = "phase21-5-smoke"
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="profile",
            value={"learning_level": "grade10", "explanation_style": "step_by_step"},
        )
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:algebra",
            value={"topic": "algebra", "status": "active", "mastery_score": 0.3},
            confidence=0.8,
        )
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.LEARNING_HISTORY,
            memory_key="turn:1",
            value={"topic": "algebra", "agent_type": "VIDEO_AGENT", "citation_count": 2},
            confidence=0.85,
        )
        memory.remember(
            user_id=user_id,
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="latest",
            value={"question": "معادله چیست؟"},
        )
        db.commit()

        progress = MemoryProgressService(memory).build(user_id)
        print("runtime: OK")
        print(f"profile_level: {progress.profile.get('learning_level')}")
        print(f"active_weak_areas: {progress.active_weak_areas}")
        print(f"learning_history_count: {progress.learning_history_count}")
        print(f"latest_question: {progress.latest_question}")
        print(f"average_confidence: {progress.average_confidence}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
