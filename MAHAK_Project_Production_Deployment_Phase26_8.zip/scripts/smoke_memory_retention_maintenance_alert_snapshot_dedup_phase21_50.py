from __future__ import annotations

import os
import tempfile
from datetime import datetime

from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot, MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_alert_persistence import MemoryRetentionMaintenanceAlertSnapshotService


def main() -> int:
    if os.getenv("PHASE21_50_LIVE") != "1":
        print("Set PHASE21_50_LIVE=1 to run the live Phase 21.50 smoke test.")
        return 0
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{path}", future=True)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        db = Session()
        try:
            db.add(MemoryRetentionMaintenanceRun(
                run_id="phase21-50-smoke-run",
                status="completed",
                started_at=datetime(2026, 9, 19, 11, 58, 30),
                completed_at=datetime(2026, 9, 19, 11, 59, 30),
                dry_run=False,
                cleanup_history=True,
                memory_status="completed",
                memory_user_count=1,
                memory_planned_count=1,
                memory_executed_count=1,
                memory_skipped_count=0,
                memory_failed_count=0,
                memory_candidate_count=0,
                memory_would_delete_count=0,
                memory_deleted_count=0,
                history_status="completed",
                history_configured=True,
                history_retention_days=365,
                history_max_delete=500,
                history_candidate_count=0,
                history_would_delete_count=0,
                history_deleted_count=0,
            ))
            db.commit()
            service = MemoryRetentionMaintenanceAlertSnapshotService(db, assume_enabled=True, stale_after_seconds=60)
            first = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 0))
            second = service.capture_if_changed(now=datetime(2026, 9, 19, 12, 0, 10))
            db.commit()
            assert first.created is True
            assert second.deduplicated is True
            assert db.scalar(select(func.count()).select_from(MemoryRetentionMaintenanceAlertSnapshot)) == 1
            print("runtime: OK")
            print("deduplication: OK")
            print("legacy_contract: OK")
            print("row_count: 1")
            return 0
        finally:
            db.close(); engine.dispose()
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
