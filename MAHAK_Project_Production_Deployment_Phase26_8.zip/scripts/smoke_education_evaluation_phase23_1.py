from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def main() -> int:
    client = TestClient(create_app())
    response = client.post(
        "/api/evaluation/answer",
        json={
            "question": "قانون دوم نیوتن چیست؟",
            "answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            "expected_answer": "قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است.",
            "expected_source_ids": ["physics.pdf"],
            "retrieved_source_ids": ["physics.pdf"],
            "cited_source_ids": ["physics.pdf"],
            "evidence_texts": ["قانون دوم نیوتن می‌گوید نیرو برابر جرم ضربدر شتاب است."],
        },
    )
    response.raise_for_status()
    payload = response.json()
    if payload["overall_score"] != 1.0 or payload["citation_correctness"] != 1.0:
        raise AssertionError(payload)
    print("evaluation framework: OK")
    print("overall_score:", payload["overall_score"])
    print("retrieval_f1:", payload["retrieval_f1"])
    print("citation_f1:", payload["citation_f1"])
    print("evidence_coverage:", payload["evidence_coverage"])
    print("hallucination_risk:", payload["heuristic_hallucination_risk"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
