from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

if os.getenv("PHASE15_LIVE", "0") != "1":
    print("Set PHASE15_LIVE=1 to run live PDF RAG smoke test.")
    raise SystemExit(0)

os.environ["MAHAK_PROVIDER_MODE"] = "live"
os.environ["VECTOR_STORE_BACKEND"] = "chroma"
os.environ["EMBED_BACKEND"] = "local"
os.environ["EMBED_MODEL"] = "BAAI/bge-m3"

import fitz
from backend_v2.chat.context import ConversationContext
from backend_v2.chat.educational import EducationalChatService
from backend_v2.core.enums import ChatMode
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.runtime import V2Runtime
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def _make_pdf(path: Path) -> None:
    doc = fitz.open()
    p1 = doc.new_page()
    p1.insert_text((72, 72), "فیزیک دهم\nقانون دوم نیوتن: نیروی خالص برابر جرم ضربدر شتاب است. F = m a")
    p2 = doc.new_page()
    p2.insert_text((72, 72), "نکته\nاگر نیروی خالص صفر باشد، شتاب جسم صفر خواهد بود.")
    doc.save(path)
    doc.close()


def main() -> int:
    try:
        with tempfile.TemporaryDirectory(prefix="mahak_phase15_") as td:
            pdf = Path(td) / "physics10.pdf"
            _make_pdf(pdf)
            ing = IngestionPipeline(chunk_size=500, overlap=60).process(pdf)
            print(f"pdf: OK | kind={ing.document.metadata['pdf_kind']} | pages={ing.document.metadata['pages']} | chunks={len(ing.chunks)}")
            pages = [c.location.page for c in ing.chunks if c.location]
            print(f"page mapping: {pages}")

            runtime = V2Runtime()
            if runtime.vector_store.name != "chroma":
                print(f"vector_store={runtime.vector_store.name}; set VECTOR_STORE_BACKEND=chroma")
                return 2

            spec = IndexSpec("physics10_pdf", "bge-m3-local", "bge-m3-v1", 1024)
            result = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
                ing.chunks,
                index_spec=spec,
                source_id="phase15-physics10-pdf",
                title="فیزیک دهم — PDF تست",
                scope_metadata={"grade_id": "10", "subject_id": "physics"},
            )
            print(f"index: OK | collection={result.collection} | chunks={result.indexed}")

            retr = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
                RetrievalRequest(
                    "قانون دوم نیوتن چیست؟",
                    RetrievalScope(grade_id="10", subject_id="physics"),
                    result.collection,
                    top_k=3,
                    candidate_k=6,
                    min_score=0.20,
                )
            )
            print(f"retrieval: {'OK' if retr.found else 'FAILED'} | hits={len(retr.accepted)} | pages={[h.metadata.get('page') for h in retr.accepted]}")
            if not retr.found:
                return 3

            ctx = ConversationContext("phase15-live-pdf", None, ChatMode.EDUCATIONAL, grade_id="10", subject_id="physics")
            service = EducationalChatService(
                RetrievalService(runtime.vector_store, runtime.embedding),
                runtime.llm_orchestrator,
                collection=result.collection,
                session_collection="mahak_sessions",
                top_k=3,
                min_score=0.20,
            )
            ans = service.ask(ctx, "قانون دوم نیوتن را بر اساس PDF توضیح بده")
            print(f"chat: {'OK' if ans.found else 'FAILED'} | provider={ans.provider} | model={ans.model}")
            print("answer:", ans.answer)
            print("citations:", len(ans.citations), "pages:", [c.page for c in ans.citations])
            return 0 if ans.found and ans.citations else 4
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}")
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
