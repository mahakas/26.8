from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.observability.metrics import metrics


def main() -> int:
    metrics.reset()
    client = TestClient(create_app())

    live = client.get("/api/health/live")
    ready = client.get("/api/health/ready")
    metric_response = client.get("/api/metrics")
    request_id = live.headers.get("X-Request-ID", "")

    ok = (
        live.status_code == 200
        and ready.status_code == 200
        and ready.json().get("status") == "ready"
        and metric_response.status_code == 200
        and "mahak_requests_total" in metric_response.text
        and bool(request_id)
    )

    print("observability & monitoring: " + ("OK" if ok else "FAILED"))
    print(f"liveness: {live.status_code}")
    print(f"readiness: {ready.status_code} | {ready.json().get('status')}")
    print(f"metrics: {metric_response.status_code} | prometheus=True")
    print(f"request_id: {'OK' if request_id else 'MISSING'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
