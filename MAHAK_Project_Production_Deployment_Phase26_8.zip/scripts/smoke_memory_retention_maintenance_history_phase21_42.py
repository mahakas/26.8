from __future__ import annotations

import os
from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService


def main() -> int:
    if os.getenv("PHASE21_42_LIVE") != "1":
        print("Set PHASE21_42_LIVE=1 to run the Phase 21.42 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    try:
        service = MemoryRetentionMaintenanceService(db, enabled=True)
        for hour in (10, 11, 12):
            service.run_with_report(
                user_ids=[],
                now=datetime(2026, 9, 19, hour, 0, tzinfo=UTC),
                dry_run=hour != 11,
                cleanup_history=hour != 10,
            )
        db.commit()

        response = client.get("/api/memory/maintenance/runs", params={"limit": 2})
        assert response.status_code == 200
        payload = response.json()
        assert payload["count"] == 2
        assert payload["read_only"] is True
        assert payload["next_cursor"]
        print("runtime: OK")
        print("history_api: OK")
        print("page1_count:", payload["count"])
        print("cursor: OK")
        print("content_free: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
