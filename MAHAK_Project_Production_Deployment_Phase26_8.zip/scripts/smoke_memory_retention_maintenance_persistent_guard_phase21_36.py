from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceLease
from backend_v2.memory.retention_maintenance import MemoryRetentionMaintenanceService
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def main() -> int:
    if os.getenv("PHASE21_36_LIVE") != "1":
        print("Set PHASE21_36_LIVE=1 to run Phase 21.36 smoke test.")
        return 0
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        lease_service = MemoryRetentionMaintenanceLeaseService(db)
        first = lease_service.acquire(ttl_seconds=60)
        try:
            try:
                MemoryRetentionMaintenanceLeaseService(db).acquire(ttl_seconds=60)
            except Exception:
                print("persistent_guard: OK")
            else:
                print("persistent_guard: FAIL")
                return 1
        finally:
            lease_service.release(first)
        report = MemoryRetentionMaintenanceService(db, enabled=True).run_with_persistent_guard(
            dry_run=True,
            cleanup_history=False,
        )
        assert report.status == "completed"
        assert db.query(MemoryRetentionMaintenanceLease).count() == 0
        print("runtime: OK")
        print("persistent_guard: OK")
        print("maintenance_contract: OK")
        print("lease_released: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
