from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:", future=True,
        connect_args={"check_same_thread": False}, poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()
    app.dependency_overrides[get_db] = lambda: (yield db)
    client = TestClient(app)
    try:
        start = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "phase22-6-smoke-user",
                "plan_id": "phase22-6-smoke-plan",
                "total_sessions": 2,
                "session_steps": 1,
                "question_count": 3,
                "target_topics": ["قانون دوم نیوتن", "انرژی جنبشی"],
                "mastery_target": 0.75,
                "max_remediation_sessions": 1,
            },
        )
        assert start.status_code == 200, start.text
        first_attempt = client.post(
            "/api/education/attempts/grade",
            json={
                "user_id": "phase22-6-smoke-user",
                "attempt_id": "phase22-6-smoke-attempt-1",
                "task_type": "quiz",
                "topic": "قانون دوم نیوتن",
                "items": [{
                    "item_id": "q1",
                    "question_type": "multiple_choice",
                    "question": "رابطه نیرو؟",
                    "topic": "قانون دوم نیوتن",
                    "answer": "F=ma",
                    "correct_answer": "F=ma",
                    "options": ["F=ma", "F=m/a"],
                }],
            },
        )
        assert first_attempt.status_code == 200, first_attempt.text
        advanced = client.post(
            "/api/education/learning-plans/phase22-6-smoke-plan/advance",
            json={"user_id": "phase22-6-smoke-user", "attempt_id": "phase22-6-smoke-attempt-1"},
        )
        assert advanced.status_code == 200, advanced.text
        body = advanced.json()
        assert body["status"] == "active"
        assert body["completed_milestones"] == 1
        assert body["current_milestone"] == 2
        assert body["next_topic"] == "انرژی جنبشی"
        replay = client.post(
            "/api/education/learning-plans/phase22-6-smoke-plan/advance",
            json={"user_id": "phase22-6-smoke-user", "attempt_id": "phase22-6-smoke-attempt-1"},
        )
        assert replay.status_code == 200, replay.text
        assert replay.json()["idempotent_replay"] is True
        fetched = client.get(
            "/api/education/learning-plans/phase22-6-smoke-plan",
            params={"user_id": "phase22-6-smoke-user"},
        )
        assert fetched.status_code == 200, fetched.text
        print("learning plan: OK")
        print("plan_id: phase22-6-smoke-plan")
        print("milestone: 2/2")
        print("completed_milestones:", body["completed_milestones"])
        print("next_topic:", body["next_topic"])
        print("idempotent_replay:", replay.json()["idempotent_replay"])
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
