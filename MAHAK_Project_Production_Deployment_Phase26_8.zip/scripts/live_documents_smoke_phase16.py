from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

if os.getenv("PHASE16_LIVE", "0") != "1":
    print("Set PHASE16_LIVE=1 to run the live document smoke test.")
    raise SystemExit(0)

os.environ["MAHAK_PROVIDER_MODE"] = "live"
os.environ["VECTOR_STORE_BACKEND"] = "chroma"
os.environ["EMBED_BACKEND"] = "local"
os.environ["EMBED_MODEL"] = "BAAI/bge-m3"

from docx import Document

from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.runtime import V2Runtime
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def make_files(td: Path) -> list[Path]:
    md = td / "physics.md"
    md.write_text("# فیزیک دهم\n\n## قانون دوم نیوتن\n\nنیروی خالص برابر جرم ضربدر شتاب است. F = ma", encoding="utf-8")
    txt = td / "notes.txt"
    txt.write_text("قانون دوم نیوتن\n\nشتاب با نیروی خالص متناسب و با جرم معکوساً متناسب است.", encoding="utf-8")
    html = td / "physics.html"
    html.write_text("<html><head><title>فیزیک دهم</title></head><body><h1>فیزیک دهم</h1><h2>قانون دوم نیوتن</h2><p>F = ma</p></body></html>", encoding="utf-8")
    docx = td / "physics.docx"
    doc = Document()
    doc.add_heading("فیزیک دهم", level=1)
    doc.add_heading("قانون دوم نیوتن", level=2)
    doc.add_paragraph("نیرو برابر جرم ضربدر شتاب است.")
    doc.save(docx)
    return [md, txt, html, docx]


def main() -> int:
    try:
        with tempfile.TemporaryDirectory(prefix="mahak_phase16_") as td_raw:
            td = Path(td_raw)
            files = make_files(td)
            pipeline = IngestionPipeline(chunk_size=500, overlap=50)
            runtime = V2Runtime()
            spec = IndexSpec("physics10_documents", "bge-m3-local", "bge-m3-v1", 1024)
            indexed = 0
            for path in files:
                result = pipeline.process(path)
                print(f"{path.suffix}: chunks={len(result.chunks)} sections={sum('section' in c.metadata for c in result.chunks)}")
                out = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
                    result.chunks, index_spec=spec, source_id=f"phase16-{path.suffix}", title=path.stem,
                    scope_metadata={"grade_id": "10", "subject_id": "physics", "source_type": path.suffix.lstrip('.')},
                )
                indexed += out.indexed
            print(f"index: OK | collection={spec.collection_name} | chunks={indexed}")
            retr = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
                RetrievalRequest("قانون دوم نیوتن", RetrievalScope(grade_id="10", subject_id="physics"),
                                 spec.collection_name, top_k=5, candidate_k=12, min_score=0.20)
            )
            print(f"retrieval: {'OK' if retr.found else 'FAILED'} | hits={len(retr.accepted)}")
            for hit in retr.accepted:
                print(" -", hit.metadata.get("source_type"), hit.metadata.get("section"), hit.metadata.get("title"))
            return 0 if retr.found and indexed >= 4 else 3
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}")
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
