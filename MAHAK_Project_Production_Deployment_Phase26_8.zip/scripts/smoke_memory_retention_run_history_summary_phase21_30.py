from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_30_LIVE") != "1":
        print("Set PHASE21_30_LIVE=1 to run the live memory retention run-history summary smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db

    try:
        now = datetime(2026, 9, 19, 10, tzinfo=UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="phase21-30-smoke",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-question",
                value_json={"question": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            )
        )
        MemoryRetentionPolicyService(db).set(
            "phase21-30-smoke",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )
        db.commit()

        scheduler = MemoryRetentionSchedulerService(db, enabled=True)
        scheduler.run_with_report(
            user_ids=["phase21-30-smoke"],
            now=datetime(2026, 9, 19, 10, tzinfo=UTC),
            dry_run=True,
        )
        scheduler.run_with_report(
            user_ids=["phase21-30-smoke"],
            now=datetime(2026, 9, 20, 10, tzinfo=UTC),
            dry_run=False,
        )

        client = TestClient(app)
        response = client.get("/api/memory/phase21-30-smoke/retention/runs/summary")
        assert response.status_code == 200
        payload = response.json()
        assert payload["run_count"] == 2
        assert payload["result_count"] == 2
        assert payload["dry_run_count"] == 1
        assert payload["planned_result_count"] == 1
        assert payload["executed_result_count"] == 1
        assert payload["deleted_count"] == 1
        assert payload["read_only"] is True
        print("runtime: OK")
        print("run_history_summary: OK")
        print(f"run_count: {payload['run_count']}")
        print(f"deleted_count: {payload['deleted_count']}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
