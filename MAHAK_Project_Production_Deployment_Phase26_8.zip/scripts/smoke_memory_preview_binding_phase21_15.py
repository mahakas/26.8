from __future__ import annotations

import os

if os.getenv("PHASE21_15_LIVE") != "1":
    print("Set PHASE21_15_LIVE=1 to run Phase 21.15 smoke.")
    raise SystemExit(0)

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    user_id = "phase21-15-smoke"
    record = {
        "id": "binding-record",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": "profile",
        "value": {"grade": "10"},
        "confidence": 1.0,
        "source": "smoke",
    }

    preview = client.post(
        f"/api/memory/{user_id}/import/preview",
        json={"user_id": user_id, "records": [record]},
    )
    assert preview.status_code == 200
    token = preview.json()["preview_token"]
    assert len(token) == 64

    safe_import = client.post(
        f"/api/memory/{user_id}/import",
        json={"user_id": user_id, "preview_token": token, "records": [record]},
    )
    assert safe_import.status_code == 201
    assert safe_import.json()["imported_count"] == 1

    second_preview = client.post(
        f"/api/memory/{user_id}/import/preview",
        json={"user_id": user_id, "records": [_record("phase21-15-smoke", "11")]},
    )
    assert second_preview.status_code == 200
    second_token = second_preview.json()["preview_token"]

    changed = client.post(
        f"/api/memory/{user_id}/import",
        json={
            "user_id": user_id,
            "records": [_record("phase21-15-smoke", "12")],
        },
    )
    assert changed.status_code == 201

    stale = client.post(
        f"/api/memory/{user_id}/import",
        json={
            "user_id": user_id,
            "preview_token": second_token,
            "records": [_record("phase21-15-smoke", "11")],
        },
    )
    assert stale.status_code == 409

    print("runtime: OK")
    print("preview_token: OK")
    print("bound_import: OK")
    print("stale_preview_rejected: OK")
    db.close()
    engine.dispose()
    return 0


def _record(user_id: str, value: str):
    return {
        "id": f"smoke-{value}",
        "user_id": user_id,
        "memory_type": "student_profile",
        "memory_key": "profile",
        "value": {"grade": value},
        "confidence": 1.0,
        "source": "smoke",
    }


if __name__ == "__main__":
    raise SystemExit(main())
