from __future__ import annotations

import os
import sys
from datetime import UTC, datetime, timedelta

sys.path.insert(0, ".")

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_27_LIVE") != "1":
        print("Set PHASE21_27_LIVE=1 to run the live smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        now = datetime(2026, 9, 19, tzinfo=UTC).replace(tzinfo=None)
        for user_id in ("phase21-27-a", "phase21-27-b"):
            db.add(
                LearningMemory(
                    user_id=user_id,
                    memory_type=MemoryType.PREVIOUS_QUESTION.value,
                    memory_key="old",
                    value_json={"q": "old"},
                    created_at=now - timedelta(days=60),
                    updated_at=now - timedelta(days=60),
                )
            )
        db.commit()
        for user_id in ("phase21-27-a", "phase21-27-b"):
            MemoryRetentionPolicyService(db).set(
                user_id,
                retention_days=30,
                max_delete=1,
                memory_type=MemoryType.PREVIOUS_QUESTION,
            )

        plan = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["phase21-27-a", "phase21-27-b"],
            now=now.replace(tzinfo=UTC),
            dry_run=True,
        )
        assert plan.status == "completed"
        assert plan.user_count == 2
        assert plan.planned_count == 2
        assert plan.candidate_count == 2
        assert plan.would_delete_count == 2
        assert plan.deleted_count == 0

        execution = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["phase21-27-a", "phase21-27-b"],
            now=now.replace(tzinfo=UTC),
        )
        assert execution.status == "completed"
        assert execution.executed_count == 2
        assert execution.deleted_count == 2

        print("runtime: OK")
        print("dry_run_report: OK")
        print("execution_report: OK")
        print(f"planned_users: {plan.planned_count}")
        print(f"deleted_count: {execution.deleted_count}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
