from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.education.recommendations import EducationalRecommendationRequest, EducationalRecommendationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> None:
    if os.getenv("PHASE22_4_LIVE") != "1":
        raise SystemExit("Set PHASE22_4_LIVE=1 before running this smoke test")

    engine = create_engine("sqlite:///:memory:", future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        memory.remember(
            user_id="phase22-4-smoke",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="weak_area:قانون دوم نیوتن",
            value={
                "topic": "قانون دوم نیوتن",
                "status": "active",
                "mastery_score": 0.4,
                "weakness_score": 0.6,
                "correctness_score": 0.4,
                "needs_retry": True,
                "attempts": 2,
            },
            source="phase22-4-smoke",
        )
        db.commit()
        result = EducationalRecommendationService(memory).recommend(
            EducationalRecommendationRequest(user_id="phase22-4-smoke", question_count=5)
        )
        assert result.recommended is True
        assert result.topic == "قانون دوم نیوتن"
        assert result.recommendation_type == "targeted_remediation"
        assert result.difficulty.value == "easy"
        assert result.generation_request is not None
        print("adaptive recommendation: OK")
        print("type:", result.recommendation_type)
        print("topic:", result.topic)
        print("difficulty:", result.difficulty.value)
        print("priority_score:", result.priority_score)
        print("mastery:", result.mastery_score)
        print("weakness:", result.weakness_score)
        print("generation_request: OK")
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    main()
