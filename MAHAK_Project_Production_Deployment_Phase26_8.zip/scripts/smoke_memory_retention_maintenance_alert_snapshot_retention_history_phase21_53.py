from __future__ import annotations

import os
import sys
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool

from backend_v2.database.connection import Base
from backend_v2.database.repositories import MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshot
from backend_v2.memory import MemoryRetentionMaintenanceAlertSnapshotRetentionService


def main() -> int:
    if os.getenv("PHASE21_53_LIVE") != "1":
        print("Set PHASE21_53_LIVE=1 to run the Phase 21.53 smoke test.")
        return 0

    fd, path = tempfile.mkstemp(prefix="mahak_phase21_53_", suffix=".db")
    os.close(fd)
    try:
        engine = create_engine(f"sqlite:///{path}", poolclass=NullPool, future=True)
        Base.metadata.create_all(engine)
        with Session(engine, expire_on_commit=False) as db:
            now = datetime.now(UTC).replace(tzinfo=None)
            db.add(
                MemoryRetentionMaintenanceAlertSnapshot(
                    snapshot_id="phase21-53-old",
                    captured_at=now - timedelta(days=40),
                    health="healthy",
                    ready=True,
                    severity="none",
                    stale_after_seconds=86400,
                    alert_count=0,
                    alert_codes="",
                    assume_enabled=False,
                    use_policy=False,
                )
            )
            db.commit()

            service = MemoryRetentionMaintenanceAlertSnapshotRetentionService(db)
            preview = service.preview_policy()
            print("runtime: OK")
            print(f"preview: OK | candidates={preview.candidate_count} | token={bool(preview.preview_token)}")
            result = service.apply_policy(preview_token=preview.preview_token)
            db.commit()
            print(f"apply: OK | deleted_count={result.deleted_count} | run_id={bool(result.run_id)}")

            runs, cursor = MemoryRetentionMaintenanceAlertSnapshotRetentionRunRepository(db).list_all(limit=10)
            print(f"history: OK | count={len(runs)} | cursor={bool(cursor)}")
            if result.deleted_count != 1 or len(runs) != 1 or runs[0].run_id != result.run_id:
                return 1

        engine.dispose()
        return 0
    finally:
        try:
            Path(path).unlink(missing_ok=True)
        except PermissionError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
