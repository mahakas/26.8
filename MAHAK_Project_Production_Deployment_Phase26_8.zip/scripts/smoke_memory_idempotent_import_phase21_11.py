from __future__ import annotations

import os

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app


def main() -> int:
    if os.getenv("PHASE21_11_LIVE") != "1":
        print("Set PHASE21_11_LIVE=1 to run memory idempotent import smoke test.")
        return 0

    app = create_app()
    client = TestClient(app)
    user_id = "smoke-phase21-11"

    cleanup = client.delete(f"/api/memory/{user_id}/records")
    assert cleanup.status_code == 200, cleanup.text

    payload = {
        "format_version": "1.0",
        "user_id": user_id,
        "records": [
            {
                "id": "legacy-id",
                "user_id": user_id,
                "memory_type": "previous_question",
                "memory_key": "q-1",
                "value": {"question": "معادله چیست؟"},
                "confidence": 0.9,
                "source": "smoke",
            }
        ],
    }

    first = client.post(f"/api/memory/{user_id}/import", json=payload)
    assert first.status_code == 201, first.text
    print("runtime: OK")
    print(f"first_imported: {first.json()['imported_count']}")
    print(f"first_skipped: {first.json()['skipped_count']}")

    second = client.post(f"/api/memory/{user_id}/import", json=payload)
    assert second.status_code == 201, second.text
    assert second.json()["imported_count"] == 0
    assert second.json()["skipped_count"] == 1
    print("second_imported: 0")
    print("second_skipped: 1")

    records = client.get(f"/api/memory/{user_id}/records")
    assert records.status_code == 200
    assert records.json()["count"] == 1
    print("records_after_repeat: 1")
    print("idempotency: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
