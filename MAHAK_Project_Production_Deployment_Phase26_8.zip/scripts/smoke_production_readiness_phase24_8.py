from __future__ import annotations

from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.operations.backup import BackupService


def main() -> int:
    temp_root = Path(tempfile.mkdtemp(prefix="mahak-phase24-8-smoke-"))
    try:
        database = temp_root / "mahak_v2.db"
        connection = sqlite3.connect(database)
        connection.execute("CREATE TABLE smoke (id INTEGER PRIMARY KEY, value TEXT NOT NULL)")
        connection.execute("INSERT INTO smoke(value) VALUES ('ok')")
        connection.commit()
        connection.close()
        storage = temp_root / "storage_v2"
        storage.mkdir()
        (storage / "state.txt").write_text("phase24-8", encoding="utf-8")

        service = BackupService(
            database_url=f"sqlite:///{database}",
            storage_dir=storage,
            backup_dir=temp_root / "backups_v2",
            retention_count=2,
            min_free_space_mb=0,
        )
        archive = service.create_backup(label="smoke")
        manifest = service.verify_backup(archive)
        (storage / "state.txt").write_text("changed", encoding="utf-8")
        restored = service.restore_backup(archive, overwrite=True, create_pre_restore_backup=False)
        assert manifest.backup_id == restored.backup_id
        assert (storage / "state.txt").read_text(encoding="utf-8") == "phase24-8"
        connection = sqlite3.connect(database)
        row = connection.execute("SELECT value FROM smoke").fetchone()
        connection.close()
        assert row == ("ok",)
        print("production readiness: OK")
        print("backup: verified")
        print("restore: verified")
        print("retention: configured")
        print("sqlite_consistency: OK")
        return 0
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
