from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.memory.retention_run_history_policy import MemoryRetentionRunHistoryPolicyService


def main() -> int:
    if os.getenv("PHASE21_32_LIVE") != "1":
        print("Set PHASE21_32_LIVE=1 to run the Phase 21.32 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        service = MemoryRetentionRunHistoryPolicyService(db)
        default = service.get()
        assert default.configured is False
        assert (default.retention_days, default.max_delete) == (365, 500)

        configured = service.set(retention_days=90, max_delete=25)
        db.commit()
        assert configured.configured is True
        assert (configured.retention_days, configured.max_delete) == (90, 25)

        reset = service.reset()
        db.commit()
        assert reset is True
        final = service.get()
        assert final.configured is False
        assert (final.retention_days, final.max_delete) == (365, 500)

        print("runtime: OK")
        print("defaults: OK")
        print("persist: OK")
        print("reset: OK")
        print("cleanup_side_effects: NONE")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
