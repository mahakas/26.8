from __future__ import annotations

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType
from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import Base
from backend_v2.memory.integration import MemoryContext
from backend_v2.memory.personalization import MemoryPersonalizationService
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


class SmokeAgent(BaseAgent):
    agent_type = AgentType.GENERAL

    def __init__(self) -> None:
        self.personalization = None

    def execute(self, query: str, **kwargs) -> AgentResult:
        self.personalization = kwargs.get("personalization_context")
        return AgentResult(answer="memory personalized specialist response", confidence=0.8)


def main() -> None:
    if os.getenv("PHASE21_3_LIVE") != "1":
        print("Set PHASE21_3_LIVE=1 to run the Phase 21.3 smoke test.")
        return

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        context = ConversationContext(
            conversation_id="phase21-3-smoke",
            user_id="student-phase21-3",
            mode=ChatMode.GENERAL,
        )
        memory.remember(
            user_id=context.user_id,
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.25},
            confidence=0.9,
            conversation_id=context.conversation_id,
        )
        memory.remember(
            user_id=context.user_id,
            memory_type=MemoryType.STUDENT_PROFILE,
            memory_key="preferences",
            value={"explanation_style": "step_by_step"},
            confidence=0.9,
            conversation_id=context.conversation_id,
        )
        db.commit()

        memory_context = MemoryContext(tuple(memory.list(context.user_id)))
        personalization = MemoryPersonalizationService().build(memory_context)
        agent = SmokeAgent()
        registry = AgentRegistry()
        registry.register(agent)
        pipeline = UnifiedAgentPipeline(AgentRouter(registry), TeacherAgent(), memory=__import__("backend_v2.memory.integration", fromlist=["MemoryIntegrationService"]).MemoryIntegrationService(memory))
        result = pipeline.execute(
            "سلام، در جبر کمکم کن",
            conversation_context=context,
            memory_context=memory_context,
            personalization_context=personalization,
        )

        print("runtime: OK")
        print(f"personalization: weak_areas={personalization.weak_areas}")
        print(f"agent_received_personalization: {agent.personalization is not None}")
        print(f"answer: {result.answer}")
        print(f"confidence: {result.confidence}")
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    main()
