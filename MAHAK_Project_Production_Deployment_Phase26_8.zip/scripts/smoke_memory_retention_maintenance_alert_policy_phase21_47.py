from __future__ import annotations

from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceRun
from backend_v2.memory.retention_maintenance_alert_policy import MemoryRetentionMaintenanceAlertPolicyService


def main() -> int:
    if __import__("os").environ.get("PHASE21_47_LIVE") != "1":
        print("Set PHASE21_47_LIVE=1 to run the Phase 21.47 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        print("runtime: OK")
        policy = MemoryRetentionMaintenanceAlertPolicyService(db).set(stale_after_seconds=3_600)
        db.commit()
        assert policy.configured is True
        print("policy_persist: OK")

        db.add(
            MemoryRetentionMaintenanceRun(
                run_id="phase21-47-smoke",
                status="completed",
                started_at=datetime(2026, 9, 18, 0, 0),
                completed_at=datetime(2026, 9, 18, 0, 0),
                dry_run=False,
                cleanup_history=True,
                memory_status="completed",
                memory_user_count=1,
                memory_planned_count=1,
                memory_executed_count=1,
                memory_skipped_count=0,
                memory_failed_count=0,
                memory_candidate_count=0,
                memory_would_delete_count=0,
                memory_deleted_count=0,
                history_status="completed",
                history_configured=True,
                history_retention_days=365,
                history_max_delete=500,
                history_candidate_count=0,
                history_would_delete_count=0,
                history_deleted_count=0,
            )
        )
        db.commit()

        payload = client.get(
            "/api/memory/maintenance/alerts",
            params={"assume_enabled": "true", "use_policy": "true"},
        )
        assert payload.status_code == 200
        body = payload.json()
        assert body["stale_after_seconds"] == 3_600
        assert any(a["code"] == "stale_last_run" for a in body["alerts"])
        print("policy_used: OK")

        status = client.get("/api/memory/maintenance/alerts/policy")
        assert status.status_code == 200
        assert status.json()["read_only"] is True
        print("policy_status: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
