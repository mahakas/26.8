from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from uuid import uuid4


def main() -> int:
    if os.getenv("PHASE21_59_LIVE") != "1":
        print("Set PHASE21_59_LIVE=1 to run Phase 21.59 smoke test.")
        return 0

    os.environ["DATABASE_URL"] = "sqlite:///:memory:"

    from backend_v2.database.connection import Base, SessionLocal, engine
    from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
    )
    from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history_policy import (
        MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService,
    )

    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        empty = service.status()
        assert empty.retention_days == 365
        assert empty.max_delete == 500
        assert empty.configured is False
        assert empty.candidate_count == 0
        assert empty.would_delete_count == 0
        assert empty.automatic_execution_enabled is False
        assert empty.execution_mode == "explicit_only"
        assert empty.read_only is True
        print("runtime: OK")
        print("status-default: OK | candidates=0 | automatic=False")

        now = datetime.now(UTC).replace(tzinfo=None)
        run_id = f"phase21-59-run-{uuid4().hex[:12]}"
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id=run_id,
                started_at=now - timedelta(hours=1, minutes=1),
                completed_at=now - timedelta(hours=1),
                older_than=now - timedelta(days=400),
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=True,
                candidate_count=4,
                deleted_count=3,
            )
        )
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id=f"phase21-59-old-{uuid4().hex[:12]}",
                started_at=now - timedelta(days=10, minutes=1),
                completed_at=now - timedelta(days=10),
                older_than=now - timedelta(days=40),
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=False,
                candidate_count=2,
                deleted_count=1,
            )
        )
        policy = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryPolicyService(db)
        policy.set(retention_days=7, max_delete=2)
        db.commit()

        status = service.status()
        assert status.configured is True
        assert status.retention_days == 7
        assert status.max_delete == 2
        assert status.candidate_count == 1
        assert status.would_delete_count == 1
        assert status.last_execution_at is not None
        assert status.last_candidate_count == 4
        assert status.last_deleted_count == 3
        assert status.last_preview_bound is True
        assert status.read_only is True
        print(
            "status-configured: OK | candidates="
            f"{status.candidate_count} | would_delete={status.would_delete_count} | latest=True"
        )
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
