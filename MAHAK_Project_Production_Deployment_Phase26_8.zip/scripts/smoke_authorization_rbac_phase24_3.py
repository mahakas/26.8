from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.auth.rbac import Role
from backend_v2.database.connection import Base
from backend_v2.database.models.auth import User


def main() -> int:
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=engine)
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    for email in ("admin@example.com", "student@example.com"):
        response = client.post(
            "/api/auth/register",
            json={"email": email, "password": "StrongPass123!", "display_name": email.split("@")[0]},
        )
        assert response.status_code == 201, response.text

    db = Session()
    admin = db.scalar(select(User).where(User.email == "admin@example.com"))
    admin.role = Role.ADMIN.value
    db.commit()
    db.close()

    admin_login = client.post("/api/auth/login", json={"email": "admin@example.com", "password": "StrongPass123!"}).json()
    student_login = client.post("/api/auth/login", json={"email": "student@example.com", "password": "StrongPass123!"}).json()

    assert client.get("/api/admin/access-check").status_code == 401
    assert client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {student_login['access_token']}"}).status_code == 403
    assert client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {admin_login['access_token']}"}).status_code == 200

    print("authorization & RBAC: OK")
    print("admin_route_protection: OK")
    print("student_forbidden: OK")
    print("admin_allowed: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
