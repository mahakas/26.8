from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_17_LIVE") != "1":
        print("Set PHASE21_17_LIVE=1 to run the Phase 21.17 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    seed_db = Session()
    app = create_app()

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        memory = MemoryService(seed_db)
        row = memory.remember(
            user_id="smoke-audit",
            memory_type=MemoryType.PREVIOUS_QUESTION,
            memory_key="q:1",
            value={"question": "2+2?"},
        )
        seed_db.commit()

        deleted = client.delete(f"/api/memory/smoke-audit/records/{row.id}")
        if deleted.status_code != 200:
            raise AssertionError(deleted.text)

        audit = client.get("/api/memory/smoke-audit/audit")
        if audit.status_code != 200:
            raise AssertionError(audit.text)
        data = audit.json()
        assert data["count"] == 1
        assert data["items"][0]["action"] == "delete"
        assert "value" not in data["items"][0]

        print("runtime: OK")
        print("audit: OK")
        print(f"events: {data['count']}")
        print("content_free: OK")
        return 0
    finally:
        seed_db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
