from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.memory.retention_maintenance_gate import (
    MemoryRetentionMaintenanceExecutionGate,
    MemoryRetentionMaintenanceNotReadyError,
)
from backend_v2.memory.retention_maintenance_lease import MemoryRetentionMaintenanceLeaseService


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        now = datetime(2026, 9, 19, 12, 0, 0, tzinfo=UTC)
        gate = MemoryRetentionMaintenanceExecutionGate(db, enabled=True)
        decision = gate.authorize(now=now)
        assert decision.allowed is True
        report = gate.run_when_ready(now=now, dry_run=True, cleanup_history=False, lease_ttl_seconds=60)
        assert report.status == "completed"

        held = MemoryRetentionMaintenanceLeaseService(db).acquire(ttl_seconds=60, now=now)
        try:
            blocked = gate.authorize(now=now + timedelta(seconds=5))
            assert blocked.allowed is False
            assert blocked.reasons == ("maintenance_lease_held",)
            try:
                gate.run_when_ready(now=now + timedelta(seconds=5), dry_run=True, cleanup_history=False)
            except MemoryRetentionMaintenanceNotReadyError:
                pass
            else:
                raise AssertionError("Expected readiness gate to block held lease")
        finally:
            MemoryRetentionMaintenanceLeaseService(db).release(held)

        final = gate.authorize(now=now + timedelta(seconds=5))
        assert final.allowed is True

        print("runtime: OK")
        print("ready_execution: OK")
        print("held_lease_guard: OK")
        print("lease_released: OK")
        print("readiness_preserved: OK")
        return 0
    finally:
        db.close(); engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
