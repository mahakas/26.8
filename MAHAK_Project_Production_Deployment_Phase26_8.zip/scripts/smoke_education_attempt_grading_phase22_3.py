from __future__ import annotations

import os
import sys
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.database.connection import Base
from backend_v2.education import EducationalAnswerSubmission, EducationalAttemptGrader, EducationalAttemptRequest
from backend_v2.memory.progress import MemoryProgressService
from backend_v2.memory.service import MemoryService


def main() -> int:
    if os.getenv("PHASE22_3_LIVE", "0") != "1":
        print("Set PHASE22_3_LIVE=1 to run the Phase 22.3 smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        memory = MemoryService(db)
        grader = EducationalAttemptGrader(memory)
        request = EducationalAttemptRequest(
            user_id="phase22-3-smoke",
            attempt_id="phase22-3-smoke-attempt",
            task_type="quiz",
            topic="قانون دوم نیوتن",
            items=(
                EducationalAnswerSubmission(
                    item_id="q1",
                    question_type="multiple_choice",
                    question="رابطه قانون دوم نیوتن چیست؟",
                    topic="قانون دوم نیوتن",
                    answer="F=m/a",
                    correct_answer="F=ma",
                    options=("F=ma", "F=m/a"),
                ),
                EducationalAnswerSubmission(
                    item_id="q2",
                    question_type="short_answer",
                    question="رابطه نیرو، جرم و شتاب چیست؟",
                    topic="قانون دوم نیوتن",
                    answer="نیرو برابر جرم ضربدر شتاب است",
                    correct_answer="نیرو برابر جرم ضربدر شتاب است",
                ),
            ),
        )
        result = grader.grade(request)
        db.commit()
        replay = grader.grade(request)
        profile = MemoryProgressService(memory).build("phase22-3-smoke")

        assert result.correct_count == 1
        assert result.incorrect_count == 1
        assert result.total_score == 0.5
        assert dict(result.mastery_by_topic)["قانون دوم نیوتن"] == 0.5
        assert "قانون دوم نیوتن" in profile.active_weak_areas
        assert replay.idempotent_replay is True

        print("education attempt grading: OK")
        print("attempt_id:", result.attempt_id)
        print("score:", result.total_score)
        print("correct:", result.correct_count)
        print("incorrect:", result.incorrect_count)
        print("mastery:", dict(result.mastery_by_topic))
        print("weak_area_status:", dict(result.weak_area_status_by_topic))
        print("idempotent_replay:", replay.idempotent_replay)
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
