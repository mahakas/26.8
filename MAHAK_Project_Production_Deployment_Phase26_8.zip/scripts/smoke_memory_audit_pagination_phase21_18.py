from __future__ import annotations

import os
import sys

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        memory = MemoryService(db)
        rows = [
            memory.remember(
                user_id="phase21-18-smoke",
                memory_type=MemoryType.PREVIOUS_QUESTION,
                memory_key=f"q:{i}",
                value={"question": f"question-{i}"},
            )
            for i in range(3)
        ]
        db.commit()
        for row in rows:
            response = client.delete(f"/api/memory/phase21-18-smoke/records/{row.id}")
            if response.status_code != 200:
                raise AssertionError(response.text)

        first = client.get(
            "/api/memory/phase21-18-smoke/audit",
            params={"limit": 2},
        )
        if first.status_code != 200:
            raise AssertionError(first.text)
        first_payload = first.json()
        if first_payload["count"] != 2 or not first_payload["next_cursor"]:
            raise AssertionError(first_payload)

        second = client.get(
            "/api/memory/phase21-18-smoke/audit",
            params={"limit": 2, "cursor": first_payload["next_cursor"]},
        )
        if second.status_code != 200:
            raise AssertionError(second.text)
        second_payload = second.json()
        if second_payload["count"] != 1 or second_payload["next_cursor"] is not None:
            raise AssertionError(second_payload)

        print("runtime: OK")
        print("page1_count:", first_payload["count"])
        print("page2_count:", second_payload["count"])
        print("cursor_pagination: OK")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
