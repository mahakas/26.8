from __future__ import annotations

import os
import sys
from datetime import UTC, datetime, timedelta

sys.path.insert(0, ".")

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_26_LIVE") != "1":
        print("Set PHASE21_26_LIVE=1 to run the live smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        now = datetime(2026, 9, 19, tzinfo=UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="phase21-26-smoke",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old",
                value_json={"q": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            )
        )
        db.commit()
        MemoryRetentionPolicyService(db).set(
            "phase21-26-smoke",
            retention_days=30,
            max_delete=1,
            memory_type=MemoryType.PREVIOUS_QUESTION,
        )

        before = db.query(LearningMemory).filter(LearningMemory.user_id == "phase21-26-smoke").count()
        plan = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            user_ids=["phase21-26-smoke"],
            now=now,
            dry_run=True,
        )
        assert plan[0].status == "planned"
        assert plan[0].would_delete_count == 1
        assert plan[0].deleted_count == 0
        assert db.query(LearningMemory).filter(LearningMemory.user_id == "phase21-26-smoke").count() == before
        assert db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "phase21-26-smoke").count() == 0

        result = MemoryRetentionSchedulerService(db, enabled=True).run_once(
            user_ids=["phase21-26-smoke"],
            now=now,
        )
        assert result[0].status == "executed"
        assert result[0].deleted_count == 1

        print("runtime: OK")
        print("dry_run: OK")
        print("non_mutating_plan: OK")
        print("scheduler_run: OK")
        print(f"would_delete_count: {plan[0].would_delete_count}")
        print(f"deleted_count: {result[0].deleted_count}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
