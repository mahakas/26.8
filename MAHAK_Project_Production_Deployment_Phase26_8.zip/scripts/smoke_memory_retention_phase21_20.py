from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory, MemoryAuditEvent
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_20_LIVE") != "1":
        print("Set PHASE21_20_LIVE=1 to run the Phase 21.20 retention smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    cutoff = datetime(2026, 1, 5, tzinfo=UTC)
    base = datetime(2026, 1, 1, tzinfo=UTC).replace(tzinfo=None)
    db.add_all(
        [
            LearningMemory(
                user_id="smoke-retention",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-1",
                value_json={"q": 1},
                created_at=base,
                updated_at=base,
            ),
            LearningMemory(
                user_id="smoke-retention",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-2",
                value_json={"q": 2},
                created_at=base + timedelta(days=1),
                updated_at=base + timedelta(days=1),
            ),
            LearningMemory(
                user_id="smoke-retention",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="new",
                value_json={"q": 3},
                created_at=base + timedelta(days=10),
                updated_at=base + timedelta(days=10),
            ),
        ]
    )
    db.commit()

    preview = client.post(
        "/api/memory/smoke-retention/retention/preview",
        params={"older_than": cutoff.isoformat(), "max_delete": 1},
    )
    assert preview.status_code == 200
    preview_payload = preview.json()
    assert preview_payload["candidate_count"] == 2
    assert preview_payload["would_delete_count"] == 1
    assert preview_payload["read_only"] is True
    print("runtime: OK")
    print("preview: OK")

    before_apply_audit = len(
        db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "smoke-retention").all()
    )
    apply = client.post(
        "/api/memory/smoke-retention/retention/apply",
        params={"older_than": cutoff.isoformat(), "max_delete": 1},
    )
    assert apply.status_code == 200
    assert apply.json()["deleted_count"] == 1
    after_apply_audit = len(
        db.query(MemoryAuditEvent).filter(MemoryAuditEvent.user_id == "smoke-retention").all()
    )
    assert before_apply_audit == 0
    assert after_apply_audit == 1
    print("apply: OK")
    print("deleted_count: 1")
    print("audit: OK")

    db.close()
    engine.dispose()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
