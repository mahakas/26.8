from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

if os.getenv("PHASE20_6_LIVE", "0") != "1":
    print("Set PHASE20_6_LIVE=1 to run the live VideoAgent smoke test.")
    raise SystemExit(0)

from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.video import VideoAgent
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import OpenCVFrameSampler, SidecarTranscript, VideoProcessor
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalService
from backend_v2.runtime import V2Runtime
from backend_v2.schemas.video_answer import VideoAnswerResponse
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--transcript")
    args = parser.parse_args()

    video = Path(args.video)
    if not video.exists():
        raise SystemExit(f"Video not found: {video}")

    if args.transcript:
        sidecar = Path(args.transcript)
        target = video.with_suffix(".srt")
        if sidecar.resolve() != target.resolve():
            target.write_bytes(sidecar.read_bytes())

    runtime = V2Runtime()
    print("runtime: OK")

    processor = VideoProcessor(
        runtime.llm_orchestrator,
        transcriber=SidecarTranscript(),
        frame_sampler=OpenCVFrameSampler(interval_seconds=10.0, max_frames=12),
        frame_output_dir=video.parent / "phase20_6_frames",
        vision_enabled=True,
    )
    result = IngestionPipeline(video_processor=processor, chunk_size=700, overlap=80).process(video)
    frame_count = int(result.document.metadata.get("frame_count") or 0)
    print(f"video: OK | chunks={len(result.chunks)} | frames={frame_count}")
    if not result.chunks:
        return 3

    dimension = runtime.embedding.embed(["x"]).dimension
    spec = IndexSpec(
        "physics10_video_20_6",
        "bge-m3-local",
        "bge-m3-v1",
        dimension,
    )
    indexed = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
        result.chunks,
        index_spec=spec,
        source_id=video.stem,
        title=video.stem,
        scope_metadata={
            "source_type": "video",
            "grade_id": "10",
            "subject_id": "physics",
            "video_id": video.stem,
        },
    )
    print(f"index: OK | collection={indexed.collection} | chunks={indexed.indexed}")

    retrieval = RetrievalService(runtime.vector_store, runtime.embedding)
    agent = VideoAgent(
        retrieval,
        collection=indexed.collection,
        scope=RetrievalScope(grade_id="10", subject_id="physics"),
        top_k=5,
        candidate_k=10,
        min_score=0.20,
    )
    registry = AgentRegistry()
    registry.register(agent)
    router = AgentRouter(registry)

    result = router.execute("قانون دوم نیوتن در ویدئو چه زمانی توضیح داده شده؟")
    response = agent.to_response(result)

    print(f"router: {AgentRouter.__name__} -> VIDEO_AGENT")
    print(f"agent: {'OK' if result.evidence else 'FAILED'} | citations={len(result.citations)}")
    print(f"schema: {type(response).__name__}")
    if not isinstance(response, VideoAnswerResponse):
        return 4

    frame_refs = sum(1 for item in result.citations if item.get("frame_path"))
    print(f"frame_references: {frame_refs}")
    print(f"confidence: {response.confidence}")
    for citation in response.citations:
        print(
            " -",
            citation.start_time_seconds,
            "->",
            citation.end_time_seconds,
            "frame=",
            bool(citation.frame_path),
        )

    return 0 if response.found else 5


if __name__ == "__main__":
    raise SystemExit(main())
