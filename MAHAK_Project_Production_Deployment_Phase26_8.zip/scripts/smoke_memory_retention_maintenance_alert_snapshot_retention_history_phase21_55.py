from __future__ import annotations

import os
from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.database.connection import Base
from backend_v2.database.models import MemoryRetentionMaintenanceAlertSnapshotRetentionRun
from backend_v2.memory.retention_maintenance_alert_snapshot_retention_history import (
    MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService,
)


def main() -> int:
    if os.getenv("PHASE21_55_LIVE") != "1":
        print("Set PHASE21_55_LIVE=1 to run the Phase 21.55 smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)()
    try:
        cutoff = datetime.now()
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id="smoke-old-a",
                started_at=cutoff - timedelta(days=4),
                completed_at=cutoff - timedelta(days=4),
                older_than=cutoff - timedelta(days=30),
                candidate_count=1,
                deleted_count=1,
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=True,
            )
        )
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id="smoke-old-b",
                started_at=cutoff - timedelta(days=3),
                completed_at=cutoff - timedelta(days=3),
                older_than=cutoff - timedelta(days=30),
                candidate_count=1,
                deleted_count=0,
                retention_days=30,
                max_delete=500,
                configured=False,
                preview_bound=False,
            )
        )
        db.add(
            MemoryRetentionMaintenanceAlertSnapshotRetentionRun(
                run_id="smoke-new",
                started_at=cutoff - timedelta(hours=1),
                completed_at=cutoff - timedelta(hours=1),
                older_than=cutoff - timedelta(days=30),
                candidate_count=0,
                deleted_count=0,
                retention_days=30,
                max_delete=500,
                configured=True,
                preview_bound=True,
            )
        )
        db.commit()

        service = MemoryRetentionMaintenanceAlertSnapshotRetentionHistoryService(db)
        preview = service.preview(older_than=cutoff - timedelta(days=2), max_delete=1)
        assert preview.candidate_count == 2
        assert preview.would_delete_count == 1

        applied = service.apply(older_than=cutoff - timedelta(days=2), max_delete=1)
        assert applied.candidate_count == 2
        assert applied.deleted_count == 1
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "smoke-old-a") is None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "smoke-old-b") is not None
        assert db.get(MemoryRetentionMaintenanceAlertSnapshotRetentionRun, "smoke-new") is not None

        print("runtime: OK")
        print("preview: OK | candidates=2 | would_delete=1")
        print("apply: OK | deleted_count=1 | oldest_first=True")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
