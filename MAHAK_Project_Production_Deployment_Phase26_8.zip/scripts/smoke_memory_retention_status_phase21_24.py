from __future__ import annotations

import os
import sys
from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

sys.path.insert(0, ".")

from backend_v2.api.app import create_app  # noqa: E402
from backend_v2.api.dependencies import get_db  # noqa: E402
from backend_v2.database.connection import Base  # noqa: E402
from backend_v2.database.models import LearningMemory  # noqa: E402
from backend_v2.memory.types import MemoryType  # noqa: E402


def main() -> int:
    if os.getenv("PHASE21_24_LIVE") != "1":
        print("Set PHASE21_24_LIVE=1 to run the live smoke test.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        db.add(
            LearningMemory(
                user_id="phase21-24-smoke",
                memory_type=MemoryType.PREVIOUS_QUESTION.value,
                memory_key="old-question",
                value_json={"q": "old"},
                created_at=now - timedelta(days=60),
                updated_at=now - timedelta(days=60),
            )
        )
        db.commit()

        configured = client.put(
            "/api/memory/phase21-24-smoke/retention/policy",
            json={"retention_days": 30, "max_delete": 10, "memory_type": "previous_question"},
        )
        assert configured.status_code == 200

        status = client.get("/api/memory/phase21-24-smoke/retention/status")
        assert status.status_code == 200
        payload = status.json()
        assert payload["candidate_count"] == 1
        assert payload["would_delete_count"] == 1
        assert payload["automatic_execution_enabled"] is False
        assert payload["execution_mode"] == "explicit_only"
        print("runtime: OK")
        print("status: OK")
        print(f"candidate_count: {payload['candidate_count']}")
        print(f"would_delete_count: {payload['would_delete_count']}")
        print(f"last_execution: {payload['last_execution_at']}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
