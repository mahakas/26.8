from __future__ import annotations

import argparse
from datetime import UTC, datetime
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend_v2.core.config import settings
from backend_v2.operations.backup import BackupService
from backend_v2.operations.readiness import check_operational_readiness


def main() -> int:
    parser = argparse.ArgumentParser(description="MAHAK Phase 24.8 operational readiness check")
    parser.add_argument("--require-backup", action="store_true")
    parser.add_argument("--max-backup-age-hours", type=float, default=24.0)
    args = parser.parse_args()

    readiness = check_operational_readiness()
    print(f"operational readiness: {readiness.status.upper()}")
    for name, value in readiness.checks.items():
        print(f"{name}: {value}")

    service = BackupService(
        database_url=settings.database_url,
        storage_dir=settings.storage_dir,
        backup_dir=settings.backup_dir,
        retention_count=settings.backup_retention_count,
        include_storage=settings.backup_include_storage,
        verify_after_create=settings.backup_verify_after_create,
        min_free_space_mb=settings.backup_min_free_space_mb,
    )
    backups = service.list_backups()
    backup_ok = False
    if backups:
        latest = backups[0]
        age_hours = (datetime.now(UTC).timestamp() - latest.stat().st_mtime) / 3600.0
        backup_ok = age_hours <= args.max_backup_age_hours
        print(f"latest_backup: {latest.name}")
        print(f"backup_age_hours: {age_hours:.2f}")
    else:
        print("latest_backup: none")
    print(f"backup_fresh: {'ok' if backup_ok else 'error'}")

    if args.require_backup and not backup_ok:
        return 1
    return 0 if readiness.ready else 1


if __name__ == "__main__":
    raise SystemExit(main())
