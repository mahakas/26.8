from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.database.models import LearningMemory
from backend_v2.memory.retention_policy import MemoryRetentionPolicyService
from backend_v2.memory.retention_scheduler import MemoryRetentionSchedulerService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_29_LIVE") != "1":
        print("Set PHASE21_29_LIVE=1 to run Phase 21.29 smoke.")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    app = create_app()

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)

    try:
        now = datetime(2026, 9, 19, tzinfo=UTC).replace(tzinfo=None)
        for user_id in ("smoke-29-a", "smoke-29-b"):
            db.add(
                LearningMemory(
                    user_id=user_id,
                    memory_type=MemoryType.PREVIOUS_QUESTION.value,
                    memory_key=f"old:{user_id}",
                    value_json={"question": "old"},
                    created_at=now - timedelta(days=60),
                    updated_at=now - timedelta(days=60),
                )
            )
            MemoryRetentionPolicyService(db).set(
                user_id,
                retention_days=30,
                max_delete=1,
                memory_type=MemoryType.PREVIOUS_QUESTION,
            )
        db.commit()

        report = MemoryRetentionSchedulerService(db, enabled=True).run_with_report(
            user_ids=["smoke-29-a", "smoke-29-b"],
            now=datetime(2026, 9, 19, tzinfo=UTC),
            dry_run=True,
        )
        assert report.status == "completed"

        first = client.get("/api/memory/smoke-29-a/retention/runs", params={"limit": 1})
        assert first.status_code == 200
        payload = first.json()
        assert payload["count"] == 1
        assert payload["items"][0]["user_id"] == "smoke-29-a"
        print("runtime: OK")
        print("history_api: OK")
        print("user_scope: OK")
        print(f"run_id: {payload['items'][0]['run_id']}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
