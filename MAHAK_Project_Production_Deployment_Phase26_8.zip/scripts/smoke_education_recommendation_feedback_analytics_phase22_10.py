from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend_v2.api.app import create_app
from backend_v2.api.dependencies import get_db
from backend_v2.database.connection import Base
from backend_v2.education.recommendation_feedback import EducationalRecommendationFeedbackRequest
from backend_v2.education.recommendation_feedback_history import EducationalRecommendationFeedbackHistoryService
from backend_v2.memory.service import MemoryService


@dataclass(frozen=True)
class _SmokeResult:
    outcome: str
    feedback_action: str
    topic: str = "قانون دوم نیوتن"
    difficulty: str | None = "medium"
    completion_percent: float = 100.0
    mastery_gap: float = 0.0
    latest_score: float | None = 1.0
    remediation_share: float = 0.0


def main() -> int:
    if os.getenv("PHASE22_10_LIVE") != "1":
        print("PHASE22_10_LIVE is not set to 1; smoke skipped")
        return 0

    engine = create_engine(
        "sqlite:///:memory:",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()

    try:
        app = create_app()
        app.dependency_overrides[get_db] = lambda: (yield db)
        client = TestClient(app)

        started = client.post(
            "/api/education/learning-plans/start",
            json={
                "user_id": "student-22-10-smoke",
                "plan_id": "phase22-10-smoke-plan",
                "total_sessions": 1,
                "session_steps": 1,
                "topic": "قانون دوم نیوتن",
                "mastery_target": 0.75,
                "max_remediation_sessions": 1,
            },
        )
        assert started.status_code == 200, started.text

        history = EducationalRecommendationFeedbackHistoryService(MemoryService(db))
        request = EducationalRecommendationFeedbackRequest(
            user_id="student-22-10-smoke",
            learning_plan_id="phase22-10-smoke-plan",
            question_count=5,
        )
        for feedback_id, completion, gap in (
            ("phase22-10-old-1", 70.0, 0.20),
            ("phase22-10-old-2", 70.0, 0.20),
            ("phase22-10-new-1", 100.0, 0.00),
            ("phase22-10-new-2", 100.0, 0.00),
        ):
            history.record(
                request,
                _SmokeResult(
                    outcome="on_track",
                    feedback_action="reinforce",
                    completion_percent=completion,
                    mastery_gap=gap,
                    latest_score=completion / 100.0,
                ),
                feedback_id=feedback_id,
            )

        response = client.get(
            "/api/education/recommendations/feedback/analytics",
            params={
                "user_id": "student-22-10-smoke",
                "learning_plan_id": "phase22-10-smoke-plan",
                "window_size": 2,
            },
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total_feedback"] == 4
        assert body["trend"] == "improving"
        assert body["completion_delta_percent"] == 30.0
        assert body["mastery_gap_delta"] == -0.2
        assert body["remediation_rate"] == 0.0

        print("learning recommendation feedback analytics: OK")
        print(f"total_feedback: {body['total_feedback']}")
        print(f"trend: {body['trend']}")
        print(f"completion_delta_percent: {body['completion_delta_percent']}")
        print(f"mastery_gap_delta: {body['mastery_gap_delta']}")
        print(f"latest_action: {body['latest_action']}")
        return 0
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
