from __future__ import annotations

import os

from backend_v2.agents.base import BaseAgent
from backend_v2.agents.pipeline import UnifiedAgentPipeline
from backend_v2.agents.registry import AgentRegistry
from backend_v2.agents.router import AgentRouter
from backend_v2.agents.teacher import TeacherAgent
from backend_v2.agents.types import AgentResult, AgentType


class SmokeDocumentAgent(BaseAgent):
    agent_type = AgentType.DOCUMENT

    def execute(self, query: str, **kwargs) -> AgentResult:
        return AgentResult(
            answer=f"Document answer for: {query}",
            evidence=[{"type": "document", "page": 2}],
            citations=[{"title": "smoke-document", "page": 2}],
            confidence=0.85,
        )


def main() -> int:
    if os.getenv("PHASE20_9_LIVE") != "1":
        print("Set PHASE20_9_LIVE=1 to run the unified agent pipeline smoke test.")
        return 0

    registry = AgentRegistry()
    registry.register(SmokeDocumentAgent())

    pipeline = UnifiedAgentPipeline(
        AgentRouter(registry),
        TeacherAgent(),
    )

    result = pipeline.execute("صفحه دوم این کتاب را توضیح بده")

    if not result.answer:
        raise SystemExit("answer: FAIL")
    if not result.evidence:
        raise SystemExit("evidence: FAIL")
    if not result.citations:
        raise SystemExit("citations: FAIL")

    print("runtime: OK")
    print("router: DOCUMENT_AGENT")
    print("specialist: OK")
    print("teacher: OK")
    print("evidence: preserved")
    print("citations: preserved")
    print(f"confidence: {result.confidence}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
