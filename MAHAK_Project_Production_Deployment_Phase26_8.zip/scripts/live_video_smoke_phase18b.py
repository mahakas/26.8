from __future__ import annotations
import argparse, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
load_dotenv(ROOT / '.env')

if os.getenv('PHASE18B_LIVE', '0') != '1':
    print('Set PHASE18B_LIVE=1 to run the live video 18B smoke test.')
    raise SystemExit(0)

os.environ['MAHAK_PROVIDER_MODE'] = 'live'
os.environ['VECTOR_STORE_BACKEND'] = 'chroma'
os.environ['EMBED_BACKEND'] = 'local'
os.environ['EMBED_MODEL'] = 'BAAI/bge-m3'

from backend_v2.runtime import V2Runtime
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.video import VideoProcessor, SidecarTranscript, OpenCVFrameSampler, FasterWhisperTranscriber
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalService, RetrievalRequest
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--video', required=True)
    parser.add_argument('--transcript', default=None)
    parser.add_argument('--transcribe', action='store_true')
    parser.add_argument('--interval', type=float, default=20.0)
    parser.add_argument('--max-frames', type=int, default=4)
    args = parser.parse_args()
    video = Path(args.video)
    if not video.exists():
        raise SystemExit(f'Video not found: {video}')
    if args.transcript:
        sidecar = Path(args.transcript)
        target = video.with_suffix('.srt')
        if sidecar.resolve() != target.resolve():
            target.write_bytes(sidecar.read_bytes())
    runtime = V2Runtime()
    transcriber = FasterWhisperTranscriber(model_size=os.getenv('WHISPER_MODEL', 'small'), device=os.getenv('WHISPER_DEVICE', 'cpu'), compute_type=os.getenv('WHISPER_COMPUTE_TYPE', 'int8'), language='fa') if args.transcribe else SidecarTranscript()
    processor = VideoProcessor(
        runtime.llm_orchestrator,
        transcriber=transcriber,
        frame_sampler=OpenCVFrameSampler(interval_seconds=args.interval, max_frames=args.max_frames),
        frame_output_dir=video.parent / f'{video.stem}_phase18b_frames',
        vision_enabled=True,
    )
    result = IngestionPipeline(video_processor=processor, chunk_size=700, overlap=80).process(video)
    print(f'video: OK | transcript_segments={result.document.metadata.get("transcript_segment_count")} | transcription_backend={result.document.metadata.get("transcription_backend")} | frames={result.document.metadata.get("frame_count")} | frame_backend={result.document.metadata.get("frame_backend")} | chunks={len(result.chunks)}')
    for chunk in result.chunks[:8]:
        print(' -', chunk.metadata.get('kind'), chunk.metadata.get('start_time_seconds'), chunk.metadata.get('end_time_seconds'), chunk.text[:100])
    if not result.chunks:
        return 3
    spec = IndexSpec('physics10_video_18b', 'bge-m3-local', 'bge-m3-v1', 1024)
    indexed = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
        result.chunks, index_spec=spec, source_id=video.stem, title=video.stem,
        scope_metadata={'grade_id': '10', 'subject_id': 'physics', 'source_type': 'video', 'video_id': video.stem},
    )
    print(f'index: OK | collection={indexed.collection} | chunks={indexed.indexed}')
    retr = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
        RetrievalRequest('در ویدئو قانون دوم نیوتن و رابطه F = ma چه زمانی توضیح داده شده؟', RetrievalScope(grade_id='10', subject_id='physics'), spec.collection_name, top_k=5, candidate_k=10, min_score=.20)
    )
    print(f'retrieval: {"OK" if retr.found else "FAILED"} | hits={len(retr.accepted)}')
    for hit in retr.accepted:
        print(' -', hit.metadata.get('kind'), hit.metadata.get('start_time_seconds'), hit.metadata.get('end_time_seconds'), hit.metadata.get('vision_model'))
    return 0 if retr.found else 4

if __name__ == '__main__':
    raise SystemExit(main())
