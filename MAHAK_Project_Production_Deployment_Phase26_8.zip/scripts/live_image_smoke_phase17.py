from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
load_dotenv(ROOT / '.env')

if os.getenv('PHASE17_LIVE', '0') != '1':
    print('Set PHASE17_LIVE=1 to run the live image smoke test.')
    raise SystemExit(0)

os.environ['MAHAK_PROVIDER_MODE'] = 'live'
os.environ['VECTOR_STORE_BACKEND'] = 'chroma'
os.environ['EMBED_BACKEND'] = 'local'
os.environ['EMBED_MODEL'] = 'BAAI/bge-m3'

from backend_v2.runtime import V2Runtime
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.ingestion.processors.image import VisionImageProcessor
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalService, RetrievalRequest
from backend_v2.vectorstores.indexing import IndexSpec
from backend_v2.vectorstores.knowledge import KnowledgeIndexService


def make_image(path: Path) -> None:
    image = Image.new('RGB', (1000, 500), 'white')
    draw = ImageDraw.Draw(image)
    draw.text((40, 40), 'فیزیک دهم', fill='black')
    draw.text((40, 120), 'قانون دوم نیوتن', fill='black')
    draw.text((40, 220), 'F = ma', fill='black')
    draw.text((40, 320), 'نیروی خالص = جرم × شتاب', fill='black')
    image.save(path)


def main() -> int:
    try:
        with tempfile.TemporaryDirectory(prefix='mahak_phase17_') as td_raw:
            td = Path(td_raw)
            path = td / 'newton-law.png'
            make_image(path)
            runtime = V2Runtime()
            processor = VisionImageProcessor(runtime.llm_orchestrator, ocr_enabled=os.getenv('IMAGE_OCR_ENABLED', 'true').lower() in {'1','true','yes','on'}, ocr_language=os.getenv('OCR_LANG', 'fas+eng'))
            pipeline = IngestionPipeline(chunk_size=700, overlap=80, vision_processor=processor)
            result = pipeline.process(path)
            print(f'image: OK | chunks={len(result.chunks)} | vision={result.document.metadata.get("vision_provider")} | model={result.document.metadata.get("vision_model")}')
            print(f'ocr_present: {result.document.metadata.get("ocr_text_present")}')
            spec = IndexSpec('physics10_images', 'bge-m3-local', 'bge-m3-v1', 1024)
            indexed = KnowledgeIndexService(runtime.vector_store, runtime.embedding).index_chunks(
                result.chunks, index_spec=spec, source_id='phase17-image', title='قانون دوم نیوتن - تصویر',
                scope_metadata={'grade_id':'10','subject_id':'physics','source_type':'image','image_id':result.document.metadata.get('image_id')},
            )
            print(f'index: OK | collection={indexed.collection} | chunks={indexed.indexed}')
            retr = RetrievalService(runtime.vector_store, runtime.embedding).retrieve(
                RetrievalRequest('قانون دوم نیوتن', RetrievalScope(grade_id='10', subject_id='physics'), spec.collection_name, top_k=3, candidate_k=6, min_score=.20)
            )
            print(f'retrieval: {"OK" if retr.found else "FAILED"} | hits={len(retr.accepted)}')
            for hit in retr.accepted:
                print(' -', hit.metadata.get('source_type'), hit.metadata.get('image_id'), hit.metadata.get('title'))
            return 0 if indexed.indexed and retr.found else 3
    except Exception as exc:
        print(f'ERROR: {type(exc).__name__}: {exc}')
        return 10


if __name__ == '__main__':
    raise SystemExit(main())
