from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend_v2.database.connection import Base
from backend_v2.memory.service import MemoryService
from backend_v2.memory.types import MemoryType


def main() -> int:
    if os.getenv("PHASE21_1_LIVE") != "1":
        print("Set PHASE21_1_LIVE=1 to run the Phase 21.1 memory smoke test.")
        return 0

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Session()
    try:
        service = MemoryService(db)
        service.remember(
            user_id="smoke-user",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
            value={"mastery": 0.35},
            confidence=0.9,
            source="phase21.1-smoke",
        )
        db.commit()
        record = service.latest(
            "smoke-user",
            memory_type=MemoryType.WEAK_AREA,
            memory_key="algebra",
        )
        assert record is not None
        assert record.value["mastery"] == 0.35
        print("runtime: OK")
        print(f"memory: {record.memory_type.value}")
        print(f"confidence: {record.confidence}")
        print("persistence: OK")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
