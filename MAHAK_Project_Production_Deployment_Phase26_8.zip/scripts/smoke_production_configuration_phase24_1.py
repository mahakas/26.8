from __future__ import annotations

import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    if os.getenv("PHASE24_1_LIVE") != "1":
        print("set PHASE24_1_LIVE=1 to run Phase 24.1 smoke")
        return 0

    from backend_v2.core.config import AppSettings, ConfigurationError

    production = AppSettings(
        environment="production",
        debug=False,
        secret_key="phase24-1-" + "x" * 64,
        allowed_hosts=("api.example.com",),
        cors_origins=("https://app.example.com",),
        log_level="INFO",
    )
    production.validate()
    safe = production.safe_dict()

    assert production.is_production is True
    assert production.secret_configured is True
    assert "secret_key" not in safe
    assert production.secret_key not in repr(safe)

    try:
        AppSettings(environment="production", allowed_hosts=("api.example.com",)).validate()
    except ConfigurationError:
        rejected = True
    else:
        rejected = False

    assert rejected is True

    print("production configuration: OK")
    print(f"environment: {production.environment}")
    print(f"secret_configured: {production.secret_configured}")
    print(f"allowed_hosts: {production.allowed_hosts}")
    print(f"safe_secret_exposure: {'secret_key' in safe}")
    print(f"unsafe_production_rejected: {rejected}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
