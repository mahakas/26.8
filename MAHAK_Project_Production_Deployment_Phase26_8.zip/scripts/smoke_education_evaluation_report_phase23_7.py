from __future__ import annotations

import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    if os.getenv("PHASE23_7_LIVE") != "1":
        print("set PHASE23_7_LIVE=1 to run Phase 23.7 smoke")
        return 0

    from backend_v2.evaluation import EducationalEvaluationReportService

    answer = {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_overall_score": 0.95,
        "average_answer_quality_score": 0.95,
        "average_retrieval_f1": 0.95,
        "average_citation_f1": 0.95,
        "average_evidence_coverage": 0.95,
        "quality_band_counts": {"excellent": 2},
        "cases": [],
        "errors": [],
    }
    groundedness = {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_groundedness_score": 0.95,
        "average_unsupported_claim_rate": 0.05,
        "average_hallucination_risk": 0.05,
        "groundedness_band_counts": {"well_grounded": 2},
        "cases": [],
        "errors": [],
    }
    agents = {
        "total_cases": 2,
        "evaluated_cases": 2,
        "failed_cases": 0,
        "average_overall_score": 0.95,
        "average_modality_evidence_coverage": 0.95,
        "average_locator_completeness": 0.95,
        "agent_type_counts": {"teacher": 2},
        "quality_band_counts": {"excellent": 2},
        "cases": [],
        "errors": [],
    }

    service = EducationalEvaluationReportService()
    first = service.build(
        report_id="phase23-7-smoke",
        answer_batch=answer,
        groundedness_batch=groundedness,
        agents_batch=agents,
    )
    second = service.build(
        report_id="phase23-7-smoke",
        answer_batch=answer,
        groundedness_batch=groundedness,
        agents_batch=agents,
    )

    assert first.as_dict() == second.as_dict()
    assert first.overall_score is not None and first.overall_score >= 0.9
    assert first.risk_flags == ()
    assert first.quality_band == "excellent"

    print("evaluation report: OK")
    print(f"sections: {first.section_count}")
    print(f"overall_score: {first.overall_score}")
    print(f"quality_band: {first.quality_band}")
    print(f"risk_flags: {len(first.risk_flags)}")
    print(f"deterministic_repeat: {first.as_dict() == second.as_dict()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
