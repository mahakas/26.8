from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend_v2.agents.evidence_fusion import CrossModalEvidenceFusion
from backend_v2.agents.types import AgentResult


def main():
    results = [
        AgentResult("doc", [{"type": "document", "text": "قانون دوم نیرو شتاب"}], [{"source_id": "book", "page": 4}], 0.9),
        AgentResult("image", [{"type": "image", "text": "نمودار نیرو شتاب"}], [{"source_id": "diagram", "image_id": "img-1"}], 0.8),
        AgentResult("audio", [{"type": "audio", "transcript": "رابطه نیرو شتاب"}], [{"source_id": "lecture", "start_time_seconds": 12.0, "end_time_seconds": 15.0}], 0.8),
    ]
    fused, report = CrossModalEvidenceFusion().fuse(results)
    assert set(report.modalities) == {"document", "image", "audio"}
    assert report.cross_modal_links
    assert len(fused.evidence) == 3
    assert len(fused.citations) == 3
    assert 0.0 <= fused.confidence <= 1.0
    print("cross-modal reasoning & evidence fusion: OK")
    print(f"modalities: {report.modalities}")
    print(f"evidence: {report.evidence_count}")
    print(f"cross_modal_links: {len(report.cross_modal_links)}")
    print(f"corroboration: {report.corroboration_score}")
    print(f"fused_confidence: {report.fused_confidence}")


if __name__ == "__main__":
    main()
