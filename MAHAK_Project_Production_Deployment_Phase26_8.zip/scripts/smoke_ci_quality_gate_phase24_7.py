from __future__ import annotations

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    command = [sys.executable, str(ROOT / "scripts/ci_quality_gate_phase24_7.py"), "--skip-tests"]
    result = subprocess.run(command, cwd=ROOT)
    print("ci quality gate smoke: " + ("OK" if result.returncode == 0 else "FAILED"))
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
