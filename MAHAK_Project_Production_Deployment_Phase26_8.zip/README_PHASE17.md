# Phase 17 — Image + Vision + OCR

This phase adds a multimodal image pipeline to Mahak v2.

## Flow

`Image -> optional local OCR -> Vision Provider -> normalized text -> BGE-M3 -> Chroma -> Retrieval -> image-aware citation`

## Environment

```env
IMAGE_OCR_ENABLED=true
OCR_LANG=fas+eng
EMBED_BACKEND=local
EMBED_MODEL=BAAI/bge-m3
VECTOR_STORE_BACKEND=chroma
```

For real Vision execution, configure a provider model with the `vision` capability, for example an OpenAI-compatible provider:

```env
OPENROUTER_API_KEY=...
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
OPENROUTER_VISION_MODEL=your-vision-model
```

The system never fabricates OCR text when the Tesseract binary is unavailable; it records a warning and can continue with the Vision provider.

## Live test

```powershell
$env:PHASE17_LIVE="1"
python scripts/live_image_smoke_phase17.py
```

Expected shape:

```text
image: OK | chunks=... | vision=... | model=...
ocr_present: ...
index: OK | collection=physics10_images | chunks=...
retrieval: OK | hits=...
```
