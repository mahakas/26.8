# MAHAK Phase 26.2 — Request Validation & Structured Errors

## Delivered

The v1 Teacher API now returns a consistent error envelope for authentication, authorization, not-found, validation, conflict, rate-limit, and unexpected internal errors.

Example shape:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "request failed",
    "details": {}
  },
  "request_id": "..."
}
```

Business-level 422 errors use `INVALID_TEACHER_REQUEST`, while FastAPI request-body validation remains `VALIDATION_ERROR`.

Legacy `/api/*` behavior is preserved outside `/api/teacher/v1`.
