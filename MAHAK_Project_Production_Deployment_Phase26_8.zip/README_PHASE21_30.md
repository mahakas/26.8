# Phase 21.30 — Retention Scheduler Run History Summary

Adds a read-only, user-scoped aggregate API:

`GET /api/memory/{user_id}/retention/runs/summary`

The summary aggregates scheduler run history without exposing memory content or other users' aggregates. Supported filters:

- `start_at` inclusive
- `end_at` exclusive
- `run_status`: `completed` or `completed_with_errors`
- `result_status`: `planned`, `executed`, `skipped`, `failed`
- `dry_run`: boolean

No mutation occurs and no scheduler run is created by the endpoint.
