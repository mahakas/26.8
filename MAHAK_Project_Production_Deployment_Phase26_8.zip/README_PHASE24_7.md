# MAHAK Phase 24.7 — CI/CD Pipeline & Automated Quality Gates

## Goal

Establish repeatable CI quality gates and a generic container release pipeline without assuming a specific cloud deployment target.

## CI workflow

`.github/workflows/ci.yml` runs on pull requests and pushes to `main`/`master`.

Quality gates:

1. Full `tests_v2` regression.
2. `python -m compileall -q backend_v2 scripts`.
3. Phase 24.4 Security Hardening smoke.
4. Phase 24.5 Observability smoke.
5. Phase 24.6 Docker packaging smoke.
6. Production Docker build.
7. `docker compose config --quiet`.

The workflow uses least-privilege `contents: read` permissions for CI and cancels superseded runs on the same ref.

## Local quality gate

PowerShell:

```powershell
python scripts/ci_quality_gate_phase24_7.py
```

To require an installed Docker runtime:

```powershell
python scripts/ci_quality_gate_phase24_7.py --require-docker
```

CI smoke:

```powershell
python scripts/smoke_ci_quality_gate_phase24_7.py
```

## Release workflow

`.github/workflows/release.yml` runs for tags matching `v*.*.*` and can also be started manually.

It logs into GitHub Container Registry (GHCR), builds the existing production `Dockerfile`, and publishes:

- the semantic release tag;
- the immutable Git SHA tag.

No cloud vendor deployment target is assumed. Deployment promotion remains an environment-specific concern outside this phase.

## Secret safety gate

`.gitignore` excludes local `.env` files, databases, persistent storage, caches, logs, and large media. Only the example environment templates remain tracked.

Never commit `.env.production` or a real `MAHAK_SECRET_KEY`.

## Required local verification

```powershell
python -m pytest -q tests_v2
python -m pytest -q tests_v2/test_phase24_7_ci_cd.py
python scripts/smoke_ci_quality_gate_phase24_7.py
python -m compileall -q backend_v2 scripts
```

## Runtime note

The Phase 24.4 process-local rate limiter and Phase 24.5 in-memory metrics remain single-process concerns. Phase 24.6 therefore defaults to one Uvicorn worker. A later horizontally-scaled deployment phase should introduce shared state before increasing replica/worker count.
