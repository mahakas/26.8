# Phase 21.18 — Memory Audit Cursor Pagination

Phase 21.18 adds stable, user-scoped cursor pagination to the Memory mutation audit API.

## API

- `GET /api/memory/{user_id}/audit`
- Existing `action` filter remains supported.
- Existing `limit=1..500` remains supported.
- New optional `cursor` continues a previous page.
- Response adds `next_cursor` when another page exists.

## Pagination model

Audit events are ordered by `created_at DESC, id DESC`. The cursor encodes only the final event's ordering key (`created_at` and `id`). No Memory content is included.

The next page uses a keyset predicate rather than offset pagination, so inserts before the cursor do not duplicate already-read rows.

## Safety and compatibility

- User scoping is enforced by the database query on every page.
- Invalid cursors return HTTP 422.
- A cursor from another user cannot expose that user's events.
- Existing action filtering remains compatible with cursor pagination.
- The feature is read-only; it does not create, delete, or mutate Memory or audit records.
