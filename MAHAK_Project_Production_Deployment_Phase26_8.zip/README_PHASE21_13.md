# MAHAK Phase 21.13 — Memory Import Conflict Resolution

Phase 21.13 adds explicit, backward-compatible conflict policies to the memory
snapshot import flow.

## Policies

- `append` (default): preserves the Phase 21.11 behavior. Exact duplicates are
  skipped; records with the same `memory_type` + `memory_key` but different
  content are appended and reported as conflicts.
- `skip`: exact duplicates and logical-key conflicts are skipped. No existing
  memory is overwritten.
- `reject`: any logical-key conflict rejects the whole import with HTTP 409.
  No records from that request are written.

## API

```text
POST /api/memory/{user_id}/import
```

The request may include:

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "conflict_policy": "skip",
  "records": []
}
```

Successful responses now include:

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "conflict_policy": "skip",
  "imported_count": 0,
  "skipped_count": 1,
  "conflict_count": 1
}
```

For the default `append` policy with zero conflicts, the new default-valued
fields are omitted from the JSON response so existing Phase 21.10/21.11
consumers that compare the legacy response shape remain compatible. Non-default
policies or non-zero conflict counts are included explicitly.

`replace` is intentionally not supported. Existing memory is never silently
overwritten by an import request.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_13_memory_conflict_resolution.py -q

$env:PHASE21_13_LIVE="1"
python scripts/smoke_memory_conflict_phase21_13.py

pytest tests_v2 -q

python -m compileall -q backend_v2 scripts
```