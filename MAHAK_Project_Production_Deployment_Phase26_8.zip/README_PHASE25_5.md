# MAHAK Phase 25.5 — Multimodal Teacher Feedback & Continuous Adaptation

Adds a persistent, migration-free feedback loop to the Phase 25.4 adaptive teaching strategy.

## Features
- `POST /api/teacher/feedback` records explicit learner feedback.
- `GET /api/teacher/feedback/summary` returns conversation-scoped feedback signals.
- Feedback is persisted through the existing MemoryService using `LEARNING_HISTORY`.
- Duplicate feedback IDs are idempotent within the same conversation.
- Negative feedback (`rating <= 2`, `understood=false`, or `strategy_effective=false`) produces `needs_support`.
- Positive feedback produces `progressing`.
- The next `TeacherAgent` planning cycle consumes the latest feedback signal.
- `AUTO` switches to remediation after negative feedback and can move to practice when feedback is positive and confidence is high.
- Explicit teaching modes still override the automatic policy.
- Evidence and citations remain untouched by the feedback layer.

## Validation
- Dedicated Phase 25.5 tests.
- Phase 25.4 regression tests.
- Smoke script: `scripts/smoke_teacher_feedback_adaptation_phase25_5.py`.
