# MAHAK Phase 25.8 — Teacher Outcome Analytics

Phase 25.8 turns the traceable Teacher interaction/feedback loop into a read-only analytics contract for dashboards, student views, and future product UI.

## Delivered

- `TeacherOutcomeAnalyticsService` aggregates `TeacherInteractionService` + `TeacherFeedbackService` data.
- New `GET /api/teacher/analytics` endpoint for the authenticated user.
- Optional filters:
  - `conversation_id`
  - `learning_plan_id`
- Configurable analytics window:
  - `limit` (1-100)
  - `window_size` (1-50)
  - `recent_interactions` (1-20)
- Interaction metrics:
  - total interactions
  - average confidence
  - found rate
  - average evidence/citation counts
  - strategy mode/difficulty distribution
  - recommended mode distribution
  - learning outcome distribution
  - modality distribution
  - next-action distribution
- Feedback metrics:
  - total/bound/unbound feedback
  - interaction feedback coverage
  - average rating
  - understood rate
  - strategy-effectiveness rate
  - signal counts/rates
- Feedback trend is deterministic and explicitly reports `improving`, `declining`, `stable`, or `insufficient_history` using a fixed calibration threshold.
- Recent interaction traces are included for UI timeline rendering.

## Scope boundary

The analytics layer is strictly read-only with respect to Teacher interaction and feedback records. It does not create, modify, remove, reorder, or reconstruct RAG evidence, citations, retrieval results, source references, or answer text.

When `learning_plan_id` is supplied, only interactions belonging to that learning plan are included; feedback is limited to feedback explicitly bound to those selected interactions. This prevents unrelated feedback from contaminating plan-specific analytics.

## API

`GET /api/teacher/analytics`

Example query:

```text
/api/teacher/analytics?conversation_id=conv-1&learning_plan_id=plan-1&limit=50&window_size=5&recent_interactions=10
```

Representative response:

```json
{
  "total_interactions": 12,
  "average_confidence": 0.84,
  "found_rate": 0.92,
  "total_feedback": 8,
  "feedback_coverage_rate": 0.58,
  "feedback_signal_counts": {
    "progressing": 5,
    "needs_support": 2,
    "neutral": 1
  },
  "feedback_trend": "stable",
  "recent_interactions": []
}
```

## Validation

```powershell
python -m pytest -q tests_v2/test_phase25_8_teacher_outcome_analytics.py tests_v2/test_phase25_7_teacher_interaction_tracking.py tests_v2/test_phase25_6_teacher_learning_loop.py tests_v2/test_phase25_5_teacher_feedback_adaptation.py
python -m compileall -q backend_v2 scripts
python scripts/smoke_teacher_outcome_analytics_phase25_8.py
```
