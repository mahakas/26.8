# MAHAK Phase 25.4 — Multimodal Teacher Modes & Adaptive Teaching Strategy

## Goal

Add an explicit teaching-mode contract and a deterministic adaptive teaching strategy on top of the Phase 25.3 multimodal evidence-fusion pipeline.

## Teaching modes

- `auto` — selects a mode from learning context and query intent.
- `explain` — progressive direct instruction.
- `socratic` — guided-question interaction.
- `practice` — worked example followed by independent practice.
- `summary` — compact review.
- `exam` — assessment-focused response.
- `remediation` — scaffolded, step-by-step support for weak areas.

## Adaptive inputs

The planner considers:

- explicit requested teaching mode;
- active weak areas from memory;
- recent average learning confidence;
- recorded learning level;
- preferred explanation style;
- available modalities;
- fused/source confidence;
- lightweight query intent signals for practice, summary, and exam requests.

The strategy is presentation policy only. It never creates or changes evidence, citations, retrieval hits, or source truth.

## API

`POST /api/teacher/ask` accepts:

```json
{"teaching_mode":"auto"}
```

The response now includes `teaching_strategy` with mode, difficulty, explanation depth, interaction style, scaffolding, focus, rationale, and next step.

Existing requests remain backward compatible because `teaching_mode` defaults to `auto` and the new response field is optional.

## Validation

- Phase 25.4 dedicated tests
- Phase 25.3 regression
- Phase 25.1/25.2 regression
- Phase 25.4 smoke test
- `python -m compileall -q backend_v2 scripts`
