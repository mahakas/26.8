# MAHAK Phase 23.7 — Evaluation Reports / Dashboard

Phase 23.7 aggregates the outputs of the deterministic evaluation layers from Phases 23.1–23.6 into a single replayable report.

## Scope

- Combined report across answer, retrieval, citation, groundedness, and agent/multimodal evaluation sections.
- Section-level scores and metric snapshots.
- Overall score and quality band using the same thresholds as the evaluation framework.
- Threshold-based risk flags and deterministic recommendations.
- Deterministic Markdown rendering for dashboard/report consumers.
- No database migration and no mutation of educational state.

## API

- `POST /api/evaluation/report`
- `POST /api/evaluation/report/markdown`

## Validation

- Baseline before Phase 23.7: `521 passed, 3 skipped`
- Dedicated tests: `8 passed`
- Final regression: `529 passed, 3 skipped`
- Smoke: `scripts/smoke_education_evaluation_report_phase23_7.py`
- Compile: `python -m compileall -q backend_v2 scripts`
