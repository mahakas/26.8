# Phase 21.24 — Memory Retention Status / Health API

Adds a read-only status endpoint that combines the effective retention policy,
currently eligible memory count, delete cap, and the latest explicit retention
execution metadata for one user.

## Endpoint

`GET /api/memory/{user_id}/retention/status`

The response includes:

- effective `retention_days`, `max_delete`, and `memory_type`
- whether the policy is explicitly configured
- the current retention cutoff
- total eligible records and the count that would be deleted under the current cap
- the latest explicit retention execution time/count when one exists
- explicit confirmation that automatic execution is disabled

This endpoint is strictly read-only. It does not delete memory, create audit
records, or enable a scheduler.

Smoke:
`PHASE21_24_LIVE=1 python scripts/smoke_memory_retention_status_phase21_24.py`
