# Phase 18B — Video Audio + Frames + Vision

Adds:
- OpenCV frame extraction without a system ffmpeg binary.
- Optional local Faster-Whisper transcription backend.
- Timestamp-aware transcript + frame chunks in one video source.
- Live smoke test on an existing MP4.

Live example on Windows:
```powershell
$env:PHASE18B_LIVE="1"
python scripts/live_video_smoke_phase18b.py --video "D:\path\video.mp4" --transcript "D:\path\transcription.srt"
```

For real audio transcription from the MP4, install the optional `faster-whisper` dependency and run:
```powershell
python scripts/live_video_smoke_phase18b.py --video "D:\path\video.mp4" --transcribe
```
