# MAHAK Phase 24.6 — Docker & Production Deployment Packaging

## Goal

Package the MAHAK FastAPI service as a production-oriented non-root container with persistent application data, health checks, a production environment template, and hardened Compose defaults.

## Deliverables

- `Dockerfile`: Python 3.12 slim runtime, non-root user `10001:10001`, runtime libraries for current multimodal dependencies, and container healthcheck.
- `compose.yaml`: persistent `/app/data` volume, readiness healthcheck, read-only root filesystem, `tmpfs` for `/tmp`, dropped Linux capabilities, and `no-new-privileges`.
- `.env.production.example`: production configuration template based on Phases 24.1–24.5.
- `.dockerignore`: excludes virtual environments, caches, local databases, secrets, generated media, and large sample files.
- `scripts/smoke_docker_deployment_phase24_6.py`: static packaging smoke; optionally runs real Docker validation when Docker is installed.

## Local production packaging

PowerShell:

```powershell
Copy-Item .env.production.example .env.production
# Edit .env.production and set MAHAK_SECRET_KEY and deployment-specific values.

docker compose config

docker compose build

docker compose up -d

docker compose ps
docker compose logs --tail 100 mahak
```

Health checks:

```powershell
curl http://127.0.0.1:8000/api/health/live
curl http://127.0.0.1:8000/api/health/ready
curl http://127.0.0.1:8000/api/metrics
```

Stop:

```powershell
docker compose down
```

The named `mahak_data` volume is intentionally persistent across container replacement.

## Production notes

1. The default container uses one Uvicorn worker. This preserves the current process-local Phase 24.4 rate limiter and Phase 24.5 metrics semantics. Multi-worker or horizontally scaled deployment should move those stateful concerns to shared infrastructure before increasing worker count.
2. Bind to `127.0.0.1` by default. Put the API behind a TLS-capable reverse proxy or ingress for public exposure.
3. Keep `.env.production` outside version control. Production secrets should be injected by the deployment platform rather than committed to the repository.
4. `VECTOR_STORE_BACKEND=chroma` persists inside `/app/data/storage_v2/vectors` through the named volume.
5. The container runs as UID/GID `10001` and the root filesystem is read-only. Only `/app/data` is writable, plus `/tmp` through tmpfs.
6. Docker build was not available in the current development execution environment; therefore the included static smoke validates the deployment contract, while `docker compose build`/`up` remains the authoritative host-side runtime verification.
