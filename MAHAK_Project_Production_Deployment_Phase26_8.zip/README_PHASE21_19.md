# Phase 21.19 — Memory Audit Summary / Analytics

Phase 21.19 adds a read-only aggregate endpoint for the user-scoped memory mutation audit trail.

## API

- `GET /api/memory/{user_id}/audit/summary`
- Optional `action` filter: `import`, `delete`, `clear`, `prune`
- Optional `start_at` and `end_at` ISO-8601 time boundaries.
- `start_at` is inclusive; `end_at` is exclusive.

## Response

The summary contains:

- `event_count`
- `affected_count`
- `skipped_count`
- `conflict_count`
- `action_counts`
- `first_event_at`
- `last_event_at`

## Safety

- The summary is strictly scoped by `user_id`.
- It exposes audit metadata only; Memory values and question/profile content are not returned.
- The endpoint is read-only and creates no audit events.
- Invalid actions and inverted time ranges return HTTP 422.
- Existing audit pagination and mutation APIs remain unchanged.
