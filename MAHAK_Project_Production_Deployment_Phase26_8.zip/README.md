# Mahak RAG Agent

A Persian-speaking RAG agent built with LangGraph that answers **only from your own data**, cites its sources, and honestly **admits when it doesn't know** — instead of hallucinating. Free, local, and beginner-friendly.

It reads **Word, PDF, TXT, HTML and Markdown documents**, **analyzes images** (via a Vision model or OCR) and **understands videos and YouTube links** — chunks everything, embeds it, stores it in a local Chroma database, and answers grounded in those sources.

> This repo is the companion code for the video tutorial on building an AI agent from scratch.

**[فارسی را پایین‌تر بخوانید ↓](#راهنمای-فارسی)**

---

## What makes this an agent, not a workflow

A plain RAG pipeline is a straight line: question → retrieve → answer. This agent makes real decisions:

1. **Retrieve** from a local vector database (documents + images + videos).
2. **Self-grade** — a model judges whether the retrieved chunks actually answer the question.
3. **Rewrite & loop** — if not, it rewrites the query and searches again (max 2 tries).
4. **Admit & fall back** — if it still can't answer, it says so honestly, then searches the web.

It has two real tools (the archive and the web), a loop, and it judges its own output. That's what makes it an agent.

## Features

- 🎯 Answers grounded in your documents, with source citations
- 📄 Ingests `.docx`, `.pdf`, `.txt`, `.md`, `.html`
- 🖼 Analyses images (`png`, `jpg`, `webp`, `bmp`, `gif`, `tiff`) with a Vision model or OCR
- 🎥 Video (`.mp4`) and YouTube-link understanding with real timestamps
- 🔁 Self-correcting retrieval loop with a hard iteration cap
- 🧠 Conversation memory (follow-up questions work)
- 🛡️ Prompt-injection guardrails (3 layers)
- 🌐 Falls back to web search when the archive has no answer
- ♻️ Model-failover chain — survives rate limits and dead endpoints
- 🇮🇷 Multilingual embeddings — works well with Persian text
- 💰 Fully free: free models, local embeddings, local database

## Stack

| Layer | Tool |
|---|---|
| Orchestration | LangGraph |
| LLM | NVIDIA Build (free tier) / OpenAI-compatible |
| Embeddings | BAAI/bge-m3 (local, CPU) or external BGE Server |
| Vector DB | Chroma (local) |
| Text readers | python-docx, pypdf/pdfplumber, BeautifulSoup |
| Vision | Gemini / Qwen-VL (OpenAI-compatible) / Tesseract OCR |
| Web search | ddgs (DuckDuckGo) |
| UI | Gradio |

## Three Chroma collections

The index is split so re-ingesting one type never wipes another:

| Collection | Holds |
|---|---|
| `TEXT_COLLECTION` (default `mahak_scripts`) | Documents: DOCX, PDF, TXT, HTML, MD |
| `IMAGE_COLLECTION` (default `mahak_images`) | Analysed images (vision text + OCR) |
| `VIDEO_COLLECTION` (default `mahak_videos`) | Time-stamped video segments |

The agent searches all three on every question.

## Setup

**1. Clone and enter**
```bash
git clone <repo-url>
cd mahak-rag-agent
```

**2. Virtual environment**
```bash
python -m venv .venv
# Windows:
.\.venv\Scripts\Activate.ps1
# macOS / Linux:
source .venv/bin/activate
```

**3. Install**
```bash
pip install -r requirements.txt
```

**4. Configure**

Copy `.env.example` to `.env` and add your free NVIDIA API key from [build.nvidia.com](https://build.nvidia.com), plus a Gemini (or Qwen) key if you want video/image analysis:
```
NVIDIA_API_KEY=nvapi-xxxxxxxx
GEMINI_API_KEY=...
EMBED_BACKEND=local
```

> `NVIDIA_BASE_URL` must be the **base URL** (e.g. `https://integrate.api.nvidia.com/v1`), not the full `/chat/completions` endpoint. `config.py` strips an accidental `/chat/completions` suffix as a safety net.

**5. Add your data**

Drop your `.docx`, `.pdf`, `.txt`, `.md`, `.html` and image files into `scripts/`. Optionally add `metadata.xlsx` (or `metadata.csv`) with columns `file`, `title`, `url` so answers can link back to sources.

## Run

```bash
# 1. Build the document + image index
python ingest.py            # everything
python ingest.py --no-images    # documents only
python ingest.py --only-images  # vision/OCR for images only

# 2. (Optional) build the video index from videos/*.mp4
python video_ingest.py

# 3. Launch the chat UI
python app.py
```

## Swapping models

All model names live in `.env`, not in the code. Because the providers follow the OpenAI-compatible standard, switching providers is usually just changing `NVIDIA_BASE_URL` and the model names — the code stays untouched.

If a model gets deprecated, just edit `.env`. No code changes needed.

## Embeddings

- `EMBED_BACKEND=local` (default) loads `BAAI/bge-m3` locally through `sentence-transformers` — no external service, works offline after the first download (~2.3 GB).
- `EMBED_BACKEND=bge` calls an external BGE Server over HTTP at `BGE_SERVER_URL` (default `http://127.0.0.1:8000`). If that server is unreachable, the code prints a warning and falls back to local embeddings automatically.

> Whichever backend you pick must be used consistently for both ingestion and querying — embeddings from different models are not comparable. Re-run ingestion after switching.

## Notes

- The NVIDIA free tier is rate-limited (~40 req/min). The agent handles this with exponential backoff and a model-failover chain.
- The free key is for personal/development use. Commercial use needs a license.
- The `scripts/` and `videos/` folders and the local data files are git-ignored.
- `.doc` (legacy binary Word) is not supported — convert it to `.docx`.

## License

MIT

---
---

<a name="راهنمای-فارسی"></a>

<div dir="rtl">

# دستیار هوش مصنوعی مهک (راهنمای فارسی)

## نسخهٔ Qwen

این کپی برای تحلیل ویدئو و تصویر با Qwen آماده شده است و نسخهٔ اصلی Gemini را تغییر نمی‌دهد.
فایل `.env.example` را به `.env` تبدیل کن و این موارد را تنظیم کن:

```env
VIDEO_PROVIDER=qwen
IMAGE_PROVIDER=qwen
QWEN_API_KEY=کلید سرویس Qwen
QWEN_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
QWEN_VIDEO_MODEL=qwen2.5-vl-72b-instruct
QWEN_IMAGE_MODEL=qwen2.5-vl-72b-instruct
```

`QWEN_BASE_URL` باید endpointی باشد که قالب OpenAI-compatible و ورودی `video_url` / `image_url` را پشتیبانی کند. برای لینک YouTube، سرویس Qwen باید بتواند URL عمومی ویدئو را بخواند. اگر endpoint سرویس شما فقط فایل آپلودشده را می‌پذیرد، ابتدا ویدئو را دانلود کن و از تب «ویدئو (MP4)» استفاده کن.

یک ایجنت هوش مصنوعی فارسی‌زبان، ساخته‌شده با LangGraph، که **فقط از روی دیتای خودت** جواب می‌دهد، منبع هر جوابش را نشان می‌دهد، و هر جا نداند **صادقانه می‌گوید نمی‌دانم** — به‌جای اینکه از خودش در بیاورد. رایگان، لوکال، و مناسب مبتدی.

> این کد، همراه ویدیوی آموزش ساخت ایجنت از صفر است.

## چرا این ایجنت است، نه ورک‌فلو

یک رگ ساده یک خط مستقیم است: سؤال ← بازیابی ← جواب. ولی این ایجنت واقعاً تصمیم می‌گیرد:

۱. **بازیابی** از وکتور دیتابیس لوکال (اسناد + تصاویر + ویدئوها).
۲. **داوری** — یک مدل قضاوت می‌کند که آیا تیکه‌های پیداشده واقعاً جواب سؤال را دارند.
۳. **بازنویسی و حلقه** — اگر نداشتند، سؤال را با کلمات دیگر می‌نویسد و دوباره می‌گردد (سقف: دو بار).
۴. **اعتراف و ابزار دوم** — اگر باز هم نشد، صادقانه می‌گوید بلد نیست، بعد می‌رود سراغ وب.

دو ابزار واقعی دارد (آرشیو و وب)، یک حلقه دارد، و روی خروجی خودش قضاوت می‌کند. همین یعنی ایجنت.

## امکانات

- 🎯 جواب از روی اسناد خودت، با ذکر منبع
- 📄 خواندن `.docx`، `.pdf`، `.txt`، `.md`، `.html`
- 🖼 تحلیل تصویر (jpg، png، webp، bmp، gif، tiff) با Vision Model یا OCR
- 🎥 درک ویدئو (mp4) و لینک YouTube با timestamp واقعی
- 🔁 حلقهٔ بازیابی خوداصلاح، با سقف تکرار مشخص
- 🧠 حافظهٔ مکالمه (سؤال دنباله‌دار کار می‌کند)
- 🛡️ محافظت در برابر پرامپت اینجکشن (سه لایه)
- 🌐 وقتی آرشیو جواب نداشت، می‌رود سراغ وب
- ♻️ زنجیرهٔ جایگزینی مدل — از ریت‌لیمیت و مرگ مدل جان سالم به در می‌برد
- 🇮🇷 امبدینگ چندزبانه — با متن فارسی خوب کار می‌کند
- 💰 کاملاً رایگان: مدل رایگان، امبدینگ لوکال، دیتابیس لوکال

## وارد کردن داده

این پروژه چهار مسیر داده دارد:

| نوع داده | محل قرار دادن | روش اجرا |
|---|---|---|
| Word با پسوند `.docx` | `scripts/` | اجرای `python ingest.py` یا تب «اسناد (DOCX/PDF/TXT/HTML)» در رابط |
| `.pdf` | `scripts/` | در همان تب «اسناد» (پارسر: pypdf، و در صورت نبودش pdfplumber) |
| `.txt` و `.md` | `scripts/` | در همان تب «اسناد» |
| `.html` و `.htm` | `scripts/` | در همان تب «اسناد» (بدون تگ، با BeautifulSoup یا regex) |
| تصویر (`.jpg`، `.png`، `.webp`، `.bmp`، `.gif`، `.tiff`) | `scripts/` | اجرای `python ingest.py --only-images` یا تب «تصاویر (Vision)» |
| ویدئوی `.mp4` | `videos/` | اجرای `python video_ingest.py` یا تب «ویدئو (MP4)» در رابط |
| لینک YouTube | نیازی به ذخیره فایل نیست | تب «لینک یوتیوب» در رابط یا دستور `python video_ingest.py --url "..."` |

### فایل‌های متنی

فایل‌های `.docx`، `.pdf`، `.txt`، `.md`، `.html` را داخل پوشهٔ `scripts/` بریز و سپس ایندکس متن را بساز:

```bash
python ingest.py --no-images
```

برای عنوان و لینک منبع، می‌توانی کنار آن فایل `metadata.xlsx` یا `metadata.csv` قرار بدهی. ستون‌های لازم عبارت‌اند از `file`، `title` و `url`.

### تصاویر

تصاویر هم داخل `scripts/` قرار می‌گیرند ولی با یک collection جدا ایندکس می‌شوند تا بازسازی ایندکس متن، تحلیل تصاویر را پاک نکند:

```bash
python ingest.py --only-images     # فقط تصاویر
python ingest.py                   # اسناد + تصاویر
```

از طریق `IMAGE_PROVIDER` مشخص می‌کنی با Qwen-VL تحلیل شوند یا با Gemini؛ `get_image_provider` اگر هیچ مدلی در دسترس نبود به OCR (pytesseract) برمی‌گردد. خروجی تحلیل شامل متن داخل تصویر، توضیح تصویری و نوع تصویر (photo/screenshot/diagram/scan) است و در collection تصویر ذخیره می‌شود. برای OCR فارسی، موتور Tesseract با زبان `fas` باید نصب باشد (`OCR_LANG=fas+eng`).

### ویدئو و YouTube

فایل `.mp4` را داخل `videos/` قرار بده و اجرا کن:

```bash
python video_ingest.py
```

یا از تب‌های ویدئویی رابط `app.py` استفاده کن. برای لینک YouTube، لینک را مستقیماً در تب «لینک یوتیوب» وارد کن؛ دانلود دستی لازم نیست. در خط فرمان نیز می‌توانی از این شکل استفاده کنی:

```bash
python video_ingest.py --url "https://www.youtube.com/watch?v=VIDEO_ID" --title "عنوان اختیاری"
```

پوشه‌های `scripts/` و `videos/` و فایل‌های دادهٔ محلی در Git نادیده گرفته می‌شوند؛ داده‌ها را فقط در همان پوشه‌های محلی پروژه نگه دار.

## سه collection در کروما

ایندکس به سه collection تقسیم شده تا بازسازی یکی، بقیه را پاک نکند:

| collection | نگه‌دارنده |
|---|---|
| `TEXT_COLLECTION` (پیش‌فرض `mahak_scripts`) | اسناد متنی (DOCX/PDF/TXT/HTML/MD) |
| `IMAGE_COLLECTION` (پیش‌فرض `mahak_images`) | متن تحلیل‌شدهٔ تصاویر (تصویری + OCR) |
| `VIDEO_COLLECTION` (پیش‌فرض `mahak_videos`) | چانک‌های زمان‌دار ویدئو |

ایجنت هنگام بازیابی، در هر سه جستوجو می‌کند و نتایج را merge می‌کند.

## استک

| لایه | ابزار |
|---|---|
| ارکستریشن | LangGraph |
| مدل زبانی | NVIDIA Build (لایهٔ رایگان) / OpenAI-compatible |
| امبدینگ | BAAI/bge-m3 (لوکال، CPU) یا BGE Server خارجی |
| وکتور دیتابیس | Chroma (لوکال) |
| خوانندگان متن | python-docx، pypdf/pdfplumber، BeautifulSoup |
| تحلیل تصویر/ویدئو | Gemini یا Qwen-VL یا Tesseract OCR |
| جست‌وجوی وب | ddgs |
| رابط کاربری | Gradio |

## ساختار پروژه

```
config.py            اتصال به مدل، زنجیرهٔ جایگزین، موتور امبدینگ، collectionها
ingest.py            خوانندهٔ چندفرمتی (docx/pdf/txt/html) + تحلیل تصویر → چانک → کروما
image_provider.py    فکتوری Vision (qwen / gemini / ocr) برای تحلیل تصویر
video_ingest.py      تحلیل ویدئو و لینک YouTube → چانک زمان‌دار → collection ویدئو
video_provider.py    واسط انتزاعی پرووایدر درک ویدئو/تصویر
agent.py             گراف لنگ‌گراف — بازیابی ترکیبی (متن + تصویر + ویدئو)
video_citation.py    ساخت citation فقط از متادیتای واقعی (timestamp / url / منبع)
guard.py             سه لایه گاردریل امنیتی
app.py               رابط چت گرِیدیو — اسناد + تصاویر + ویدئو + YouTube + چت
api_server.py        (اختیاری) backend FastAPI
requirements.txt
scripts/             ← فایل‌های متنی و تصویری خودت را اینجا بگذار
metadata.xlsx        ← اختیاری: file, title, url
```

## نصب

**۱. کلون و ورود به پوشه**
```bash
git clone <repo-url>
cd mahak-rag-agent
```

**۲. محیط مجازی**
```bash
python -m venv .venv
# ویندوز:
.\.venv\Scripts\Activate.ps1
# مک / لینوکس:
source .venv/bin/activate
```

**۳. نصب پکیج‌ها**
```bash
pip install -r requirements.txt
```

**۴. تنظیمات**

فایل `.env.example` را به `.env` تغییر نام بده و کلید رایگان انویدیا را از [build.nvidia.com](https://build.nvidia.com) بگیر و بگذار:
```
NVIDIA_API_KEY=nvapi-xxxxxxxx
```

> `NVIDIA_BASE_URL` باید آدرس پایه باشد (مثلاً `https://integrate.api.nvidia.com/v1`)، نه خود endpoint کامل `/chat/completions`. اگر پسوند اضافه بگذاری، `config.py` به‌صورت خودکار حذفش می‌کند.

**۵. دیتای خودت**

فایل‌های `.docx`، `.pdf`، `.txt`، `.md`، `.html` یا تصاویر را در پوشهٔ `scripts/` بریز. اگر خواستی، `metadata.xlsx` را با ستون‌های `file`، `title`، `url` بساز تا جواب‌ها به منبع لینک بخورند.

## اجرا

```bash
# ۱. ساخت ایندکس (یک بار، چند دقیقه طول می‌کشد)
python ingest.py              # متن + تصاویر
python ingest.py --no-images  # فقط متن اسناد
python ingest.py --only-images  # فقط تحلیل تصاویر

# ۲. اجرای رابط چت
python app.py
```

## امبدینگ

دو راه داری (با `EMBED_BACKEND` در `.env`):

- `local` (پیش‌فرض): مدل `BAAI/bge-m3` روی CPU و همان‌جای پروژه اجرا می‌شود؛ به سرویس جدا نیازی نیست و بعد از یک بار دانلود، آفلاین کار می‌کند.
- `bge`: فراخوانی BGE Server روی `BGE_SERVER_URL` (پیش‌فرض `http://127.0.0.1:8000`). اگر سرور بالا نباشد، کد هشدار می‌دهد و خودکار به امبدینگ لوکال برمی‌گردد تا ingest کرش نکند.

> امبدینگ‌ها باید در زمان ایندکس و زمان بازیابی از یک مدل باشند؛ اگر بک‌اند را عوض کردی، ایندکس را دوباره بساز.

## عوض کردن مدل

اسم همهٔ مدل‌ها در `.env` است، نه در کد. چون سرویس‌ها از استاندارد اوپن‌ای‌آی پیروی می‌کنند، برای رفتن سراغ سرویس دیگر معمولاً فقط `NVIDIA_BASE_URL` و اسم مدل‌ها را عوض می‌کنی — کد دست‌نخورده می‌ماند.

اگر مدلی از دسترس خارج شد، فقط `.env` را عوض کن.

## نکته‌ها

- لایهٔ رایگان انویدیا ریت‌لیمیت دارد (حدود ۴۰ درخواست در دقیقه). ایجنت با عقب‌نشینی نمایی و زنجیرهٔ جایگزین مدل این را مدیریت می‌کند.
- کلید رایگان برای استفادهٔ شخصی و توسعه است. استفادهٔ تجاری به لایسنس نیاز دارد.
- امبدینگ لوکال روی سی‌پی‌یو اجرا می‌شود — بدون ریت‌لیمیت، بدون تاریخ انقضا، و بعد از دانلود اول (حدود ۲.۳ گیگ) آفلاین کار می‌کند.
- فرمت قدیمی `.doc` ورد پشتیبانی نمی‌شود؛ اول به `.docx` تبدیلش کن.

## لایسنس

MIT

</div>

## Phase 7 — Educational Chat

مسیر آموزشی نسخه v2 اکنون به‌صورت closed-world پیاده‌سازی شده است:

```text
ConversationContext
  -> QueryPlanner
  -> RetrievalScope
  -> RetrievalService
  -> Context/Prompt Builder
  -> Provider Orchestrator (CHAT)
  -> Answer + Source-aware Citations
```

اگر Retrieval نتیجه قابل‌اعتماد نداشته باشد، پاسخ کنترل‌شدهٔ زیر برگردانده می‌شود:

`این سؤال در منابع آموزشی انتخاب‌شده برای این درس پیدا نشد.`

Endpoint پایه:

`POST /api/chat/educational`

این endpoint فعلاً از Providerهای Mock برای تست محلی استفاده می‌کند؛ Providerهای واقعی در فازهای بعدی به Registry متصل خواهند شد.

## Phase 13

For the normal test suite, keep `MAHAK_PROVIDER_MODE=mock`. To run the real providers explicitly, set `MAHAK_PROVIDER_MODE=live` (or export `PHASE13_LIVE=1` for the smoke script). — Live Providers

Phase 13 adds real provider execution with environment-only secrets, per-provider rate limiting, retry with exponential backoff + jitter, circuit breakers, and automatic fallback. No API secret is stored in source code or logs.

### Live smoke test

Set at least one real provider key in `.env`, then run:

```bash
export PHASE13_LIVE=1
python scripts/live_smoke_phase13.py
```

On Windows PowerShell:

```powershell
$env:PHASE13_LIVE="1"
python scripts/live_smoke_phase13.py
```

Never paste real API keys into chat, source files, tests, or Git.

## Phase 14 — Real RAG with Chroma + BGE-M3
`VECTOR_STORE_BACKEND=chroma` selects persistent Chroma. `EMBED_BACKEND=local` with `EMBED_MODEL=BAAI/bge-m3` selects the local 1024-dimensional embedding provider. `scripts/live_rag_smoke_phase14.py` runs TXT -> ingestion -> local BGE-M3 -> Chroma -> retrieval -> live LLM -> citation.

## Phase 15 — Real PDF ingestion
- Text-native PDFs preserve page-aware chunks for citations.
- Scanned or hybrid PDFs are detected and declare OCR/Vision requirements when pages remain unresolved.
- Optional local OCR uses PyMuPDF + Tesseract when `PDF_OCR_ENABLED=true`.
- Live smoke: `PHASE15_LIVE=1 python scripts/live_pdf_smoke_phase15.py`.

## Phase 21.14 — Memory Import Preview / Dry Run

- Read-only endpoint: `POST /api/memory/{user_id}/import/preview`
- Reuses the Phase 21.13 `append`, `skip`, and `reject` policies.
- Predicts imports, skips, exact duplicates, conflicts, and reject outcome without mutating memory.
- Optional Phase 21.12 snapshot checksum verification is supported.
- Validation: `5` focused tests, smoke `read_only: OK`, full suite `188 passed, 3 skipped`, compile clean.

## Phase 21.20 — Memory Retention Policy & Cleanup

- `POST /api/memory/{user_id}/retention/preview` یک dry-run کاملاً read-only برای پیدا کردن Memoryهای قدیمی است.
- `POST /api/memory/{user_id}/retention/apply` با `older_than`، `memory_type` و سقف ایمنی `max_delete` رکوردهای قدیمی را به‌صورت صریح حذف می‌کند.
- retention به‌صورت خودکار در Chat/Agent اجرا نمی‌شود و حذف موفق با action=`retention` در Audit ثبت می‌شود.
- `older_than` در آینده مجاز نیست و `max_delete` بین 1 و 500 محدود است.
- Validation این مرحله: `5` تست focused، Smoke سبز، `214 passed, 3 skipped` و compile بدون خطا.

## Phase 21.25 — Memory Retention Scheduler Engine

- Adds `MemoryRetentionSchedulerService` as an opt-in, deterministic retention job runner.
- Disabled mode is strictly non-mutating.
- Enabled runs execute only explicitly configured per-user retention policies; users without a policy are skipped.
- A run can target selected users or all configured users, capped at 500 users per run.
- Existing `retention` audit events are emitted only when records are actually deleted.
- Each user runs inside its own SQLAlchemy savepoint so one malformed policy cannot roll back successful users in the same batch.
- No background thread, cron loop, or automatic FastAPI startup execution is enabled in this phase.
- Validation: `11` focused/nearby tests, smoke green, `240 passed, 3 skipped`, compile clean.

Phase 23.1 adds the deterministic Evaluation Framework API.

## Phase 23.2 — Evaluation Dataset & Batch Runner

Adds repeatable evaluation datasets, JSONL loading, batch aggregation, and `POST /api/evaluation/batch` on top of Phase 23.1.

## Phase 23.5 — Hallucination / Groundedness Evaluation

Adds deterministic claim-level lexical groundedness evaluation to the Evaluation Framework.

- `POST /api/evaluation/groundedness`
- `POST /api/evaluation/groundedness/batch`

Validation: `511 passed, 3 skipped`; Phase 23.5 tests `10 passed`; Smoke and compile successful.

## Phase 23.6 — Agent & Multimodal Evaluation

Phase 23.6 is complete. The evaluation framework now covers specialist-agent and multimodal output contracts, including agent selection accuracy, evidence modality coverage, citation/evidence alignment, and modality-specific locator completeness.

## Phase 23.7

Evaluation Reports / Dashboard aggregation is available through the evaluation API. See `README_PHASE23_7.md`.

## Phase 24.1 — Production Configuration & Secrets

Phase 24.1 hardens runtime configuration for production deployments without changing development/test defaults.

- Explicit environments: `development`, `staging`, `production`.
- Production fail-fast validation for `APP_DEBUG`, `MAHAK_SECRET_KEY`, and `ALLOWED_HOSTS`.
- Diagnostics-safe configuration via `AppSettings.safe_dict()`; secret values are never exposed.
- New operational settings: `LOG_LEVEL`, `CORS_ORIGINS`, and `TRUST_PROXY_HEADERS`.

See `README_PHASE24_1.md` and `ROADMAP_STATUS_PHASE24_1.md`.


## Phase 24.2 — Authentication & Identity Layer

Phase 24.2 adds persistent user identity, PBKDF2 password hashing, bearer access tokens, rotating/revocable refresh sessions, and `GET /api/auth/me`. Legacy routes remain behavior-compatible; route-level authorization is deferred to Phase 24.3. See `README_PHASE24_2.md` and `ROADMAP_STATUS_PHASE24_2.md`.

## Phase 24.3 — Authorization / RBAC & Route-Level Access Control

Phase 24.3 adds `student`, `teacher`, and `admin` roles, a central permission registry, reusable `require_roles(...)` / `require_permissions(...)` dependencies, protected admin routes, and additive compatibility migration for the User role. See `README_PHASE24_3.md` and `ROADMAP_STATUS_PHASE24_3.md`.

## Phase 24.4 — Security Hardening

Phase 24.4 adds HTTP security headers, exact-origin CORS, configured host validation, API/auth rate limiting, authentication cache prevention, opt-in proxy-header trust, and production-safe API documentation defaults. See `README_PHASE24_4.md` and `ROADMAP_STATUS_PHASE24_4.md`.

## Phase 24.5 — Observability

Structured request logging, request correlation IDs, Prometheus-compatible metrics, and liveness/readiness endpoints are documented in `README_PHASE24_5.md`.

- Phase 24.6: Docker & Production Deployment Packaging — see `README_PHASE24_6.md`.

## Phase 24.7 — CI/CD Pipeline & Automated Quality Gates

Phase 24.7 adds repeatable CI quality gates and a generic container release workflow.

- `.github/workflows/ci.yml`: PR/main CI for regression, compile, security/observability/Docker smokes, Docker build, and Compose validation.
- `.github/workflows/release.yml`: version-tagged GHCR image publishing without assuming a cloud deployment provider.
- `scripts/ci_quality_gate_phase24_7.py`: local/CI quality gate runner.
- `scripts/smoke_ci_quality_gate_phase24_7.py`: focused CI gate smoke.
- `.gitignore`: excludes secrets, local state, caches, and large runtime media.

Validation: `588 passed, 3 skipped`; Phase 24.7 tests `9 passed`; compile and smoke successful.

## Phase 24.8 — Production Readiness, Backup/Recovery & Operational Hardening

Phase 24.8 completes the Phase 24 production line with transaction-consistent SQLite backups, persistent storage/Chroma backup verification, retention, guarded restore, expanded readiness checks, graceful application shutdown, and an operator recovery runbook. See `README_PHASE24_8.md` and `ROADMAP_STATUS_PHASE24_8.md`.

## MAHAK Phase 25

Phase 25 begins with `README_PHASE25_1.md`: Multimodal Teacher Orchestration & Unified Answer.

## Phase 25.2 — Audio Ingestion & Speech Understanding

Phase 25.2 adds first-class audio ingestion and timestamp-aware speech understanding on top of the Phase 25.1 multimodal teacher orchestration.

- Audio formats: MP3, WAV, M4A, FLAC, OGG/OGA, OPUS, AAC, WMA.
- Deterministic SRT/VTT/TXT sidecar transcript support.
- Optional local `FasterWhisperTranscriber` injection without automatic model download.
- Timestamp-preserving transcript chunks and citation-ready audio evidence.
- `AudioAgent` and multimodal Teacher routing through `AUDIO_AGENT` / `audio` modality.
- `POST /api/teacher/ask` accepts explicit `modalities: ["audio"]`.

See `README_PHASE25_2.md` and `ROADMAP_STATUS_PHASE25_2.md`.

## Phase 25.7 — Teacher Interaction Outcome Tracking

Phase 25.7 makes the Multimodal Teacher learning loop explicitly traceable at interaction level.

- `POST /api/teacher/ask` now returns an `interaction_id` for authenticated Teacher executions.
- `TeacherInteractionService` persists lightweight strategy/learning-loop metadata without duplicating answer text.
- `TeacherFeedbackRequest.interaction_id` can bind feedback to the exact Teacher interaction.
- Cross-conversation interaction binding is rejected; legacy feedback without an interaction remains supported.
- `GET /api/teacher/interactions` exposes recent interaction traces for the authenticated user.
- Interaction records use the existing `learning_history` memory type, so no database migration is required.

See `README_PHASE25_7.md` and `ROADMAP_STATUS_PHASE25_7.md`.
## Phase 25.8 — Teacher Outcome Analytics

Phase 25.8 exposes read-only analytics over Teacher interactions and explicit feedback for dashboard and product UI consumers.

- New `GET /api/teacher/analytics` endpoint.
- Optional `conversation_id` and `learning_plan_id` scoping.
- Interaction confidence/found/evidence/citation metrics and strategy/modality/outcome distributions.
- Feedback coverage, rating, understanding, strategy-effectiveness, signal distributions, and deterministic trend.
- Recent interaction timeline entries are included for UI rendering.
- Plan-scoped analytics excludes feedback that is not explicitly bound to a selected interaction.
- Evidence, citations, retrieval results, source references, and answer text remain outside the analytics boundary.

See `README_PHASE25_8.md` and `ROADMAP_STATUS_PHASE25_8.md`.

## Phase 25.9 — Teacher Dashboard Read Model

Phase 25.9 adds a product-facing read-only dashboard contract that composes Teacher progress, feedback, learning-loop state, outcome analytics, and learning-plan summaries.

- New `GET /api/teacher/dashboard` endpoint.
- Optional `conversation_id` and `learning_plan_id` scoping.
- Student progress/weak-area/mastery summary.
- Embedded feedback summary, learning-loop state, and Phase 25.8 outcome analytics.
- Recent learning-plan completion/mastery/remediation/next-topic summaries.
- Unknown explicit learning plans return `404`; no RAG evidence/citation/source truth is touched.

See `README_PHASE25_9.md` and `ROADMAP_STATUS_PHASE25_9.md`.

## Phase 25.10 — Teacher Session Lifecycle

Phase 25.10 adds optional product-level Teacher sessions with persisted active/closed lifecycle, session binding on Teacher interactions, and authenticated session lifecycle APIs. No database migration is required. See `README_PHASE25_10.md`.

## Phase 25.11 — Teacher Reporting & Export

Phase 25.11 adds read-only JSON and CSV reporting over the stable Teacher dashboard, interaction, and feedback contracts. See `README_PHASE25_11.md`.

## Phase 25.12 — Teacher Product Readiness

Phase 25.12 adds capability discovery and deterministic readiness checks. The Phase 25 Teacher product line is complete through orchestration, learning loop, feedback, traceability, analytics, dashboard, sessions, reporting, and readiness. See `README_PHASE25_12.md`.

---

## Phase 26 — Production Teacher API

Phase 26 adds the stable, additive `/api/teacher/v1` contract over the existing multimodal Teacher system. It preserves evidence, citations, confidence, sessions, learning context, and request correlation while standardizing client-facing errors and API metadata.

See:

- `README_PHASE26_COMPLETE.md`
- `docs/specs/07_PHASE26_API_CONTRACT.md`
- `scripts/smoke_teacher_api_phase26.py`

## Production deployment — Phase 26.8

The verified Phase 26.8 snapshot includes a hardened Docker/Compose deployment pack. See `README_PRODUCTION_DEPLOYMENT_PHASE26_8.md` for environment variables, live-provider configuration, health/readiness probes, startup/update commands, backup/restore operations, and the production checklist.

