# Phase 21.25 — Memory Retention Scheduler Engine

Adds an opt-in retention job runner that executes only explicitly configured
per-user retention policies. The runner is intentionally an engine/service, not
a background thread: Phase 21.25 does not start automatic scheduling and does
not require an unprotected mutation endpoint. This keeps it compatible with the
current roadmap, where authentication/permissions and production job
orchestration are handled later.

## Capabilities

- Run one retention pass for selected `user_id` values.
- Run one retention pass across configured users.
- Skip users that have no explicit retention policy.
- Disabled mode is strictly non-mutating.
- Uses each user's `retention_days`, `max_delete`, and optional `memory_type`.
- Writes the existing `retention` audit event only when records are deleted.
- Returns per-user execution status for future scheduler adapters.
- Hard caps one run at 500 configured users.

## Design boundary

No background thread, cron process, APScheduler instance, or automatic FastAPI
startup task is enabled in this phase. The scheduler engine is ready to be
invoked by a trusted job runner later.

Smoke:
`PHASE21_25_LIVE=1 python scripts/smoke_memory_retention_scheduler_phase21_25.py`
