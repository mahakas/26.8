# Phase 21.17 — Memory Mutation Audit Trail

Phase 21.17 adds a user-scoped, non-content audit trail for successful memory mutations.

## API

- `GET /api/memory/{user_id}/audit`
- Optional `action`: `import`, `delete`, `clear`, `prune`
- Optional `limit`: `1..500`

## Audited operations

Successful memory imports and destructive management operations are recorded. Preview/export operations remain read-only and are not audited.

The audit record stores only operational metadata: action, counts, memory type when applicable, import format/policy/checksum, and timestamp. Memory `value` content is never stored in the audit table.

Audit entries are persisted in the same database transaction as the mutation so a rolled-back mutation does not create a false success audit event.
