# MAHAK Phase 21.12 — Memory Snapshot Integrity

Phase 21.12 adds integrity verification to the existing memory export/import flow without changing the memory model or AgentResult contract.

## What changed

- Added a stable SHA-256 `checksum` to `GET /api/memory/{user_id}/export`.
- The checksum covers snapshot `format_version`, `user_id`, and exported record data.
- Transport-only fields such as `exported_at` are intentionally excluded.
- Record ordering does not affect the checksum.
- `POST /api/memory/{user_id}/import` accepts an optional checksum and rejects tampered snapshots with HTTP 422.
- Imports without a checksum remain supported for backward compatibility with Phase 21.10 snapshots.
- Verified imports echo the validated checksum in the API response.
- Added unit/integration tests and a smoke test for round-trip integrity and tamper rejection.

## API

### Export

```text
GET /api/memory/{user_id}/export
```

The response now includes:

```json
{
  "format_version": "1.0",
  "exported_at": "...",
  "user_id": "student-1",
  "count": 1,
  "checksum": "<64-char-sha256>",
  "records": [],
  "progress": {}
}
```

### Import

```text
POST /api/memory/{user_id}/import
```

A snapshot may include:

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "checksum": "<64-char-sha256>",
  "records": []
}
```

When `checksum` is omitted, the Phase 21.10-compatible import path is preserved.

## Validation

```powershell
$env:PYTHONPATH="."
pytest tests_v2/test_phase21_12_memory_snapshot_integrity.py -q

$env:PHASE21_12_LIVE="1"
python scripts/smoke_memory_snapshot_integrity_phase21_12.py
```
