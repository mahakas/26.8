# MAHAK Phase 22.2 — Educational Question/Content Generation

Phase 22.2 extends the Phase 22.1 task planner into a closed-world educational content generation pipeline.

## What was added

- Structured educational question contract with multiple-choice, short-answer, true/false, open-ended and problem-solving types.
- RAG-grounded generation using existing vector retrieval and existing provider orchestration.
- Structured-output capability with JSON validation and CHAT fallback for compatible providers.
- Every generated item must carry at least one valid `source_refs` reference.
- Citation binding preserves existing page, video timestamp, frame, image and relevance metadata.
- New endpoint: `POST /api/education/tasks/generate`.
- Deterministic mock generation path for local API/smoke testing.

## Closed-world rule

No supported retrieval sources means no generated educational content. The API returns `generated=false` rather than inventing content from outside the selected knowledge scope.

## Test commands

```powershell
python -m pytest -q tests_v2
python -m pytest -q tests_v2/test_phase22_2_education_content_generation.py
$env:PHASE22_2_LIVE="1"
python scripts/smoke_education_content_generation_phase22_2.py
python -m compileall -q backend_v2 scripts
```

The first command is the regression suite. The second targets this phase. The smoke script validates structured output parsing and citation binding without external credentials.
