# MAHAK Production Deployment Status — Phase 26.8

## Prepared
- Docker/Compose production packaging retained and updated for the Phase 26.8 snapshot.
- Image tag default updated from 24.8 to 26.8.
- Container runs as UID/GID 10001 with read-only root filesystem, dropped capabilities, and persistent `/app/data` volume.
- Docker and Compose healthchecks use `/api/health/ready`.
- Readiness now returns HTTP 200 only when operational checks are healthy and HTTP 503 otherwise.
- Production environment template now explicitly selects `MAHAK_PROVIDER_MODE=live` and the local `BAAI/bge-m3` embedding baseline.
- Provider retry/circuit/rate settings are included in the template.
- Production runbook added at `README_PRODUCTION_DEPLOYMENT_PHASE26_8.md`.

## Validation
- Targeted regression/deployment tests: 35 passed.
- `python -m compileall -q backend_v2 scripts tests_v2/test_phase26_8_production_deployment.py`: passed.
- Production deployment packaging smoke: passed.
- Existing Phase 24 Docker packaging smoke: passed (Docker CLI unavailable, so runtime Docker build was not executed in this environment).
- Compose YAML syntax: valid.
- A full post-change pytest run was attempted in the working container but exceeded the execution timeout before completion; it is therefore not reported as a completed full-suite validation. The previously verified Phase 26.8 baseline remains 662 passed, 3 skipped, 0 failed, 0 errors before this deployment-only change set.

## Deployment commands
```bash
cp .env.production.example .env.production
chmod 600 .env.production
docker compose config
docker compose build --pull
docker compose up -d
docker compose ps
curl -fsS http://127.0.0.1:8000/api/health/live
curl -fsS http://127.0.0.1:8000/api/health/ready
```

## Production values that must be customized
- `MAHAK_SECRET_KEY`
- `ALLOWED_HOSTS`
- `CORS_ORIGINS`
- provider API keys/models/base URLs actually in use
- TLS/reverse-proxy configuration
- backup destination/infrastructure policy

Do not commit `.env.production` or real secrets.
