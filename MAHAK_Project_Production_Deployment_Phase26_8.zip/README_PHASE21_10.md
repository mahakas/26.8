# MAHAK Phase 21.10 — Memory Import & Restore

Phase 21.10 adds controlled restore of the Phase 21 memory export snapshot.

## What changed

- Added `POST /api/memory/{user_id}/import`.
- Added schema validation for memory snapshot `format_version` 1.0.
- Enforced path/body/record `user_id` isolation.
- Restore is append-only and never reuses exported database IDs.
- Existing memories are never overwritten or deleted by import.
- Progress remains derived from persisted memory records and is not imported as a separate memory record.
- API import commits the validated restore as one transaction.
- Added focused tests, smoke test, and Phase 21.10 documentation.

## Validation performed

- `pytest tests_v2/test_phase21_10_memory_import.py -q` → 5 passed
- `PYTHONPATH=. PHASE21_10_LIVE=1 python scripts/smoke_memory_import_phase21_10.py` → runtime OK
- `pytest tests_v2 -q` → 162 passed, 3 skipped
- `python -m compileall -q backend_v2 scripts` → OK

## API example

```http
POST /api/memory/student-1/import
Content-Type: application/json
```

```json
{
  "format_version": "1.0",
  "user_id": "student-1",
  "records": [
    {
      "id": "exported-id",
      "user_id": "student-1",
      "memory_type": "previous_question",
      "memory_key": "q-1",
      "value": {"question": "What is x?"},
      "confidence": 0.9,
      "source": "chat"
    }
  ]
}
```

The historical `id` is accepted for portability but is not reused as the new database primary key.
