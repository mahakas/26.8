# MAHAK Phase 23.2 — Evaluation Dataset & Batch Runner

Phase 23.2 adds a deterministic batch evaluation layer on top of Phase 23.1.

## Scope

- bounded evaluation case datasets;
- JSONL dataset loading for repeatable offline/CI runs;
- batch evaluation with per-case results;
- aggregate overall/answer/retrieval/citation/evidence metrics;
- quality-band counts;
- fail-soft and fail-fast execution modes;
- API endpoint `POST /api/evaluation/batch`;
- Windows-safe smoke coverage.

The batch runner is side-effect free and does not persist evaluation state.

## JSONL format

Each line contains:

```json
{"case_id":"physics-001","request":{"question":"...","answer":"...","expected_answer":"...","expected_source_ids":["physics.pdf"],"retrieved_source_ids":["physics.pdf"],"cited_source_ids":["physics.pdf"],"evidence_texts":["..."]}}
```

## API

`POST /api/evaluation/batch`

Swagger: `http://127.0.0.1:8000/docs`

## Exact tests

```powershell
python -m pytest -q tests_v2/test_phase23_2_evaluation_batch.py
$env:PHASE23_2_LIVE="1"
python scripts/smoke_education_evaluation_batch_phase23_2.py
python -m compileall -q backend_v2 scripts
```

## Full regression validation

Phase 23.2 validation: `475 passed, 3 skipped`.
