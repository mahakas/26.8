# Mahak AI V2 — Phase 15.5

## Retrieval Quality & Citation Precision

This phase improves retrieval quality without changing the successful PDF/BGE-M3/Chroma pipeline.

### Improvements
- Quality-aware hybrid reranking (vector + lexical + document quality)
- Detection and penalty of garbled/mojibake chunks
- Near-duplicate chunk suppression
- Quality-aware acceptance threshold
- Citation relevance score and confidence (`high`, `medium`, `low`)
- Existing PDF page mapping remains intact

### Why this matters
A high vector score alone should not allow malformed or duplicate chunks to dominate the final context. The retrieval layer now rejects low-quality/garbled candidates before they reach the LLM and keeps citations tied to the accepted ranked evidence.

### Tests
Run:

```powershell
python -m pytest -q tests_v2
python -m compileall -q backend_v2 scripts
```

For a live PDF/RAG test:

```powershell
$env:PHASE15_LIVE="1"
python scripts/live_pdf_smoke_phase15.py
```
