# MAHAK Phase 24.5 — Observability, Structured Logging & Monitoring

Phase 24.5 adds dependency-free application observability without changing the public behavior of existing endpoints.

## Added

- Structured JSON request logs with secret/body redaction.
- Request correlation through `X-Request-ID`.
- Thread-safe in-memory metrics registry.
- Prometheus-compatible `/api/metrics` output.
- `/api/health/live` for liveness.
- `/api/health/ready` for database readiness.
- Existing `/api/health` remains backward compatible.

## Configuration

```env
REQUEST_LOGGING_ENABLED=true
STRUCTURED_LOGGING_ENABLED=true
LOG_FORMAT=json
METRICS_ENABLED=true
```

`METRICS_ENABLED` currently controls exposure of the Prometheus endpoint. For internet-facing deployments, place the endpoint behind the deployment's network/authentication boundary.

## Validation

- Dedicated tests: `tests_v2/test_phase24_5_observability_monitoring.py`
- Smoke: `scripts/smoke_observability_monitoring_phase24_5.py`
- No new third-party runtime dependency is required.
