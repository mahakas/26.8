# MAHAK Phase 24.4 — Security Hardening

Phase 24.4 adds application-level HTTP security hardening on top of Phase 24.3 RBAC.

## Delivered

- Security response headers:
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY`
  - `Referrer-Policy: no-referrer`
  - `Permissions-Policy` disabling camera, microphone and geolocation by default.
- Optional production HSTS through `SECURITY_HSTS_ENABLED`.
- Exact-origin CORS support through `CORS_ORIGINS`; wildcard CORS is rejected in production.
- `TrustedHostMiddleware` when `ALLOWED_HOSTS` is configured.
- Process-local per-IP fixed-window rate limiting for `/api/*` routes.
- Stricter authentication rate limiting for login, register, refresh and logout endpoints.
- `Retry-After`, `X-RateLimit-Limit`, and `X-RateLimit-Remaining` response headers.
- Authentication responses are marked `Cache-Control: no-store`.
- API documentation is enabled by default outside production and disabled by default in production; `API_DOCS_ENABLED` can override that behavior.
- Proxy headers are trusted only when `TRUST_PROXY_HEADERS=true`.
- Invalid security/rate-limit settings fail during configuration validation.

## Configuration

```dotenv
SECURITY_HEADERS_ENABLED=true
SECURITY_HSTS_ENABLED=false
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=120
RATE_LIMIT_WINDOW_SECONDS=60
AUTH_RATE_LIMIT_REQUESTS=10
AUTH_RATE_LIMIT_WINDOW_SECONDS=60
API_DOCS_ENABLED=
```

The rate limiter is intentionally process-local in this phase. Distributed enforcement across multiple workers requires a shared state store and is deferred to later production infrastructure work.

## Validation

```powershell
python -m pytest -q tests_v2/test_phase24_4_security_hardening.py
python scripts/smoke_security_hardening_phase24_4.py
python -m compileall -q backend_v2 scripts
python -m pytest -q tests_v2
```

Phase 24.4 validation target/result: `563 passed, 3 skipped` after the dedicated security tests are included.
