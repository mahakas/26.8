# Phase 21.34 — Unified Retention Maintenance

Phase 21.34 adds `MemoryRetentionMaintenanceService`, an explicit orchestration layer that reuses the existing memory-retention scheduler and scheduler-run-history retention policy.

## API

```python
MemoryRetentionMaintenanceService(...).run_with_report(
    user_ids=None,
    now=None,
    dry_run=False,
    cleanup_history=True,
)
```

## Behavior

- `enabled=False` is strictly non-mutating.
- `dry_run=True` plans both memory retention and run-history retention.
- `dry_run=False` executes both policies explicitly.
- Run-history cleanup is isolated in a savepoint, so a history-cleanup failure does not roll back successful memory retention.
- `cleanup_history=False` runs memory retention only.
- Existing scheduler and run-history service contracts remain unchanged.
- No background scheduler is started by this phase.
- No content values are written to the maintenance report.

## Report

`RetentionMaintenanceRunReport` contains the existing scheduler report plus a bounded history-cleanup result and a combined status.
