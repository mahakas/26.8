# MAHAK Phase 21.11 — Idempotent Memory Import

Phase 21.11 hardens the Phase 21.10 restore flow so repeated imports of the same snapshot do not create duplicate memories.

## What changed

- Added stable content fingerprinting for memory records.
- Historical memory IDs are excluded from duplicate detection.
- Exact duplicates are skipped across previous imports and within the same import batch.
- Changed content remains importable as a new memory.
- `POST /api/memory/{user_id}/import` now returns `imported_count` and `skipped_count`.
- Existing memory management, export, progress, AgentResult, retrieval, and citation behavior remains unchanged.
- Added focused regression tests, smoke test, and documentation.
