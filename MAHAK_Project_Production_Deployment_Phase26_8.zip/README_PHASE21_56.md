# Phase 21.56 — Snapshot Retention Execution History Policy

Phase 21.56 adds a persistent, configuration-only retention policy for the execution history produced by maintenance alert snapshot retention.

Defaults are 365 retention days and a maximum delete limit of 500 records. The policy supports `get`, `set`, and `reset`, is stored as a singleton configuration row, and does not execute cleanup. Public mutation endpoints remain intentionally deferred to the production security phase.
