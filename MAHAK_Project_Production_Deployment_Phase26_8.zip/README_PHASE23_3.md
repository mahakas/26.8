# MAHAK Phase 23.3 — RAG / Retrieval Evaluation

Phase 23.3 adds a dedicated rank-aware retrieval evaluation layer on top of the Phase 23.1/23.2 Evaluation Framework.

## Scope

- binary source relevance evaluation;
- Precision@K;
- Recall@K;
- reciprocal rank / MRR aggregation;
- Average Precision / MAP aggregation;
- NDCG@K;
- HitRate@K;
- deterministic batch retrieval evaluation;
- API endpoints for single and batch retrieval evaluation;
- Windows-safe smoke coverage.

The evaluator is side-effect free. It evaluates an ordered list of retrieved source ids against an ordered/normalized set of expected relevant source ids. Retrieval metrics are source-id based; they do not claim semantic relevance beyond the supplied reference labels.

## API

- `POST /api/evaluation/retrieval`
- `POST /api/evaluation/retrieval/batch`

Swagger: `http://127.0.0.1:8000/docs`

## Exact tests

```powershell
python -m pytest -q tests_v2/test_phase23_3_retrieval_evaluation.py
$env:PHASE23_3_LIVE="1"
python scripts/smoke_education_evaluation_retrieval_phase23_3.py
python -m compileall -q backend_v2 scripts
```

## Validation

Phase 23.3 validation: `491 passed, 3 skipped` in the full `tests_v2` regression.
The Phase 23.3 test file contains 9 passing tests.
