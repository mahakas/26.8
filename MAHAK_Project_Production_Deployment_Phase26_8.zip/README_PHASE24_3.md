# MAHAK Phase 24.3 — Authorization / RBAC & Route-Level Access Control

Phase 24.3 adds the authorization boundary on top of Phase 24.2 identity/authentication.

## Delivered

- Explicit roles: `student`, `teacher`, `admin`.
- Central permission registry and role-to-permission mapping.
- Reusable FastAPI dependencies:
  - `require_roles(...)`
  - `require_permissions(...)`
- Route-level protection for the administrative authorization surface.
- Persistent role on `User`, defaulting to `student`.
- Additive startup migration for existing Phase 24.2 databases that lack the `users.role` column.
- Admin user listing and role-management endpoints.
- Initial operator CLI for assigning a role to an existing user.
- Authorization is resolved from the current database User record rather than trusted from a JWT role claim, so role changes take effect without token re-issuance.
- Administrators cannot demote themselves through the HTTP role-management endpoint.

## Roles

| Role | Scope |
|---|---|
| student | profile/chat/learning access permissions |
| teacher | student permissions + education/evaluation permissions |
| admin | wildcard administrative permission |

## Key endpoints

- `GET /api/admin/access-check` — protected admin boundary smoke endpoint.
- `GET /api/admin/users` — requires `users:read`.
- `PATCH /api/admin/users/{user_id}/role` — requires `users:role:write`.
- `GET /api/auth/me` — now includes the current role.

Legacy business routes are not globally locked in this phase. They remain compatibility-preserving while route-by-route authorization is introduced intentionally in later production hardening work.

## Operator role assignment

```powershell
python scripts/set_user_role.py --email admin@example.com --role admin
```

## Validation

```powershell
python -m pytest -q tests_v2/test_phase24_3_authorization_rbac.py
python scripts/smoke_authorization_rbac_phase24_3.py
python -m compileall -q backend_v2 scripts
python -m pytest -q tests_v2
```
