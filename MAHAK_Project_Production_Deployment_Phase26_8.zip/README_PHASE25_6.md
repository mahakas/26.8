# Phase 25.6 — Multimodal Teacher Learning Loop

Phase 25.6 adds a deterministic closed-loop learning controller above the existing multimodal teacher pipeline.

## Loop inputs

The controller combines persisted signals from:

- Phase 25.5 teacher feedback (`needs_support`, `progressing`, `neutral`)
- Phase 21 student progress, confidence, and active weak areas
- Phase 22 quiz/practice attempt history and score trend
- optional Phase 22 learning-plan analytics when `learning_plan_id` is supplied
- the strategy selected for the current interaction

## Loop outputs

`TeacherLearningLoopState` exposes:

- `learning_outcome`
- `latest_score`, `recent_average_score`, `score_trend`
- `average_confidence`
- `active_weak_areas`
- `feedback_signal`
- `recommended_mode`
- `recommended_difficulty`
- `next_action`
- deterministic `reasons` and source attribution

The controller is policy-only. It never creates, removes, or modifies RAG evidence or citations.

## Integration

`MultimodalTeacherService` now evaluates the loop before the final adaptive teaching strategy. The final strategy remains backward compatible: explicit teaching modes still override automatic adaptation.

`POST /api/teacher/ask` accepts an optional `learning_plan_id` and returns `learning_loop` alongside `teaching_strategy`.

A read-only endpoint is also available:

`GET /api/teacher/learning-loop?conversation_id=<id>&learning_plan_id=<optional>`

## Deterministic policy

- `needs_support` / `at_risk` → remediation + foundational difficulty
- `ready_to_advance` → independent practice + advanced difficulty
- `progressing` → guided practice or reinforcement depending on confidence/weak areas
- `stable` → continue with existing adaptive policy

No new database table or migration is required.

## Validation

Targeted tests:

```powershell
python -m pytest -q tests_v2/test_phase25_6_teacher_learning_loop.py tests_v2/test_phase25_5_teacher_feedback_adaptation.py tests_v2/test_phase25_4_teacher_modes_adaptive_strategy.py
```

Compile:

```powershell
python -m compileall -q backend_v2 scripts
```

Smoke:

```powershell
python scripts/smoke_teacher_learning_loop_phase25_6.py
```
