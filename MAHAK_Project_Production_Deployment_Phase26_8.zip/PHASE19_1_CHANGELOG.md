# Phase19.1

- Added frame references to video transcript chunks.
- Extended citation builder to preserve float timestamps and frame metadata.
- Video citations can now expose frame_path and frame_timestamp_seconds.

## Phase 20.9 — Unified Agent Pipeline

- Added `UnifiedAgentPipeline` for Router -> Specialist Agent -> TeacherAgent execution.
- Preserved `AgentResult`, evidence, citations, and confidence.
- Added unified pipeline tests, smoke test, and documentation.
