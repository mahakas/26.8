# Phase 21.33 — Retention Run History Policy Execution

This phase connects the persisted Phase 21.32 run-history retention policy to the existing explicit `MemoryRetentionRunHistoryService`.

## New service methods

- `MemoryRetentionRunHistoryService.preview_policy()`
- `MemoryRetentionRunHistoryService.apply_policy()`

The methods use the effective system policy (`retention_days` / `max_delete`) and do not add a new public mutation API.

`preview_policy()` is read-only. `apply_policy()` explicitly deletes expired run-history parent rows and dependent result rows within the existing transaction semantics.

If the policy has not been configured, Phase 21.32 defaults are used (`365` days / `500` records).


## Smoke test robustness

The phase smoke test generates a unique `run_id` for each invocation so it can be rerun safely against a persistent SQLite database without triggering the unique constraint on `memory_retention_runs.run_id`.


The smoke test also uses an isolated in-memory SQLite database for deterministic reruns and never touches the project's persistent `mahak_v2.db`.
