# MAHAK AI — Phase 21.9: Memory Export & Data Portability

Phase 21.9 adds a read-only, user-scoped memory snapshot endpoint.

## API

`GET /api/memory/{user_id}/export`

Query:

- `limit`: number of memory records included in the snapshot (`1..500`, default `500`)

Response contains:

- `format_version`
- `exported_at`
- `user_id`
- `count`
- `records`
- `progress` (derived from the same exported record window)

## Guarantees

- Export is strictly scoped to the requested `user_id`.
- Export performs no mutation.
- The progress snapshot is derived from the same record window returned in the export, avoiding a hidden second dataset.
- Existing memory read/management endpoints and AgentResult contracts remain unchanged.

## Validation

```text
Focused tests: 4 passed
Smoke: runtime/export/read-only OK
Full suite: 157 passed, 3 skipped (baseline environment)
Compile: python -m compileall -q backend_v2 scripts
```
