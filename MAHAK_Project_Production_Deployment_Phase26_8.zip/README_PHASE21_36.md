# MAHAK Phase 21.36 — Persistent Maintenance Lease

Phase 21.36 adds an optional database-backed lease for `MemoryRetentionMaintenanceService`.

## Scope

- Existing `run_with_report()` contract is unchanged.
- New `run_with_persistent_guard()` is opt-in and backward-compatible.
- Lease is shared through the configured SQL database, so separate processes can coordinate.
- Lease has a configurable TTL (default 900 seconds, maximum 3600 seconds).
- Expired leases are reclaimable.
- A failed maintenance run releases the lease in a `finally` path.
- Disabled maintenance does not acquire a lease.
- The feature does not start background scheduling.

## API

```python
service.run_with_persistent_guard(
    user_ids=None,
    now=None,
    dry_run=False,
    cleanup_history=True,
    lease_ttl_seconds=900,
)
```

The existing `run_with_report()` method remains the default path.

## Deployment note

The persistent guard requires a shared persistent database. SQLite in-memory databases are suitable for tests but do not provide cross-process coordination outside the same process.
