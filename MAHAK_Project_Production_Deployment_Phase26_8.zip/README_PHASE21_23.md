# Phase 21.23 — Memory Retention Preview Binding

Adds an optional consistency guard between retention policy preview and apply.

## Endpoints

- `POST /api/memory/{user_id}/retention/policy/preview`
- `POST /api/memory/{user_id}/retention/policy/apply?preview_token=...`

The preview response now includes an opaque `preview_token`. The token binds the
user, effective retention policy, exact preview cutoff, candidate count, and the
candidate IDs within the configured delete cap.

When `preview_token` is supplied to `apply`:

- the token is validated,
- the current policy must match the preview policy,
- the current candidate state must match the preview state,
- the original preview cutoff is reused for the apply operation.

A changed policy or memory state returns `409` and performs no deletion. An invalid
or malformed token returns `422`.

Submitting `apply` without a token remains fully backward-compatible with Phase 21.22.

The token is a consistency guard, not an authentication credential.

Smoke test:
`PHASE21_23_LIVE=1 python scripts/smoke_memory_retention_preview_binding_phase21_23.py`
