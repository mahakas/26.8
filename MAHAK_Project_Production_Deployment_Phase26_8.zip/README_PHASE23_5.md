# MAHAK Phase 23.5 — Hallucination / Groundedness Evaluation

Phase 23.5 adds a deterministic, lexical-only groundedness evaluator on top of the Phase 23.1–23.4 evaluation stack.

## New API

- `POST /api/evaluation/groundedness`
- `POST /api/evaluation/groundedness/batch`

## Metrics

- `groundedness_score`
- `average_claim_support`
- `unsupported_claim_rate`
- `hallucination_risk`
- `supported_claim_count`
- `unsupported_claim_count`
- `groundedness_band`

Each answer is split into claims. Every claim is scored against its best single evidence item using token F1. A claim is supported when its score reaches the configured `claim_support_threshold` (default `0.55`).

## Scope and limitation

This is a deterministic lexical heuristic. `semantic_verification_available` is always `false` in Phase 23.5 because no NLI model, LLM judge, or external fact checker is invoked. The metric is intended for regression/evaluation signals and must not be treated as semantic truth verification.

## Determinism

The evaluator and batch evaluator are side-effect free. Repeating an identical request produces an identical structured result.

## Final validation

- Full regression: `511 passed, 3 skipped`
- Phase-specific tests: `10 passed`
- Smoke: `scripts/smoke_education_evaluation_groundedness_phase23_5.py` — OK
- Compile: `python -m compileall -q backend_v2 scripts` — OK
- ZIP integrity: verified with `unzip -tq`
