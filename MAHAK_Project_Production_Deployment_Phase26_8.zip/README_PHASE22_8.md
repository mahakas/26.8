# MAHAK Phase 22.8 — Learning Outcome Evaluation & Recommendation Feedback Loop

Phase 22.8 closes the loop between Phase 22.7 learning-plan outcome analytics and the next adaptive educational recommendation. The implementation is additive and keeps the existing `POST /api/education/recommendations/next` contract unchanged.

## API

`POST /api/education/recommendations/feedback`

Request fields:

- `user_id`
- `learning_plan_id`
- `task_type`
- `question_count`
- optional `topic`, `grade_id`, `subject_id`, `course_id`

The endpoint reads the existing learning-plan analytics, classifies the outcome, and feeds that outcome into the next recommendation. It is read-only with respect to learning-plan state.

## Feedback actions

- `completed` -> `advance` -> advancement recommendation
- `at_risk` -> `remediate` -> targeted remediation recommendation
- `on_track` with no attempts -> `continue`
- `on_track` with attempts -> `reinforce`
- `blocked` -> `stop` and request a new learning plan rather than continuing a blocked plan

The generated recommendation carries loop metadata in `generation_request`, including `feedback_action`, `learning_plan_outcome`, `mastery_gap`, and `completion_percent`.

## Compatibility fix

The Phase 22.7 analytics completion percentage is now bounded to 100%. This prevents remediation sessions from producing values above 100% when `completed_sessions` includes remediation executions beyond the plan's nominal session count.

## Tests

Specific test file:

`tests_v2/test_phase22_8_learning_outcome_feedback.py`

Specific smoke script:

`scripts/smoke_education_learning_outcome_feedback_phase22_8.py`

Smoke command:

```powershell
$env:PHASE22_8_LIVE="1"
python scripts/smoke_education_learning_outcome_feedback_phase22_8.py
```

Compile command:

```powershell
python -m compileall -q backend_v2 scripts
```

## Expected smoke output

```text
learning outcome feedback: OK
outcome: completed
feedback_action: advance
recommendation_type: advancement
difficulty: hard
completion: 100.0%
mastery_gap: 0.0
read_only_repeat: True
```
