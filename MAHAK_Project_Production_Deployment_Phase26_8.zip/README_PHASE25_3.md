# Phase 25.3 — Cross-Modal Reasoning & Evidence Fusion

Adds deterministic cross-modal evidence fusion to the Multimodal Teacher pipeline.

## Scope

- Deduplicate evidence and citations across specialist agents.
- Preserve original evidence/citation payloads without inventing sources.
- Detect lightweight cross-modal corroboration using shared lexical terms.
- Compute evidence coverage, corroboration, and bounded fused confidence.
- Pass the fusion report to `TeacherAgent` so the final educational pass can compare modalities.
- Expose the fusion report from `POST /api/teacher/ask`.

The lexical linker is intentionally deterministic and is not a semantic fact checker. A future embedding/LLM fusion implementation can replace it without changing the report contract.

## Validation

- Dedicated tests: `tests_v2/test_phase25_3_cross_modal_reasoning.py`
- Smoke: `scripts/smoke_cross_modal_reasoning_phase25_3.py`
- Compile: `python -m compileall -q backend_v2 scripts`
